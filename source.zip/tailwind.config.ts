import type { Config } from "tailwindcss";

export default {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: { DEFAULT: "#0b1530", soft: "#44506b", mute: "#7a8499" },
        navy: { DEFAULT: "#071b45", 600: "#0c2a66", 50: "#eef2fa" },
        accent: { DEFAULT: "#0062dd", soft: "#e6f0ff" },
        cyan: { DEFAULT: "#00c8f0", soft: "#e0f8fe" },
      },
      fontFamily: { sans: ["var(--font-sans)", "system-ui", "sans-serif"] },
    },
  },
  plugins: [],
} satisfies Config;
