"use client";
// Seleção múltipla: caixas de seleção ligadas a um formulário (atributo form=…) + barra fixa com as ações em conjunto.
import { useEffect, useState } from "react";
import { SubmitButton } from "@/components/client";

export type BulkOp = { op: string; label: string; className?: string; confirm?: string; pendingText?: string };

function boxes(formId: string) {
  return Array.from(document.querySelectorAll<HTMLInputElement>(`input[type="checkbox"][form="${formId}"][name="ids"]`));
}

export function BulkCheckbox({ formId, id, label }: { formId: string; id: string; label?: string }) {
  return (
    <label className="inline-flex cursor-pointer items-center" title="Selecionar">
      <input
        type="checkbox"
        name="ids"
        value={id}
        form={formId}
        aria-label={label ?? "Selecionar"}
        className="h-5 w-5 cursor-pointer rounded border-slate-300 accent-[#0b1f4d]"
        onChange={() => document.dispatchEvent(new CustomEvent(`bulk:${formId}`))}
      />
    </label>
  );
}

export function BulkBar({ formId, action, ops, back, noun = ["item", "itens"], fem = false }: { formId: string; action: (f: FormData) => void | Promise<void>; ops: BulkOp[]; back: string; noun?: [string, string]; fem?: boolean }) {
  const [count, setCount] = useState(0);
  const [total, setTotal] = useState(0);
  useEffect(() => {
    const update = () => {
      const all = boxes(formId);
      setTotal(all.length);
      setCount(all.filter((b) => b.checked).length);
    };
    update();
    document.addEventListener(`bulk:${formId}`, update);
    return () => document.removeEventListener(`bulk:${formId}`, update);
  }, [formId]);

  const setAll = (v: boolean) => {
    boxes(formId).forEach((b) => (b.checked = v));
    document.dispatchEvent(new CustomEvent(`bulk:${formId}`));
  };

  return (
    <form id={formId} action={action} className={`sticky top-2 z-20 mb-4 flex flex-wrap items-center gap-2 rounded-xl border p-3 text-sm shadow-sm ${count ? "border-navy bg-white" : "border-slate-200 bg-white/90"}`}>
      <input type="hidden" name="back" value={back} />
      <span className="font-semibold">{count ? `${count} ${count > 1 ? noun[1] : noun[0]} selecionad${fem ? "a" : "o"}${count > 1 ? "s" : ""}` : "Marque as caixas para agir em conjunto"}</span>
      {total > 0 && (
        <button type="button" className="text-accent hover:underline" onClick={() => setAll(count < total)}>
          {count < total ? "Selecionar todos" : "Limpar seleção"}
        </button>
      )}
      {count > 0 && count < total && (
        <button type="button" className="text-ink-mute hover:underline" onClick={() => setAll(false)}>Limpar</button>
      )}
      <div className="ml-auto flex flex-wrap gap-2">
        {ops.map((o) =>
          count ? (
            <SubmitButton key={o.op} name="op" value={o.op} className={o.className ?? "btn-ghost btn-sm"} pendingText={o.pendingText ?? "Aguarde…"} confirm={o.confirm?.replace("{n}", String(count))}>
              {o.label}
            </SubmitButton>
          ) : (
            <button key={o.op} type="button" disabled className={`${o.className ?? "btn-ghost btn-sm"} cursor-not-allowed opacity-40`}>{o.label}</button>
          ),
        )}
      </div>
    </form>
  );
}
