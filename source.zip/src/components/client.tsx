"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useFormStatus } from "react-dom";
import { useRef } from "react";

export function SubmitButton({ children, className = "btn-primary", pendingText = "Processando…", confirm, name, value }: { children: React.ReactNode; className?: string; pendingText?: string; confirm?: string; name?: string; value?: string }) {
  const { pending } = useFormStatus();
  return (
    <button
      type="submit"
      name={name}
      value={value}
      className={className}
      disabled={pending}
      onClick={(e) => {
        if (confirm && !window.confirm(confirm)) {
          e.preventDefault();
          return;
        }
        // Garante que o valor do botão clicado chegue à ação do servidor mesmo em navegadores
        // que não enviam o botão "submitter" no FormData (ex.: vários botões no mesmo formulário).
        const form = e.currentTarget.form;
        if (form && name && value != null) {
          let hidden = form.querySelector<HTMLInputElement>(`input[type="hidden"][data-submitter="${name}"]`);
          if (!hidden) {
            hidden = document.createElement("input");
            hidden.type = "hidden";
            hidden.name = name;
            hidden.dataset.submitter = name;
            form.prepend(hidden);
          }
          hidden.value = value;
        }
      }}
    >
      {pending ? (
        <>
          <span className="h-3 w-3 animate-spin rounded-full border-2 border-current border-t-transparent" />
          {pendingText}
        </>
      ) : (
        children
      )}
    </button>
  );
}

type NavItem = { href: string; label: string; icon: keyof typeof ICONS; exact?: boolean };
const NAV: { group?: string; items: NavItem[] }[] = [
  { items: [{ href: "/central", label: "Central", icon: "home" }] },
  {
    group: "Conteúdo",
    items: [
      { href: "/dashboard", label: "Visão do conteúdo", icon: "chart" },
      { href: "/radar", label: "Radar de tendências", icon: "radar" },
      { href: "/studio/scripts", label: "Sala de roteiristas", icon: "pen" },
      { href: "/calendar", label: "Calendário editorial", icon: "calendar" },
      { href: "/studio/content", label: "AI Content Studio", icon: "spark" },
      { href: "/studio/creative", label: "AI Creative Studio", icon: "image" },
      { href: "/studio/video", label: "AI Video Studio", icon: "video" },
      { href: "/posts", label: "Publicações", icon: "list" },
      { href: "/media", label: "Biblioteca de mídia", icon: "folder" },
    ],
  },
  {
    group: "Tráfego pago",
    items: [
      { href: "/traffic", label: "Visão geral", icon: "trend", exact: true },
      { href: "/traffic/creatives", label: "Campanhas e criativos", icon: "grid" },
      { href: "/traffic/ai", label: "IA gestora de tráfego", icon: "brain" },
    ],
  },
  {
    group: "Comercial e análise",
    items: [
      { href: "/offers", label: "Ofertas comerciais", icon: "tag" },
      { href: "/reports", label: "Relatórios", icon: "doc" },
      { href: "/notifications", label: "Alertas", icon: "bell" },
    ],
  },
  { items: [{ href: "/settings", label: "Configurações", icon: "gear" }] },
];

const ICONS = {
  home: "M3 11l9-7 9 7v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z",
  radar: "M12 3a9 9 0 1 0 9 9M12 7a5 5 0 1 0 5 5M12 12l6-6",
  pen: "M4 20h4L19 9l-4-4L4 16zM13 7l4 4",
  video: "M4 6h11v12H4zM15 10l5-3v10l-5-3z",
  chart: "M4 20V10m6 10V4m6 16v-7m4 7H2",
  calendar: "M4 6h16v14H4zM4 10h16M8 3v4m8-4v4",
  spark: "M12 3l2.2 5.8L20 11l-5.8 2.2L12 19l-2.2-5.8L4 11l5.8-2.2z",
  image: "M4 5h16v14H4zM4 16l5-5 4 4 3-3 4 4M15 9h.01",
  list: "M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01",
  folder: "M3 7h6l2 2h10v10H3z",
  trend: "M3 17l6-6 4 4 8-8M15 7h6v6",
  grid: "M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z",
  brain: "M9 4a3 3 0 0 0-3 3 3 3 0 0 0-2 5 3 3 0 0 0 2 5 3 3 0 0 0 6 0V4zm6 0a3 3 0 0 1 3 3 3 3 0 0 1 2 5 3 3 0 0 1-2 5 3 3 0 0 1-6 0",
  tag: "M3 12V4h8l10 10-8 8zM7.5 7.5h.01",
  doc: "M6 3h9l4 4v14H6zM9 12h7M9 16h7",
  bell: "M6 16V11a6 6 0 0 1 12 0v5l2 2H4zM10 21h4",
  gear: "M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-2.8 1.2V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-2.8-1.2l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1A1.7 1.7 0 0 0 3.2 14H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.2-2.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1A1.7 1.7 0 0 0 10 3.2V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 2.8 1.2l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1A1.7 1.7 0 0 0 20.8 10H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z",
} as const;

function Icon({ name }: { name: keyof typeof ICONS }) {
  return (
    <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d={ICONS[name]} />
    </svg>
  );
}

export function NavLinks({ onNavigate, badges = {} }: { onNavigate?: () => void; badges?: Record<string, number> }) {
  const path = usePathname();
  return (
    <nav className="flex flex-col gap-4">
      {NAV.map((g, gi) => (
        <div key={gi} className="flex flex-col gap-0.5">
          {g.group && <div className="mb-1 px-3 text-[10px] font-bold uppercase tracking-[0.18em] text-cyan/80">{g.group}</div>}
          {g.items.map((n) => {
            const active = n.exact ? path === n.href : path === n.href || path.startsWith(n.href + "/");
            const badge = badges[n.href];
            return (
              <Link
                key={n.href}
                href={n.href}
                onClick={onNavigate}
                className={`flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm font-medium transition ${active ? "bg-white/15 text-white shadow-[inset_3px_0_0_#00c8f0]" : "text-white/70 hover:bg-white/10 hover:text-white"}`}
              >
                <Icon name={n.icon} />
                <span className="flex-1">{n.label}</span>
                {badge ? <span className="rounded-full bg-cyan px-1.5 text-[10px] font-bold text-navy">{badge}</span> : null}
              </Link>
            );
          })}
        </div>
      ))}
    </nav>
  );
}

export function AutoSubmitSelect({ name, defaultValue, options, className = "input" }: { name: string; defaultValue: string; options: { value: string; label: string }[]; className?: string }) {
  const ref = useRef<HTMLSelectElement>(null);
  return (
    <select ref={ref} name={name} defaultValue={defaultValue} className={className} onChange={() => ref.current?.form?.requestSubmit()}>
      {options.map((o) => (
        <option key={o.value} value={o.value}>
          {o.label}
        </option>
      ))}
    </select>
  );
}
