"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useFormStatus } from "react-dom";
import { useRef } from "react";

export function SubmitButton({ children, className = "btn-primary", pendingText = "Processando…", confirm, name, value }: { children: React.ReactNode; className?: string; pendingText?: string; confirm?: string; name?: string; value?: string }) {
  const { pending } = useFormStatus();
  return (
    <button
      type="submit"
      name={name}
      value={value}
      className={className}
      disabled={pending}
      onClick={(e) => {
        if (confirm && !window.confirm(confirm)) e.preventDefault();
      }}
    >
      {pending ? (
        <>
          <span className="h-3 w-3 animate-spin rounded-full border-2 border-current border-t-transparent" />
          {pendingText}
        </>
      ) : (
        children
      )}
    </button>
  );
}

const NAV = [
  { href: "/dashboard", label: "Dashboard" },
  { href: "/calendar", label: "Calendário editorial" },
  { href: "/studio/content", label: "AI Content Studio" },
  { href: "/studio/creative", label: "AI Creative Studio" },
  { href: "/posts", label: "Publicações" },
  { href: "/media", label: "Biblioteca de mídia" },
  { href: "/offers", label: "Ofertas comerciais" },
  { href: "/reports", label: "Relatórios" },
  { href: "/settings", label: "Configurações" },
];

export function NavLinks({ onNavigate }: { onNavigate?: () => void }) {
  const path = usePathname();
  return (
    <nav className="flex flex-col gap-0.5">
      {NAV.map((n) => {
        const active = path === n.href || path.startsWith(n.href + "/");
        return (
          <Link
            key={n.href}
            href={n.href}
            onClick={onNavigate}
            className={`rounded-lg px-3 py-2 text-sm font-medium transition ${active ? "bg-white/15 text-white" : "text-white/70 hover:bg-white/10 hover:text-white"}`}
          >
            {n.label}
          </Link>
        );
      })}
    </nav>
  );
}

export function AutoSubmitSelect({ name, defaultValue, options, className = "input" }: { name: string; defaultValue: string; options: { value: string; label: string }[]; className?: string }) {
  const ref = useRef<HTMLSelectElement>(null);
  return (
    <select ref={ref} name={name} defaultValue={defaultValue} className={className} onChange={() => ref.current?.form?.requestSubmit()}>
      {options.map((o) => (
        <option key={o.value} value={o.value}>
          {o.label}
        </option>
      ))}
    </select>
  );
}
