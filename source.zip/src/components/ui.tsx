import Link from "next/link";
import { STATUS_COLOR, STATUS_LABEL, PILLAR_COLOR, PILLAR_LABEL, FORMAT_LABEL } from "@/lib/labels";

export function PageHeader({ title, subtitle, actions }: { title: string; subtitle?: React.ReactNode; actions?: React.ReactNode }) {
  return (
    <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">{title}</h1>
        {subtitle && <p className="mt-1 text-sm text-ink-soft">{subtitle}</p>}
      </div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </div>
  );
}

export function Flash({ ok, error }: { ok?: string; error?: string }) {
  if (!ok && !error) return null;
  return (
    <div className={`mb-4 rounded-xl border p-3 text-sm ${error ? "border-red-200 bg-red-50 text-red-800" : "border-emerald-200 bg-emerald-50 text-emerald-800"}`} role="status">
      {error ?? ok}
    </div>
  );
}

export function StatusBadge({ status }: { status: string }) {
  return <span className={`badge ${STATUS_COLOR[status] ?? "bg-slate-100"}`}>{STATUS_LABEL[status] ?? status}</span>;
}

export function PillarBadge({ pillar }: { pillar: string }) {
  return <span className={`badge border ${PILLAR_COLOR[pillar] ?? ""}`}>{PILLAR_LABEL[pillar] ?? pillar}</span>;
}

export function FormatBadge({ format }: { format: string }) {
  return <span className="badge bg-slate-100 text-slate-700">{FORMAT_LABEL[format] ?? format}</span>;
}

export function Stat({ label, value, hint }: { label: string; value: React.ReactNode; hint?: React.ReactNode }) {
  return (
    <div className="card p-4">
      <div className="text-xs font-semibold uppercase tracking-wide text-ink-mute">{label}</div>
      <div className="mt-1 text-2xl font-bold">{value}</div>
      {hint && <div className="mt-1 text-xs text-ink-soft">{hint}</div>}
    </div>
  );
}

export function Empty({ title, children, action }: { title: string; children?: React.ReactNode; action?: React.ReactNode }) {
  return (
    <div className="card flex flex-col items-center justify-center p-10 text-center">
      <div className="text-base font-semibold">{title}</div>
      {children && <div className="mt-1 max-w-md text-sm text-ink-soft">{children}</div>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function Tabs({ items, current }: { items: { href: string; label: string; key: string }[]; current: string }) {
  return (
    <div className="mb-5 flex gap-1 overflow-x-auto border-b border-slate-200">
      {items.map((i) => (
        <Link
          key={i.key}
          href={i.href}
          className={`whitespace-nowrap border-b-2 px-3 py-2 text-sm font-semibold ${i.key === current ? "border-accent text-ink" : "border-transparent text-ink-mute hover:text-ink"}`}
        >
          {i.label}
        </Link>
      ))}
    </div>
  );
}

export function Field({ label, children, hint }: { label: string; children: React.ReactNode; hint?: React.ReactNode }) {
  return (
    <div>
      <label className="label">{label}</label>
      {children}
      {hint && <p className="mt-1 text-xs text-ink-mute">{hint}</p>}
    </div>
  );
}

/** Indicador honesto do estado de uma integração. */
export function IntegrationState({ state }: { state: "ok" | "test" | "pending" | "missing" | "error" }) {
  const map = {
    ok: ["bg-emerald-100 text-emerald-800", "Funcionando"],
    test: ["bg-blue-100 text-blue-800", "Em teste"],
    pending: ["bg-amber-100 text-amber-900", "Depende de aprovação externa"],
    missing: ["bg-slate-200 text-slate-700", "Não configurado"],
    error: ["bg-red-100 text-red-800", "Com erro"],
  } as const;
  const [cls, label] = map[state];
  return <span className={`badge ${cls}`}>{label}</span>;
}
