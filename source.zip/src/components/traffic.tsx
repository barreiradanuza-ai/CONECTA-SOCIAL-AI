// Componentes visuais do módulo de tráfego e da Central (renderizados no servidor).
import Link from "next/link";
import { Tabs } from "@/components/ui";
import { int, pct } from "@/lib/format";

export function TrafficTabs({ current }: { current: "overview" | "creatives" | "ai" | "settings" }) {
  return (
    <Tabs
      current={current}
      items={[
        { key: "overview", href: "/traffic", label: "Visão geral" },
        { key: "creatives", href: "/traffic/creatives", label: "Campanhas e criativos" },
        { key: "ai", href: "/traffic/ai", label: "IA gestora de tráfego" },
        { key: "settings", href: "/traffic/settings", label: "Configuração" },
      ]}
    />
  );
}

/** KPI com variação vs. período anterior. `goodWhen` define se subir é bom ou ruim. */
export function Kpi({ label, value, hint, change, goodWhen = "up", tone = "default" }: { label: string; value: React.ReactNode; hint?: React.ReactNode; change?: number | null; goodWhen?: "up" | "down"; tone?: "default" | "navy" }) {
  const good = change == null ? null : goodWhen === "up" ? change >= 0 : change <= 0;
  const navy = tone === "navy";
  return (
    <div className={`rounded-2xl border p-4 shadow-sm ${navy ? "border-navy bg-navy text-white" : "border-slate-200 bg-white"}`}>
      <div className={`text-[11px] font-semibold uppercase tracking-wide ${navy ? "text-cyan" : "text-ink-mute"}`}>{label}</div>
      <div className="mt-1 text-2xl font-bold tabular-nums">{value}</div>
      <div className="mt-1 flex flex-wrap items-center gap-2 text-xs">
        {change != null && (
          <span className={`badge ${good ? "bg-emerald-100 text-emerald-800" : "bg-red-100 text-red-800"}`}>
            {change >= 0 ? "▲" : "▼"} {Math.abs(change).toLocaleString("pt-BR", { maximumFractionDigits: 0 })}%
          </span>
        )}
        {hint && <span className={navy ? "text-white/70" : "text-ink-soft"}>{hint}</span>}
      </div>
    </div>
  );
}

export function Section({ title, subtitle, action, children, className = "" }: { title: string; subtitle?: React.ReactNode; action?: React.ReactNode; children: React.ReactNode; className?: string }) {
  return (
    <section className={`card p-5 ${className}`}>
      <div className="mb-4 flex flex-wrap items-start justify-between gap-2">
        <div>
          <h2 className="font-semibold">{title}</h2>
          {subtitle && <p className="text-xs text-ink-mute">{subtitle}</p>}
        </div>
        {action}
      </div>
      {children}
    </section>
  );
}

/** Funil completo. Etapas sem fonte de dados aparecem como "sem dados" (nunca estimadas). */
export function Funnel({ steps }: { steps: { label: string; value: number | null; note?: string }[] }) {
  const max = Math.max(1, ...steps.map((s) => s.value ?? 0));
  return (
    <ol className="space-y-2">
      {steps.map((s, i) => {
        const prev = i > 0 ? steps[i - 1].value : null;
        const rate = s.value != null && prev ? (s.value / prev) * 100 : null;
        const w = s.value != null ? Math.max(4, (s.value / max) * 100) : 0;
        return (
          <li key={s.label} className="grid grid-cols-[110px_1fr_auto] items-center gap-3 text-sm">
            <span className="font-medium text-ink-soft">{s.label}</span>
            <div className="h-7 overflow-hidden rounded-lg bg-slate-100">
              {s.value != null ? (
                <div className="flex h-full items-center rounded-lg bg-gradient-to-r from-navy to-accent px-2 text-xs font-semibold text-white" style={{ width: `${w}%` }}>
                  {int(s.value)}
                </div>
              ) : (
                <div className="flex h-full items-center px-2 text-xs text-ink-mute">{s.note ?? "sem dados"}</div>
              )}
            </div>
            <span className="w-16 text-right text-xs text-ink-mute">{rate != null ? pct(rate, 1) : ""}</span>
          </li>
        );
      })}
    </ol>
  );
}

export function LevelBadge({ level }: { level: string }) {
  const map: Record<string, [string, string]> = {
    AUTO: ["bg-emerald-100 text-emerald-800", "AUTO"],
    APPROVAL: ["bg-amber-100 text-amber-900", "PRECISA DE APROVAÇÃO"],
    BLOCKED: ["bg-slate-200 text-slate-700", "BLOQUEADA"],
  };
  const [cls, label] = map[level] ?? ["bg-slate-100", level];
  return <span className={`badge ${cls}`}>{label}</span>;
}

export function RecStatusBadge({ status }: { status: string }) {
  const map: Record<string, [string, string]> = {
    PENDING: ["bg-blue-100 text-blue-800", "Pendente"],
    APPROVED: ["bg-blue-100 text-blue-800", "Aprovada"],
    EXECUTED: ["bg-emerald-100 text-emerald-800", "Executada"],
    REJECTED: ["bg-slate-200 text-slate-700", "Rejeitada"],
    FAILED: ["bg-red-100 text-red-800", "Falhou"],
    SUPERSEDED: ["bg-slate-100 text-slate-500", "Substituída"],
  };
  const [cls, label] = map[status] ?? ["bg-slate-100", status];
  return <span className={`badge ${cls}`}>{label}</span>;
}

export function AdStatus({ status }: { status: string }) {
  const map: Record<string, [string, string]> = {
    ACTIVE: ["bg-emerald-100 text-emerald-800", "Ativo"],
    PAUSED: ["bg-slate-200 text-slate-700", "Pausado"],
    CAMPAIGN_PAUSED: ["bg-slate-200 text-slate-700", "Campanha pausada"],
    ADSET_PAUSED: ["bg-slate-200 text-slate-700", "Conjunto pausado"],
    PENDING_REVIEW: ["bg-amber-100 text-amber-900", "Em análise"],
    IN_PROCESS: ["bg-amber-100 text-amber-900", "Processando"],
    DISAPPROVED: ["bg-red-100 text-red-800", "Reprovado"],
    WITH_ISSUES: ["bg-red-100 text-red-800", "Com problemas"],
  };
  const [cls, label] = map[status] ?? ["bg-slate-100 text-slate-700", status];
  return <span className={`badge ${cls}`}>{label}</span>;
}

/** Barras diárias com duas séries (ex.: gasto e conversas), escala independente. */
export function DualBars({ data, a, b }: { data: { label: string; a: number; b: number }[]; a: { name: string; fmt: (v: number) => string }; b: { name: string; fmt: (v: number) => string } }) {
  const maxA = Math.max(1, ...data.map((d) => d.a));
  const maxB = Math.max(1, ...data.map((d) => d.b));
  return (
    <div>
      <div className="mb-2 flex gap-4 text-xs text-ink-soft">
        <span className="flex items-center gap-1"><i className="inline-block h-2.5 w-2.5 rounded-sm bg-navy" /> {a.name}</span>
        <span className="flex items-center gap-1"><i className="inline-block h-2.5 w-2.5 rounded-sm bg-cyan" /> {b.name}</span>
      </div>
      <div className="flex h-44 items-end gap-1">
        {data.map((d) => (
          <div key={d.label} className="group relative flex h-full flex-1 items-end justify-center gap-[2px]">
            <div className="w-1/2 rounded-t bg-navy" style={{ height: `${(d.a / maxA) * 100}%` }} />
            <div className="w-1/2 rounded-t bg-cyan" style={{ height: `${(d.b / maxB) * 100}%` }} />
            <div className="pointer-events-none absolute bottom-full z-10 mb-1 hidden whitespace-nowrap rounded-lg bg-ink px-2 py-1 text-[11px] text-white group-hover:block">
              {d.label}: {a.fmt(d.a)} · {b.fmt(d.b)}
            </div>
          </div>
        ))}
      </div>
      <div className="mt-1 flex justify-between text-[10px] text-ink-mute">
        <span>{data[0]?.label}</span>
        <span>{data[data.length - 1]?.label}</span>
      </div>
    </div>
  );
}

export function EmptyTraffic({ reason }: { reason: "no-account" | "no-token" | "no-data" | "error"; detail?: string }) {
  const text = {
    "no-account": "Nenhuma conta de anúncio configurada para esta marca.",
    "no-token": "Falta o token do Meta Ads.",
    "no-data": "Aguardando a primeira sincronização com o Meta Ads (a cada 15 minutos).",
    error: "A última sincronização falhou.",
  }[reason];
  return (
    <div className="card flex flex-col items-center p-10 text-center">
      <div className="font-semibold">{text}</div>
      <p className="mt-1 max-w-md text-sm text-ink-soft">Configure a conta de anúncio e o token em Tráfego → Configuração e em Configurações → Integrações e chaves.</p>
      <Link href="/traffic/settings" className="btn-primary mt-4">Configurar tráfego</Link>
    </div>
  );
}
