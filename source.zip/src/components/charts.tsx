// Gráficos SVG simples renderizados no servidor (sem dependências).

export function BarChart({ data, height = 180, valueLabel }: { data: { label: string; value: number; sub?: string }[]; height?: number; valueLabel?: (v: number) => string }) {
  const max = Math.max(1, ...data.map((d) => d.value));
  const w = 100 / Math.max(1, data.length);
  const fmt = valueLabel ?? ((v: number) => v.toLocaleString("pt-BR"));
  return (
    <div>
      <svg viewBox={`0 0 100 ${height / 3}`} preserveAspectRatio="none" className="w-full" style={{ height }} role="img">
        {[0.25, 0.5, 0.75].map((g) => (
          <line key={g} x1="0" x2="100" y1={(height / 3) * g} y2={(height / 3) * g} stroke="#e2e8f0" strokeWidth="0.2" />
        ))}
        {data.map((d, i) => {
          const h = (d.value / max) * (height / 3 - 2);
          return (
            <rect key={d.label + i} x={i * w + w * 0.18} y={height / 3 - h} width={w * 0.64} height={h} rx="0.6" fill="#1f7bff">
              <title>{`${d.label}: ${fmt(d.value)}`}</title>
            </rect>
          );
        })}
      </svg>
      <div className="mt-1 grid text-center text-[10px] text-ink-mute" style={{ gridTemplateColumns: `repeat(${data.length}, minmax(0, 1fr))` }}>
        {data.map((d, i) => (
          <div key={d.label + i} className="truncate" title={d.label}>
            <div className="font-semibold text-ink">{fmt(d.value)}</div>
            {d.label}
          </div>
        ))}
      </div>
    </div>
  );
}

export function LineChart({ points, height = 160 }: { points: { label: string; value: number | null }[]; height?: number }) {
  const vals = points.map((p) => p.value).filter((v): v is number => v != null);
  if (vals.length < 2) return <p className="text-sm text-ink-soft">Dados insuficientes para o gráfico.</p>;
  const min = Math.min(...vals);
  const max = Math.max(...vals);
  const span = max - min || 1;
  const H = 50;
  const coords = points
    .map((p, i) => (p.value == null ? null : `${(i / Math.max(1, points.length - 1)) * 100},${H - 3 - ((p.value - min) / span) * (H - 6)}`))
    .filter(Boolean)
    .join(" ");
  return (
    <div>
      <svg viewBox={`0 0 100 ${H}`} preserveAspectRatio="none" className="w-full" style={{ height }}>
        <polyline points={coords} fill="none" stroke="#1f7bff" strokeWidth="0.8" vectorEffect="non-scaling-stroke" />
      </svg>
      <div className="flex justify-between text-[10px] text-ink-mute">
        <span>{points[0].label}: {points[0].value?.toLocaleString("pt-BR") ?? "—"}</span>
        <span>{points[points.length - 1].label}: {points[points.length - 1].value?.toLocaleString("pt-BR") ?? "—"}</span>
      </div>
    </div>
  );
}
