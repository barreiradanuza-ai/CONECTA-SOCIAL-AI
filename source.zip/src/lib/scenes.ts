/** Divide um roteiro de Reels em partes (cenas) para edição individual. */
export function splitScenes(script: string | null | undefined): string[] {
  const text = (script ?? "").replace(/\r\n/g, "\n").trim();
  if (!text) return [];
  // Roteiros em blocos separados por linha em branco (CENA 1 … / TEXTO FINAL …)
  if (/\n\s*\n/.test(text)) {
    return text
      .split(/\n\s*\n+/)
      .map((s) => s.trim())
      .filter(Boolean);
  }
  // Roteiros da Sala de roteiristas: uma cena por linha ("1. [ato] …")
  return text
    .split("\n")
    .map((s) => s.trim())
    .filter(Boolean);
}

export function joinScenes(scenes: string[]): string {
  return scenes
    .map((s) => s.replace(/\r\n/g, "\n").trim())
    .filter(Boolean)
    .join("\n\n");
}

/** Lê as cenas enviadas pelo formulário (campos scene_0, scene_1, …). */
export function scenesFromForm(form: FormData): string[] {
  const out: { i: number; v: string }[] = [];
  for (const [k, v] of form.entries()) {
    const m = /^scene_(\d+)$/.exec(k);
    if (m && typeof v === "string") out.push({ i: Number(m[1]), v });
  }
  return out.sort((a, b) => a.i - b.i).map((x) => x.v);
}
