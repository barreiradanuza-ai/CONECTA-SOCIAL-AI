// Rótulos em português para enums (compartilhado entre servidor e cliente).
export const PILLAR_LABEL: Record<string, string> = {
  EDUCATION: "Educação e informação",
  ENGAGEMENT: "Engajamento e interação",
  AUTHORITY: "Autoridade e confiança",
  OFFERS: "Ofertas e oportunidades",
  INSTITUTIONAL: "Institucional",
  SEASONAL: "Sazonal e tendências",
  STORYTELLING: "Universo do personagem",
};

export const PILLAR_COLOR: Record<string, string> = {
  EDUCATION: "bg-sky-100 text-sky-800 border-sky-200",
  ENGAGEMENT: "bg-violet-100 text-violet-800 border-violet-200",
  AUTHORITY: "bg-indigo-100 text-indigo-800 border-indigo-200",
  OFFERS: "bg-amber-100 text-amber-900 border-amber-200",
  INSTITUTIONAL: "bg-slate-100 text-slate-800 border-slate-200",
  SEASONAL: "bg-emerald-100 text-emerald-800 border-emerald-200",
  STORYTELLING: "bg-fuchsia-100 text-fuchsia-800 border-fuchsia-200",
};

export const FORMAT_LABEL: Record<string, string> = {
  FEED_IMAGE: "Feed (imagem)",
  CAROUSEL: "Carrossel",
  STORY: "Story",
  REEL: "Reels",
};

export const STATUS_LABEL: Record<string, string> = {
  PLANNED: "Planejada",
  GENERATING: "Gerando",
  DRAFT: "Rascunho",
  PENDING_APPROVAL: "Aguardando aprovação",
  APPROVED: "Aprovada",
  SCHEDULED: "Agendada",
  PUBLISHING: "Publicando",
  PUBLISHED: "Publicada",
  PARTIALLY_PUBLISHED: "Publicada parcialmente",
  FAILED: "Com erro",
  CANCELED: "Cancelada",
};

export const STATUS_COLOR: Record<string, string> = {
  PLANNED: "bg-slate-100 text-slate-700",
  GENERATING: "bg-blue-50 text-blue-700",
  DRAFT: "bg-slate-200 text-slate-800",
  PENDING_APPROVAL: "bg-amber-100 text-amber-900",
  APPROVED: "bg-teal-100 text-teal-800",
  SCHEDULED: "bg-blue-100 text-blue-800",
  PUBLISHING: "bg-blue-200 text-blue-900",
  PUBLISHED: "bg-emerald-100 text-emerald-800",
  PARTIALLY_PUBLISHED: "bg-orange-100 text-orange-800",
  FAILED: "bg-red-100 text-red-800",
  CANCELED: "bg-slate-100 text-slate-500 line-through",
};

export const TARGET_STATUS_LABEL: Record<string, string> = {
  PENDING: "Pendente",
  QUEUED: "Na fila",
  PUBLISHING: "Publicando",
  PUBLISHED: "Publicado",
  FAILED: "Falhou",
  CANCELED: "Cancelado",
  SKIPPED: "Ignorado",
};

export const NETWORK_LABEL: Record<string, string> = { FACEBOOK: "Facebook", INSTAGRAM: "Instagram" };

export const PILLARS = ["STORYTELLING", "EDUCATION", "ENGAGEMENT", "AUTHORITY", "OFFERS", "INSTITUTIONAL", "SEASONAL"] as const;
export const FORMATS = ["FEED_IMAGE", "CAROUSEL", "STORY", "REEL"] as const;
