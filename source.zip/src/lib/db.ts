import { PrismaClient } from "@prisma/client";
import { fixDeep } from "@/lib/spelling";

const g = globalThis as unknown as { __prisma?: PrismaClient };

function create(): PrismaClient {
  const base = new PrismaClient({
    log: process.env.NODE_ENV === "development" ? ["warn", "error"] : ["error"],
  });
  // Todo texto gravado passa pela grafia correta (ex.: "Uái-Fái" → "Wi-Fi"); a voz pronuncia em inglês à parte.
  return base.$extends({
    query: {
      $allModels: {
        async create({ args, query }) {
          if ((args as any).data) (args as any).data = fixDeep((args as any).data);
          return query(args);
        },
        async createMany({ args, query }) {
          if ((args as any).data) (args as any).data = fixDeep((args as any).data);
          return query(args);
        },
        async update({ args, query }) {
          if ((args as any).data) (args as any).data = fixDeep((args as any).data);
          return query(args);
        },
        async updateMany({ args, query }) {
          if ((args as any).data) (args as any).data = fixDeep((args as any).data);
          return query(args);
        },
        async upsert({ args, query }) {
          const a = args as any;
          if (a.create) a.create = fixDeep(a.create);
          if (a.update) a.update = fixDeep(a.update);
          return query(args);
        },
      },
    },
  }) as unknown as PrismaClient;
}

export const db: PrismaClient = g.__prisma ?? create();

if (process.env.NODE_ENV !== "production") g.__prisma = db;
