// Acesso centralizado às variáveis de ambiente (somente servidor).
// Nenhuma chave é exposta ao frontend: não usamos NEXT_PUBLIC_* para segredos.

function opt(name: string, fallback?: string): string | undefined {
  const v = process.env[name];
  return v && v.trim() !== "" ? v.trim() : fallback;
}

export const env = {
  get appUrl() {
    const raw =
      opt("APP_URL") ??
      (process.env.RAILWAY_PUBLIC_DOMAIN ? `https://${process.env.RAILWAY_PUBLIC_DOMAIN}` : undefined) ??
      "http://localhost:3000";
    return raw.replace(/\/$/, "");
  },
  get sessionSecret() {
    const v = opt("SESSION_SECRET");
    if (!v || v.length < 32) {
      if (process.env.NODE_ENV === "production") throw new Error("SESSION_SECRET ausente ou curto (mín. 32 caracteres).");
      return "dev-only-session-secret-change-me-please-0123456789";
    }
    return v;
  },
  get encryptionKey() {
    // 32 bytes em base64 ou hex
    const v = opt("ENCRYPTION_KEY");
    if (!v) {
      if (process.env.NODE_ENV === "production") throw new Error("ENCRYPTION_KEY ausente.");
      return "ZGV2LW9ubHkta2V5LWRldi1vbmx5LWtleS0xMjM0NTY="; // apenas desenvolvimento
    }
    return v;
  },
  get setupToken() {
    return opt("SETUP_TOKEN");
  },
  meta: {
    get appId() {
      return opt("META_APP_ID");
    },
    get appSecret() {
      return opt("META_APP_SECRET");
    },
    get graphVersion() {
      return opt("META_GRAPH_VERSION", "v25.0")!;
    },
    get loginConfigId() {
      return opt("META_LOGIN_CONFIG_ID");
    },
  },
  ai: {
    get anthropicModel() {
      return opt("ANTHROPIC_MODEL", "claude-sonnet-5")!;
    },
    get openaiImageModel() {
      return opt("OPENAI_IMAGE_MODEL", "gpt-image-2")!;
    },
    get openaiImageQuality() {
      return opt("OPENAI_IMAGE_QUALITY", "medium")!;
    },
  },
  storage: {
    get bucket() {
      return opt("S3_BUCKET") ?? opt("BUCKET");
    },
    get endpoint() {
      return opt("S3_ENDPOINT") ?? opt("ENDPOINT");
    },
    get region() {
      return opt("S3_REGION") ?? opt("REGION") ?? "auto";
    },
    get accessKeyId() {
      return opt("S3_ACCESS_KEY_ID") ?? opt("ACCESS_KEY_ID");
    },
    get secretAccessKey() {
      return opt("S3_SECRET_ACCESS_KEY") ?? opt("SECRET_ACCESS_KEY");
    },
    get localDir() {
      return opt("STORAGE_DIR", "./storage")!;
    },
  },
  get resendApiKey() {
    return opt("RESEND_API_KEY");
  },
  get emailFrom() {
    return opt("EMAIL_FROM", "Conecta Social AI <alertas@example.com>")!;
  },
  get retentionDays() {
    return Number(opt("DATA_RETENTION_DAYS", "365"));
  },
};
