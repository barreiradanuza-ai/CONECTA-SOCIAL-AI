import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";

function isNextControlFlow(e: unknown) {
  const d = (e as { digest?: unknown })?.digest;
  return typeof d === "string" && (d.startsWith("NEXT_REDIRECT") || d.startsWith("NEXT_NOT_FOUND") || d.startsWith("NEXT_HTTP_ERROR"));
}

function withParam(path: string, key: string, value: string) {
  const [base, qs] = path.split("?");
  const p = new URLSearchParams(qs);
  p.delete("ok");
  p.delete("error");
  p.set(key, value);
  return `${base}?${p.toString()}`;
}

/**
 * Executa uma ação de formulário e volta para `back` com mensagem de sucesso ou erro legível.
 * `fn` pode retornar { message, redirectTo } para personalizar.
 */
export async function runAction(back: string, fn: () => Promise<string | { message?: string; redirectTo?: string } | void>): Promise<never> {
  let result: Awaited<ReturnType<typeof fn>>;
  try {
    result = await fn();
  } catch (e) {
    if (isNextControlFlow(e)) throw e;
    console.error("[action]", e);
    const msg = e instanceof Error ? e.message : "Erro inesperado.";
    redirect(withParam(back, "error", msg.slice(0, 400)));
  }
  revalidatePath("/", "layout");
  const message = typeof result === "string" ? result : result?.message ?? "Alterações salvas.";
  const to = typeof result === "object" && result?.redirectTo ? result.redirectTo : back;
  redirect(withParam(to, "ok", message));
}

export function str(form: FormData, key: string) {
  const v = form.get(key);
  return typeof v === "string" ? v.trim() : "";
}

export function lines(form: FormData, key: string) {
  return str(form, key)
    .split(/\r?\n|,/)
    .map((s) => s.trim())
    .filter(Boolean);
}

export function int(form: FormData, key: string, def: number, min = 0, max = 1000) {
  const n = Number.parseInt(str(form, key), 10);
  if (Number.isNaN(n)) return def;
  return Math.min(max, Math.max(min, n));
}
