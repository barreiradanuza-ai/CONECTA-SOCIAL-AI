import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import type { Role } from "@prisma/client";
import { db } from "./db";
import { env } from "./env";
import { SESSION_COOKIE, SESSION_TTL_SECONDS, signSession, verifySession } from "./session-token";

export const BRAND_COOKIE = "csai_brand";

const ROLE_RANK: Record<Role, number> = { VIEWER: 0, EDITOR: 1, ADMIN: 2, OWNER: 3 };

export async function createSession(userId: string, orgId: string) {
  const token = await signSession({ uid: userId, oid: orgId }, env.sessionSecret);
  const jar = await cookies();
  jar.set(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: SESSION_TTL_SECONDS,
  });
}

export async function destroySession() {
  const jar = await cookies();
  jar.delete(SESSION_COOKIE);
}

export type AuthContext = {
  user: { id: string; name: string; email: string };
  orgId: string;
  orgName: string;
  role: Role;
};

export async function getAuth(): Promise<AuthContext | null> {
  const jar = await cookies();
  const data = await verifySession(jar.get(SESSION_COOKIE)?.value, env.sessionSecret);
  if (!data) return null;
  const membership = await db.membership.findUnique({
    where: { userId_orgId: { userId: data.uid, orgId: data.oid } },
    include: { user: true, org: true },
  });
  if (!membership || !membership.user.isActive) return null;
  return {
    user: { id: membership.user.id, name: membership.user.name, email: membership.user.email },
    orgId: membership.orgId,
    orgName: membership.org.name,
    role: membership.role,
  };
}

export async function requireAuth(minRole: Role = "VIEWER"): Promise<AuthContext> {
  const auth = await getAuth();
  if (!auth) redirect("/login");
  if (ROLE_RANK[auth.role] < ROLE_RANK[minRole]) throw new Error("Permissão insuficiente para esta ação.");
  return auth;
}

export function hasRole(auth: AuthContext, minRole: Role) {
  return ROLE_RANK[auth.role] >= ROLE_RANK[minRole];
}

/** Marca ativa (cookie) validada contra a organização do usuário. */
export async function getActiveBrand(auth: AuthContext) {
  const jar = await cookies();
  const wanted = jar.get(BRAND_COOKIE)?.value;
  const brands = await db.brand.findMany({ where: { orgId: auth.orgId, isActive: true }, orderBy: { createdAt: "asc" } });
  const brand = brands.find((b) => b.id === wanted) ?? brands[0] ?? null;
  return { brand, brands };
}

export async function requireBrand(minRole: Role = "VIEWER") {
  const auth = await requireAuth(minRole);
  const { brand, brands } = await getActiveBrand(auth);
  if (!brand) redirect("/onboarding");
  return { auth, brand, brands };
}

/** Garante que um recurso de marca pertence à organização do usuário. */
export async function assertBrandAccess(auth: AuthContext, brandId: string) {
  const b = await db.brand.findFirst({ where: { id: brandId, orgId: auth.orgId } });
  if (!b) throw new Error("Marca não encontrada nesta organização.");
  return b;
}
