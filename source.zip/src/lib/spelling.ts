// Grafia correta de termos em inglês nos TEXTOS (título, capa, legenda, roteiro, fala salva).
// A pronúncia em inglês é tratada só na voz (src/server/video/minimax.ts → forSpeech);
// se alguém escrever a forma fonética ("Uái-Fái"), o texto volta para "Wi-Fi".
const WRITTEN: [RegExp, string][] = [
  [/#u[áa]i[\s-]?f[áa]i(?![\p{L}])/giu, "#WiFi"], // hashtag não aceita hífen
  [/(^|[^\p{L}])u[áa]i[\s-]?f[áa]i(s?)(?![\p{L}])/giu, "$1Wi-Fi$2"],
];

export function fixWrittenTerms(s: string): string {
  return WRITTEN.reduce((t, [re, w]) => t.replace(re, w), s);
}

export function needsSpellingFix(s: string | null | undefined): boolean {
  return !!s && WRITTEN.some(([re]) => new RegExp(re.source, re.flags).test(s));
}

/** Aplica a correção em todas as strings de um objeto (dados de escrita do Prisma), sem mexer em datas, números etc. */
export function fixDeep<T>(v: T): T {
  if (typeof v === "string") return (needsSpellingFix(v) ? fixWrittenTerms(v) : v) as T;
  if (Array.isArray(v)) return v.map(fixDeep) as T;
  if (v && typeof v === "object" && Object.getPrototypeOf(v) === Object.prototype) {
    const out: Record<string, unknown> = {};
    for (const [k, x] of Object.entries(v as Record<string, unknown>)) out[k] = fixDeep(x);
    return out as T;
  }
  return v;
}
