// Vídeos acima de 15 s são feitos em partes (o modelo de vídeo gera no máximo 15 s por clipe).
// Divide a fala em N partes equilibradas, cortando sempre entre frases (ou, se preciso, entre vírgulas/palavras).

/** Limites de duração dos vídeos da persona (segundos de fala/clipe, sem a vinheta final). */
export const VIDEO_MIN_SECONDS = 20;
export const VIDEO_MAX_SECONDS = 30;
export const VIDEO_DEFAULT_SECONDS = 25;
/** Máximo por clipe aceito pelo modelo de vídeo. */
export const CLIP_MAX_SECONDS = 15;
/** Ritmo médio da fala em português (palavras por segundo) usado para estimar o tamanho do texto. */
export const WORDS_PER_SECOND = 2.4;

export function clampVideoSeconds(n: number | null | undefined): number {
  const v = Math.round(Number(n) || VIDEO_DEFAULT_SECONDS);
  return Math.min(VIDEO_MAX_SECONDS, Math.max(VIDEO_MIN_SECONDS, v));
}

export function wordCount(s: string): number {
  return s.trim().split(/\s+/).filter(Boolean).length;
}

/** Faixa de palavras da fala para uma duração alvo. */
export function speechWordRange(seconds: number) {
  return { min: Math.round(seconds * WORDS_PER_SECOND * 0.85), max: Math.round(seconds * WORDS_PER_SECOND * 1.05) };
}

function sentences(text: string): string[] {
  const t = text.replace(/\s+/g, " ").trim();
  if (!t) return [];
  return t.match(/[^.!?…]+(?:[.!?…]+["”']?|$)/g)?.map((s) => s.trim()).filter(Boolean) ?? [t];
}

/** Divide em `n` partes com quantidade parecida de palavras, sem quebrar frases quando possível. */
export function splitSpeech(text: string, n: number): string[] {
  const t = text.replace(/\s+/g, " ").trim();
  if (n <= 1 || !t) return t ? [t] : [];
  let units = sentences(t);
  // poucas frases: divide também por vírgula / ponto e vírgula / dois-pontos
  if (units.length < n) units = units.flatMap((s) => s.split(/(?<=[,;:])\s+/)).filter(Boolean);
  // ainda poucas: divide por palavras
  if (units.length < n) {
    const words = t.split(" ");
    const size = Math.ceil(words.length / n);
    return Array.from({ length: n }, (_, i) => words.slice(i * size, (i + 1) * size).join(" ")).filter(Boolean);
  }
  const total = wordCount(t);
  const target = total / n;
  const parts: string[] = [];
  let cur: string[] = [];
  let acc = 0;
  let done = 0;
  for (let i = 0; i < units.length; i++) {
    const u = units[i];
    const w = wordCount(u);
    const remainingUnits = units.length - i;
    const remainingParts = n - parts.length;
    // fecha a parte atual quando passar do alvo (ou para garantir uma unidade por parte restante)
    if (cur.length && parts.length < n - 1 && (done + acc + w / 2 > target * (parts.length + 1) || remainingUnits < remainingParts)) {
      parts.push(cur.join(" "));
      done += acc;
      cur = [];
      acc = 0;
    }
    cur.push(u);
    acc += w;
  }
  if (cur.length) parts.push(cur.join(" "));
  return parts;
}
