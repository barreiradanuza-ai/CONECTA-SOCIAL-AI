export const metadata = { title: "Termos de uso — Conecta Social AI" };

export default function Termos() {
  return (
    <main className="mx-auto max-w-2xl p-6 text-sm leading-relaxed">
      <h1 className="mb-4 text-2xl font-bold">Termos de uso</h1>
      <p className="mb-3">O Conecta Social AI é uma ferramenta interna da Conecta Aqui para planejar, criar, aprovar e publicar conteúdo nas contas oficiais da própria empresa no Facebook, Instagram e TikTok. O acesso é restrito a usuários autorizados pela empresa.</p>
      <p className="mb-3">As contas de redes sociais são conectadas pelos próprios administradores, por meio dos logins oficiais de cada plataforma. A ferramenta publica somente nas contas autorizadas, apenas o conteúdo aprovado ou configurado pela equipe, e respeita as regras e os limites de cada plataforma.</p>
      <p className="mb-3">O acesso a uma conta pode ser revogado a qualquer momento nas configurações da ferramenta ou nas configurações da própria plataforma (Facebook, Instagram ou TikTok).</p>
      <p className="mb-3">O tratamento de dados segue a nossa <a className="underline" href="/privacidade">política de privacidade</a> e a LGPD (Lei 13.709/2018).</p>
      <p>Dúvidas: entre em contato pelos canais oficiais da Conecta Aqui.</p>
    </main>
  );
}
