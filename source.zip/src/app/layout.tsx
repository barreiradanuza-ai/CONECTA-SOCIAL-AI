import type { Metadata, Viewport } from "next";
import localFont from "next/font/local";
import "./globals.css";

const poppins = localFont({
  src: [
    { path: "../../assets/fonts/Poppins-Regular.ttf", weight: "400" },
    { path: "../../assets/fonts/Poppins-Medium.ttf", weight: "500" },
    { path: "../../assets/fonts/Poppins-Bold.ttf", weight: "700" },
  ],
  variable: "--font-sans",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Conecta Social AI",
  description: "Gestor de redes sociais com inteligência artificial",
  robots: { index: false, follow: false },
};

export const viewport: Viewport = { width: "device-width", initialScale: 1, themeColor: "#071b45" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR" className={poppins.variable}>
      <body className="min-h-screen font-sans antialiased">{children}</body>
    </html>
  );
}
