import { NextResponse, type NextRequest } from "next/server";
import { db } from "@/lib/db";
import { decrypt } from "@/lib/crypto";

export const dynamic = "force-dynamic";

/** Arquivo de verificação de URL do TikTok (servido na raiz do site via middleware: /tiktokXXXX.txt). */
export async function GET(_req: NextRequest, { params }: { params: Promise<{ file: string }> }) {
  const { file } = await params;
  if (!/^[\w-]+\.txt$/i.test(file)) return new NextResponse("Não encontrado", { status: 404 });
  const rows = await db.integrationSecret.findMany({ where: { key: { in: ["TIKTOK_VERIFY_FILENAME", "TIKTOK_VERIFY_CONTENT"] } } });
  const val = (k: string) => {
    const r = rows.find((x) => x.key === k);
    try {
      return r ? decrypt(r.valueEnc) : process.env[k];
    } catch {
      return undefined;
    }
  };
  const name = val("TIKTOK_VERIFY_FILENAME")?.trim();
  const content = val("TIKTOK_VERIFY_CONTENT")?.trim();
  if (!name || !content || name !== file) return new NextResponse("Não encontrado", { status: 404 });
  return new NextResponse(content, { headers: { "Content-Type": "text/plain; charset=utf-8", "Cache-Control": "no-store" } });
}
