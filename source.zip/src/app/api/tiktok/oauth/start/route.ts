import { NextResponse } from "next/server";
import { requireBrand } from "@/lib/auth";
import { signPayload } from "@/lib/crypto";
import { env } from "@/lib/env";
import { tiktokAuthUrl, tiktokConfig } from "@/server/tiktok/api";

export const dynamic = "force-dynamic";

export async function GET() {
  const { auth, brand } = await requireBrand("ADMIN");
  const cfg = await tiktokConfig(auth.orgId);
  if (!cfg) {
    return NextResponse.redirect(
      `${env.appUrl}/settings/accounts?error=${encodeURIComponent("Cadastre o Client Key e o Client Secret do app do TikTok em Configurações → Integrações e chaves.")}`,
    );
  }
  const state = signPayload({ o: auth.orgId, u: auth.user.id, b: brand.id }, 15 * 60);
  return NextResponse.redirect(tiktokAuthUrl(cfg.clientKey, state));
}
