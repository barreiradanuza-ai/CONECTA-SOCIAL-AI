import { NextResponse, type NextRequest } from "next/server";
import { db } from "@/lib/db";
import { env } from "@/lib/env";
import { encrypt, verifyPayload } from "@/lib/crypto";
import { getAuth } from "@/lib/auth";
import { audit } from "@/server/audit";
import { tiktokConfig, tiktokExchangeCode, tiktokUser } from "@/server/tiktok/api";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const back = (q: string) => NextResponse.redirect(`${env.appUrl}/settings/accounts?${q}`);
  const sp = req.nextUrl.searchParams;
  if (sp.get("error")) return back(`error=${encodeURIComponent(sp.get("error_description") ?? "Autorização do TikTok cancelada.")}`);

  const state = verifyPayload<{ o: string; u: string; b: string }>(sp.get("state") ?? "");
  const auth = await getAuth();
  if (!state || !auth || auth.orgId !== state.o || auth.user.id !== state.u) {
    return back(`error=${encodeURIComponent("Sessão de autorização inválida ou expirada. Tente novamente.")}`);
  }

  try {
    const cfg = await tiktokConfig(state.o);
    if (!cfg) throw new Error("App do TikTok não configurado em Integrações e chaves.");
    const t = await tiktokExchangeCode(cfg, sp.get("code") ?? "");
    const missing = ["video.publish"].filter((s) => t.scopes.length && !t.scopes.includes(s));
    if (missing.length) throw new Error(`Autorize todas as permissões pedidas (faltou: ${missing.join(", ")}).`);
    const user = await tiktokUser(t.token);
    const openId = user.openId || t.openId;
    const data = {
      orgId: state.o,
      brandId: state.b,
      name: user.name,
      username: null,
      pictureUrl: user.avatar,
      linkedPageId: null,
      accessTokenEnc: encrypt(t.token),
      tokenExpiresAt: t.expiresAt,
      refreshTokenEnc: t.refreshToken ? encrypt(t.refreshToken) : null,
      refreshExpiresAt: t.refreshExpiresAt,
      scopes: t.scopes,
      status: "ACTIVE" as const,
      lastCheckedAt: new Date(),
      lastError: null,
      connectedById: state.u,
    };
    await db.socialAccount.upsert({
      where: { brandId_network_externalId: { brandId: state.b, network: "TIKTOK", externalId: openId } },
      create: { ...data, network: "TIKTOK", externalId: openId },
      update: data,
    });
    await audit(state.o, "tiktok.connect", { userId: state.u, meta: { name: user.name } });
    return back(`ok=${encodeURIComponent(`TikTok ${user.name} conectado.`)}`);
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Falha na autorização do TikTok.";
    return back(`error=${encodeURIComponent(msg)}`);
  }
}
