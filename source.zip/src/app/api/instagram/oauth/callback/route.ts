import { NextResponse, type NextRequest } from "next/server";
import { db } from "@/lib/db";
import { env } from "@/lib/env";
import { encrypt, verifyPayload } from "@/lib/crypto";
import { getAuth } from "@/lib/auth";
import { audit } from "@/server/audit";
import { igExchangeCode, igLoginConfig, igProfile } from "@/server/instagram/oauth";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const back = (q: string) => NextResponse.redirect(`${env.appUrl}/settings/accounts?${q}`);
  const sp = req.nextUrl.searchParams;
  if (sp.get("error")) return back(`error=${encodeURIComponent(sp.get("error_description") ?? "Autorização do Instagram cancelada.")}`);

  const state = verifyPayload<{ o: string; u: string; b: string }>(sp.get("state") ?? "");
  const auth = await getAuth();
  if (!state || !auth || auth.orgId !== state.o || auth.user.id !== state.u) {
    return back(`error=${encodeURIComponent("Sessão de autorização inválida ou expirada. Tente novamente.")}`);
  }

  try {
    const cfg = await igLoginConfig(state.o);
    if (!cfg) throw new Error("App do Instagram não configurado em Integrações e chaves.");
    const { token, expiresAt, scopes } = await igExchangeCode(cfg, sp.get("code") ?? "");
    const profile = await igProfile(token);
    const data = {
      orgId: state.o,
      brandId: state.b,
      name: profile.name,
      username: profile.username ?? null,
      pictureUrl: profile.picture ?? null,
      linkedPageId: null,
      accessTokenEnc: encrypt(token),
      tokenExpiresAt: expiresAt,
      scopes,
      status: "ACTIVE" as const,
      lastCheckedAt: new Date(),
      lastError: null,
      connectedById: state.u,
    };
    await db.socialAccount.upsert({
      where: { brandId_network_externalId: { brandId: state.b, network: "INSTAGRAM", externalId: profile.id } },
      create: { ...data, network: "INSTAGRAM", externalId: profile.id },
      update: data,
    });
    await audit(state.o, "instagram.connect", { userId: state.u, meta: { username: profile.username } });
    return back(`ok=${encodeURIComponent(`Instagram @${profile.username ?? profile.id} conectado.`)}`);
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Falha na autorização do Instagram.";
    return back(`error=${encodeURIComponent(msg)}`);
  }
}
