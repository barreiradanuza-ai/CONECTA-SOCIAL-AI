import { NextResponse } from "next/server";
import { requireBrand } from "@/lib/auth";
import { signPayload } from "@/lib/crypto";
import { env } from "@/lib/env";
import { igBuildAuthUrl, igLoginConfig } from "@/server/instagram/oauth";

export const dynamic = "force-dynamic";

export async function GET() {
  const { auth, brand } = await requireBrand("ADMIN");
  const cfg = await igLoginConfig(auth.orgId);
  if (!cfg) {
    return NextResponse.redirect(
      `${env.appUrl}/settings/accounts?error=${encodeURIComponent("Cadastre o ID e a chave secreta do app do Instagram em Configurações → Integrações e chaves.")}`,
    );
  }
  const state = signPayload({ o: auth.orgId, u: auth.user.id, b: brand.id }, 15 * 60);
  return NextResponse.redirect(igBuildAuthUrl(cfg.appId, state));
}
