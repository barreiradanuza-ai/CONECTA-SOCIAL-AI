import { NextResponse, type NextRequest } from "next/server";
import { getObject, verifyMediaSignature } from "@/server/storage";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

// Serve mídia somente com assinatura válida (URLs assinadas e com expiração).
export async function GET(req: NextRequest, { params }: { params: Promise<{ key: string[] }> }) {
  const { key: parts } = await params;
  const key = parts.map(decodeURIComponent).join("/");
  const sp = req.nextUrl.searchParams;
  if (!verifyMediaSignature(key, sp.get("exp"), sp.get("sig"))) return new NextResponse("Link inválido ou expirado", { status: 403 });
  const asset = await db.mediaAsset.findUnique({ where: { storageKey: key } });
  if (!asset) return new NextResponse("Não encontrado", { status: 404 });
  try {
    const buf = await getObject(key);
    return new NextResponse(new Uint8Array(buf), {
      headers: {
        "Content-Type": asset.mimeType,
        "Content-Length": String(buf.length),
        "Cache-Control": "private, max-age=3600",
        "X-Content-Type-Options": "nosniff",
        ...(asset.mimeType === "image/svg+xml" ? { "Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'" } : {}),
      },
    });
  } catch {
    return new NextResponse("Não encontrado", { status: 404 });
  }
}
