import { NextResponse, type NextRequest } from "next/server";
import { getObject, verifyMediaSignature } from "@/server/storage";
import { db } from "@/lib/db";
import { decrypt } from "@/lib/crypto";

/** Arquivo de verificação de domínio do TikTok (URL prefix …/api/media/), cadastrado em Integrações e chaves. */
async function tiktokVerification(name: string) {
  if (!/^tiktok[\w-]*\.txt$/i.test(name)) return null;
  const rows = await db.integrationSecret.findMany({ where: { key: { in: ["TIKTOK_VERIFY_FILENAME", "TIKTOK_VERIFY_CONTENT"] } } });
  const val = (k: string) => {
    const r = rows.find((x) => x.key === k);
    try {
      return r ? decrypt(r.valueEnc) : process.env[k];
    } catch {
      return undefined;
    }
  };
  const file = val("TIKTOK_VERIFY_FILENAME")?.trim();
  const content = val("TIKTOK_VERIFY_CONTENT")?.trim();
  return file && content && file === name ? content : null;
}

export const dynamic = "force-dynamic";

// Serve mídia somente com assinatura válida (URLs assinadas e com expiração).
export async function GET(req: NextRequest, { params }: { params: Promise<{ key: string[] }> }) {
  const { key: parts } = await params;
  const key = parts.map(decodeURIComponent).join("/");
  if (parts.length === 1) {
    const verification = await tiktokVerification(key);
    if (verification) return new NextResponse(verification, { headers: { "Content-Type": "text/plain; charset=utf-8" } });
  }
  const sp = req.nextUrl.searchParams;
  if (!verifyMediaSignature(key, sp.get("exp"), sp.get("sig"))) return new NextResponse("Link inválido ou expirado", { status: 403 });
  const asset = await db.mediaAsset.findUnique({ where: { storageKey: key } });
  if (!asset) return new NextResponse("Não encontrado", { status: 404 });
  try {
    const buf = await getObject(key);
    return new NextResponse(new Uint8Array(buf), {
      headers: {
        "Content-Type": asset.mimeType,
        "Content-Length": String(buf.length),
        "Cache-Control": "private, max-age=3600",
        "X-Content-Type-Options": "nosniff",
        ...(asset.mimeType === "image/svg+xml" ? { "Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'" } : {}),
      },
    });
  } catch {
    return new NextResponse("Não encontrado", { status: 404 });
  }
}
