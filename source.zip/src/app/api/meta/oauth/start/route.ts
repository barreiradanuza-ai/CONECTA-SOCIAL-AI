import { NextResponse, type NextRequest } from "next/server";
import { requireBrand } from "@/lib/auth";
import { signPayload } from "@/lib/crypto";
import { buildAuthUrl, metaConfigured } from "@/server/meta/oauth";
import { env } from "@/lib/env";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const { auth, brand } = await requireBrand("ADMIN");
  if (!metaConfigured()) {
    return NextResponse.redirect(`${env.appUrl}/settings/accounts?error=${encodeURIComponent("Configure META_APP_ID e META_APP_SECRET no servidor.")}`);
  }
  const n = req.nextUrl.searchParams.get("rede");
  const only = n === "facebook" || n === "instagram" ? n : undefined;
  const state = signPayload({ o: auth.orgId, u: auth.user.id, b: brand.id, ...(only ? { n: only } : {}) }, 15 * 60);
  return NextResponse.redirect(buildAuthUrl(state));
}
