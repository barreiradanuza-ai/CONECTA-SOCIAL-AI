import { NextResponse } from "next/server";
import { requireBrand } from "@/lib/auth";
import { signPayload } from "@/lib/crypto";
import { buildAuthUrl, metaConfigured } from "@/server/meta/oauth";
import { env } from "@/lib/env";

export const dynamic = "force-dynamic";

export async function GET() {
  const { auth, brand } = await requireBrand("ADMIN");
  if (!metaConfigured()) {
    return NextResponse.redirect(`${env.appUrl}/settings/accounts?error=${encodeURIComponent("Configure META_APP_ID e META_APP_SECRET no servidor.")}`);
  }
  const state = signPayload({ o: auth.orgId, u: auth.user.id, b: brand.id }, 15 * 60);
  return NextResponse.redirect(buildAuthUrl(state));
}
