import { NextResponse, type NextRequest } from "next/server";
import { db } from "@/lib/db";
import { env } from "@/lib/env";
import { encrypt, verifyPayload } from "@/lib/crypto";
import { getAuth } from "@/lib/auth";
import { debugToken, discoverPages, exchangeCode } from "@/server/meta/oauth";
import { audit } from "@/server/audit";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const back = (q: string) => NextResponse.redirect(`${env.appUrl}/settings/accounts?${q}`);
  const sp = req.nextUrl.searchParams;
  if (sp.get("error")) return back(`error=${encodeURIComponent(sp.get("error_description") ?? "Autorização cancelada.")}`);

  const state = verifyPayload<{ o: string; u: string; b: string }>(sp.get("state") ?? "");
  const auth = await getAuth();
  if (!state || !auth || auth.orgId !== state.o || auth.user.id !== state.u) return back(`error=${encodeURIComponent("Sessão de autorização inválida ou expirada. Tente novamente.")}`);

  try {
    const { userToken } = await exchangeCode(sp.get("code") ?? "");
    const [pages, info] = await Promise.all([discoverPages(userToken), debugToken(userToken).catch(() => null)]);
    if (!pages.length) return back(`error=${encodeURIComponent("Nenhuma Página do Facebook foi autorizada. Verifique se você é administrador da Página e selecionou-a na tela da Meta.")}`);
    const pending = await db.oAuthPending.create({
      data: {
        orgId: state.o,
        brandId: state.b,
        userId: state.u,
        payloadEnc: encrypt(JSON.stringify({ pages, scopes: info?.scopes ?? [] })),
        expiresAt: new Date(Date.now() + 20 * 60_000),
      },
    });
    await audit(state.o, "meta.oauth", { userId: state.u, meta: { pages: pages.length } });
    return back(`pending=${pending.id}`);
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Falha na autorização.";
    return back(`error=${encodeURIComponent(msg)}`);
  }
}
