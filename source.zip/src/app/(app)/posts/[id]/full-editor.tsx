// Editor completo de uma publicação: textos, legendas, hashtags, prompt da imagem e, nos Reels,
// roteiro por partes + fala e cena do vídeo — tudo editável, com "gerar novamente" por parte e no conjunto.
// Usado na página da publicação (briefing e edição) e na biblioteca de mídia.
import type { Post, PostTarget } from "@prisma/client";
import { Field } from "@/components/ui";
import { SubmitButton } from "@/components/client";
import { NETWORK_LABEL } from "@/lib/labels";
import { splitScenes } from "@/lib/scenes";
import { briefAction } from "../actions";

export const LAYOUTS = [
  { v: "hero-bottom", l: "Foto com título sobreposto" },
  { v: "split-panel", l: "Foto + painel" },
  { v: "question-card", l: "Pergunta em destaque" },
  { v: "offer", l: "Oferta (preço da oferta cadastrada)" },
  { v: "story", l: "Story" },
  { v: "carousel", l: "Carrossel" },
];

export function FullEditor({ post, mode, back }: { post: Post & { targets: PostTarget[] }; mode: "brief" | "edit"; back?: string }) {
  const brief = mode === "brief";
  const reel = post.format === "REEL";
  const scenes = splitScenes(post.reelScript);
  const slides = (post.slides as { title: string; body: string }[] | null) ?? [];
  return (
            <form action={briefAction} className={`card space-y-5 p-5 ${brief ? "border-violet-300" : ""}`}>
              <input type="hidden" name="id" value={post.id} />
              {back && <input type="hidden" name="back" value={back} />}
              {brief ? (
                <div className="rounded-xl bg-violet-50 p-3 text-sm text-violet-900">
                  <div className="font-semibold">Etapa 1 de 2: aprovar o briefing para produção</div>
                  <p className="mt-1">Revise e edite tudo abaixo. Nenhuma imagem ou vídeo foi gerado ainda. Ao aprovar, o app produz a arte{post.format === "CAROUSEL" ? ", os slides" : ""}{post.format === "REEL" ? " e o vídeo" : ""} exatamente com este briefing; depois você confere o resultado e aprova para publicação (etapa 2).</p>
                </div>
              ) : (
                <div>
                  <h2 className="font-semibold">{reel ? "Vídeo: roteiro, legendas e cena" : "Conteúdo completo"}</h2>
                  <p className="text-xs text-ink-mute">Edite qualquer parte. “Gerar novamente” refaz só aquela parte; no final, “Gerar tudo novamente com as alterações” refaz {post.format === "REEL" ? "o vídeo (e a capa, se a foto for da IA)" : post.format === "CAROUSEL" ? "a imagem e os slides" : "a imagem e a arte"} com o conteúdo exatamente como está aqui.</p>
                </div>
              )}

              <div className="space-y-4">
                <h3 className="text-sm font-bold uppercase tracking-wide text-ink-mute">Textos</h3>
                <Field label="Tema"><input className="input" name="theme" defaultValue={post.theme} /></Field>
                {reel ? (
                  <p className="rounded-lg bg-slate-50 p-2 text-xs text-ink-mute">Título, texto, chamada, layout e foto da capa ficam no quadro <b>Capa do Reels</b>, separado do vídeo.</p>
                ) : (
                  <>
                    <div className="grid gap-4 sm:grid-cols-2">
                      <Field label="Título da arte"><input className="input" name="title" defaultValue={post.title ?? ""} /></Field>
                      <Field label="Chamada para ação"><input className="input" name="cta" defaultValue={post.cta ?? ""} /></Field>
                    </div>
                    <Field label="Texto secundário"><input className="input" name="subtitle" defaultValue={post.subtitle ?? ""} /></Field>
                    <Field label="Layout">
                      <select className="input" name="layout" defaultValue={post.layout ?? "hero-bottom"}>{LAYOUTS.map((l) => <option key={l.v} value={l.v}>{l.l}</option>)}</select>
                    </Field>
                  </>
                )}
                {post.format === "CAROUSEL" && (
                  <Field label="Slides (título na 1ª linha; separe slides com ---)">
                    <textarea className="input min-h-48 font-mono text-xs" name="slides" defaultValue={slides.map((x) => `${x.title}\n${x.body}`).join("\n---\n")} />
                  </Field>
                )}
                {post.targets.map((t) => (
                  <Field key={t.id} label={`Legenda ${NETWORK_LABEL[t.network]}`} hint={t.network === "INSTAGRAM" ? `${(t.caption ?? "").length}/2200 caracteres` : undefined}>
                    <textarea className="input min-h-36" name={`caption_${t.network}`} defaultValue={t.caption ?? ""} />
                  </Field>
                ))}
                <Field label="Hashtags (sem #, separadas por vírgula)"><input className="input" name="hashtags" defaultValue={post.hashtags.join(", ")} /></Field>
                <div className="flex flex-wrap items-end gap-2 rounded-xl bg-blue-50 p-3">
                  <div className="min-w-48 flex-1">
                    <Field label="Criar legenda com IA: instruções (opcional)">
                      <input className="input" name="captionNote" maxLength={500} placeholder="Ex.: mais curta, chamar para o WhatsApp, tom divertido" />
                    </Field>
                  </div>
                  <SubmitButton name="op" value="caption" className="btn-primary btn-sm" pendingText="Escrevendo a legenda…" confirm={post.targets.some((t) => t.caption) ? "Criar uma legenda nova com a IA? A legenda e as hashtags atuais serão substituídas." : undefined}>
                    Criar legenda com IA
                  </SubmitButton>
                </div>
              </div>

              <p className="text-xs text-ink-mute">O prompt e a foto ficam no quadro <b>{reel ? "Capa do Reels" : "Imagem da publicação"}</b>.</p>

              {post.format === "REEL" && (
                <div className="space-y-3">
                  <h3 className="text-sm font-bold uppercase tracking-wide text-ink-mute">Roteiro do Reels</h3>
                  {(scenes.length ? scenes : [""]).map((sc, i) => (
                    <div key={`${i}-${sc}`} className="space-y-2 rounded-xl border border-slate-200 p-3">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold uppercase tracking-wide text-ink-mute">Parte {i + 1}</span>
                        {scenes.length > 1 && (
                          <SubmitButton name="op" value={`remove:${i}`} className="text-xs text-red-700 hover:underline" pendingText="Aguarde…" confirm={`Remover a parte ${i + 1}?`}>Remover parte</SubmitButton>
                        )}
                      </div>
                      <textarea className="input min-h-28 text-sm leading-relaxed" name={`scene_${i}`} defaultValue={sc} maxLength={3000} />
                      <div className="flex flex-col gap-2 sm:flex-row">
                        <input className="input py-1.5 text-sm" name={`note_${i}`} maxLength={500} placeholder="O que mudar nesta parte? (opcional)" />
                        <SubmitButton name="op" value={`scene:${i}`} className="btn-ghost btn-sm shrink-0" pendingText="Aguarde…">Gerar novamente esta parte</SubmitButton>
                      </div>
                    </div>
                  ))}
                  <SubmitButton name="op" value="add" className="btn-ghost btn-sm" pendingText="Aguarde…">+ Adicionar parte</SubmitButton>
                  <h3 className="pt-2 text-sm font-bold uppercase tracking-wide text-ink-mute">Vídeo da persona</h3>
                  <Field label="Fala do personagem no vídeo (50 a 65 palavras ≈ 22–28 s)">
                    <textarea className="input min-h-20 text-sm" name="videoSpeech" defaultValue={post.videoSpeech ?? ""} maxLength={1000} />
                  </Field>
                  <Field label="Cena do vídeo (em inglês: cenário, enquadramento, gestos, câmera)">
                    <textarea className="input min-h-24 font-mono text-xs" name="videoPrompt" defaultValue={post.videoPrompt ?? ""} maxLength={2000} />
                  </Field>
                </div>
              )}

              <div className="space-y-2 rounded-xl border border-dashed border-slate-300 p-3">
                <Field label={brief ? "Refazer o briefing com IA: instruções (opcional)" : "Reescrever todo o texto com IA: instruções (opcional)"}>
                  <input className="input" name="instructions" maxLength={1000} placeholder="Ex.: gancho mais forte, legenda mais curta, falar de golpe no Wi-Fi" />
                </Field>
                <SubmitButton name="op" value="redo" className="btn-ghost btn-sm" pendingText="Aguarde…" confirm="Reescrever todo o texto com a IA? Suas edições atuais serão substituídas.">{brief ? "Refazer briefing com IA" : "Reescrever texto com IA"}</SubmitButton>
              </div>

              <div className="flex flex-wrap gap-2 border-t border-slate-100 pt-4">
                <SubmitButton name="op" value="save" className="btn-ghost" pendingText="Aguarde…">{brief ? "Salvar briefing" : "Salvar alterações"}</SubmitButton>
                {brief ? (
                  <SubmitButton name="op" value="approve" className="btn-accent" pendingText="Produzindo… (até 2 min)" confirm="Aprovar este briefing e produzir agora a arte e as peças com ele?">
                    Aprovar para produção
                  </SubmitButton>
                ) : (
                  <SubmitButton name="op" value="produce" className="btn-accent" pendingText="Gerando tudo… (até 2 min)" confirm="Gerar agora a imagem, a arte e as peças (e o vídeo, nos Reels) com o conteúdo exatamente como está aqui?">
                    Gerar tudo novamente com as alterações
                  </SubmitButton>
                )}
              </div>
            </form>
  );
}
