import Link from "next/link";
import { notFound } from "next/navigation";
import { requireBrand, hasRole } from "@/lib/auth";
import { db } from "@/lib/db";
import { Flash, StatusBadge, PillarBadge, FormatBadge, Field } from "@/components/ui";
import { SubmitButton } from "@/components/client";
import { formatDateTime, toDatetimeLocal, formatDate } from "@/lib/time";
import { NETWORK_LABEL, TARGET_STATUS_LABEL, FUNNEL_LABEL } from "@/lib/labels";
import { mediaPath } from "@/server/storage";
import { formatBRL } from "@/server/guard";
import { splitScenes } from "@/lib/scenes";
import { approveAction, unapproveAction, cancelAction, publishNowAction, rescheduleAction, retryAction, saveContentAction, regenerateAction, attachVideoAction, saveImagePromptAction, regenerateReelScriptAction, reelScenesAction, briefAction } from "../actions";

const LAYOUTS = [
  { v: "hero-bottom", l: "Foto com título sobreposto" },
  { v: "split-panel", l: "Foto + painel" },
  { v: "question-card", l: "Pergunta em destaque" },
  { v: "offer", l: "Oferta (preço da oferta cadastrada)" },
  { v: "story", l: "Story" },
  { v: "carousel", l: "Carrossel" },
];

export default async function PostDetail({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ ok?: string; error?: string }> }) {
  const { auth, brand } = await requireBrand();
  const { id } = await params;
  const sp = await searchParams;
  const post = await db.post.findFirst({
    where: { id, orgId: auth.orgId, brandId: brand.id },
    include: {
      offer: true,
      targets: { include: { attemptsLog: { orderBy: { startedAt: "desc" }, take: 10 }, metrics: { orderBy: { collectedAt: "desc" }, take: 1 }, socialAccount: true } },
      media: { include: { asset: true }, orderBy: { position: "asc" } },
      links: { include: { _count: { select: { clicks: true } } } },
    },
  });
  if (!post) notFound();
  const admin = hasRole(auth, "ADMIN");
  const validation = (post.validation ?? null) as { ok: boolean; errors: string[]; warnings: string[] } | null;
  const finals = post.media.filter((m) => ["COMPOSED", "SLIDE", "COVER"].includes(m.purpose));
  const background = post.media.find((m) => m.purpose === "BACKGROUND");
  const video = post.media.find((m) => m.purpose === "VIDEO");
  const slides = (post.slides as { title: string; body: string }[] | null) ?? [];
  const library = await db.mediaAsset.findMany({ where: { brandId: brand.id, kind: "IMAGE", role: { in: ["PHOTO", "GENERATED", "REFERENCE"] } }, orderBy: { createdAt: "desc" }, take: 24 });
  const videos = post.format === "REEL" ? await db.mediaAsset.findMany({ where: { brandId: brand.id, kind: "VIDEO" }, orderBy: { createdAt: "desc" }, take: 30 }) : [];
  const locked = ["PUBLISHED", "PUBLISHING"].includes(post.status);
  const scenes = splitScenes(post.reelScript);
  const brief = post.status === "BRIEF_REVIEW";
  const ig = post.targets.find((t) => t.network === "INSTAGRAM");
  const fb = post.targets.find((t) => t.network === "FACEBOOK");

  return (
    <div>
      <div className="mb-2 text-sm"><Link href="/posts" className="text-accent">← Publicações</Link></div>
      <div className="mb-5 flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between">
        <div>
          <h1 className="text-2xl font-bold">{post.title ?? post.theme}</h1>
          <div className="mt-2 flex flex-wrap items-center gap-2 text-sm">
            <StatusBadge status={post.status} />
            <FormatBadge format={post.format} />
            <PillarBadge pillar={post.pillar} />
            {post.episodeNumber && <span className="badge bg-fuchsia-100 text-fuchsia-800">Ep. {post.episodeNumber}</span>}
            <span className="text-ink-soft">{formatDateTime(post.scheduledAt, brand.timezone)}</span>
            <span className="text-ink-mute">· {post.targets.map((t) => NETWORK_LABEL[t.network]).join(" + ")}</span>
          </div>
          {post.timeReason && <p className="mt-1 text-xs text-ink-mute">Horário: {post.timeReason}</p>}
        </div>
        <div className="flex flex-wrap gap-2">
          {admin && post.status === "PENDING_APPROVAL" && (
            <form action={approveAction}><input type="hidden" name="id" value={post.id} /><SubmitButton className="btn-accent" pendingText="Aprovando…">Aprovar e agendar</SubmitButton></form>
          )}
          {admin && ["SCHEDULED", "APPROVED"].includes(post.status) && (
            <>
              <form action={publishNowAction}><input type="hidden" name="id" value={post.id} /><SubmitButton className="btn-primary" confirm="Publicar agora nas redes selecionadas?">Publicar agora</SubmitButton></form>
              <form action={unapproveAction}><input type="hidden" name="id" value={post.id} /><SubmitButton className="btn-ghost">Voltar para rascunho</SubmitButton></form>
            </>
          )}
          {!locked && post.status !== "CANCELED" && (
            <form action={cancelAction}><input type="hidden" name="id" value={post.id} /><SubmitButton className="btn-danger" confirm="Cancelar este agendamento? O conteúdo será mantido.">Cancelar</SubmitButton></form>
          )}
        </div>
      </div>
      <Flash ok={sp.ok} error={sp.error} />

      {post.status === "GENERATING" && <div className="mb-4 rounded-xl bg-blue-50 p-3 text-sm text-blue-800">Gerando conteúdo… atualize a página em instantes.</div>}
      {post.generationError && <div className="mb-4 rounded-xl bg-red-50 p-3 text-sm text-red-800">Última geração falhou: {post.generationError}</div>}

      <div className="grid gap-6 xl:grid-cols-5">
        {/* Prévia */}
        <section className="space-y-4 xl:col-span-2">
          <div className="card overflow-hidden">
            <div className="flex items-center gap-2 border-b border-slate-100 p-3 text-sm font-semibold">
              <div className="h-7 w-7 rounded-full bg-navy" />
              {brand.name}
              <span className="ml-auto text-xs font-normal text-ink-mute">Prévia</span>
            </div>
            {finals.length ? (
              <div className="flex snap-x snap-mandatory overflow-x-auto">
                {finals.map((m) => (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img key={m.id} src={mediaPath(m.asset.storageKey)} alt="" className="w-full shrink-0 snap-center" />
                ))}
              </div>
            ) : (
              <div className="flex aspect-[4/5] items-center justify-center bg-slate-100 text-sm text-ink-mute">Sem arte gerada</div>
            )}
            {finals.length > 1 && <div className="px-3 pt-2 text-xs text-ink-mute">{finals.length} slides — role para o lado</div>}
            {video && <video src={mediaPath(video.asset.storageKey)} controls className="w-full" />}
            <div className="whitespace-pre-line p-3 text-sm">{ig?.caption ?? fb?.caption ?? <span className="text-ink-mute">Sem legenda</span>}</div>
          </div>
          {validation && (
            <div className={`card p-4 text-sm ${validation.errors.length ? "border-red-200" : ""}`}>
              <div className="mb-2 font-semibold">Validação pré-publicação {validation.errors.length ? <span className="badge bg-red-100 text-red-800">com problemas</span> : <span className="badge bg-emerald-100 text-emerald-800">aprovada</span>}</div>
              {validation.errors.map((e) => <div key={e} className="text-red-700">• {e}</div>)}
              {validation.warnings.map((w) => <div key={w} className="text-amber-700">• {w}</div>)}
              {!validation.errors.length && !validation.warnings.length && <div className="text-ink-soft">Dimensões, formato, legibilidade, marca e dados comerciais verificados.</div>}
            </div>
          )}
          {post.approvalReasons.length > 0 && post.status === "PENDING_APPROVAL" && (
            <div className="card p-4 text-sm"><div className="mb-1 font-semibold">Por que precisa de aprovação</div>{post.approvalReasons.map((r) => <div key={r}>• {r}</div>)}</div>
          )}
          {post.offer && (
            <div className="card p-4 text-sm">
              <div className="font-semibold">Oferta vinculada</div>
              <div>{post.offer.operator} · {post.offer.speedMbps} Mega · {formatBRL(post.offer.priceCents)}{post.offer.pricePeriod}</div>
              <div className="text-xs text-ink-mute">Válida até {formatDate(post.offer.validUntil, brand.timezone)} · status {post.offer.status}</div>
            </div>
          )}
        </section>

        {/* Edição */}
        <section className="space-y-6 xl:col-span-3">
          {brief ? (
            <form action={briefAction} className="card space-y-5 border-violet-300 p-5">
              <input type="hidden" name="id" value={post.id} />
              <div className="rounded-xl bg-violet-50 p-3 text-sm text-violet-900">
                <div className="font-semibold">Etapa 1 de 2: aprovar o briefing para produção</div>
                <p className="mt-1">Revise e edite tudo abaixo. Nenhuma imagem ou vídeo foi gerado ainda. Ao aprovar, o app produz a arte{post.format === "CAROUSEL" ? ", os slides" : ""}{post.format === "REEL" ? " e o vídeo" : ""} exatamente com este briefing; depois você confere o resultado e aprova para publicação (etapa 2).</p>
              </div>

              <div className="space-y-4">
                <h3 className="text-sm font-bold uppercase tracking-wide text-ink-mute">Textos</h3>
                <Field label="Tema"><input className="input" name="theme" defaultValue={post.theme} /></Field>
                <div className="grid gap-4 sm:grid-cols-2">
                  <Field label="Título da arte"><input className="input" name="title" defaultValue={post.title ?? ""} /></Field>
                  <Field label="Chamada para ação"><input className="input" name="cta" defaultValue={post.cta ?? ""} /></Field>
                </div>
                <Field label="Texto secundário"><input className="input" name="subtitle" defaultValue={post.subtitle ?? ""} /></Field>
                <Field label="Layout">
                  <select className="input" name="layout" defaultValue={post.layout ?? "hero-bottom"}>{LAYOUTS.map((l) => <option key={l.v} value={l.v}>{l.l}</option>)}</select>
                </Field>
                {post.format === "CAROUSEL" && (
                  <Field label="Slides (título na 1ª linha; separe slides com ---)">
                    <textarea className="input min-h-48 font-mono text-xs" name="slides" defaultValue={slides.map((x) => `${x.title}\n${x.body}`).join("\n---\n")} />
                  </Field>
                )}
                {post.targets.map((t) => (
                  <Field key={t.id} label={`Legenda ${NETWORK_LABEL[t.network]}`} hint={t.network === "INSTAGRAM" ? `${(t.caption ?? "").length}/2200 caracteres` : undefined}>
                    <textarea className="input min-h-36" name={`caption_${t.network}`} defaultValue={t.caption ?? ""} />
                  </Field>
                ))}
                <Field label="Hashtags (sem #, separadas por vírgula)"><input className="input" name="hashtags" defaultValue={post.hashtags.join(", ")} /></Field>
              </div>

              <div className="space-y-4">
                <h3 className="text-sm font-bold uppercase tracking-wide text-ink-mute">Imagem</h3>
                <Field label="Prompt da imagem (a foto de fundo, sem textos)">
                  <textarea className="input min-h-28 font-mono text-xs" name="imagePrompt" defaultValue={post.imagePrompt ?? ""} maxLength={4000} />
                </Field>
                <Field label="Direção de arte">
                  <input className="input" name="artDirection" defaultValue={post.artDirection ?? ""} maxLength={1000} />
                </Field>
              </div>

              {post.format === "REEL" && (
                <div className="space-y-3">
                  <h3 className="text-sm font-bold uppercase tracking-wide text-ink-mute">Roteiro do Reels</h3>
                  {(scenes.length ? scenes : [""]).map((sc, i) => (
                    <div key={`${i}-${sc}`} className="space-y-2 rounded-xl border border-slate-200 p-3">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold uppercase tracking-wide text-ink-mute">Parte {i + 1}</span>
                        {scenes.length > 1 && (
                          <SubmitButton name="op" value={`remove:${i}`} className="text-xs text-red-700 hover:underline" pendingText="Aguarde…" confirm={`Remover a parte ${i + 1}?`}>Remover parte</SubmitButton>
                        )}
                      </div>
                      <textarea className="input min-h-28 text-sm leading-relaxed" name={`scene_${i}`} defaultValue={sc} maxLength={3000} />
                      <div className="flex flex-col gap-2 sm:flex-row">
                        <input className="input py-1.5 text-sm" name={`note_${i}`} maxLength={500} placeholder="O que mudar nesta parte? (opcional)" />
                        <SubmitButton name="op" value={`scene:${i}`} className="btn-ghost btn-sm shrink-0" pendingText="Aguarde…">Gerar novamente esta parte</SubmitButton>
                      </div>
                    </div>
                  ))}
                  <SubmitButton name="op" value="add" className="btn-ghost btn-sm" pendingText="Aguarde…">+ Adicionar parte</SubmitButton>
                  <h3 className="pt-2 text-sm font-bold uppercase tracking-wide text-ink-mute">Vídeo da persona</h3>
                  <Field label="Fala do personagem no vídeo (até ~30 palavras)">
                    <textarea className="input min-h-20 text-sm" name="videoSpeech" defaultValue={post.videoSpeech ?? ""} maxLength={600} />
                  </Field>
                  <Field label="Cena do vídeo (em inglês: cenário, enquadramento, gestos, câmera)">
                    <textarea className="input min-h-24 font-mono text-xs" name="videoPrompt" defaultValue={post.videoPrompt ?? ""} maxLength={2000} />
                  </Field>
                </div>
              )}

              <div className="space-y-2 rounded-xl border border-dashed border-slate-300 p-3">
                <Field label="Refazer o briefing com IA: instruções (opcional)">
                  <input className="input" name="instructions" maxLength={1000} placeholder="Ex.: gancho mais forte, legenda mais curta, falar de golpe no Wi-Fi" />
                </Field>
                <SubmitButton name="op" value="redo" className="btn-ghost btn-sm" pendingText="Aguarde…" confirm="Refazer o briefing inteiro com a IA? Suas edições atuais serão substituídas.">Refazer briefing com IA</SubmitButton>
              </div>

              <div className="flex flex-wrap gap-2 border-t border-slate-100 pt-4">
                <SubmitButton name="op" value="save" className="btn-ghost" pendingText="Aguarde…">Salvar briefing</SubmitButton>
                <SubmitButton
                  name="op"
                  value="approve"
                  className="btn-accent"
                  pendingText="Produzindo… (até 2 min)"
                  confirm="Aprovar este briefing e produzir agora a arte e as peças com ele?"
                >
                  Aprovar para produção
                </SubmitButton>
              </div>
            </form>
          ) : (
            <>
          {!locked && (
            <form action={regenerateAction} className="card space-y-3 p-5">
              <input type="hidden" name="id" value={post.id} />
              <h2 className="font-semibold">Gerar com IA</h2>
              <Field label="Instruções adicionais (opcional)"><textarea className="input min-h-16" name="instructions" placeholder="Ex.: foque em quem trabalha em home office; tom mais descontraído." /></Field>
              <Field label="Usar imagem da biblioteca como fundo (opcional)">
                <select name="backgroundAssetId" className="input" defaultValue="">
                  <option value="">— gerar/usar imagem da IA —</option>
                  {library.map((a) => <option key={a.id} value={a.id}>{a.title ?? a.originalName ?? a.id} ({a.role === "GENERATED" ? "IA" : a.role === "PHOTO" ? "foto" : "referência"})</option>)}
                </select>
              </Field>
              <div className="flex flex-wrap gap-2">
                <SubmitButton name="mode" value="brief" className="btn-accent" pendingText="Aguarde…">{post.title ? "Novo briefing para aprovar" : "Gerar briefing para aprovar"}</SubmitButton>
                {post.title && <SubmitButton name="mode" value="all" className="btn-ghost" pendingText="Gerando (até 2 min)…">Regerar tudo direto</SubmitButton>}
                {!post.title && <SubmitButton name="mode" value="all" className="btn-ghost" pendingText="Gerando (até 2 min)…">Gerar conteúdo e arte direto</SubmitButton>}
                {post.title && <SubmitButton name="mode" value="text" className="btn-ghost" pendingText="Gerando…">Só texto</SubmitButton>}
                {post.title && <SubmitButton name="mode" value="image" className="btn-ghost" pendingText="Gerando…">Nova imagem</SubmitButton>}
                {post.title && <SubmitButton name="mode" value="compose" className="btn-ghost" pendingText="Recompondo…">Aplicar fundo/recompor</SubmitButton>}
              </div>
            </form>
          )}

          {!locked && post.title && (
            <form action={saveImagePromptAction} className="card space-y-3 p-5">
              <input type="hidden" name="id" value={post.id} />
              <div>
                <h2 className="font-semibold">Prompt da imagem</h2>
                <p className="text-xs text-ink-mute">Descreva a foto de fundo que a IA deve criar. Escreva sem textos, preços ou logotipo: esses elementos são desenhados pelo app por cima da imagem.</p>
              </div>
              <Field label="Prompt">
                <textarea className="input min-h-32 font-mono text-xs" name="imagePrompt" defaultValue={post.imagePrompt ?? ""} required maxLength={4000} />
              </Field>
              <Field label="Direção de arte (opcional)">
                <input className="input" name="artDirection" defaultValue={post.artDirection ?? ""} maxLength={1000} placeholder="Ex.: luz natural, tons quentes, ambiente de casa aconchegante" />
              </Field>
              <div className="flex flex-wrap gap-2">
                <SubmitButton name="op" value="generate" className="btn-primary" pendingText="Gerando imagem (até 2 min)…">Salvar e gerar nova imagem</SubmitButton>
                <SubmitButton name="op" value="save" className="btn-ghost" pendingText="Salvando…">Só salvar</SubmitButton>
              </div>
            </form>
          )}

          {post.format === "REEL" && (
            <div className="card space-y-3 p-5">
              <h2 className="font-semibold">Reels</h2>
              {locked ? (
                post.reelScript && <div className="whitespace-pre-line rounded-lg bg-slate-50 p-3 text-sm">{post.reelScript}</div>
              ) : (
                <form action={reelScenesAction} className="space-y-3">
                  <input type="hidden" name="id" value={post.id} />
                  <p className="text-xs text-ink-mute">Edite cada parte do roteiro. Use “Gerar novamente esta parte” para a IA refazer só aquele trecho. No final, “Gerar tudo agora” refaz capa, título, legendas, imagem e vídeo com o roteiro como você deixou.</p>
                  {(scenes.length ? scenes : [""]).map((sc, i) => (
                    <div key={`${i}-${sc}`} className="space-y-2 rounded-xl border border-slate-200 p-3">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold uppercase tracking-wide text-ink-mute">Parte {i + 1}</span>
                        {scenes.length > 1 && (
                          <SubmitButton name="op" value={`remove:${i}`} className="text-xs text-red-700 hover:underline" pendingText="Aguarde…" confirm={`Remover a parte ${i + 1}?`}>
                            Remover parte
                          </SubmitButton>
                        )}
                      </div>
                      <textarea className="input min-h-28 text-sm leading-relaxed" name={`scene_${i}`} defaultValue={sc} maxLength={3000} placeholder="CENA 1 (0-3s) — ação, enquadramento e fala" />
                      <div className="flex flex-col gap-2 sm:flex-row">
                        <input className="input py-1.5 text-sm" name={`note_${i}`} maxLength={500} placeholder="O que mudar nesta parte? (opcional)" />
                        <SubmitButton name="op" value={`scene:${i}`} className="btn-ghost btn-sm shrink-0" pendingText="Aguarde…">
                          Gerar novamente esta parte
                        </SubmitButton>
                      </div>
                    </div>
                  ))}
                  <div className="flex flex-wrap gap-2">
                    <SubmitButton name="op" value="save" className="btn-ghost btn-sm" pendingText="Aguarde…">Salvar alterações</SubmitButton>
                    <SubmitButton name="op" value="add" className="btn-ghost btn-sm" pendingText="Aguarde…">+ Adicionar parte</SubmitButton>
                  </div>
                  <div className="space-y-2 rounded-xl bg-navy-50 p-3">
                    <Field label="Instruções gerais para a geração final (opcional)">
                      <input className="input" name="instructions" maxLength={1000} placeholder="Ex.: legenda mais curta, capa com o Claudinho apontando para o roteador" />
                    </Field>
                    <SubmitButton
                      name="op"
                      value="all"
                      className="btn-accent"
                      pendingText="Gerando tudo… (até 2 min)"
                      confirm="Gerar agora capa, título, legendas, imagem e vídeo com este roteiro? O conteúdo atual dessas partes será substituído."
                    >
                      Gerar tudo agora com as alterações
                    </SubmitButton>
                  </div>
                </form>
              )}
              {!locked && (
                <form action={regenerateReelScriptAction} className="space-y-2 rounded-lg border border-dashed border-slate-200 p-3">
                  <input type="hidden" name="id" value={post.id} />
                  <Field label="Roteiro totalmente novo — instruções (opcional)">
                    <input className="input" name="instructions" maxLength={1000} placeholder="Ex.: outro gancho, mais curto, mais engraçado" />
                  </Field>
                  <SubmitButton
                    className="btn-ghost btn-sm"
                    pendingText="Escrevendo novo roteiro (até 1 min)…"
                    confirm={post.reelScript ? "Escrever um roteiro totalmente novo? O roteiro atual será substituído." : undefined}
                  >
                    Escrever roteiro do zero
                  </SubmitButton>
                </form>
              )}
              <p className="text-xs text-ink-mute">Com a IA de vídeo ligada em Configurações → Automação, o vídeo da persona é produzido a partir deste roteiro. Também dá para gravar, enviar o vídeo (MP4, 9:16, até 90s) à biblioteca e vincular aqui. A arte acima é usada como capa.</p>
              {!locked && (
                <form action={attachVideoAction} className="flex gap-2">
                  <input type="hidden" name="id" value={post.id} />
                  <select name="videoId" className="input" required defaultValue={video?.assetId ?? ""}>
                    <option value="" disabled>Selecione um vídeo…</option>
                    {videos.map((v) => <option key={v.id} value={v.id}>{v.title ?? v.originalName}</option>)}
                  </select>
                  <SubmitButton className="btn-ghost">Vincular</SubmitButton>
                </form>
              )}
            </div>
          )}

          <form action={saveContentAction} className="card space-y-4 p-5">
            <input type="hidden" name="id" value={post.id} />
            <h2 className="font-semibold">Conteúdo</h2>
            <fieldset disabled={locked} className="space-y-4">
              <Field label="Tema"><input className="input" name="theme" defaultValue={post.theme} /></Field>
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Título da arte"><input className="input" name="title" defaultValue={post.title ?? ""} /></Field>
                <Field label="Chamada para ação"><input className="input" name="cta" defaultValue={post.cta ?? ""} /></Field>
              </div>
              <Field label="Texto secundário"><input className="input" name="subtitle" defaultValue={post.subtitle ?? ""} /></Field>
              <Field label="Layout">
                <select className="input" name="layout" defaultValue={post.layout ?? "hero-bottom"}>{LAYOUTS.map((l) => <option key={l.v} value={l.v}>{l.l}</option>)}</select>
              </Field>
              {post.format === "CAROUSEL" && (
                <Field label="Slides (título na 1ª linha; separe slides com ---)">
                  <textarea className="input min-h-40 font-mono text-xs" name="slides" defaultValue={slides.map((s) => `${s.title}\n${s.body}`).join("\n---\n")} />
                </Field>
              )}
              {post.targets.map((t) => (
                <Field key={t.id} label={`Legenda ${NETWORK_LABEL[t.network]}`} hint={t.network === "INSTAGRAM" ? `${(t.caption ?? "").length}/2200 caracteres` : undefined}>
                  <textarea className="input min-h-36" name={`caption_${t.network}`} defaultValue={t.caption ?? ""} />
                </Field>
              ))}
              <Field label="Hashtags (sem #, separadas por vírgula)"><input className="input" name="hashtags" defaultValue={post.hashtags.join(", ")} /></Field>
              <div className="flex flex-wrap gap-2">
                <SubmitButton className="btn-primary">Salvar texto</SubmitButton>
                <SubmitButton className="btn-ghost" name="recompose" value="1" pendingText="Recompondo…">Salvar e recompor arte</SubmitButton>
              </div>
            </fieldset>
          </form>

            </>
          )}

          <form action={rescheduleAction} className="card flex flex-wrap items-end gap-3 p-5">
            <input type="hidden" name="id" value={post.id} />
            <Field label={`Data e hora (${brand.timezone})`}><input className="input" type="datetime-local" name="scheduledAt" defaultValue={toDatetimeLocal(post.scheduledAt, brand.timezone)} required disabled={locked} /></Field>
            <SubmitButton className="btn-ghost">Reagendar</SubmitButton>
          </form>

          <div className="card p-5">
            <h2 className="mb-3 font-semibold">Destinos, resultado e tentativas</h2>
            <div className="space-y-4">
              {post.targets.map((t) => {
                const m = t.metrics[0];
                return (
                  <div key={t.id} className="rounded-xl border border-slate-200 p-3">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-semibold">{NETWORK_LABEL[t.network]}</span>
                      <span className="badge bg-slate-100">{TARGET_STATUS_LABEL[t.status]}</span>
                      {t.socialAccount && <span className="text-xs text-ink-mute">{t.socialAccount.username ? `@${t.socialAccount.username}` : t.socialAccount.name}</span>}
                      {t.permalink && <a href={t.permalink} target="_blank" rel="noreferrer" className="text-xs text-accent">ver publicação ↗</a>}
                      {t.externalId && <span className="font-mono text-[11px] text-ink-mute">ID {t.externalId}</span>}
                      {admin && t.status === "FAILED" && !t.externalId && (
                        <form action={retryAction} className="ml-auto"><input type="hidden" name="postId" value={post.id} /><input type="hidden" name="targetId" value={t.id} /><SubmitButton className="btn-ghost btn-sm">Tentar novamente</SubmitButton></form>
                      )}
                    </div>
                    {t.lastError && <div className="mt-1 text-xs text-red-700">{t.lastError}</div>}
                    {m && (
                      <div className="mt-2 grid grid-cols-3 gap-2 text-xs sm:grid-cols-7">
                        {([["Visualizações", m.views], ["Alcance", m.reach], ["Curtidas", m.likes], ["Comentários", m.comments], ["Compart.", m.shares], ["Salvos", m.saves], ["Cliques", m.clicks]] as const).map(([k, v]) => (
                          <div key={k} className="rounded-lg bg-slate-50 p-2"><div className="text-ink-mute">{k}</div><div className="font-semibold">{v ?? "—"}</div></div>
                        ))}
                      </div>
                    )}
                    {t.attemptsLog.length > 0 && (
                      <details className="mt-2 text-xs">
                        <summary className="cursor-pointer text-ink-soft">{t.attemptsLog.length} tentativa(s)</summary>
                        <ul className="mt-1 space-y-1">
                          {t.attemptsLog.map((a) => (
                            <li key={a.id} className={a.success ? "text-emerald-700" : "text-red-700"}>
                              {formatDateTime(a.startedAt, brand.timezone)} — {a.success ? "sucesso" : `falha ${a.errorCode ?? ""}: ${a.errorMessage ?? ""}`}
                            </li>
                          ))}
                        </ul>
                      </details>
                    )}
                  </div>
                );
              })}
            </div>
            {post.links.length > 0 && <p className="mt-3 text-xs text-ink-mute">Cliques rastreados no WhatsApp: {post.links.reduce((a, l) => a + l._count.clicks, 0)}</p>}
          </div>

          {(post.funnelStage || post.hook || post.centralIdea) && (
            <div className="card space-y-1.5 p-5 text-sm">
              <h2 className="mb-1 font-semibold">Estratégia desta publicação</h2>
              {post.funnelStage && <p><span className="font-semibold">Função:</span> {FUNNEL_LABEL[post.funnelStage]}</p>}
              <p><span className="font-semibold">Objetivo:</span> {post.objective ?? "—"}</p>
              {post.angle && <p><span className="font-semibold">Ângulo:</span> {post.angle}</p>}
              {post.hook && <p><span className="font-semibold">Hook:</span> {post.hook}</p>}
              {post.centralIdea && <p><span className="font-semibold">Ideia central:</span> {post.centralIdea}</p>}
              {post.ctaPlan && <p><span className="font-semibold">CTA:</span> {post.ctaPlan}</p>}
              {post.strategyNote && <p className="text-ink-soft"><span className="font-semibold">Observação:</span> {post.strategyNote}</p>}
            </div>
          )}

          <details className="card p-5 text-sm">
            <summary className="cursor-pointer font-semibold">Direção de arte e prompt interno</summary>
            <p className="mt-2"><span className="font-semibold">Objetivo:</span> {post.objective ?? "—"}</p>
            {post.episodeSummary && <p className="mt-2"><span className="font-semibold">Resumo do episódio (memória da série):</span> {post.episodeSummary}</p>}
            <p className="mt-2"><span className="font-semibold">Direção de arte:</span> {post.artDirection ?? "—"}</p>
            <p className="mt-2 font-mono text-xs text-ink-soft">{post.imagePrompt ?? "—"}</p>
            {background && <p className="mt-2 text-xs text-ink-mute">Fundo: {background.asset.source === "AI" ? "gerado por IA" : "biblioteca"} ({background.asset.width}×{background.asset.height})</p>}
            <p className="mt-2 text-xs text-ink-mute">Modelo: {post.aiModel ?? "—"} · Origem: {post.origin === "AI" ? "agente de IA" : "manual"}</p>
          </details>
        </section>
      </div>
    </div>
  );
}
