// Imagem da publicação / Capa do Reels: prompt da imagem e a FOTO (manter, gerar nova com IA, escolher uma
// imagem já gerada/da biblioteca ou enviar do computador). Nos Reels também título, texto, chamada e layout
// da capa. Aplicar refaz só a arte/capa — o vídeo não muda.
import { db } from "@/lib/db";
import { Field } from "@/components/ui";
import { SubmitButton } from "@/components/client";
import { mediaPath } from "@/server/storage";
import { coverAction } from "../actions";
import { LAYOUTS } from "./full-editor";

export async function CoverEditor({ postId, back }: { postId: string; back?: string }) {
  const post = await db.post.findUnique({
    where: { id: postId },
    include: { media: { where: { purpose: { in: ["COVER", "BACKGROUND"] } }, include: { asset: true } } },
  });
  if (!post) return null;
  const reel = post.format === "REEL";
  const brief = post.status === "BRIEF_REVIEW";
  const cover = post.media.find((m) => m.purpose === "COVER");
  const photo = post.media.find((m) => m.purpose === "BACKGROUND");
  const library = await db.mediaAsset.findMany({
    where: { brandId: post.brandId, kind: "IMAGE", role: { in: ["PHOTO", "GENERATED", "REFERENCE", "CHARACTER_REFERENCE"] } },
    orderBy: { createdAt: "desc" },
    take: 36,
  });

  return (
    <form action={coverAction} className="card space-y-4 p-5">
      <input type="hidden" name="id" value={post.id} />
      {back && <input type="hidden" name="back" value={back} />}
      <div>
        <h2 className="font-semibold">{reel ? "Capa do Reels" : "Imagem da publicação"}</h2>
        <p className="text-xs text-ink-mute">
          {brief
            ? `A ${reel ? "capa" : "arte"} é produzida quando você aprovar o briefing. Escolha aqui a foto e o prompt que ${reel ? "ela" : "ela"} vai usar.`
            : reel
              ? "Editada separadamente do vídeo: aplicar aqui refaz só a capa (a imagem que aparece no feed e na grade). O vídeo não muda."
              : "Edite o prompt, envie uma foto do computador ou escolha uma imagem já gerada. Aplicar refaz a arte com os textos atuais."}
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-[150px_1fr]">
        <div className="space-y-2">
          <div className="text-[11px] font-bold uppercase tracking-wide text-ink-mute">{reel ? "Capa atual" : "Arte atual"}</div>
          {cover ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={mediaPath(cover.asset.storageKey)} alt="Capa atual" className="w-full rounded-lg border border-slate-200" />
          ) : (
            <div className="flex aspect-[9/16] items-center justify-center rounded-lg bg-slate-100 p-2 text-center text-xs text-ink-mute">{reel ? "Ainda sem capa" : "Ainda sem arte"}</div>
          )}
          {photo && (
            <>
              <div className="pt-1 text-[11px] font-bold uppercase tracking-wide text-ink-mute">Foto usada</div>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={mediaPath(photo.asset.storageKey)} alt="Foto da capa" className="w-full rounded-lg border border-slate-200" />
              <div className="text-[11px] text-ink-mute">{photo.asset.source === "AI" ? "Gerada por IA" : "Sua foto"}</div>
            </>
          )}
        </div>

        <div className="space-y-4">
          {reel && (
            <>
          <Field label="Título da capa"><input className="input" name="title" defaultValue={post.title ?? ""} maxLength={120} /></Field>
          <Field label="Texto secundário"><input className="input" name="subtitle" defaultValue={post.subtitle ?? ""} maxLength={200} /></Field>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Chamada para ação"><input className="input" name="cta" defaultValue={post.cta ?? ""} maxLength={80} /></Field>
            <Field label="Layout da capa">
              <select className="input" name="layout" defaultValue={post.layout ?? "hero-bottom"}>
                {LAYOUTS.filter((l) => l.v !== "carousel").map((l) => <option key={l.v} value={l.v}>{l.l}</option>)}
              </select>
            </Field>
          </div>

            </>
          )}
          <fieldset className="space-y-2 rounded-xl border border-slate-200 p-3">
            <legend className="px-1 text-[11px] font-bold uppercase tracking-wide text-ink-mute">{reel ? "Foto da capa" : "Foto da arte"}</legend>
            <label className="flex items-center gap-2 text-sm"><input type="radio" name="photo" value="keep" defaultChecked /> Manter a foto atual</label>
            <label className="flex items-center gap-2 text-sm"><input type="radio" name="photo" value="ai" /> Gerar nova foto com IA (usa o prompt abaixo)</label>
            <div className="pt-1 text-sm">Ou escolha uma imagem já gerada / da biblioteca:</div>
            {library.length ? (
              <div className="grid max-h-64 grid-cols-4 gap-2 overflow-y-auto pr-1 sm:grid-cols-6">
                {library.map((a) => (
                  <label key={a.id} className="group relative cursor-pointer" title={a.title ?? a.originalName ?? ""}>
                    <input type="radio" name="libraryId" value={a.id} className="peer absolute left-1 top-1 z-10 h-4 w-4" />
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={mediaPath(a.storageKey)} alt="" loading="lazy" className="aspect-square w-full rounded-md border-2 border-transparent object-cover peer-checked:border-accent peer-checked:ring-2 peer-checked:ring-accent" />
                    {a.id === photo?.assetId && <span className="absolute bottom-1 left-1 rounded bg-white/90 px-1 text-[10px]">atual</span>}
                    {a.role === "GENERATED" && <span className="absolute bottom-1 right-1 rounded bg-indigo-600/90 px-1 text-[10px] text-white">IA</span>}
                  </label>
                ))}
              </div>
            ) : (
              <p className="text-xs text-ink-mute">Nenhuma imagem na biblioteca ainda.</p>
            )}
            <div className="pt-1 text-sm">Ou envie uma foto do computador:</div>
            <input type="file" name="file" accept="image/jpeg,image/png,image/webp" className="block w-full text-sm" />
            <p className="text-[11px] text-ink-mute">Prioridade: foto enviada → imagem escolhida na grade → “gerar nova com IA” → manter a atual.</p>
          </fieldset>

          <Field label="Prompt da foto (usado quando a foto é gerada por IA)">
            <textarea className="input min-h-24 font-mono text-xs" name="imagePrompt" defaultValue={post.imagePrompt ?? ""} maxLength={4000} />
          </Field>
          <Field label="Direção de arte">
            <input className="input" name="artDirection" defaultValue={post.artDirection ?? ""} maxLength={1000} />
          </Field>
        </div>
      </div>

      <div className="flex flex-wrap gap-2 border-t border-slate-100 pt-4">
        <SubmitButton name="op" value="save" className="btn-ghost" pendingText="Aguarde…">{reel ? "Salvar capa" : "Salvar imagem"}</SubmitButton>
        {!brief && (
          <SubmitButton name="op" value="apply" className="btn-accent" pendingText={reel ? "Refazendo a capa…" : "Refazendo a arte…"}>
            {reel ? "Aplicar e refazer só a capa" : "Aplicar e refazer a arte"}
          </SubmitButton>
        )}
      </div>
    </form>
  );
}
