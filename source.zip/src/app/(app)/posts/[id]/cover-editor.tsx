// Capa do Reels: edição separada do vídeo. Título, texto, chamada, layout, prompt e a FOTO (manter, gerar
// nova com IA, escolher da biblioteca ou enviar do computador). Aplicar refaz só a capa — o vídeo não muda.
import { db } from "@/lib/db";
import { Field } from "@/components/ui";
import { SubmitButton } from "@/components/client";
import { mediaPath } from "@/server/storage";
import { coverAction } from "../actions";
import { LAYOUTS } from "./full-editor";

export async function CoverEditor({ postId, back }: { postId: string; back?: string }) {
  const post = await db.post.findUnique({
    where: { id: postId },
    include: { media: { where: { purpose: { in: ["COVER", "BACKGROUND"] } }, include: { asset: true } } },
  });
  if (!post || post.format !== "REEL") return null;
  const brief = post.status === "BRIEF_REVIEW";
  const cover = post.media.find((m) => m.purpose === "COVER");
  const photo = post.media.find((m) => m.purpose === "BACKGROUND");
  const library = await db.mediaAsset.findMany({
    where: { brandId: post.brandId, kind: "IMAGE", role: { in: ["PHOTO", "GENERATED", "REFERENCE", "CHARACTER_REFERENCE"] } },
    orderBy: { createdAt: "desc" },
    take: 30,
  });

  return (
    <form action={coverAction} className="card space-y-4 p-5">
      <input type="hidden" name="id" value={post.id} />
      {back && <input type="hidden" name="back" value={back} />}
      <div>
        <h2 className="font-semibold">Capa do Reels</h2>
        <p className="text-xs text-ink-mute">
          {brief
            ? "A capa é produzida junto com o vídeo quando você aprovar o briefing. Ajuste aqui o texto e a foto que ela vai usar."
            : "Editada separadamente do vídeo: aplicar aqui refaz só a capa (a imagem que aparece no feed e na grade). O vídeo não muda."}
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-[150px_1fr]">
        <div className="space-y-2">
          <div className="text-[11px] font-bold uppercase tracking-wide text-ink-mute">Capa atual</div>
          {cover ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={mediaPath(cover.asset.storageKey)} alt="Capa atual" className="w-full rounded-lg border border-slate-200" />
          ) : (
            <div className="flex aspect-[9/16] items-center justify-center rounded-lg bg-slate-100 p-2 text-center text-xs text-ink-mute">Ainda sem capa</div>
          )}
          {photo && (
            <>
              <div className="pt-1 text-[11px] font-bold uppercase tracking-wide text-ink-mute">Foto usada</div>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={mediaPath(photo.asset.storageKey)} alt="Foto da capa" className="w-full rounded-lg border border-slate-200" />
              <div className="text-[11px] text-ink-mute">{photo.asset.source === "AI" ? "Gerada por IA" : "Sua foto"}</div>
            </>
          )}
        </div>

        <div className="space-y-4">
          <Field label="Título da capa"><input className="input" name="title" defaultValue={post.title ?? ""} maxLength={120} /></Field>
          <Field label="Texto secundário"><input className="input" name="subtitle" defaultValue={post.subtitle ?? ""} maxLength={200} /></Field>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Chamada para ação"><input className="input" name="cta" defaultValue={post.cta ?? ""} maxLength={80} /></Field>
            <Field label="Layout da capa">
              <select className="input" name="layout" defaultValue={post.layout ?? "hero-bottom"}>
                {LAYOUTS.filter((l) => l.v !== "carousel").map((l) => <option key={l.v} value={l.v}>{l.l}</option>)}
              </select>
            </Field>
          </div>

          <fieldset className="space-y-2 rounded-xl border border-slate-200 p-3">
            <legend className="px-1 text-[11px] font-bold uppercase tracking-wide text-ink-mute">Foto da capa</legend>
            <label className="flex items-center gap-2 text-sm"><input type="radio" name="photo" value="keep" defaultChecked /> Manter a foto atual</label>
            <label className="flex items-center gap-2 text-sm"><input type="radio" name="photo" value="ai" /> Gerar nova foto com IA (usa o prompt abaixo)</label>
            <label className="flex items-center gap-2 text-sm"><input type="radio" name="photo" value="library" /> Usar foto da biblioteca</label>
            <select name="libraryId" className="input py-1.5 text-sm" defaultValue="">
              <option value="">— escolha a foto —</option>
              {library.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.title ?? a.originalName ?? a.id} ({a.role === "GENERATED" ? "IA" : a.role === "PHOTO" ? "foto" : "referência"})
                </option>
              ))}
            </select>
            <label className="flex items-center gap-2 text-sm"><input type="radio" name="photo" value="upload" /> Enviar foto do computador</label>
            <input type="file" name="file" accept="image/jpeg,image/png,image/webp" className="block w-full text-sm" />
            <p className="text-[11px] text-ink-mute">Ao escolher ou enviar uma foto, basta selecionar o arquivo — o app marca a opção certa sozinho.</p>
          </fieldset>

          <Field label="Prompt da foto (usado quando a foto é gerada por IA)">
            <textarea className="input min-h-24 font-mono text-xs" name="imagePrompt" defaultValue={post.imagePrompt ?? ""} maxLength={4000} />
          </Field>
          <Field label="Direção de arte">
            <input className="input" name="artDirection" defaultValue={post.artDirection ?? ""} maxLength={1000} />
          </Field>
        </div>
      </div>

      <div className="flex flex-wrap gap-2 border-t border-slate-100 pt-4">
        <SubmitButton name="op" value="save" className="btn-ghost" pendingText="Aguarde…">Salvar capa</SubmitButton>
        {!brief && (
          <SubmitButton name="op" value="apply" className="btn-accent" pendingText="Refazendo a capa…">
            Aplicar e refazer só a capa
          </SubmitButton>
        )}
      </div>
    </form>
  );
}
