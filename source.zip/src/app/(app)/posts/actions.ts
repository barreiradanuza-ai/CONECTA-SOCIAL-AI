"use server";
import type { Network, Pillar, PostFormat } from "@prisma/client";
import { requireBrand } from "@/lib/auth";
import { runAction, str, lines } from "@/lib/actions";
import { fromDatetimeLocal } from "@/lib/time";
import { approvePost, cancelPost, createManualPost, getPostForOrg, publishNow, rejectToDraft, reschedulePost, retryTarget, updatePostContent } from "@/server/posts";
import { producePost } from "@/server/production";
import { audit } from "@/server/audit";
import { db } from "@/lib/db";
import { getBrandContext } from "@/server/brand";
import { generateReelScript, rewriteReelScene } from "@/server/ai/agent";
import { joinScenes, scenesFromForm } from "@/lib/scenes";
import { checkCommercialText, formatBRL, isOfferValid } from "@/server/guard";

const back = (id: string) => `/posts/${id}`;

export async function approveAction(form: FormData) {
  const { auth } = await requireBrand("ADMIN");
  const id = str(form, "id");
  return runAction(str(form, "back") || back(id), async () => {
    await approvePost(auth.orgId, auth.user.id, id);
    return "Publicação aprovada e agendada.";
  });
}

export async function unapproveAction(form: FormData) {
  const { auth } = await requireBrand("ADMIN");
  const id = str(form, "id");
  return runAction(back(id), async () => {
    await rejectToDraft(auth.orgId, auth.user.id, id);
    return "Publicação voltou para rascunho.";
  });
}

export async function cancelAction(form: FormData) {
  const { auth } = await requireBrand("EDITOR");
  const id = str(form, "id");
  return runAction(str(form, "back") || back(id), async () => {
    await cancelPost(auth.orgId, auth.user.id, id);
    return "Agendamento cancelado. O conteúdo foi mantido.";
  });
}

export async function publishNowAction(form: FormData) {
  const { auth } = await requireBrand("ADMIN");
  const id = str(form, "id");
  return runAction(back(id), async () => {
    await publishNow(auth.orgId, auth.user.id, id);
    return "Enviado para a fila de publicação. O worker publica em até 1 minuto.";
  });
}

export async function rescheduleAction(form: FormData) {
  const { auth, brand } = await requireBrand("EDITOR");
  const id = str(form, "id");
  return runAction(back(id), async () => {
    const at = fromDatetimeLocal(str(form, "scheduledAt"), brand.timezone);
    await reschedulePost(auth.orgId, auth.user.id, id, at);
    return "Horário atualizado.";
  });
}

export async function retryAction(form: FormData) {
  const { auth } = await requireBrand("ADMIN");
  return runAction(back(str(form, "postId")), async () => {
    await retryTarget(auth.orgId, auth.user.id, str(form, "targetId"));
    return "Nova tentativa enfileirada.";
  });
}

export async function saveContentAction(form: FormData) {
  const { auth } = await requireBrand("EDITOR");
  const id = str(form, "id");
  return runAction(back(id), async () => {
    const slidesRaw = str(form, "slides");
    const slides = slidesRaw
      ? slidesRaw.split(/\n-{3,}\n/).map((block) => {
          const [title, ...body] = block.trim().split("\n");
          return { title: title.trim(), body: body.join(" ").trim() };
        })
      : undefined;
    await updatePostContent(auth.orgId, auth.user.id, id, {
      title: str(form, "title"),
      subtitle: str(form, "subtitle"),
      cta: str(form, "cta"),
      theme: str(form, "theme") || undefined,
      layout: str(form, "layout") || undefined,
      hashtags: lines(form, "hashtags").map((h) => h.replace(/^#/, "")),
      captions: { INSTAGRAM: str(form, "caption_INSTAGRAM") || undefined, FACEBOOK: str(form, "caption_FACEBOOK") || undefined, TIKTOK: str(form, "caption_TIKTOK") || undefined },
      slides,
    });
    if (form.get("recompose") === "1") {
      await producePost(id, { actor: "user" });
      return "Conteúdo salvo e arte recomposta. Revise e aprove.";
    }
    return "Conteúdo salvo. A publicação voltou para aprovação.";
  });
}

export async function regenerateAction(form: FormData) {
  const { auth } = await requireBrand("EDITOR");
  const id = str(form, "id");
  return runAction(back(id), async () => {
    await getPostForOrg(auth.orgId, id);
    const mode = str(form, "mode");
    const bg = str(form, "backgroundAssetId");
    if (bg) {
      const a = await db.mediaAsset.findFirst({ where: { id: bg, orgId: auth.orgId } });
      if (!a) throw new Error("Imagem não encontrada.");
    }
    if (mode === "brief") {
      const rb = await producePost(id, { actor: "user", regenerateText: true, stopAfterText: true, extraInstructions: str(form, "instructions") || undefined });
      await audit(auth.orgId, "post.brief.generate", { userId: auth.user.id, entity: "Post", entityId: id });
      return rb.errors.length ? `Briefing gerado, mas revise: ${rb.errors[0]}` : "Briefing gerado. Revise, edite e aprove para produção.";
    }
    const r = await producePost(id, {
      actor: "user",
      regenerateText: mode === "text" || mode === "all",
      regenerateImage: mode === "image" || mode === "all",
      backgroundAssetId: bg || undefined,
      extraInstructions: str(form, "instructions") || undefined,
    });
    await audit(auth.orgId, "post.generate", { userId: auth.user.id, entity: "Post", entityId: id, meta: { mode } });
    return r.errors.length ? `Gerado com alertas de validação: ${r.errors[0]}` : "Conteúdo gerado. Revise e aprove.";
  });
}

export async function saveImagePromptAction(form: FormData) {
  const { auth } = await requireBrand("EDITOR");
  const id = str(form, "id");
  return runAction(back(id), async () => {
    const post = await getPostForOrg(auth.orgId, id);
    if (["PUBLISHED", "PUBLISHING"].includes(post.status)) throw new Error("Publicação já publicada: o prompt não pode mais ser alterado.");
    const imagePrompt = String(form.get("imagePrompt") ?? "").trim().slice(0, 4000);
    const artDirection = String(form.get("artDirection") ?? "").trim().slice(0, 1000);
    if (!imagePrompt) throw new Error("Escreva o prompt da imagem.");
    await db.post.update({ where: { id }, data: { imagePrompt, artDirection: artDirection || null } });
    const generate = str(form, "op") === "generate";
    await audit(auth.orgId, "post.prompt", { userId: auth.user.id, entity: "Post", entityId: id, meta: { generate } });
    if (!generate) return "Prompt salvo. Clique em “Salvar e gerar nova imagem” quando quiser aplicar.";
    const r = await producePost(id, { actor: "user", regenerateImage: true });
    return r.errors.length ? `Nova imagem gerada com alertas de validação: ${r.errors[0]}` : "Nova imagem gerada com o seu prompt. Revise e aprove.";
  });
}

export async function saveReelScriptAction(form: FormData) {
  const { auth } = await requireBrand("EDITOR");
  const id = str(form, "id");
  return runAction(back(id), async () => {
    const post = await getPostForOrg(auth.orgId, id);
    if (["PUBLISHED", "PUBLISHING"].includes(post.status)) throw new Error("Publicação já publicada: o roteiro não pode mais ser alterado.");
    const reelScript = String(form.get("reelScript") ?? "").trim().slice(0, 8000);
    await db.post.update({ where: { id }, data: { reelScript: reelScript || null } });
    await audit(auth.orgId, "post.reelScript", { userId: auth.user.id, entity: "Post", entityId: id });
    return "Roteiro salvo.";
  });
}

export async function regenerateReelScriptAction(form: FormData) {
  const { auth } = await requireBrand("EDITOR");
  const id = str(form, "id");
  return runAction(back(id), async () => {
    await getPostForOrg(auth.orgId, id);
    const post = await db.post.findUniqueOrThrow({ where: { id }, include: { brand: true, offer: true } });
    if (["PUBLISHED", "PUBLISHING"].includes(post.status)) throw new Error("Publicação já publicada: o roteiro não pode mais ser alterado.");
    const when = post.scheduledAt ?? new Date();
    const offer = post.offer && isOfferValid(post.offer, when) ? post.offer : null;
    const offerText = offer
      ? `${offer.operator} · ${offer.speedMbps} Mega · ${formatBRL(offer.priceCents)}${offer.pricePeriod ?? ""}`
      : null;
    const ctx = await getBrandContext(post.brand);
    const { script } = await generateReelScript(auth.orgId, ctx, {
      pillar: post.pillar,
      theme: post.theme,
      objective: post.objective,
      hook: post.hook,
      centralIdea: post.centralIdea,
      ctaPlan: post.ctaPlan,
      currentScript: post.reelScript,
      instructions: str(form, "instructions") || null,
      offerText,
    });
    await db.post.update({ where: { id }, data: { reelScript: script } });
    await audit(auth.orgId, "post.reelScript.generate", { userId: auth.user.id, entity: "Post", entityId: id });
    const guard = checkCommercialText([script], offer, when);
    return guard.violations.length
      ? `Novo roteiro gerado, mas revise: ${guard.violations[0]}`
      : "Novo roteiro gerado. Revise e ajuste se quiser.";
  });
}

export async function reelScenesAction(form: FormData) {
  const { auth } = await requireBrand("EDITOR");
  const id = str(form, "id");
  return runAction(back(id), async () => {
    await getPostForOrg(auth.orgId, id);
    const post = await db.post.findUniqueOrThrow({ where: { id }, include: { brand: true, offer: true } });
    if (["PUBLISHED", "PUBLISHING"].includes(post.status)) throw new Error("Publicação já publicada: o roteiro não pode mais ser alterado.");
    const op = str(form, "op") || "save";
    let scenes = scenesFromForm(form).map((s) => s.replace(/\r\n/g, "\n").trim());

    if (op === "add") scenes.push("Nova cena: descreva a ação e a fala.");
    const removeMatch = /^remove:(\d+)$/.exec(op);
    if (removeMatch) scenes.splice(Number(removeMatch[1]), 1);
    scenes = scenes.filter(Boolean);
    const when = post.scheduledAt ?? new Date();
    const offer = post.offer && isOfferValid(post.offer, when) ? post.offer : null;
    const offerText = offer ? `${offer.operator} · ${offer.speedMbps} Mega · ${formatBRL(offer.priceCents)}${offer.pricePeriod}` : null;

    // Gerar novamente uma única parte
    const sceneMatch = /^scene:(\d+)$/.exec(op);
    if (sceneMatch) {
      const index = Number(sceneMatch[1]);
      if (index < 0 || index >= scenes.length) throw new Error("Parte do roteiro não encontrada.");
      const ctx = await getBrandContext(post.brand);
      scenes[index] = await rewriteReelScene(auth.orgId, ctx, {
        theme: post.theme,
        scenes,
        index,
        instructions: str(form, `note_${index}`) || null,
        offerText,
      });
    }

    const script = joinScenes(scenes);
    if (!script) throw new Error("O roteiro está vazio.");
    await db.post.update({ where: { id }, data: { reelScript: script } });

    if (op !== "all") {
      await audit(auth.orgId, "post.reelScript", { userId: auth.user.id, entity: "Post", entityId: id, meta: { op } });
      if (sceneMatch) {
        const g = checkCommercialText([scenes[Number(sceneMatch[1])]], offer, when);
        return g.violations.length ? `Parte ${Number(sceneMatch[1]) + 1} gerada novamente, mas revise: ${g.violations[0]}` : `Parte ${Number(sceneMatch[1]) + 1} gerada novamente.`;
      }
      if (op === "add") return "Cena adicionada no final. Edite o texto e salve.";
      if (removeMatch) return "Cena removida.";
      return "Roteiro salvo.";
    }

    // Gerar tudo agora a partir do roteiro editado: título, legendas, imagem e vídeo
    const aiVideos = await db.postMedia.findMany({ where: { postId: id, purpose: "VIDEO", asset: { source: "AI" } }, select: { id: true } });
    if (aiVideos.length) await db.postMedia.deleteMany({ where: { id: { in: aiVideos.map((v) => v.id) } } });
    await db.videoJob.deleteMany({ where: { postId: id, status: "QUEUED" } });
    const r = await producePost(id, {
      actor: "user",
      regenerateText: true,
      regenerateImage: true,
      lockedReelScript: script,
      extraInstructions: str(form, "instructions") || undefined,
    });
    await audit(auth.orgId, "post.generate", { userId: auth.user.id, entity: "Post", entityId: id, meta: { mode: "reel-all" } });
    const guard = checkCommercialText([script], offer, when);
    const alert = r.errors[0] ?? guard.violations[0];
    return alert
      ? `Tudo gerado com o seu roteiro, mas revise: ${alert}`
      : "Tudo gerado com o seu roteiro: capa, título, legendas e imagem prontos. O vídeo entra em produção agora e aparece aqui em alguns minutos.";
  });
}

// ───────── Briefing (etapa 1 de 2): revisar e aprovar antes de produzir ─────────

function slidesFrom(raw: string) {
  return raw
    ? raw.split(/\n-{3,}\n/).map((block) => {
        const [title, ...body] = block.trim().split("\n");
        return { title: (title ?? "").trim(), body: body.join(" ").trim() };
      })
    : undefined;
}

export async function briefAction(form: FormData) {
  const { auth } = await requireBrand("EDITOR");
  const id = str(form, "id");
  const backTo = str(form, "back");
  const dest = backTo.startsWith("/") && !backTo.startsWith("//") ? backTo : back(id);
  return runAction(dest, async () => {
    const before = await getPostForOrg(auth.orgId, id);
    const isBrief = before.status === "BRIEF_REVIEW";
    if (["PUBLISHED", "PUBLISHING"].includes(before.status)) throw new Error("Publicação já publicada.");
    const op = str(form, "op") || "save";

    // 1) Salva tudo o que está no formulário
    await updatePostContent(auth.orgId, auth.user.id, id, {
      title: str(form, "title"),
      subtitle: str(form, "subtitle"),
      cta: str(form, "cta"),
      theme: str(form, "theme") || undefined,
      layout: str(form, "layout") || undefined,
      hashtags: lines(form, "hashtags").map((h) => h.replace(/^#/, "")),
      captions: { INSTAGRAM: str(form, "caption_INSTAGRAM") || undefined, FACEBOOK: str(form, "caption_FACEBOOK") || undefined, TIKTOK: str(form, "caption_TIKTOK") || undefined },
      slides: slidesFrom(str(form, "slides")),
    });
    let scenes = scenesFromForm(form).map((x) => x.replace(/\r\n/g, "\n").trim());
    if (op === "add") scenes.push("Nova cena: descreva a ação e a fala.");
    const removeMatch = /^remove:(\d+)$/.exec(op);
    if (removeMatch) scenes.splice(Number(removeMatch[1]), 1);
    scenes = scenes.filter(Boolean);

    const post = await db.post.findUniqueOrThrow({ where: { id }, include: { brand: true, offer: true } });
    const when = post.scheduledAt ?? new Date();
    const offer = post.offer && isOfferValid(post.offer, when) ? post.offer : null;
    const sceneMatch = /^scene:(\d+)$/.exec(op);
    if (sceneMatch) {
      const index = Number(sceneMatch[1]);
      if (index < 0 || index >= scenes.length) throw new Error("Parte do roteiro não encontrada.");
      const ctx = await getBrandContext(post.brand);
      scenes[index] = await rewriteReelScene(auth.orgId, ctx, {
        theme: post.theme,
        scenes,
        index,
        instructions: str(form, `note_${index}`) || null,
        offerText: offer ? `${offer.operator} · ${offer.speedMbps} Mega · ${formatBRL(offer.priceCents)}${offer.pricePeriod}` : null,
      });
    }
    await db.post.update({
      where: { id },
      data: {
        imagePrompt: str(form, "imagePrompt") || null,
        artDirection: str(form, "artDirection") || null,
        ...(post.format === "REEL"
          ? { reelScript: joinScenes(scenes) || null, videoSpeech: str(form, "videoSpeech") || null, videoPrompt: str(form, "videoPrompt") || null }
          : {}),
      },
    });

    if (op === "redo") {
      const r = await producePost(id, { actor: "user", regenerateText: true, stopAfterText: isBrief, extraInstructions: str(form, "instructions") || undefined });
      await audit(auth.orgId, "post.brief.redo", { userId: auth.user.id, entity: "Post", entityId: id });
      return r.errors.length ? `Novo briefing gerado, mas revise: ${r.errors[0]}` : "Novo briefing gerado. Revise e aprove para produção.";
    }

    if (op === "produce") {
      // Refaz imagem, arte/slides e vídeo com o conteúdo exatamente como está (sem reescrever o texto)
      const aiVideos = await db.postMedia.findMany({ where: { postId: id, purpose: "VIDEO", asset: { source: "AI" } }, select: { id: true } });
      if (aiVideos.length) await db.postMedia.deleteMany({ where: { id: { in: aiVideos.map((v) => v.id) } } });
      await db.videoJob.deleteMany({ where: { postId: id, status: "QUEUED" } });
      const r = await producePost(id, { actor: "user", regenerateImage: true });
      await audit(auth.orgId, "post.produce", { userId: auth.user.id, entity: "Post", entityId: id });
      const extra = post.format === "REEL" ? " O novo vídeo entra em produção e aparece na publicação em alguns minutos." : "";
      return r.errors.length ? `Gerado com alertas: ${r.errors[0]}. Revise e aprove.` : `Tudo gerado novamente com as suas alterações. Revise e aprove.${extra}`;
    }

    if (op === "approve") {
      const fresh = await db.post.findUniqueOrThrow({ where: { id } });
      if (!fresh.title) throw new Error("O briefing está sem título da arte.");
      if (fresh.format === "REEL" && !fresh.reelScript) throw new Error("O roteiro do Reels está vazio.");
      await db.post.update({ where: { id }, data: { briefApprovedAt: new Date(), briefApprovedById: auth.user.id } });
      await audit(auth.orgId, "post.brief.approve", { userId: auth.user.id, entity: "Post", entityId: id });
      // Etapa 2: produz agora (imagem, arte, carrossel e vídeo) com o briefing exatamente como aprovado
      const r = await producePost(id, { actor: "user", regenerateImage: true });
      const extra = fresh.format === "REEL" ? " O vídeo entra em produção e aparece aqui em alguns minutos." : "";
      return r.errors.length
        ? `Produzido com alertas: ${r.errors[0]}. Revise e aprove para publicação.`
        : `Briefing aprovado e produzido. Agora confira o resultado e aprove para publicação.${extra}`;
    }

    await audit(auth.orgId, "post.brief.edit", { userId: auth.user.id, entity: "Post", entityId: id, meta: { op } });
    if (sceneMatch) return `Parte ${Number(sceneMatch[1]) + 1} gerada novamente.`;
    if (op === "add") return "Parte adicionada no final do roteiro.";
    if (removeMatch) return "Parte removida.";
    return "Briefing salvo.";
  });
}

export async function attachVideoAction(form: FormData) {
  const { auth } = await requireBrand("EDITOR");
  const id = str(form, "id");
  return runAction(back(id), async () => {
    await getPostForOrg(auth.orgId, id);
    const video = await db.mediaAsset.findFirst({ where: { id: str(form, "videoId"), orgId: auth.orgId, kind: "VIDEO" } });
    if (!video) throw new Error("Vídeo não encontrado.");
    await db.postMedia.deleteMany({ where: { postId: id, purpose: "VIDEO" } });
    await db.postMedia.create({ data: { postId: id, assetId: video.id, purpose: "VIDEO" } });
    await producePost(id, { actor: "user" });
    return "Vídeo vinculado ao Reels.";
  });
}

export async function createPostAction(form: FormData) {
  const { auth, brand } = await requireBrand("EDITOR");
  return runAction(str(form, "back") || "/posts", async () => {
    const networks = form.getAll("networks").map(String) as Network[];
    if (!networks.length) throw new Error("Selecione ao menos uma rede.");
    const theme = str(form, "theme");
    if (!theme) throw new Error("Informe o tema.");
    const when = str(form, "scheduledAt");
    const post = await createManualPost({
      orgId: auth.orgId,
      userId: auth.user.id,
      brandId: brand.id,
      pillar: (str(form, "pillar") || "EDUCATION") as Pillar,
      format: (str(form, "format") || "FEED_IMAGE") as PostFormat,
      theme,
      objective: str(form, "objective") || undefined,
      networks,
      scheduledAt: when ? fromDatetimeLocal(when, brand.timezone) : null,
      offerId: str(form, "offerId") || null,
    });
    if (form.get("generate") === "1") {
      await producePost(post.id, { actor: "user", extraInstructions: str(form, "instructions") || undefined });
    }
    return { message: "Publicação criada.", redirectTo: `/posts/${post.id}` };
  });
}
