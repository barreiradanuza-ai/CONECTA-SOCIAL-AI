"use server";
import type { Network, Pillar, PostFormat } from "@prisma/client";
import { requireBrand } from "@/lib/auth";
import { runAction, str, lines } from "@/lib/actions";
import { fromDatetimeLocal } from "@/lib/time";
import { approvePost, cancelPost, createManualPost, getPostForOrg, publishNow, rejectToDraft, reschedulePost, retryTarget, updatePostContent } from "@/server/posts";
import { producePost } from "@/server/production";
import { audit } from "@/server/audit";
import { db } from "@/lib/db";
import { getBrandContext } from "@/server/brand";
import { generateReelScript, rewriteReelScene } from "@/server/ai/agent";
import { joinScenes, scenesFromForm } from "@/lib/scenes";
import { checkCommercialText, formatBRL, isOfferValid } from "@/server/guard";
import { saveAsset } from "@/server/media";

const back = (id: string) => `/posts/${id}`;

export async function approveAction(form: FormData) {
  const { auth } = await requireBrand("ADMIN");
  const id = str(form, "id");
  return runAction(str(form, "back") || back(id), async () => {
    await approvePost(auth.orgId, auth.user.id, id);
    return "Publicação aprovada e agendada.";
  });
}

export async function unapproveAction(form: FormData) {
  const { auth } = await requireBrand("ADMIN");
  const id = str(form, "id");
  return runAction(back(id), async () => {
    await rejectToDraft(auth.orgId, auth.user.id, id);
    return "Publicação voltou para rascunho.";
  });
}

export async function cancelAction(form: FormData) {
  const { auth } = await requireBrand("EDITOR");
  const id = str(form, "id");
  return runAction(str(form, "back") || back(id), async () => {
    await cancelPost(auth.orgId, auth.user.id, id);
    return "Agendamento cancelado. O conteúdo foi mantido.";
  });
}

export async function publishNowAction(form: FormData) {
  const { auth } = await requireBrand("ADMIN");
  const id = str(form, "id");
  return runAction(back(id), async () => {
    await publishNow(auth.orgId, auth.user.id, id);
    return "Enviado para a fila de publicação. O worker publica em até 1 minuto.";
  });
}

export async function rescheduleAction(form: FormData) {
  const { auth, brand } = await requireBrand("EDITOR");
  const id = str(form, "id");
  return runAction(back(id), async () => {
    const at = fromDatetimeLocal(str(form, "scheduledAt"), brand.timezone);
    await reschedulePost(auth.orgId, auth.user.id, id, at);
    return "Horário atualizado.";
  });
}

export async function retryAction(form: FormData) {
  const { auth } = await requireBrand("ADMIN");
  return runAction(back(str(form, "postId")), async () => {
    await retryTarget(auth.orgId, auth.user.id, str(form, "targetId"));
    return "Nova tentativa enfileirada.";
  });
}

export async function saveContentAction(form: FormData) {
  const { auth } = await requireBrand("EDITOR");
  const id = str(form, "id");
  return runAction(back(id), async () => {
    const slidesRaw = str(form, "slides");
    const slides = slidesRaw
      ? slidesRaw.split(/\n-{3,}\n/).map((block) => {
          const [title, ...body] = block.trim().split("\n");
          return { title: title.trim(), body: body.join(" ").trim() };
        })
      : undefined;
    await updatePostContent(auth.orgId, auth.user.id, id, {
      title: str(form, "title"),
      subtitle: str(form, "subtitle"),
      cta: str(form, "cta"),
      theme: str(form, "theme") || undefined,
      layout: str(form, "layout") || undefined,
      hashtags: lines(form, "hashtags").map((h) => h.replace(/^#/, "")),
      captions: { INSTAGRAM: str(form, "caption_INSTAGRAM") || undefined, FACEBOOK: str(form, "caption_FACEBOOK") || undefined, TIKTOK: str(form, "caption_TIKTOK") || undefined },
      slides,
    });
    if (form.get("recompose") === "1") {
      await producePost(id, { actor: "user" });
      return "Conteúdo salvo e arte recomposta. Revise e aprove.";
    }
    return "Conteúdo salvo. A publicação voltou para aprovação.";
  });
}

export async function regenerateAction(form: FormData) {
  const { auth } = await requireBrand("EDITOR");
  const id = str(form, "id");
  return runAction(back(id), async () => {
    await getPostForOrg(auth.orgId, id);
    const mode = str(form, "mode");
    const bg = str(form, "backgroundAssetId");
    if (bg) {
      const a = await db.mediaAsset.findFirst({ where: { id: bg, orgId: auth.orgId } });
      if (!a) throw new Error("Imagem não encontrada.");
    }
    if (mode === "brief") {
      const rb = await producePost(id, { actor: "user", regenerateText: true, stopAfterText: true, extraInstructions: str(form, "instructions") || undefined });
      await audit(auth.orgId, "post.brief.generate", { userId: auth.user.id, entity: "Post", entityId: id });
      return rb.errors.length ? `Briefing gerado, mas revise: ${rb.errors[0]}` : "Briefing gerado. Revise, edite e aprove para produção.";
    }
    const r = await producePost(id, {
      actor: "user",
      regenerateText: mode === "text" || mode === "all",
      regenerateImage: mode === "image" || mode === "all",
      backgroundAssetId: bg || undefined,
      extraInstructions: str(form, "instructions") || undefined,
    });
    await audit(auth.orgId, "post.generate", { userId: auth.user.id, entity: "Post", entityId: id, meta: { mode } });
    return r.errors.length ? `Gerado com alertas de validação: ${r.errors[0]}` : "Conteúdo gerado. Revise e aprove.";
  });
}

export async function saveImagePromptAction(form: FormData) {
  const { auth } = await requireBrand("EDITOR");
  const id = str(form, "id");
  return runAction(back(id), async () => {
    const post = await getPostForOrg(auth.orgId, id);
    if (["PUBLISHED", "PUBLISHING"].includes(post.status)) throw new Error("Publicação já publicada: o prompt não pode mais ser alterado.");
    const imagePrompt = String(form.get("imagePrompt") ?? "").trim().slice(0, 4000);
    const artDirection = String(form.get("artDirection") ?? "").trim().slice(0, 1000);
    if (!imagePrompt) throw new Error("Escreva o prompt da imagem.");
    await db.post.update({ where: { id }, data: { imagePrompt, artDirection: artDirection || null } });
    const generate = str(form, "op") === "generate";
    await audit(auth.orgId, "post.prompt", { userId: auth.user.id, entity: "Post", entityId: id, meta: { generate } });
    if (!generate) return "Prompt salvo. Clique em “Salvar e gerar nova imagem” quando quiser aplicar.";
    const r = await producePost(id, { actor: "user", regenerateImage: true });
    return r.errors.length ? `Nova imagem gerada com alertas de validação: ${r.errors[0]}` : "Nova imagem gerada com o seu prompt. Revise e aprove.";
  });
}

export async function saveReelScriptAction(form: FormData) {
  const { auth } = await requireBrand("EDITOR");
  const id = str(form, "id");
  return runAction(back(id), async () => {
    const post = await getPostForOrg(auth.orgId, id);
    if (["PUBLISHED", "PUBLISHING"].includes(post.status)) throw new Error("Publicação já publicada: o roteiro não pode mais ser alterado.");
    const reelScript = String(form.get("reelScript") ?? "").trim().slice(0, 8000);
    await db.post.update({ where: { id }, data: { reelScript: reelScript || null } });
    await audit(auth.orgId, "post.reelScript", { userId: auth.user.id, entity: "Post", entityId: id });
    return "Roteiro salvo.";
  });
}

export async function regenerateReelScriptAction(form: FormData) {
  const { auth } = await requireBrand("EDITOR");
  const id = str(form, "id");
  return runAction(back(id), async () => {
    await getPostForOrg(auth.orgId, id);
    const post = await db.post.findUniqueOrThrow({ where: { id }, include: { brand: true, offer: true } });
    if (["PUBLISHED", "PUBLISHING"].includes(post.status)) throw new Error("Publicação já publicada: o roteiro não pode mais ser alterado.");
    const when = post.scheduledAt ?? new Date();
    const offer = post.offer && isOfferValid(post.offer, when) ? post.offer : null;
    const offerText = offer
      ? `${offer.operator} · ${offer.speedMbps} Mega · ${formatBRL(offer.priceCents)}${offer.pricePeriod ?? ""}`
      : null;
    const ctx = await getBrandContext(post.brand);
    const { script } = await generateReelScript(auth.orgId, ctx, {
      pillar: post.pillar,
      theme: post.theme,
      objective: post.objective,
      hook: post.hook,
      centralIdea: post.centralIdea,
      ctaPlan: post.ctaPlan,
      currentScript: post.reelScript,
      instructions: str(form, "instructions") || null,
      offerText,
    });
    await db.post.update({ where: { id }, data: { reelScript: script } });
    await audit(auth.orgId, "post.reelScript.generate", { userId: auth.user.id, entity: "Post", entityId: id });
    const guard = checkCommercialText([script], offer, when);
    return guard.violations.length
      ? `Novo roteiro gerado, mas revise: ${guard.violations[0]}`
      : "Novo roteiro gerado. Revise e ajuste se quiser.";
  });
}

export async function reelScenesAction(form: FormData) {
  const { auth } = await requireBrand("EDITOR");
  const id = str(form, "id");
  return runAction(back(id), async () => {
    await getPostForOrg(auth.orgId, id);
    const post = await db.post.findUniqueOrThrow({ where: { id }, include: { brand: true, offer: true } });
    if (["PUBLISHED", "PUBLISHING"].includes(post.status)) throw new Error("Publicação já publicada: o roteiro não pode mais ser alterado.");
    const op = str(form, "op") || "save";
    let scenes = scenesFromForm(form).map((s) => s.replace(/\r\n/g, "\n").trim());

    if (op === "add") scenes.push("Nova cena: descreva a ação e a fala.");
    const removeMatch = /^remove:(\d+)$/.exec(op);
    if (removeMatch) scenes.splice(Number(removeMatch[1]), 1);
    scenes = scenes.filter(Boolean);
    const when = post.scheduledAt ?? new Date();
    const offer = post.offer && isOfferValid(post.offer, when) ? post.offer : null;
    const offerText = offer ? `${offer.operator} · ${offer.speedMbps} Mega · ${formatBRL(offer.priceCents)}${offer.pricePeriod}` : null;

    // Gerar novamente uma única parte
    const sceneMatch = /^scene:(\d+)$/.exec(op);
    if (sceneMatch) {
      const index = Number(sceneMatch[1]);
      if (index < 0 || index >= scenes.length) throw new Error("Parte do roteiro não encontrada.");
      const ctx = await getBrandContext(post.brand);
      scenes[index] = await rewriteReelScene(auth.orgId, ctx, {
        theme: post.theme,
        scenes,
        index,
        instructions: str(form, `note_${index}`) || null,
        offerText,
      });
    }

    const script = joinScenes(scenes);
    if (!script) throw new Error("O roteiro está vazio.");
    await db.post.update({ where: { id }, data: { reelScript: script } });

    if (op !== "all") {
      await audit(auth.orgId, "post.reelScript", { userId: auth.user.id, entity: "Post", entityId: id, meta: { op } });
      if (sceneMatch) {
        const g = checkCommercialText([scenes[Number(sceneMatch[1])]], offer, when);
        return g.violations.length ? `Parte ${Number(sceneMatch[1]) + 1} gerada novamente, mas revise: ${g.violations[0]}` : `Parte ${Number(sceneMatch[1]) + 1} gerada novamente.`;
      }
      if (op === "add") return "Cena adicionada no final. Edite o texto e salve.";
      if (removeMatch) return "Cena removida.";
      return "Roteiro salvo.";
    }

    // Gerar tudo agora a partir do roteiro editado: título, legendas, imagem e vídeo
    const vids = await db.postMedia.findMany({ where: { postId: id, purpose: "VIDEO" }, include: { asset: { select: { id: true, source: true } } } });
    const aiVideo = vids.find((v) => v.asset.source === "AI");
    const ownVideo = vids.some((v) => v.asset.source !== "AI");
    await db.videoJob.deleteMany({ where: { postId: id, status: "QUEUED" } });
    await db.videoJob.updateMany({ where: { postId: id, status: { in: ["VOICE_READY", "SUBMITTED"] } }, data: { status: "CANCELED", error: "Substituído por uma nova geração." } });
    const r = await producePost(id, {
      actor: "user",
      regenerateText: true,
      regenerateImage: true,
      forceNewVideo: !ownVideo,
      replaceVideoAssetId: aiVideo?.asset.id,
      lockedReelScript: script,
      extraInstructions: str(form, "instructions") || undefined,
    });
    await audit(auth.orgId, "post.generate", { userId: auth.user.id, entity: "Post", entityId: id, meta: { mode: "reel-all" } });
    const guard = checkCommercialText([script], offer, when);
    const alert = r.errors[0] ?? guard.violations[0];
    return alert
      ? `Tudo gerado com o seu roteiro, mas revise: ${alert}`
      : "Tudo gerado com o seu roteiro: capa, título, legendas e imagem prontos. O vídeo entra em produção agora e aparece aqui em alguns minutos.";
  });
}

// ───────── Briefing (etapa 1 de 2): revisar e aprovar antes de produzir ─────────

function slidesFrom(raw: string) {
  return raw
    ? raw.split(/\n-{3,}\n/).map((block) => {
        const [title, ...body] = block.trim().split("\n");
        return { title: (title ?? "").trim(), body: body.join(" ").trim() };
      })
    : undefined;
}

/** Foto escolhida/enviada por você para a capa (não gerada por IA): é mantida ao produzir. */
async function userPhoto(postId: string) {
  const bg = await db.postMedia.findFirst({ where: { postId, purpose: "BACKGROUND" }, include: { asset: { select: { id: true, source: true } } } });
  return bg && bg.asset.source !== "AI" ? bg.asset.id : undefined;
}

/** Capa do Reels: salva textos e foto e, se pedido, refaz só a capa (o vídeo não muda). */
export async function coverAction(form: FormData) {
  const { auth, brand } = await requireBrand("EDITOR");
  const id = str(form, "id");
  const backTo = str(form, "back");
  const dest = backTo.startsWith("/") && !backTo.startsWith("//") ? backTo : back(id);
  return runAction(dest, async () => {
    const before = await getPostForOrg(auth.orgId, id);
    if (["PUBLISHED", "PUBLISHING"].includes(before.status)) throw new Error("Publicação já publicada.");
    const isBrief = before.status === "BRIEF_REVIEW";
    const op = str(form, "op") || "save";
    if (!str(form, "title")) throw new Error("Escreva o título da capa.");

    await updatePostContent(auth.orgId, auth.user.id, id, {
      title: str(form, "title"),
      subtitle: str(form, "subtitle"),
      cta: str(form, "cta"),
      layout: str(form, "layout") || undefined,
    });
    await db.post.update({ where: { id }, data: { imagePrompt: str(form, "imagePrompt") || null, artDirection: str(form, "artDirection") || null } });

    // Foto: arquivo enviado > "gerar com IA" > foto da biblioteca > manter
    const file = form.get("file");
    const choice = str(form, "photo") || "keep";
    let photoId: string | undefined;
    let newAi = false;
    if (file instanceof File && file.size > 0) {
      if (file.size > 25 * 1024 * 1024) throw new Error("Foto acima de 25 MB.");
      const ext = file.name.split(".").pop()?.toLowerCase();
      const mime = ["image/jpeg", "image/png", "image/webp"].includes(file.type) ? file.type : ({ jpg: "image/jpeg", jpeg: "image/jpeg", png: "image/png", webp: "image/webp" } as Record<string, string>)[ext ?? ""];
      if (!mime) throw new Error("Envie a foto em JPG, PNG ou WEBP.");
      const asset = await saveAsset({ orgId: auth.orgId, brandId: brand.id, buffer: Buffer.from(await file.arrayBuffer()), mimeType: mime, kind: "IMAGE", role: "PHOTO", originalName: file.name, title: `Capa — ${str(form, "title")}`.slice(0, 120), isApproved: true });
      photoId = asset.id;
    } else if (choice === "ai") {
      newAi = true;
    } else if (str(form, "libraryId")) {
      const a = await db.mediaAsset.findFirst({ where: { id: str(form, "libraryId"), orgId: auth.orgId, kind: "IMAGE" } });
      if (!a) throw new Error("Foto da biblioteca não encontrada.");
      photoId = a.id;
    }
    if (newAi && !str(form, "imagePrompt")) throw new Error("Escreva o prompt da foto para gerar com IA.");

    if (isBrief || op === "save") {
      // Guarda a escolha da foto; a capa é montada na produção (ou ao clicar em aplicar)
      if (photoId || newAi) await db.postMedia.deleteMany({ where: { postId: id, purpose: "BACKGROUND" } });
      if (photoId) await db.postMedia.create({ data: { postId: id, assetId: photoId, purpose: "BACKGROUND", position: 0 } });
      await audit(auth.orgId, "post.cover.save", { userId: auth.user.id, entity: "Post", entityId: id });
      if (isBrief) return "Capa salva. Ela será produzida quando você aprovar o briefing.";
      return newAi ? "Capa salva. Clique em “Aplicar e refazer só a capa” para gerar a nova foto." : "Capa salva. Clique em “Aplicar e refazer só a capa” para ver o resultado.";
    }

    const r = await producePost(id, { actor: "user", coverOnly: true, regenerateImage: newAi, backgroundAssetId: photoId });
    await audit(auth.orgId, "post.cover.apply", { userId: auth.user.id, entity: "Post", entityId: id, meta: { photo: photoId ? "own" : newAi ? "ai" : "keep" } });
    return r.errors.length ? `Capa refeita com alertas: ${r.errors[0]}` : "Capa refeita. O vídeo não foi alterado. Revise e aprove.";
  });
}

export async function briefAction(form: FormData) {
  const { auth } = await requireBrand("EDITOR");
  const id = str(form, "id");
  const backTo = str(form, "back");
  const dest = backTo.startsWith("/") && !backTo.startsWith("//") ? backTo : back(id);
  return runAction(dest, async () => {
    const before = await getPostForOrg(auth.orgId, id);
    const isBrief = before.status === "BRIEF_REVIEW";
    if (["PUBLISHED", "PUBLISHING"].includes(before.status)) throw new Error("Publicação já publicada.");
    const op = str(form, "op") || "save";

    // 1) Salva tudo o que está no formulário
    const opt = (k: string) => (form.has(k) ? str(form, k) : undefined);
    await updatePostContent(auth.orgId, auth.user.id, id, {
      title: opt("title"),
      subtitle: opt("subtitle"),
      cta: opt("cta"),
      theme: str(form, "theme") || undefined,
      layout: opt("layout") || undefined,
      hashtags: lines(form, "hashtags").map((h) => h.replace(/^#/, "")),
      captions: { INSTAGRAM: str(form, "caption_INSTAGRAM") || undefined, FACEBOOK: str(form, "caption_FACEBOOK") || undefined, TIKTOK: str(form, "caption_TIKTOK") || undefined },
      slides: slidesFrom(str(form, "slides")),
    });
    let scenes = scenesFromForm(form).map((x) => x.replace(/\r\n/g, "\n").trim());
    if (op === "add") scenes.push("Nova cena: descreva a ação e a fala.");
    const removeMatch = /^remove:(\d+)$/.exec(op);
    if (removeMatch) scenes.splice(Number(removeMatch[1]), 1);
    scenes = scenes.filter(Boolean);

    const post = await db.post.findUniqueOrThrow({ where: { id }, include: { brand: true, offer: true } });
    const when = post.scheduledAt ?? new Date();
    const offer = post.offer && isOfferValid(post.offer, when) ? post.offer : null;
    const sceneMatch = /^scene:(\d+)$/.exec(op);
    if (sceneMatch) {
      const index = Number(sceneMatch[1]);
      if (index < 0 || index >= scenes.length) throw new Error("Parte do roteiro não encontrada.");
      const ctx = await getBrandContext(post.brand);
      scenes[index] = await rewriteReelScene(auth.orgId, ctx, {
        theme: post.theme,
        scenes,
        index,
        instructions: str(form, `note_${index}`) || null,
        offerText: offer ? `${offer.operator} · ${offer.speedMbps} Mega · ${formatBRL(offer.priceCents)}${offer.pricePeriod}` : null,
      });
    }
    await db.post.update({
      where: { id },
      data: {
        ...(form.has("imagePrompt") ? { imagePrompt: str(form, "imagePrompt") || null } : {}),
        ...(form.has("artDirection") ? { artDirection: str(form, "artDirection") || null } : {}),
        ...(post.format === "REEL"
          ? { reelScript: joinScenes(scenes) || null, videoSpeech: str(form, "videoSpeech") || null, videoPrompt: str(form, "videoPrompt") || null }
          : {}),
      },
    });

    if (op === "redo") {
      const r = await producePost(id, { actor: "user", regenerateText: true, stopAfterText: isBrief, extraInstructions: str(form, "instructions") || undefined });
      await audit(auth.orgId, "post.brief.redo", { userId: auth.user.id, entity: "Post", entityId: id });
      return r.errors.length ? `Novo briefing gerado, mas revise: ${r.errors[0]}` : "Novo briefing gerado. Revise e aprove para produção.";
    }

    if (op === "produce") {
      // Refaz imagem, arte/slides e vídeo com o conteúdo exatamente como está (sem reescrever o texto)
      // Vídeo da IA é refeito NO MESMO arquivo da biblioteca; vídeo enviado por você é mantido
      const vids = await db.postMedia.findMany({ where: { postId: id, purpose: "VIDEO" }, include: { asset: { select: { id: true, source: true } } } });
      const aiVideo = vids.find((v) => v.asset.source === "AI");
      const ownVideo = vids.some((v) => v.asset.source !== "AI");
      await db.videoJob.deleteMany({ where: { postId: id, status: "QUEUED" } });
      await db.videoJob.updateMany({ where: { postId: id, status: { in: ["VOICE_READY", "SUBMITTED"] } }, data: { status: "CANCELED", error: "Substituído por uma nova geração." } });
      const ownPhoto = await userPhoto(id);
      const r = await producePost(id, { actor: "user", regenerateImage: !ownPhoto, backgroundAssetId: ownPhoto, forceNewVideo: post.format === "REEL" && !ownVideo, replaceVideoAssetId: aiVideo?.asset.id });
      await audit(auth.orgId, "post.produce", { userId: auth.user.id, entity: "Post", entityId: id });
      const extra = post.format === "REEL" ? " O novo vídeo entra em produção e aparece na publicação em alguns minutos." : "";
      return r.errors.length ? `Gerado com alertas: ${r.errors[0]}. Revise e aprove.` : `Tudo gerado novamente com as suas alterações. Revise e aprove.${extra}`;
    }

    if (op === "approve") {
      const fresh = await db.post.findUniqueOrThrow({ where: { id } });
      if (!fresh.title) throw new Error(fresh.format === "REEL" ? "Escreva o título no quadro Capa do Reels." : "O briefing está sem título da arte.");
      if (fresh.format === "REEL" && !fresh.reelScript) throw new Error("O roteiro do Reels está vazio.");
      await db.post.update({ where: { id }, data: { briefApprovedAt: new Date(), briefApprovedById: auth.user.id } });
      await audit(auth.orgId, "post.brief.approve", { userId: auth.user.id, entity: "Post", entityId: id });
      // Etapa 2: produz agora (imagem, arte, carrossel e vídeo) com o briefing exatamente como aprovado
      const ownPhoto = await userPhoto(id);
      const r = await producePost(id, { actor: "user", regenerateImage: !ownPhoto, backgroundAssetId: ownPhoto, forceNewVideo: fresh.format === "REEL" });
      const extra = fresh.format === "REEL" ? " O vídeo entra em produção e aparece aqui em alguns minutos." : "";
      return r.errors.length
        ? `Produzido com alertas: ${r.errors[0]}. Revise e aprove para publicação.`
        : `Briefing aprovado e produzido. Agora confira o resultado e aprove para publicação.${extra}`;
    }

    await audit(auth.orgId, "post.brief.edit", { userId: auth.user.id, entity: "Post", entityId: id, meta: { op } });
    if (sceneMatch) return `Parte ${Number(sceneMatch[1]) + 1} gerada novamente.`;
    if (op === "add") return "Parte adicionada no final do roteiro.";
    if (removeMatch) return "Parte removida.";
    return "Briefing salvo.";
  });
}

/** Usa um vídeo da biblioteca na publicação (Reels) e, se pedido, aprova e publica na hora. Não gera nada novo. */
export async function useVideoAction(form: FormData) {
  const { auth } = await requireBrand("ADMIN");
  const id = str(form, "id");
  const assetId = str(form, "videoId");
  const backTo = str(form, "back");
  const dest = backTo.startsWith("/") && !backTo.startsWith("//") ? backTo : back(id);
  return runAction(dest, async () => {
    const post = await getPostForOrg(auth.orgId, id);
    if (["PUBLISHED", "PUBLISHING"].includes(post.status) && str(form, "publish") !== "1") throw new Error("Publicação já publicada.");
    const video = await db.mediaAsset.findFirst({ where: { id: assetId, orgId: auth.orgId, kind: "VIDEO" } });
    if (!video) throw new Error("Vídeo não encontrado.");
    const current = await db.postMedia.findFirst({ where: { postId: id, purpose: "VIDEO" } });
    if (current?.assetId !== video.id) {
      await db.postMedia.deleteMany({ where: { postId: id, purpose: "VIDEO" } });
      await db.postMedia.create({ data: { postId: id, assetId: video.id, purpose: "VIDEO", position: 0 } });
      await db.mediaAsset.update({ where: { id: video.id }, data: { isApproved: true } });
      // vídeos ainda em produção para esta publicação não substituem mais o escolhido
      await db.videoJob.updateMany({ where: { postId: id, status: { in: ["QUEUED", "VOICE_READY", "SUBMITTED"] } }, data: { status: "CANCELED", error: "Outro vídeo foi escolhido para a publicação." } });
      if (post.status === "DRAFT") await db.post.update({ where: { id }, data: { status: "PENDING_APPROVAL" } });
    }
    await audit(auth.orgId, "post.video.use", { userId: auth.user.id, entity: "Post", entityId: id, meta: { assetId } });
    if (str(form, "publish") === "1") {
      await publishNow(auth.orgId, auth.user.id, id);
      return "Vídeo definido na publicação e enviado para as redes. O worker publica em até 1 minuto.";
    }
    return "Este vídeo agora é o vídeo da publicação.";
  });
}

export async function attachVideoAction(form: FormData) {
  const { auth } = await requireBrand("EDITOR");
  const id = str(form, "id");
  return runAction(back(id), async () => {
    await getPostForOrg(auth.orgId, id);
    const video = await db.mediaAsset.findFirst({ where: { id: str(form, "videoId"), orgId: auth.orgId, kind: "VIDEO" } });
    if (!video) throw new Error("Vídeo não encontrado.");
    await db.postMedia.deleteMany({ where: { postId: id, purpose: "VIDEO" } });
    await db.postMedia.create({ data: { postId: id, assetId: video.id, purpose: "VIDEO" } });
    await producePost(id, { actor: "user" });
    return "Vídeo vinculado ao Reels.";
  });
}

export async function createPostAction(form: FormData) {
  const { auth, brand } = await requireBrand("EDITOR");
  return runAction(str(form, "back") || "/posts", async () => {
    const networks = form.getAll("networks").map(String) as Network[];
    if (!networks.length) throw new Error("Selecione ao menos uma rede.");
    const theme = str(form, "theme");
    if (!theme) throw new Error("Informe o tema.");
    const when = str(form, "scheduledAt");
    const post = await createManualPost({
      orgId: auth.orgId,
      userId: auth.user.id,
      brandId: brand.id,
      pillar: (str(form, "pillar") || "EDUCATION") as Pillar,
      format: (str(form, "format") || "FEED_IMAGE") as PostFormat,
      theme,
      objective: str(form, "objective") || undefined,
      networks,
      scheduledAt: when ? fromDatetimeLocal(when, brand.timezone) : null,
      offerId: str(form, "offerId") || null,
    });
    if (form.get("generate") === "1") {
      await producePost(post.id, { actor: "user", extraInstructions: str(form, "instructions") || undefined });
    }
    return { message: "Publicação criada.", redirectTo: `/posts/${post.id}` };
  });
}

/** Ações em conjunto na lista de publicações: aprovar e agendar, publicar agora, voltar para rascunho, cancelar. */
export async function bulkPostsAction(form: FormData) {
  const { auth, brand } = await requireBrand("EDITOR");
  const backTo = str(form, "back");
  const dest = backTo.startsWith("/") && !backTo.startsWith("//") ? backTo : "/posts";
  const op = str(form, "op");
  if (["approve", "publish", "unapprove"].includes(op)) await requireBrand("ADMIN");
  return runAction(dest, async () => {
    const ids = [...new Set(form.getAll("ids").map(String).filter(Boolean))].slice(0, 150);
    if (!ids.length) throw new Error("Selecione ao menos uma publicação.");
    const posts = await db.post.findMany({ where: { id: { in: ids }, orgId: auth.orgId, brandId: brand.id }, select: { id: true, status: true } });
    let ok = 0;
    let skipped = 0;
    const fails: string[] = [];
    for (const p of posts) {
      try {
        if (op === "approve") {
          if (!["PENDING_APPROVAL", "DRAFT"].includes(p.status)) { skipped++; continue; }
          await approvePost(auth.orgId, auth.user.id, p.id);
        } else if (op === "publish") {
          if (["PUBLISHED", "PUBLISHING", "CANCELED", "BRIEF_REVIEW", "PLANNED", "GENERATING"].includes(p.status)) { skipped++; continue; }
          await publishNow(auth.orgId, auth.user.id, p.id);
        } else if (op === "unapprove") {
          if (!["SCHEDULED", "APPROVED"].includes(p.status)) { skipped++; continue; }
          await rejectToDraft(auth.orgId, auth.user.id, p.id);
        } else if (op === "cancel") {
          if (["PUBLISHED", "PUBLISHING", "CANCELED"].includes(p.status)) { skipped++; continue; }
          await cancelPost(auth.orgId, auth.user.id, p.id);
        } else throw new Error("Ação desconhecida.");
        ok++;
      } catch (e) {
        fails.push(e instanceof Error ? e.message : String(e));
      }
    }
    const verb = ({ approve: "aprovada(s) e agendada(s)", publish: "enviada(s) para publicação agora", unapprove: "voltaram para rascunho", cancel: "cancelada(s)" } as Record<string, string>)[op];
    const msg = `${ok} publicação(ões) ${verb}.${skipped ? ` ${skipped} ignorada(s) por não estarem no status certo.` : ""}`;
    if (fails.length) throw new Error(`${msg} ${fails.length} com problema: ${fails[0]}`);
    await audit(auth.orgId, `post.bulk.${op}`, { userId: auth.user.id, meta: { ok, skipped, failed: fails.length } });
    return msg;
  });
}
