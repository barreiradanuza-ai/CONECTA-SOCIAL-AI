"use server";
import { db } from "@/lib/db";
import { requireBrand } from "@/lib/auth";
import { runAction, str, int } from "@/lib/actions";
import { audit } from "@/server/audit";
import { saveAsset } from "@/server/media";
import { designVoice } from "@/server/video/minimax";
import { enqueueVideo } from "@/server/video/jobs";

export async function designVoiceAction(form: FormData) {
  const { auth, brand } = await requireBrand("ADMIN");
  return runAction("/studio/video", async () => {
    const prompt = str(form, "prompt");
    const preview = str(form, "preview");
    if (prompt.length < 20) throw new Error("Descreva a voz com mais detalhes (mínimo 20 caracteres).");
    if (preview.length < 20) throw new Error("Escreva uma frase de teste com pelo menos 20 caracteres.");
    const v = await designVoice(auth.orgId, prompt, preview.slice(0, 500));
    let sampleId: string | null = null;
    if (v.sample) {
      const a = await saveAsset({ orgId: auth.orgId, brandId: brand.id, buffer: v.sample, mimeType: "audio/mpeg", kind: "AUDIO", role: "VOICE", source: "AI", title: "Amostra da voz da persona", prompt, isApproved: true });
      sampleId = a.id;
    }
    await db.brand.update({ where: { id: brand.id }, data: { personaVoiceId: v.voiceId, personaVoicePrompt: prompt, personaVoiceSampleId: sampleId } });
    await audit(auth.orgId, "voice.design", { userId: auth.user.id, meta: { voiceId: v.voiceId } });
    return "Voz da persona criada. Ouça a amostra: se não gostar, ajuste a descrição e crie outra.";
  });
}

export async function createVideoAction(form: FormData) {
  const { auth, brand } = await requireBrand("EDITOR");
  return runAction("/studio/video", async () => {
    const brief = str(form, "brief");
    if (brief.length < 10) throw new Error("Descreva a ideia do vídeo.");
    const job = await enqueueVideo({ orgId: auth.orgId, brandId: brand.id, brief, durationSec: int(form, "duration", 10, 4, 15), createdById: auth.user.id });
    await audit(auth.orgId, "video.enqueue", { userId: auth.user.id, entity: "VideoJob", entityId: job.id });
    return "Vídeo enviado para produção. Leva de 2 a 10 minutos; esta página mostra o andamento.";
  });
}

export async function videoJobAction(form: FormData) {
  const { auth, brand } = await requireBrand("EDITOR");
  const id = str(form, "id");
  const op = str(form, "op");
  return runAction("/studio/video", async () => {
    const job = await db.videoJob.findFirst({ where: { id, brandId: brand.id } });
    if (!job) throw new Error("Vídeo não encontrado.");
    if (op === "cancel") {
      if (job.status === "SUBMITTED") throw new Error("Já está sendo gerado na MiniMax; não dá para cancelar agora.");
      await db.videoJob.update({ where: { id }, data: { status: "CANCELED" } });
      return "Cancelado.";
    }
    if (op === "retry") {
      if (job.status !== "FAILED") throw new Error("Só é possível refazer vídeos que falharam.");
      await db.videoJob.update({ where: { id }, data: { status: job.voiceAssetId ? "VOICE_READY" : "QUEUED", attempts: 0, error: null, taskId: null } });
      return "Reenviado para produção.";
    }
    if (op === "approve" && job.videoAssetId) {
      await db.mediaAsset.update({ where: { id: job.videoAssetId }, data: { isApproved: true } });
      await audit(auth.orgId, "video.approve", { userId: auth.user.id, entity: "VideoJob", entityId: id });
      return "Vídeo aprovado na biblioteca: pode ser usado em Reels e anúncios.";
    }
    throw new Error("Operação inválida.");
  });
}
