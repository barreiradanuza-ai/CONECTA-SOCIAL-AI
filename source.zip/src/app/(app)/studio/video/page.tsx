import Link from "next/link";
import { requireBrand } from "@/lib/auth";
import { db } from "@/lib/db";
import { PageHeader, Flash, Field } from "@/components/ui";
import { SubmitButton } from "@/components/client";
import { Section } from "@/components/traffic";
import { getSecret } from "@/server/integrations";
import { mediaPath } from "@/server/storage";
import { monthVideoSpend } from "@/server/video/jobs";
import { formatDateTime } from "@/lib/time";
import { designVoiceAction, createVideoAction, videoJobAction } from "./actions";

export const dynamic = "force-dynamic";

const STATUS: Record<string, [string, string]> = {
  QUEUED: ["bg-slate-100 text-slate-700", "Na fila: escrevendo a fala"],
  VOICE_READY: ["bg-blue-100 text-blue-800", "Voz pronta: enviando para gerar"],
  SUBMITTED: ["bg-amber-100 text-amber-900", "Gerando vídeo na MiniMax…"],
  SUCCEEDED: ["bg-emerald-100 text-emerald-800", "Pronto"],
  FAILED: ["bg-red-100 text-red-800", "Falhou"],
  CANCELED: ["bg-slate-200 text-slate-600", "Cancelado"],
};

const DEFAULT_VOICE =
  "Homem brasileiro de 30 a 40 anos, voz carismática, elegante e teatral, com trejeitos levemente afeminados sem caricatura. Tom irônico e sarcástico, como quem sabe um segredo. Fala com ritmo ágil, pausas dramáticas e sorriso na voz. Sotaque brasileiro neutro.";
const DEFAULT_PREVIEW = "Gente… ninguém me conta nada, mas eu descubro tudo. Quem saiu do grupo da família às três da manhã? Eu já sei. E você vai saber agora.";

export default async function VideoStudio({ searchParams }: { searchParams: Promise<{ ok?: string; error?: string }> }) {
  const { auth, brand } = await requireBrand("EDITOR");
  const sp = await searchParams;
  const [settings, key, jobs, refs, spent, sample] = await Promise.all([
    db.automationSettings.findUnique({ where: { brandId: brand.id } }),
    getSecret(auth.orgId, "MINIMAX_API_KEY"),
    db.videoJob.findMany({ where: { brandId: brand.id }, orderBy: { createdAt: "desc" }, take: 30 }),
    db.mediaAsset.findMany({ where: { brandId: brand.id, role: "CHARACTER_REFERENCE", kind: "IMAGE" }, orderBy: { createdAt: "asc" }, take: 5 }),
    monthVideoSpend(brand.id),
    brand.personaVoiceSampleId ? db.mediaAsset.findUnique({ where: { id: brand.personaVoiceSampleId } }) : null,
  ]);
  const assetIds = [...new Set(jobs.flatMap((j) => [j.videoAssetId, j.voiceAssetId]).filter(Boolean) as string[])];
  const assets = new Map((await db.mediaAsset.findMany({ where: { id: { in: assetIds } } })).map((a) => [a.id, a]));
  const budget = settings?.videoMonthlyBudgetUsd ?? 0;
  const pct = budget ? Math.min(100, (spent / budget) * 100) : 0;

  return (
    <div>
      <PageHeader title="AI Video Studio" subtitle="A persona com voz própria: roteiro (Claude) → voz fixa → vídeo com a boca sincronizada (MiniMax H3, vertical 768p)." />
      <Flash ok={sp.ok} error={sp.error} />
      {!key && <div className="mb-4 rounded-xl border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900">Falta a chave da MiniMax. Cadastre em <Link href="/settings/integrations" className="underline">Configurações → Integrações e chaves</Link>.</div>}

      <div className="mb-6 grid gap-6 lg:grid-cols-3">
        <Section title="Voz da persona" subtitle="Criada uma vez e usada em todos os vídeos" className="lg:col-span-2">
          {brand.personaVoiceId ? (
            <div className="mb-4 rounded-xl bg-navy-50 p-4 text-sm">
              <div className="font-semibold text-navy">Voz ativa</div>
              {sample && <audio src={mediaPath(sample.storageKey)} controls className="mt-2 w-full" />}
              <p className="mt-2 text-xs text-ink-soft">{brand.personaVoicePrompt}</p>
            </div>
          ) : (
            <p className="mb-4 text-sm text-ink-soft">Nenhuma voz criada ainda. Descreva como o personagem fala; a MiniMax cria a voz (custo único de ~US$3).</p>
          )}
          <form action={designVoiceAction} className="space-y-3">
            <Field label="Como é a voz">
              <textarea name="prompt" rows={3} className="input" defaultValue={brand.personaVoicePrompt ?? DEFAULT_VOICE} />
            </Field>
            <Field label="Frase de teste">
              <textarea name="preview" rows={2} className="input" defaultValue={DEFAULT_PREVIEW} />
            </Field>
            <SubmitButton className="btn-primary" pendingText="Criando a voz…" confirm={brand.personaVoiceId ? "Criar uma nova voz substitui a atual nos próximos vídeos. Continuar?" : undefined}>
              {brand.personaVoiceId ? "Criar nova versão da voz" : "Criar voz da persona"}
            </SubmitButton>
          </form>
        </Section>

        <div className="space-y-6">
          <Section title="Orçamento de vídeo do mês">
            <div className="text-2xl font-bold tabular-nums">US$ {spent.toFixed(2)}</div>
            <div className="text-sm text-ink-soft">de US$ {budget.toFixed(2)} (estimado a US$0,08/s em 768p)</div>
            <div className="mt-3 h-2.5 overflow-hidden rounded-full bg-slate-100"><div className={`h-full ${pct >= 90 ? "bg-red-500" : "bg-accent"}`} style={{ width: `${pct}%` }} /></div>
            <Link href="/settings/automation" className="mt-2 block text-xs text-accent">ajustar teto</Link>
          </Section>
          <Section title="Fotos de referência">
            {refs.length === 0 ? (
              <p className="text-sm text-ink-soft">Cadastre as fotos da persona em <Link href="/settings/brand" className="text-accent underline">Marca</Link> (tipo “Referência do personagem”).</p>
            ) : (
              <div className="grid grid-cols-5 gap-1.5">{refs.map((r) => <img key={r.id} src={mediaPath(r.storageKey)} alt="" className="aspect-square rounded-lg object-cover" />)}</div>
            )}
          </Section>
        </div>
      </div>

      <div className="mb-4 rounded-2xl border border-cyan/40 bg-cyan-soft p-4 text-sm text-navy">
        O caminho principal é a <Link href="/studio/scripts" className="font-semibold underline">Sala de roteiristas</Link>: a IA acha o viral, escreve o roteiro completo e você só clica em “Produzir vídeo”. O campo abaixo é para pedidos avulsos.
      </div>
      <Section title="Pedido avulso de vídeo" subtitle="Escreva a ideia; a IA escreve a fala no tom do personagem e dirige a cena" className="mb-6">
        <form action={createVideoAction} className="grid gap-4 md:grid-cols-6">
          <div className="md:col-span-5">
            <textarea name="brief" rows={3} className="input" placeholder="Ex.: Ele descobre, pela conexão lenta do vizinho, que alguém está maratonando série escondido. Final: 'com internet boa, até o segredo carrega mais rápido'." required />
          </div>
          <div className="space-y-2">
            <select name="duration" className="input" defaultValue={String(settings?.videoDefaultSeconds ?? 10)}>
              {[5, 8, 10, 12, 15].map((d) => <option key={d} value={d}>{d} segundos</option>)}
            </select>
            <SubmitButton className="btn-accent w-full" pendingText="Enviando…">Gerar vídeo</SubmitButton>
          </div>
        </form>
        <p className="mt-2 text-xs text-ink-mute">Pautas aprovadas no <Link href="/radar" className="text-accent underline">Radar</Link> também podem virar vídeo com um clique. Reels do calendário geram vídeo sozinhos quando a opção está ligada.</p>
      </Section>

      <h2 className="mb-3 text-lg font-bold">Produções</h2>
      {jobs.length === 0 && <div className="card p-6 text-sm text-ink-soft">Nenhum vídeo ainda.</div>}
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {jobs.map((j) => {
          const video = j.videoAssetId ? assets.get(j.videoAssetId) : null;
          const voice = j.voiceAssetId ? assets.get(j.voiceAssetId) : null;
          const [cls, label] = STATUS[j.status] ?? ["bg-slate-100", j.status];
          return (
            <article key={j.id} className="card overflow-hidden">
              <div className="flex aspect-[9/16] max-h-96 items-center justify-center bg-navy">
                {video ? <video src={mediaPath(video.storageKey)} controls className="h-full w-full object-contain" /> : <span className="px-6 text-center text-sm text-white/70">{label}</span>}
              </div>
              <div className="space-y-2 p-4 text-sm">
                <div className="flex flex-wrap items-center gap-2">
                  <span className={`badge ${cls}`}>{label}</span>
                  <span className="badge bg-slate-100 text-slate-600">{j.durationSec}s · {j.resolution}</span>
                  <span className="badge bg-slate-100 text-slate-600">~US$ {j.estCostUsd.toFixed(2)}</span>
                  {video?.isApproved && <span className="badge bg-emerald-100 text-emerald-800">aprovado</span>}
                </div>
                {j.speech && <p className="italic text-ink-soft">“{j.speech}”</p>}
                {voice && !video && <audio src={mediaPath(voice.storageKey)} controls className="w-full" />}
                {j.error && <p className="rounded-lg bg-red-50 p-2 text-xs text-red-800">{j.error}</p>}
                <div className="flex flex-wrap items-center gap-2 text-xs text-ink-mute">
                  <span>{formatDateTime(j.createdAt, brand.timezone)}</span>
                  {j.postId && <Link href={`/posts/${j.postId}`} className="text-accent underline">ver publicação</Link>}
                </div>
                <form action={videoJobAction} className="flex flex-wrap gap-2">
                  <input type="hidden" name="id" value={j.id} />
                  {video && !video.isApproved && <SubmitButton name="op" value="approve" className="btn-primary btn-sm">Aprovar vídeo</SubmitButton>}
                  {j.status === "FAILED" && <SubmitButton name="op" value="retry" className="btn-ghost btn-sm">Tentar de novo</SubmitButton>}
                  {["QUEUED", "VOICE_READY"].includes(j.status) && <SubmitButton name="op" value="cancel" className="btn-ghost btn-sm">Cancelar</SubmitButton>}
                </form>
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
}
