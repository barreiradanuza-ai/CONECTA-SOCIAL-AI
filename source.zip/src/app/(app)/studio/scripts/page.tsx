import Link from "next/link";
import { requireBrand } from "@/lib/auth";
import { db } from "@/lib/db";
import { PageHeader, Flash } from "@/components/ui";
import { SubmitButton } from "@/components/client";
import { formatDateTime } from "@/lib/time";
import { writeAboutAction, scriptAction } from "./actions";

export const dynamic = "force-dynamic";

type Beat = { ato: string; visual: string; fala?: string; texto_tela?: string };

const TABS = [
  { key: "new", label: "Novos", where: ["DRAFT", "APPROVED"] },
  { key: "produced", label: "Produzidos", where: ["PRODUCED"] },
  { key: "discarded", label: "Descartados", where: ["DISCARDED"] },
];

export default async function ScriptsRoom({ searchParams }: { searchParams: Promise<{ ok?: string; error?: string; tab?: string }> }) {
  const { brand } = await requireBrand("EDITOR");
  const sp = await searchParams;
  const tab = TABS.find((t) => t.key === sp.tab) ?? TABS[0];
  const [scripts, waiting] = await Promise.all([
    db.script.findMany({ where: { brandId: brand.id, status: { in: tab.where } }, orderBy: [{ createdAt: "desc" }], take: 30 }),
    db.trendNote.count({ where: { brandId: brand.id, status: "APPROVED", scriptsAt: null, validUntil: { gte: new Date() } } }),
  ]);
  const trendIds = [...new Set(scripts.map((s) => s.trendId).filter(Boolean) as string[])];
  const trends = new Map((await db.trendNote.findMany({ where: { id: { in: trendIds } } })).map((t) => [t.id, t]));

  return (
    <div>
      <PageHeader
        title="Sala de roteiristas"
        subtitle="A IA roteirista-chefe liga os virais do Brasil e do mundo ao universo da conexão e entrega roteiros prontos, no tom do personagem."
      />
      <Flash ok={sp.ok} error={sp.error} />

      <div className="mb-6 overflow-hidden rounded-3xl bg-gradient-to-r from-navy via-navy-600 to-accent p-6 text-white">
        <div className="text-[11px] font-bold uppercase tracking-[0.2em] text-cyan">Como funciona</div>
        <ol className="mt-2 grid gap-2 text-sm md:grid-cols-4">
          <li><strong>1. Radar</strong> descobre o que viralizou (Brasil e mundo) e sugere a ponte com a internet.</li>
          <li><strong>2. Você aprova</strong> a pauta (ou a auto-aprovação faz isso).</li>
          <li><strong>3. Roteirista-chefe</strong> pesquisa, escreve 3 ângulos, critica e reescreve.</li>
          <li><strong>4. Um clique</strong> vira vídeo da persona ou publicação.</li>
        </ol>
        {waiting > 0 && <p className="mt-3 text-sm text-white/80">{waiting} pauta(s) aprovada(s) na fila: os roteiros chegam em até 10 minutos.</p>}
      </div>

      <form action={writeAboutAction} className="card mb-6 flex flex-col gap-3 p-5 md:flex-row md:items-end">
        <div className="flex-1">
          <label className="label">Pedir roteiros sobre um assunto</label>
          <input name="brief" className="input" placeholder="Ex.: o apagão global da rede social de ontem · a final do reality · a nova trend de dança" />
        </div>
        <SubmitButton className="btn-accent" pendingText="Pesquisando e escrevendo… (1-2 min)">Escrever 3 roteiros</SubmitButton>
      </form>

      <div className="mb-5 flex gap-1 border-b border-slate-200">
        {TABS.map((t) => (
          <Link key={t.key} href={`/studio/scripts?tab=${t.key}`} className={`border-b-2 px-3 py-2 text-sm font-semibold ${t.key === tab.key ? "border-accent text-ink" : "border-transparent text-ink-mute hover:text-ink"}`}>{t.label}</Link>
        ))}
      </div>

      {scripts.length === 0 && <div className="card p-8 text-center text-sm text-ink-soft">Nenhum roteiro aqui. Aprove pautas no <Link href="/radar" className="text-accent underline">Radar</Link> ou peça sobre um assunto acima.</div>}

      <div className="space-y-5">
        {scripts.map((s) => {
          const beats = (s.beats as Beat[] | null) ?? [];
          const trend = s.trendId ? trends.get(s.trendId) : null;
          return (
            <article key={s.id} className="card overflow-hidden">
              <div className="flex flex-wrap items-center gap-2 border-b border-slate-100 bg-navy-50 px-5 py-3">
                <span className={`badge ${(s.score ?? 0) >= 8 ? "bg-emerald-100 text-emerald-800" : (s.score ?? 0) >= 6 ? "bg-amber-100 text-amber-900" : "bg-slate-200 text-slate-700"}`}>nota {s.score ?? "—"}/10</span>
                <span className="badge bg-white text-navy ring-1 ring-slate-200">{s.format}</span>
                {s.framework && <span className="badge bg-white text-ink-soft ring-1 ring-slate-200">{s.framework}</span>}
                {trend && <span className="badge bg-cyan-soft text-navy">{trend.scope === "GLOBAL" ? "🌍 viral mundial" : "Brasil"}: {trend.title}</span>}
                <span className="ml-auto text-xs text-ink-mute">{formatDateTime(s.createdAt, brand.timezone)}</span>
              </div>
              <div className="grid gap-6 p-5 lg:grid-cols-5">
                <div className="space-y-4 lg:col-span-3">
                  <div>
                    <h3 className="text-lg font-bold">{s.title}</h3>
                    {s.angle && <p className="text-sm text-ink-soft">{s.angle}</p>}
                  </div>
                  {s.bridge && <p className="rounded-xl bg-cyan-soft p-3 text-sm text-navy"><strong>Ponte com a conexão:</strong> {s.bridge}</p>}
                  <ol className="space-y-2">
                    {beats.map((b, i) => (
                      <li key={i} className="grid grid-cols-[28px_1fr] gap-2 text-sm">
                        <span className="flex h-6 w-6 items-center justify-center rounded-full bg-navy text-[11px] font-bold text-white">{i + 1}</span>
                        <div>
                          <div className="text-[11px] font-bold uppercase tracking-wide text-ink-mute">{b.ato}</div>
                          <div className="text-ink-soft">{b.visual}</div>
                          {b.fala && <div className="font-medium">“{b.fala}”</div>}
                          {b.texto_tela && <div className="text-xs text-accent">Na tela: {b.texto_tela}</div>}
                        </div>
                      </li>
                    ))}
                  </ol>
                </div>
                <div className="space-y-4 lg:col-span-2">
                  <form action={scriptAction} className="space-y-4">
                    <input type="hidden" name="id" value={s.id} />
                    <div>
                      <div className="label">Ganchos (escolha um)</div>
                      <div className="space-y-1.5">
                        {s.hooks.map((h, i) => (
                          <label key={i} className="flex items-start gap-2 rounded-lg border border-slate-200 p-2 text-sm">
                            <input type="radio" name="hook" value={h} defaultChecked={i === 0} className="mt-1" /> <span>{h}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                    <div className="rounded-xl bg-navy p-4 text-sm text-white">
                      <div className="text-[11px] font-bold uppercase tracking-widest text-cyan">Fala do vídeo (15 s)</div>
                      <p className="mt-1">“{s.speech}”</p>
                    </div>
                    <details className="text-sm">
                      <summary className="cursor-pointer font-semibold">Legenda pronta</summary>
                      <p className="mt-2 whitespace-pre-line text-ink-soft">{s.caption}</p>
                      {s.hashtags.length > 0 && <p className="mt-1 text-xs text-accent">{s.hashtags.map((h) => `#${h}`).join(" ")}</p>}
                    </details>
                    {s.critique && <p className="text-xs text-ink-mute"><strong>Autocrítica:</strong> {s.critique}</p>}
                    {s.status !== "DISCARDED" && s.status !== "PRODUCED" && (
                      <div className="flex flex-wrap gap-2 border-t border-slate-100 pt-3">
                        <SubmitButton name="op" value="video" className="btn-accent btn-sm" pendingText="Enviando…">Produzir vídeo da persona</SubmitButton>
                        <SubmitButton name="op" value="post" className="btn-primary btn-sm" pendingText="Criando…">Virar publicação</SubmitButton>
                        <SubmitButton name="op" value="discard" className="btn-ghost btn-sm">Descartar</SubmitButton>
                      </div>
                    )}
                    {s.status === "PRODUCED" && (
                      <p className="text-xs">
                        {s.videoJobId && <Link href="/studio/video" className="text-accent underline">ver vídeo</Link>} {s.postId && <Link href={`/posts/${s.postId}`} className="text-accent underline">ver publicação</Link>}
                      </p>
                    )}
                  </form>
                  {s.status !== "DISCARDED" && (
                    <form action={scriptAction} className="flex gap-2">
                      <input type="hidden" name="id" value={s.id} />
                      <input name="note" className="input py-1.5 text-sm" placeholder="Pedido para reescrever (opcional)" />
                      <SubmitButton name="op" value="rewrite" className="btn-ghost btn-sm" pendingText="Reescrevendo…">Reescrever</SubmitButton>
                    </form>
                  )}
                </div>
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
}
