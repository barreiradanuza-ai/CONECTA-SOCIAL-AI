"use server";
import type { PostFormat, Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { requireBrand } from "@/lib/auth";
import { runAction, str } from "@/lib/actions";
import { audit } from "@/server/audit";
import { writeScripts } from "@/server/writers/room";
import { enqueueVideo } from "@/server/video/jobs";

export async function writeAboutAction(form: FormData) {
  const { auth, brand } = await requireBrand("EDITOR");
  return runAction("/studio/scripts", async () => {
    const brief = str(form, "brief");
    if (brief.length < 8) throw new Error("Escreva o assunto ou a ideia.");
    const list = await writeScripts(brand.id, { brief, count: 3 });
    await audit(auth.orgId, "scripts.write", { userId: auth.user.id, meta: { brief, count: list.length } });
    return `${list.length} roteiro(s) escritos.`;
  });
}

type Beat = { ato: string; visual: string; fala?: string; texto_tela?: string };

export async function scriptAction(form: FormData) {
  const { auth, brand } = await requireBrand("EDITOR");
  const id = str(form, "id");
  const op = str(form, "op");
  return runAction("/studio/scripts", async () => {
    const sc = await db.script.findFirst({ where: { id, brandId: brand.id } });
    if (!sc) throw new Error("Roteiro não encontrado.");
    const hook = str(form, "hook") || sc.hooks[0] || "";

    if (op === "video") {
      const job = await enqueueVideo({
        orgId: auth.orgId,
        brandId: brand.id,
        brief: `${sc.title} — ${sc.angle ?? ""}`,
        speech: sc.speech,
        visualPrompt: sc.visualPrompt,
        durationSec: 15,
        createdById: auth.user.id,
      });
      await db.script.update({ where: { id }, data: { status: "PRODUCED", videoJobId: job.id } });
      await audit(auth.orgId, "scripts.video", { userId: auth.user.id, entity: "Script", entityId: id });
      return { message: "Roteiro enviado ao AI Video Studio.", redirectTo: "/studio/video" };
    }

    if (op === "post") {
      const beats = ((sc.beats as Beat[] | null) ?? []).slice(0, 8);
      const format = (["REEL", "CAROUSEL", "STORY"].includes(sc.format) ? sc.format : "REEL") as PostFormat;
      const caption = [hook, sc.caption].filter(Boolean).join("\n\n");
      const post = await db.post.create({
        data: {
          orgId: auth.orgId,
          brandId: brand.id,
          pillar: "STORYTELLING",
          format,
          theme: sc.title,
          objective: sc.angle,
          title: hook || sc.title,
          subtitle: sc.bridge?.slice(0, 120) ?? null,
          cta: sc.cta,
          hashtags: sc.hashtags,
          imagePrompt: sc.visualPrompt,
          artDirection: sc.angle,
          layout: format === "CAROUSEL" ? "carousel" : format === "STORY" ? "story" : "hero-bottom",
          slides: format === "CAROUSEL" ? (beats.map((b) => ({ title: b.texto_tela || b.ato, body: b.fala || b.visual })) as unknown as Prisma.InputJsonValue) : undefined,
          reelScript: beats.map((b, i) => `${i + 1}. [${b.ato}] ${b.visual}${b.fala ? ` — FALA: "${b.fala}"` : ""}${b.texto_tela ? ` — TELA: ${b.texto_tela}` : ""}`).join("\n"),
          scheduledAt: new Date(Date.now() + 24 * 3600_000),
          timeReason: "Criado a partir da sala de roteiristas.",
          origin: "AI",
          status: "PLANNED",
          approvalRequired: true,
          approvalReasons: ["Roteiro da sala de roteiristas: revise antes de publicar."],
          targets: { create: [{ network: "INSTAGRAM", caption }, { network: "FACEBOOK", caption }] },
        },
      });
      await db.script.update({ where: { id }, data: { status: "PRODUCED", postId: post.id } });
      await audit(auth.orgId, "scripts.post", { userId: auth.user.id, entity: "Script", entityId: id, meta: { postId: post.id } });
      return { message: "Publicação criada a partir do roteiro. Gere a arte/vídeo e revise.", redirectTo: `/posts/${post.id}` };
    }

    if (op === "rewrite") {
      const note = str(form, "note");
      const list = await writeScripts(brand.id, {
        trendId: sc.trendId,
        brief: `Reescreva e SUPERE este roteiro (${sc.title}). Ângulo: ${sc.angle}. Fala: "${sc.speech}". Crítica anterior: ${sc.critique}. ${note ? `Pedido da equipe: ${note}` : ""}`,
        count: 1,
      });
      await db.script.update({ where: { id }, data: { status: "DISCARDED" } });
      return `Nova versão escrita (nota ${list[0]?.score ?? "—"}).`;
    }

    if (op === "approve" || op === "discard") {
      await db.script.update({ where: { id }, data: { status: op === "approve" ? "APPROVED" : "DISCARDED" } });
      return op === "approve" ? "Roteiro aprovado." : "Roteiro descartado.";
    }
    throw new Error("Operação inválida.");
  });
}
