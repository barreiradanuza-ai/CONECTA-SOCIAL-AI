import { requireBrand } from "@/lib/auth";
import { db } from "@/lib/db";
import { decrypt } from "@/lib/crypto";
import { PageHeader, Flash, IntegrationState, Empty } from "@/components/ui";
import { SubmitButton } from "@/components/client";
import { SettingsTabs } from "../tabs";
import { connectPagesAction, disconnectAccountAction, testAccountAction } from "../actions";
import { metaConfigured, META_SCOPES, redirectUri } from "@/server/meta/oauth";
import type { DiscoveredPage } from "@/server/meta/oauth";
import { formatDateTime } from "@/lib/time";
import { env } from "@/lib/env";
import { igLoginConfig, igRedirectUri, IG_LOGIN_SCOPES } from "@/server/instagram/oauth";

export default async function AccountsPage({ searchParams }: { searchParams: Promise<{ ok?: string; error?: string; pending?: string; rede?: string }> }) {
  const { auth, brand } = await requireBrand("ADMIN");
  const sp = await searchParams;
  const accounts = await db.socialAccount.findMany({ where: { brandId: brand.id }, orderBy: [{ network: "asc" }, { createdAt: "asc" }] });

  let pendingPages: DiscoveredPage[] | null = null;
  if (sp.pending) {
    const p = await db.oAuthPending.findFirst({ where: { id: sp.pending, orgId: auth.orgId, userId: auth.user.id, expiresAt: { gt: new Date() } } });
    if (p) pendingPages = (JSON.parse(decrypt(p.payloadEnc)) as { pages: DiscoveredPage[] }).pages;
  }
  const igConfigured = !!(await igLoginConfig(auth.orgId));
  const rede = sp.rede === "facebook" || sp.rede === "instagram" ? sp.rede : null;
  const showFb = rede !== "instagram";
  const showIg = rede !== "facebook";
  const fbAccounts = accounts.filter((a) => a.network === "FACEBOOK" && a.status !== "DISCONNECTED");
  const igAccounts = accounts.filter((a) => a.network === "INSTAGRAM" && a.status !== "DISCONNECTED");
  const cards = [
    {
      key: "facebook",
      name: "Facebook",
      desc: "Página do Facebook da marca.",
      list: fbAccounts,
      href: "/api/meta/oauth/start?rede=facebook",
      ready: metaConfigured(),
      color: "bg-[#1877F2]",
      letter: "f",
    },
    {
      key: "instagram",
      name: "Instagram",
      desc: "Conta profissional (Empresa ou Criador).",
      list: igAccounts,
      href: "/api/instagram/oauth/start",
      ready: igConfigured,
      color: "bg-gradient-to-br from-[#F58529] via-[#DD2A7B] to-[#8134AF]",
      letter: "IG",
    },
    {
      key: "tiktok",
      name: "TikTok",
      desc: "Conta do TikTok para Reels e artes.",
      list: [] as typeof accounts,
      href: null,
      ready: false,
      color: "bg-black",
      letter: "TT",
    },
  ];

  return (
    <div>
      <PageHeader title="Configurações" subtitle="Conecte cada rede social separadamente. Nenhuma senha pessoal é usada ou armazenada." />
      <SettingsTabs current="accounts" />
      <Flash ok={sp.ok} error={sp.error} />

      {!metaConfigured() && (
        <div className="card mb-6 border-amber-300 bg-amber-50 p-5 text-sm">
          <p className="font-semibold">App da Meta não configurado</p>
          <p className="mt-1">Defina <code>META_APP_ID</code> e <code>META_APP_SECRET</code> nas variáveis do servidor. No painel do app (developers.facebook.com), cadastre a URL de redirecionamento:</p>
          <code className="mt-2 block break-all rounded bg-white p-2">{redirectUri()}</code>
        </div>
      )}

      {pendingPages && (
        <form action={connectPagesAction} className="card mb-6 p-5">
          <input type="hidden" name="pendingId" value={sp.pending} />
          <h2 className="font-semibold">
            {rede === "facebook" ? "Escolha a Página do Facebook" : rede === "instagram" ? "Escolha a conta do Instagram" : "Selecione as contas"} para {brand.name}
          </h2>
          <p className="mb-4 text-sm text-ink-soft">Somente as contas marcadas serão vinculadas a esta marca.</p>
          <ul className="space-y-3">
            {pendingPages.map((p) => (
              <li key={p.id} className="rounded-xl border border-slate-200 p-3">
                {showFb && (
                  <label className="flex items-center gap-2 font-medium">
                    <input type="checkbox" name="fb" value={p.id} defaultChecked={pendingPages!.length === 1} /> Página do Facebook: {p.name}
                  </label>
                )}
                {showIg &&
                  (p.instagram ? (
                    <label className={`flex items-center gap-2 ${showFb ? "ml-6 mt-2 text-sm" : "font-medium"}`}>
                      <input type="checkbox" name="ig" value={p.instagram.id} defaultChecked={!showFb || pendingPages!.length === 1} /> Instagram profissional: @{p.instagram.username}
                      {!showFb && <span className="text-xs font-normal text-ink-mute">(via Página {p.name})</span>}
                    </label>
                  ) : (
                    <p className={`text-xs text-ink-mute ${showFb ? "ml-6 mt-2" : ""}`}>{showFb ? "" : `Página ${p.name}: `}sem conta profissional do Instagram vinculada.</p>
                  ))}
              </li>
            ))}
          </ul>
          <SubmitButton className="btn-primary mt-4">Conectar selecionadas</SubmitButton>
        </form>
      )}

      <div className="mb-2 grid gap-4 md:grid-cols-3">
        {cards.map((c) => (
          <div key={c.key} className="card flex flex-col p-5">
            <div className="flex items-center gap-3">
              <span className={`flex h-10 w-10 items-center justify-center rounded-xl text-sm font-bold text-white ${c.color}`}>{c.letter}</span>
              <div>
                <h2 className="font-semibold">{c.name}</h2>
                <p className="text-xs text-ink-mute">{c.desc}</p>
              </div>
            </div>
            <div className="mt-4 flex-1 space-y-1 text-sm">
              {c.list.length === 0 ? (
                <p className="text-ink-soft">{c.key === "tiktok" ? "Integração em preparação." : "Nenhuma conta conectada."}</p>
              ) : (
                c.list.map((a) => (
                  <div key={a.id} className="flex items-center justify-between gap-2">
                    <span className="truncate">
                      {a.username ? `@${a.username}` : a.name}
                      {a.network === "INSTAGRAM" && <span className="ml-1 text-xs text-ink-mute">{a.linkedPageId ? "(via Página)" : "(login direto)"}</span>}
                    </span>
                    <IntegrationState state={a.status === "ACTIVE" ? "ok" : "error"} />
                  </div>
                ))
              )}
            </div>
            {c.href ? (
              <a href={c.href} className={`btn-primary mt-4 ${c.ready ? "" : "pointer-events-none opacity-50"}`}>
                {c.list.length ? `Reconectar ${c.name}` : `Conectar ${c.name}`}
              </a>
            ) : (
              <button type="button" disabled className="btn-ghost mt-4">Em breve</button>
            )}
            {c.key === "instagram" && (
              <div className="mt-2 text-center text-xs text-ink-mute">
                {!igConfigured && <p className="mb-1 text-amber-700">Falta cadastrar o app do Instagram (veja abaixo).</p>}
              </div>
            )}
          </div>
        ))}
      </div>
      {!igConfigured && (
        <details className="card mb-4 border-amber-300 bg-amber-50 p-5 text-sm" open>
          <summary className="cursor-pointer font-semibold">Para conectar o Instagram direto (sem Página do Facebook)</summary>
          <ol className="mt-3 list-decimal space-y-1 pl-5 text-ink-soft">
            <li>Em developers.facebook.com, abra o app da Meta → <b>Instagram</b> → <b>Configuração da API com login do Instagram</b>.</li>
            <li>Em <b>Configurar login comercial do Instagram</b>, cadastre esta URL de redirecionamento:</li>
          </ol>
          <code className="mt-2 block break-all rounded bg-white p-2">{igRedirectUri()}</code>
          <ol start={3} className="mt-2 list-decimal space-y-1 pl-5 text-ink-soft">
            <li>Copie o <b>ID do app do Instagram</b> e a <b>Chave secreta do app do Instagram</b> e cole em <b>Integrações e chaves</b> (campos Instagram).</li>
            <li>Enquanto o app estiver em modo desenvolvimento: em <b>Funções do app → Funções → Testadores do Instagram</b>, adicione a conta do Instagram e aceite o convite no Instagram (Configurações → Apps e sites → Convites de testador).</li>
            <li>Volte aqui e clique em <b>Conectar Instagram</b>. Permissões: {IG_LOGIN_SCOPES.join(", ")}.</li>
          </ol>
        </details>
      )}
      <p className="mb-6 text-xs text-ink-mute">Versão da Graph API: {env.meta.graphVersion}. Ao reconectar, o login da Meta renova o acesso — se aparecer erro de acesso, entre em facebook.com, resolva o aviso de segurança e clique em Reconectar.</p>

      {accounts.length === 0 ? (
        <Empty title="Nenhuma conta conectada">Use os botões acima para conectar cada rede separadamente.</Empty>
      ) : (
        <div className="card overflow-x-auto">
          <table className="table">
            <thead><tr><th>Rede</th><th>Conta</th><th>Estado</th><th>Última verificação</th><th>Permissões</th><th /></tr></thead>
            <tbody>
              {accounts.map((a) => (
                <tr key={a.id}>
                  <td className="font-medium">{a.network === "INSTAGRAM" ? "Instagram" : a.network === "FACEBOOK" ? "Facebook" : a.network}</td>
                  <td>{a.username ? `@${a.username}` : a.name}<div className="text-xs text-ink-mute">ID {a.externalId}</div></td>
                  <td>
                    <IntegrationState state={a.status === "ACTIVE" ? "ok" : a.status === "DISCONNECTED" ? "missing" : "error"} />
                    {a.lastError && <div className="mt-1 max-w-xs text-xs text-red-700">{a.lastError}</div>}
                  </td>
                  <td className="text-xs">{formatDateTime(a.lastCheckedAt, brand.timezone)}</td>
                  <td className="max-w-xs text-[11px] text-ink-mute">{a.scopes.length ? a.scopes.join(", ") : "—"}</td>
                  <td className="whitespace-nowrap">
                    <form action={testAccountAction} className="inline"><input type="hidden" name="id" value={a.id} /><SubmitButton className="btn-ghost btn-sm" pendingText="Testando…">Testar</SubmitButton></form>{" "}
                    {a.status !== "DISCONNECTED" && (
                      <form action={disconnectAccountAction} className="inline"><input type="hidden" name="id" value={a.id} /><SubmitButton className="btn-danger btn-sm" confirm="Desconectar esta conta? Publicações agendadas para ela falharão.">Desconectar</SubmitButton></form>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <details className="card mt-6 p-5 text-sm">
        <summary className="cursor-pointer font-semibold">Requisitos da Meta (leia antes de conectar)</summary>
        <ul className="mt-3 list-disc space-y-1 pl-5 text-ink-soft">
          <li>A conta do Instagram precisa ser profissional (Empresa ou Criador) e estar vinculada à Página do Facebook.</li>
          <li>Permissões solicitadas: {META_SCOPES.join(", ")}.</li>
          <li>Enquanto o app estiver em modo de desenvolvimento, apenas usuários com papel no app conseguem autorizar. Para uso comercial contínuo, as permissões avançadas precisam passar pelo App Review e o negócio pela verificação da Meta.</li>
          <li>Limite do Instagram: 100 publicações via API a cada 24h por conta. O app consulta a cota antes de publicar.</li>
          <li>O token de Página obtido a partir do login de longa duração não expira por tempo, mas é invalidado se a senha mudar ou o acesso for revogado — o app verifica diariamente e alerta.</li>
        </ul>
      </details>
    </div>
  );
}
