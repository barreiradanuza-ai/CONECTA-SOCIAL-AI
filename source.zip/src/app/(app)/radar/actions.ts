"use server";
import { db } from "@/lib/db";
import { requireBrand } from "@/lib/auth";
import { runAction, str } from "@/lib/actions";
import { audit } from "@/server/audit";
import { runRadar } from "@/server/radar/radar";
import { writeScripts } from "@/server/writers/room";

export async function runRadarAction() {
  const { auth, brand } = await requireBrand("EDITOR");
  return runAction("/radar", async () => {
    const r = await runRadar(brand.id, "manual");
    await audit(auth.orgId, "radar.run", { userId: auth.user.id, meta: { result: r } });
    return `Radar concluído — ${r}.`;
  });
}

export async function decideTrendAction(form: FormData) {
  const { auth, brand } = await requireBrand("EDITOR");
  const id = str(form, "id");
  const decision = str(form, "decision");
  return runAction("/radar", async () => {
    const t = await db.trendNote.findFirst({ where: { id, brandId: brand.id } });
    if (!t) throw new Error("Pauta não encontrada.");
    if (decision === "approve" || decision === "reject") {
      await db.trendNote.update({ where: { id }, data: { status: decision === "approve" ? "APPROVED" : "REJECTED", decidedAt: new Date() } });
      await audit(auth.orgId, `radar.${decision}`, { userId: auth.user.id, entity: "TrendNote", entityId: id, meta: { title: t.title } });
      return decision === "approve" ? "Pauta aprovada: a IA de conteúdo já pode usar." : "Pauta descartada.";
    }
    if (decision === "write") {
      if (t.status !== "APPROVED") await db.trendNote.update({ where: { id }, data: { status: "APPROVED", decidedAt: new Date() } });
      const list = await writeScripts(brand.id, { trendId: id, count: 3 });
      await audit(auth.orgId, "scripts.write", { userId: auth.user.id, entity: "TrendNote", entityId: id, meta: { count: list.length } });
      return { message: `${list.length} roteiros escritos para “${t.title}”.`, redirectTo: "/studio/scripts" };
    }
    throw new Error("Decisão inválida.");
  });
}
