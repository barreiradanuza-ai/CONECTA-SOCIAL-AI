import Link from "next/link";
import { requireBrand } from "@/lib/auth";
import { db } from "@/lib/db";
import { PageHeader, Flash } from "@/components/ui";
import { SubmitButton } from "@/components/client";
import { Section } from "@/components/traffic";
import { getSecret } from "@/server/integrations";
import { formatDateTime } from "@/lib/time";
import { runRadarAction, decideTrendAction } from "./actions";

export const dynamic = "force-dynamic";

function Score({ label, value, invert }: { label: string; value: number | null; invert?: boolean }) {
  if (value == null) return null;
  const good = invert ? value <= 3 : value >= 7;
  const bad = invert ? value >= 6 : value <= 4;
  return <span className={`badge ${good ? "bg-emerald-100 text-emerald-800" : bad ? "bg-red-100 text-red-800" : "bg-amber-100 text-amber-900"}`}>{label} {value}/10</span>;
}

export default async function RadarPage({ searchParams }: { searchParams: Promise<{ ok?: string; error?: string }> }) {
  const { auth, brand } = await requireBrand();
  const sp = await searchParams;
  const now = new Date();
  const [settings, pending, approved, lastRun, runs, serp, apify, anthropic] = await Promise.all([
    db.automationSettings.findUnique({ where: { brandId: brand.id } }),
    db.trendNote.findMany({ where: { brandId: brand.id, status: "PENDING", validUntil: { gte: now } }, orderBy: [{ fitScore: "desc" }, { createdAt: "desc" }] }),
    db.trendNote.findMany({ where: { brandId: brand.id, status: "APPROVED", validUntil: { gte: now } }, orderBy: { createdAt: "desc" }, take: 20 }),
    db.radarRun.findFirst({ where: { brandId: brand.id }, orderBy: { createdAt: "desc" } }),
    db.radarRun.findMany({ where: { brandId: brand.id }, orderBy: { createdAt: "desc" }, take: 8 }),
    getSecret(auth.orgId, "SERPAPI_API_KEY"),
    getSecret(auth.orgId, "APIFY_TOKEN"),
    getSecret(auth.orgId, "ANTHROPIC_API_KEY"),
  ]);

  return (
    <div>
      <PageHeader
        title="Radar de tendências"
        subtitle="Virais do Brasil e do mundo, ligados ao universo da conexão e filtrados para a persona. Roda todo dia a partir das 6h; pautas aprovadas viram roteiros sozinhas."
        actions={
          <form action={runRadarAction}>
            <SubmitButton className="btn-accent" pendingText="Pesquisando a internet… (1-3 min)">Rodar radar agora</SubmitButton>
          </form>
        }
      />
      <Flash ok={sp.ok} error={sp.error} />

      <div className="mb-6 grid gap-4 md:grid-cols-4">
        {[
          ["Claude + busca na web", !!anthropic],
          ["Google Trends + notícias (SerpApi)", !!serp],
          ["TikTok/Instagram (Apify)", !!apify],
        ].map(([k, ok]) => (
          <div key={String(k)} className="card flex items-center justify-between p-4 text-sm">
            <span>{k}</span>
            <span className={`badge ${ok ? "bg-emerald-100 text-emerald-800" : "bg-slate-200 text-slate-700"}`}>{ok ? "Conectado" : "Sem chave"}</span>
          </div>
        ))}
        <div className="card p-4 text-sm">
          Auto-aprovação: <strong>{settings?.radarAutoApprove ? "ligada (risco ≤3 e encaixe ≥7)" : "desligada"}</strong>
          <Link href="/settings/automation" className="block text-xs text-accent">alterar</Link>
        </div>
      </div>

      {lastRun && (
        <div className={`mb-6 rounded-2xl p-5 ${lastRun.error ? "border border-red-200 bg-red-50 text-red-900" : "bg-gradient-to-r from-navy to-navy-600 text-white"}`}>
          <div className={`text-[11px] font-bold uppercase tracking-widest ${lastRun.error ? "" : "text-cyan"}`}>Última varredura · {formatDateTime(lastRun.createdAt, brand.timezone)}</div>
          <p className="mt-2 text-sm leading-relaxed">{lastRun.error ? `Falhou: ${lastRun.error}` : lastRun.summary}</p>
          {!lastRun.error && <p className="mt-2 text-xs opacity-70">{lastRun.created} pautas · {lastRun.searches} buscas na web · {Array.isArray(lastRun.signals) ? (lastRun.signals as unknown[]).length : 0} sinais coletados</p>}
          {lastRun.warnings.length > 0 && <p className="mt-2 text-xs opacity-70">{lastRun.warnings.join(" · ")}</p>}
        </div>
      )}

      <h2 className="mb-3 text-lg font-bold">Pautas para aprovar ({pending.length})</h2>
      {pending.length === 0 && <div className="card mb-6 p-6 text-sm text-ink-soft">Nenhuma pauta pendente.</div>}
      <div className="mb-8 grid gap-4 lg:grid-cols-2">
        {pending.map((t) => (
          <article key={t.id} className="card flex flex-col p-5">
            <div className="mb-2 flex flex-wrap gap-2">
              <Score label="Encaixe" value={t.fitScore} />
              <Score label="Risco" value={t.riskScore} invert />
              <span className="badge bg-navy text-white">{t.scope === "GLOBAL" ? "viral mundial" : "Brasil"}</span>
              {t.formats.map((f) => <span key={f} className="badge bg-slate-100 text-slate-700">{f}</span>)}
              <span className="badge bg-slate-100 text-slate-500">vale até {formatDateTime(t.validUntil, brand.timezone)}</span>
            </div>
            <h3 className="text-base font-semibold">{t.title}</h3>
            <p className="mt-1 text-sm text-ink-soft">{t.text}</p>
            {t.bridge && <p className="mt-3 rounded-xl bg-navy-50 p-3 text-sm text-navy"><strong>Ponte com a conexão:</strong> {t.bridge}</p>}
            {t.angle && <p className="mt-2 rounded-xl bg-cyan-soft p-3 text-sm text-navy"><strong>Ângulo da persona:</strong> {t.angle}</p>}
            {t.riskNote && <p className="mt-2 text-xs text-red-700">Risco: {t.riskNote}</p>}
            {t.sourceUrl && <a href={t.sourceUrl} target="_blank" rel="noreferrer" className="mt-2 truncate text-xs text-accent underline">{t.sourceUrl}</a>}
            <form action={decideTrendAction} className="mt-4 flex flex-wrap gap-2 border-t border-slate-100 pt-4">
              <input type="hidden" name="id" value={t.id} />
              <SubmitButton name="decision" value="approve" className="btn-primary btn-sm">Aprovar pauta</SubmitButton>
              <SubmitButton name="decision" value="write" className="btn-accent btn-sm" pendingText="Escrevendo roteiros… (1-2 min)">Aprovar e escrever roteiros</SubmitButton>
              <SubmitButton name="decision" value="reject" className="btn-ghost btn-sm">Descartar</SubmitButton>
            </form>
          </article>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <Section title={`Pautas ativas (${approved.length})`} subtitle="A IA de conteúdo usa estas pautas nos próximos posts" className="lg:col-span-2">
          {approved.length === 0 ? (
            <p className="text-sm text-ink-soft">Nenhuma pauta ativa. Sem pautas, a IA usa só situações do cotidiano (sem citar fatos reais).</p>
          ) : (
            <ul className="divide-y divide-slate-100">
              {approved.map((t) => (
                <li key={t.id} className="flex flex-wrap items-center gap-2 py-2.5 text-sm">
                  <span className="min-w-0 flex-1 truncate font-medium">{t.title ?? t.text}</span>
                  <span className="badge bg-slate-100 text-slate-600">{t.origin === "RADAR" ? "radar" : "manual"}</span>
                  <form action={decideTrendAction}>
                    <input type="hidden" name="id" value={t.id} />
                    <SubmitButton name="decision" value="write" className="btn-ghost btn-sm" pendingText="Escrevendo…">Escrever roteiros</SubmitButton>
                  </form>
                </li>
              ))}
            </ul>
          )}
        </Section>
        <Section title="Histórico do radar">
          <ul className="space-y-2 text-xs">
            {runs.map((r) => (
              <li key={r.id} className="flex justify-between gap-2">
                <span>{formatDateTime(r.createdAt, brand.timezone)} · {r.trigger === "manual" ? "manual" : "auto"}</span>
                <span className={r.error ? "text-red-700" : "text-ink-soft"}>{r.error ? "erro" : `${r.created} pautas`}</span>
              </li>
            ))}
            {runs.length === 0 && <li className="text-ink-soft">Ainda não rodou.</li>}
          </ul>
        </Section>
      </div>
    </div>
  );
}
