import Link from "next/link";
import { notFound } from "next/navigation";
import { requireBrand } from "@/lib/auth";
import { db } from "@/lib/db";
import { PageHeader, Flash, Field, StatusBadge, FormatBadge } from "@/components/ui";
import { SubmitButton } from "@/components/client";
import { updateAssetAction, deleteAssetAction, regenerateAssetAction, applyOutroAction } from "../../settings/actions";
import { mediaPath } from "@/server/storage";
import { FullEditor } from "../../posts/[id]/full-editor";
import { splitOutroPhrase } from "@/server/video/outro";
import { useVideoAction } from "../../posts/actions";
import { formatDate } from "@/lib/time";

const ROLE_OPTIONS: { value: string; label: string }[] = [
  { value: "PHOTO", label: "Fotografia" },
  { value: "REFERENCE", label: "Referência visual" },
  { value: "CHARACTER_REFERENCE", label: "Referência do personagem" },
  { value: "APPROVED_PIECE", label: "Peça aprovada" },
  { value: "COMPOSED", label: "Peça final (gerada)" },
  { value: "GENERATED", label: "Imagem de IA" },
  { value: "GRAPHIC_ELEMENT", label: "Elemento gráfico" },
  { value: "LOGO_PRIMARY", label: "Logotipo principal" },
  { value: "LOGO_TRANSPARENT", label: "Logotipo (transparente)" },
  { value: "LOGO_ALT", label: "Logotipo alternativo" },
];

export default async function MediaEditPage({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ ok?: string; error?: string; back?: string }> }) {
  const { brand } = await requireBrand();
  const { id } = await params;
  const sp = await searchParams;
  const a = await db.mediaAsset.findFirst({
    where: { id, brandId: brand.id },
    include: { postMedia: { include: { post: { select: { id: true, title: true, theme: true, status: true, format: true, scheduledAt: true } } }, orderBy: { position: "asc" } } },
  });
  if (!a) notFound();
  const back = sp.back && sp.back.startsWith("/media") ? sp.back : "/media";
  const self = `/media/${a.id}?back=${encodeURIComponent(back)}`;
  const posts = [...new Map(a.postMedia.map((pm) => [pm.post.id, pm.post])).values()];
  const canRegenerate = a.source === "AI" && (a.kind === "VIDEO" || (a.kind === "IMAGE" && a.role === "GENERATED"));
  const job = a.kind === "VIDEO" ? await db.videoJob.findFirst({ where: { videoAssetId: a.id }, orderBy: { createdAt: "desc" } }) : null;
  // Publicação ligada a este arquivo (ainda não publicada): mostra o editor completo dela aqui mesmo
  const linkedPostId = posts.find((p) => !["PUBLISHED", "PUBLISHING", "PARTIALLY_PUBLISHED", "CANCELED"].includes(p.status))?.id ?? job?.postId ?? null;
  const editPost = linkedPostId
    ? await db.post.findFirst({ where: { id: linkedPostId, brandId: brand.id, status: { notIn: ["PUBLISHED", "PUBLISHING", "PARTIALLY_PUBLISHED", "CANCELED"] } }, include: { targets: { orderBy: { network: "asc" } } } })
    : null;
  // Vídeo da persona: há uma versão mais nova (pronta ou em produção) para a mesma publicação?
  const postForJobs = editPost?.id ?? job?.postId ?? null;
  const wa = a.kind === "VIDEO" ? await db.whatsAppConfig.findUnique({ where: { brandId: brand.id }, select: { ctaText: true } }) : null;
  const pubPost = a.kind === "VIDEO" && (editPost?.id ?? job?.postId)
    ? await db.post.findFirst({ where: { id: (editPost?.id ?? job?.postId)!, brandId: brand.id }, include: { media: { where: { purpose: "VIDEO" }, select: { assetId: true } } } })
    : null;
  const isPostVideo = !!pubPost?.media.some((m) => m.assetId === a.id);
  const outroDefault = splitOutroPhrase(editPost?.cta ?? wa?.ctaText ?? "Quer descobrir qual internet está disponível no seu endereço? Fale com um especialista pelo WhatsApp.");
  const newerJob =
    a.kind === "VIDEO" && postForJobs
      ? await db.videoJob.findFirst({ where: { postId: postForJobs, createdAt: { gt: job?.createdAt ?? a.createdAt }, status: { not: "CANCELED" } }, orderBy: { createdAt: "desc" } })
      : null;

  return (
    <div>
      <PageHeader title="Editar arquivo" subtitle={a.title ?? a.originalName ?? undefined} actions={<Link href={back} className="btn-ghost">← Voltar à biblioteca</Link>} />
      <Flash ok={sp.ok} error={sp.error} />
      {pubPost && !["PUBLISHED", "PUBLISHING", "CANCELED"].includes(pubPost.status) && (
        <div className="card mb-4 flex flex-col gap-3 border-blue-200 p-4 md:flex-row md:items-center md:justify-between">
          <div className="text-sm">
            <div className="font-semibold">Publicação: {pubPost.title ?? pubPost.theme}</div>
            <div className="text-ink-soft">{isPostVideo ? "Este é o vídeo que vai ser publicado." : "Atenção: a publicação está usando outro vídeo. Use os botões para publicar ESTE vídeo (com o fechamento que você fez)."}</div>
          </div>
          <div className="flex flex-wrap gap-2">
            {!isPostVideo && (
              <form action={useVideoAction}>
                <input type="hidden" name="id" value={pubPost.id} />
                <input type="hidden" name="videoId" value={a.id} />
                <input type="hidden" name="back" value={self} />
                <SubmitButton className="btn-ghost" pendingText="Aguarde…">Usar este vídeo na publicação</SubmitButton>
              </form>
            )}
            <form action={useVideoAction}>
              <input type="hidden" name="id" value={pubPost.id} />
              <input type="hidden" name="videoId" value={a.id} />
              <input type="hidden" name="publish" value="1" />
              <input type="hidden" name="back" value={self} />
              <SubmitButton className="btn-accent" pendingText="Enviando…" confirm={`Publicar agora${isPostVideo ? "" : " com ESTE vídeo"} nas redes da publicação (${pubPost.title ?? pubPost.theme})?`}>
                {isPostVideo ? "Publicar agora" : "Usar este vídeo e publicar agora"}
              </SubmitButton>
            </form>
          </div>
        </div>
      )}
      {pubPost?.status === "PUBLISHING" && <div className="mb-4 rounded-xl bg-blue-50 p-3 text-sm text-blue-900">A publicação está sendo enviada às redes agora.</div>}
      {pubPost?.status === "PUBLISHED" && <div className="mb-4 rounded-xl bg-emerald-50 p-3 text-sm text-emerald-900">Esta publicação já foi publicada. <Link href={`/posts/${pubPost.id}`} className="underline">ver resultado</Link></div>}
      {newerJob && newerJob.videoAssetId && newerJob.videoAssetId !== a.id && !isPostVideo && (
        <div className="mb-4 flex flex-wrap items-center justify-between gap-2 rounded-xl bg-emerald-50 p-3 text-sm text-emerald-900">
          <span>Este vídeo foi substituído por uma versão nova, já pronta.</span>
          <Link href={`/media/${newerJob.videoAssetId}?back=${encodeURIComponent(back)}`} className="btn-primary btn-sm">Ver o vídeo novo →</Link>
        </div>
      )}
      {newerJob && ["QUEUED", "VOICE_READY", "SUBMITTED"].includes(newerJob.status) && (
        <div className="mb-4 rounded-xl bg-blue-50 p-3 text-sm text-blue-900">
          Vídeo novo em produção (etapa: {newerJob.status === "QUEUED" ? "na fila" : newerJob.status === "VOICE_READY" ? "voz pronta" : "gerando na MiniMax"}). Leva alguns minutos; atualize a página depois. Ele vai aparecer como um arquivo novo e na publicação.
        </div>
      )}
      {newerJob && newerJob.status === "FAILED" && (
        <div className="mb-4 rounded-xl bg-red-50 p-3 text-sm text-red-800">O vídeo novo falhou: {newerJob.error ?? "erro desconhecido"}</div>
      )}
      <div className="grid gap-6 lg:grid-cols-2">
        <div className="card overflow-hidden">
          {a.kind === "IMAGE" ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={mediaPath(a.storageKey)} alt={a.title ?? ""} className="w-full bg-slate-100 object-contain" />
          ) : a.kind === "VIDEO" ? (
            <video src={mediaPath(a.storageKey)} className="w-full bg-black" controls preload="metadata" />
          ) : (
            <div className="flex aspect-square items-center justify-center bg-slate-100 text-sm">{a.mimeType}</div>
          )}
          <div className="p-3 text-xs text-ink-mute">
            {a.role} · {a.width && a.height ? `${a.width}×${a.height} · ` : ""}{formatDate(a.createdAt)}
          </div>
        </div>

        <div className="space-y-6">
          {posts.length > 0 && !editPost && (
            <div className="card space-y-3 p-5">
              <h2 className="font-semibold">Editar texto e arte</h2>
              <p className="text-sm text-ink-soft">Esta peça foi gerada a partir de uma publicação. Para mudar o título, o texto dos slides, a legenda ou gerar a arte de novo, edite a publicação — a peça é refeita a partir dela.</p>
              <ul className="space-y-2">
                {posts.map((p) => (
                  <li key={p.id} className="flex flex-wrap items-center justify-between gap-2 rounded-lg ring-1 ring-slate-200 p-3">
                    <div className="min-w-0">
                      <div className="truncate text-sm font-medium">{p.title || p.theme}</div>
                      <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-ink-mute">
                        <StatusBadge status={p.status} />
                        <FormatBadge format={p.format} />
                        {p.scheduledAt && <span>{formatDate(p.scheduledAt)}</span>}
                      </div>
                    </div>
                    <Link href={`/posts/${p.id}`} className="btn-primary btn-sm">Editar publicação</Link>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {a.kind === "VIDEO" && (
            <form action={applyOutroAction} className="card space-y-3 border-emerald-200 p-5">
              <input type="hidden" name="id" value={a.id} />
              <input type="hidden" name="back" value={self} />
              <div>
                <h2 className="font-semibold">Fechamento com logo</h2>
                <p className="text-xs text-ink-mute">Acrescenta ao final <b>deste mesmo vídeo</b>: a imagem escurece e aparece a logo da Conecta Aqui com a frase abaixo. Não gera vídeo novo nem consome crédito de vídeo. {a.originalKey ? "Este vídeo já tem fechamento: refazer troca o texto e o fundo, sem duplicar o final." : ""}</p>
              </div>
              <Field label="Título (grande, em negrito)">
                <input className="input" name="title" maxLength={90} required defaultValue={outroDefault.title} />
              </Field>
              <Field label="Subtítulo (menor, mais leve) — opcional">
                <input className="input" name="subtitle" maxLength={140} defaultValue={outroDefault.subtitle} />
              </Field>
              <Field label="Fundo da vinheta">
                <select name="style" className="input" defaultValue="auto">
                  <option value="auto">Automático (varia a cada vez)</option>
                  <option value="video">O próprio vídeo escurecendo por baixo</option>
                  <option value="dark">Fundo escuro da marca</option>
                  <option value="image">Imagem da publicação escurecida</option>
                </select>
              </Field>
              <SubmitButton className="btn-accent" pendingText="Inserindo o fechamento… (até 1 min)">{a.originalKey ? "Refazer o fechamento" : "Inserir fechamento neste vídeo"}</SubmitButton>
            </form>
          )}

          {editPost && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-ink-soft">Conteúdo da publicação <b>{editPost.title ?? editPost.theme}</b></span>
                <Link href={`/posts/${editPost.id}`} className="text-accent">abrir publicação →</Link>
              </div>
              <FullEditor post={editPost} mode={editPost.status === "BRIEF_REVIEW" ? "brief" : "edit"} back={self} />
            </div>
          )}

          {canRegenerate && !editPost && (
            <form action={regenerateAssetAction} className="card space-y-4 border-violet-200 p-5">
              <input type="hidden" name="id" value={a.id} />
              <input type="hidden" name="back" value={self} />
              <div>
                <h2 className="font-semibold">Editar prompt e gerar novamente</h2>
                <p className="text-xs text-ink-mute">{a.kind === "VIDEO" ? "Ajuste a fala e a cena e gere um novo vídeo da persona. O vídeo atual continua na biblioteca." : "Ajuste a descrição da imagem (sem textos ou logotipo) e gere uma nova versão. A imagem atual continua na biblioteca."}</p>
              </div>
              {a.kind === "VIDEO" ? (
                <>
                  <Field label="Fala do personagem (até ~30 palavras)">
                    <textarea className="input min-h-24 text-sm" name="speech" defaultValue={job?.speech ?? a.title ?? ""} maxLength={600} required />
                  </Field>
                  <Field label="Cena do vídeo (em inglês: cenário, enquadramento, gestos, câmera)">
                    <textarea className="input min-h-40 font-mono text-xs" name="visualPrompt" defaultValue={job?.visualPrompt ?? a.prompt ?? ""} maxLength={3000} required />
                  </Field>
                </>
              ) : (
                <Field label="Prompt da imagem">
                  <textarea className="input min-h-40 font-mono text-xs" name="prompt" defaultValue={a.prompt ?? ""} maxLength={4000} required />
                </Field>
              )}
              <SubmitButton
                className="btn-accent"
                pendingText={a.kind === "VIDEO" ? "Enviando para produção…" : "Gerando imagem (até 1 min)…"}
                confirm={a.kind === "VIDEO" ? "Gerar um novo vídeo com esta fala e esta cena? Consome crédito de vídeo da MiniMax." : "Gerar uma nova imagem com este prompt?"}
              >
                Gerar novamente
              </SubmitButton>
            </form>
          )}

          <form action={updateAssetAction} className="card space-y-4 p-5">
            <h2 className="font-semibold">Informações do arquivo</h2>
            <input type="hidden" name="id" value={a.id} />
            <input type="hidden" name="back" value={self} />
            <Field label="Nome"><input className="input" name="title" defaultValue={a.title ?? a.originalName ?? ""} /></Field>
            {a.kind === "IMAGE" && (
              <Field label="Tipo">
                <select name="role" className="input" defaultValue={a.role}>
                  {ROLE_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                </select>
              </Field>
            )}
            <Field label="Tags" hint="Separe por vírgula. Ajudam a IA a escolher o arquivo certo."><input className="input" name="tags" defaultValue={a.tags.join(", ")} /></Field>
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="approved" defaultChecked={a.isApproved} /> Aprovado para uso automático</label>
            {a.prompt && !canRegenerate && (
              <details className="text-xs text-ink-mute">
                <summary className="cursor-pointer">Prompt usado na geração</summary>
                <p className="mt-2 whitespace-pre-wrap">{a.prompt}</p>
              </details>
            )}
            <div className="flex items-center gap-3">
              <SubmitButton>Salvar</SubmitButton>
              <a href={mediaPath(a.storageKey)} download className="text-sm text-accent">baixar</a>
            </div>
          </form>

          <form action={deleteAssetAction} className="text-right">
            <input type="hidden" name="id" value={a.id} />
            <input type="hidden" name="back" value={back} />
            <SubmitButton className="text-sm text-red-600" confirm="Excluir este arquivo? Se ele estiver em alguma publicação ainda não publicada, ela volta para aprovação para gerar a arte de novo.">Excluir arquivo</SubmitButton>
          </form>
        </div>
      </div>
    </div>
  );
}
