import Link from "next/link";
import { notFound } from "next/navigation";
import { requireBrand } from "@/lib/auth";
import { db } from "@/lib/db";
import { PageHeader, Flash, Field, StatusBadge, FormatBadge } from "@/components/ui";
import { SubmitButton } from "@/components/client";
import { updateAssetAction, deleteAssetAction } from "../../settings/actions";
import { mediaPath } from "@/server/storage";
import { formatDate } from "@/lib/time";

const ROLE_OPTIONS: { value: string; label: string }[] = [
  { value: "PHOTO", label: "Fotografia" },
  { value: "REFERENCE", label: "Referência visual" },
  { value: "CHARACTER_REFERENCE", label: "Referência do personagem" },
  { value: "APPROVED_PIECE", label: "Peça aprovada" },
  { value: "COMPOSED", label: "Peça final (gerada)" },
  { value: "GENERATED", label: "Imagem de IA" },
  { value: "GRAPHIC_ELEMENT", label: "Elemento gráfico" },
  { value: "LOGO_PRIMARY", label: "Logotipo principal" },
  { value: "LOGO_TRANSPARENT", label: "Logotipo (transparente)" },
  { value: "LOGO_ALT", label: "Logotipo alternativo" },
];

export default async function MediaEditPage({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ ok?: string; error?: string; back?: string }> }) {
  const { brand } = await requireBrand();
  const { id } = await params;
  const sp = await searchParams;
  const a = await db.mediaAsset.findFirst({
    where: { id, brandId: brand.id },
    include: { postMedia: { include: { post: { select: { id: true, title: true, theme: true, status: true, format: true, scheduledAt: true } } }, orderBy: { position: "asc" } } },
  });
  if (!a) notFound();
  const back = sp.back && sp.back.startsWith("/media") ? sp.back : "/media";
  const self = `/media/${a.id}?back=${encodeURIComponent(back)}`;
  const posts = [...new Map(a.postMedia.map((pm) => [pm.post.id, pm.post])).values()];

  return (
    <div>
      <PageHeader title="Editar arquivo" subtitle={a.title ?? a.originalName ?? undefined} actions={<Link href={back} className="btn-ghost">← Voltar à biblioteca</Link>} />
      <Flash ok={sp.ok} error={sp.error} />
      <div className="grid gap-6 lg:grid-cols-2">
        <div className="card overflow-hidden">
          {a.kind === "IMAGE" ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={mediaPath(a.storageKey)} alt={a.title ?? ""} className="w-full bg-slate-100 object-contain" />
          ) : a.kind === "VIDEO" ? (
            <video src={mediaPath(a.storageKey)} className="w-full bg-black" controls preload="metadata" />
          ) : (
            <div className="flex aspect-square items-center justify-center bg-slate-100 text-sm">{a.mimeType}</div>
          )}
          <div className="p-3 text-xs text-ink-mute">
            {a.role} · {a.width && a.height ? `${a.width}×${a.height} · ` : ""}{formatDate(a.createdAt)}
          </div>
        </div>

        <div className="space-y-6">
          {posts.length > 0 && (
            <div className="card space-y-3 p-5">
              <h2 className="font-semibold">Editar texto e arte</h2>
              <p className="text-sm text-ink-soft">Esta peça foi gerada a partir de uma publicação. Para mudar o título, o texto dos slides, a legenda ou gerar a arte de novo, edite a publicação — a peça é refeita a partir dela.</p>
              <ul className="space-y-2">
                {posts.map((p) => (
                  <li key={p.id} className="flex flex-wrap items-center justify-between gap-2 rounded-lg ring-1 ring-slate-200 p-3">
                    <div className="min-w-0">
                      <div className="truncate text-sm font-medium">{p.title || p.theme}</div>
                      <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-ink-mute">
                        <StatusBadge status={p.status} />
                        <FormatBadge format={p.format} />
                        {p.scheduledAt && <span>{formatDate(p.scheduledAt)}</span>}
                      </div>
                    </div>
                    <Link href={`/posts/${p.id}`} className="btn-primary btn-sm">Editar publicação</Link>
                  </li>
                ))}
              </ul>
            </div>
          )}

          <form action={updateAssetAction} className="card space-y-4 p-5">
            <h2 className="font-semibold">Informações do arquivo</h2>
            <input type="hidden" name="id" value={a.id} />
            <input type="hidden" name="back" value={self} />
            <Field label="Nome"><input className="input" name="title" defaultValue={a.title ?? a.originalName ?? ""} /></Field>
            {a.kind === "IMAGE" && (
              <Field label="Tipo">
                <select name="role" className="input" defaultValue={a.role}>
                  {ROLE_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                </select>
              </Field>
            )}
            <Field label="Tags" hint="Separe por vírgula. Ajudam a IA a escolher o arquivo certo."><input className="input" name="tags" defaultValue={a.tags.join(", ")} /></Field>
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="approved" defaultChecked={a.isApproved} /> Aprovado para uso automático</label>
            {a.prompt && (
              <details className="text-xs text-ink-mute">
                <summary className="cursor-pointer">Prompt usado na geração</summary>
                <p className="mt-2 whitespace-pre-wrap">{a.prompt}</p>
              </details>
            )}
            <div className="flex items-center gap-3">
              <SubmitButton>Salvar</SubmitButton>
              <a href={mediaPath(a.storageKey)} download className="text-sm text-accent">baixar</a>
            </div>
          </form>

          <form action={deleteAssetAction} className="text-right">
            <input type="hidden" name="id" value={a.id} />
            <input type="hidden" name="back" value={back} />
            <SubmitButton className="text-sm text-red-600" confirm="Excluir este arquivo?">Excluir arquivo</SubmitButton>
          </form>
        </div>
      </div>
    </div>
  );
}
