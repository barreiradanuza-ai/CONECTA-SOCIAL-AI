import Link from "next/link";
import type { AssetRole, Prisma } from "@prisma/client";
import { requireBrand } from "@/lib/auth";
import { db } from "@/lib/db";
import { PageHeader, Flash, Empty, Field } from "@/components/ui";
import { SubmitButton } from "@/components/client";
import { uploadAssetAction, deleteAssetAction, toggleAssetApprovalAction, bulkMediaAction } from "../settings/actions";
import { BulkBar, BulkCheckbox } from "@/components/bulk";
import { mediaPath } from "@/server/storage";
import { formatDate } from "@/lib/time";

const FILTERS: { key: string; label: string; roles?: AssetRole[] }[] = [
  { key: "all", label: "Tudo" },
  { key: "LOGO", label: "Logotipos", roles: ["LOGO_PRIMARY", "LOGO_TRANSPARENT", "LOGO_ALT"] },
  { key: "PHOTO", label: "Fotografias", roles: ["PHOTO", "REFERENCE"] },
  { key: "CHARACTER", label: "Personagem", roles: ["CHARACTER_REFERENCE"] },
  { key: "GENERATED", label: "Imagens de IA", roles: ["GENERATED"] },
  { key: "COMPOSED", label: "Peças finais", roles: ["COMPOSED", "APPROVED_PIECE"] },
  { key: "VIDEO", label: "Vídeos", roles: ["VIDEO"] },
  { key: "OTHER", label: "Elementos e fontes", roles: ["GRAPHIC_ELEMENT", "FONT"] },
  { key: "PUBLISHED", label: "Publicados" },
];
const PUBLISHED: Prisma.PostMediaListRelationFilter = { some: { post: { status: { in: ["PUBLISHED", "PARTIALLY_PUBLISHED"] } } } };

export default async function MediaPage({ searchParams }: { searchParams: Promise<{ role?: string; ok?: string; error?: string }> }) {
  const { brand } = await requireBrand();
  const sp = await searchParams;
  const filter = FILTERS.find((f) => f.key === sp.role) ?? FILTERS[0];
  const published = filter.key === "PUBLISHED";
  // Arquivos de publicações já publicadas saem da biblioteca e ficam só na aba "Publicados"
  // (logos, fontes e referências do personagem continuam sempre visíveis)
  const keep: AssetRole[] = ["LOGO_PRIMARY", "LOGO_TRANSPARENT", "LOGO_ALT", "FONT", "CHARACTER_REFERENCE", "GRAPHIC_ELEMENT"];
  const where: Prisma.MediaAssetWhereInput = published
    ? { brandId: brand.id, postMedia: PUBLISHED, role: { notIn: keep } }
    : { brandId: brand.id, OR: [{ role: { in: keep } }, { NOT: { postMedia: PUBLISHED } }] };
  if (filter.roles) where.role = { in: filter.roles };
  const assets = await db.mediaAsset.findMany({
    where,
    orderBy: { createdAt: "desc" },
    take: published ? 200 : 120,
    include: {
      _count: { select: { postMedia: true } },
      postMedia: { where: { post: { status: { in: ["PUBLISHED", "PARTIALLY_PUBLISHED"] } } }, take: 1, select: { post: { select: { id: true, title: true, theme: true, scheduledAt: true } } } },
    },
  });
  const back = `/media?role=${filter.key}`;

  return (
    <div>
      <PageHeader title="Biblioteca de mídia" subtitle="Logotipos, fotografias, vídeos, templates e peças aprovadas. Vídeos aprovados alimentam os Reels automáticos." />
      <Flash ok={sp.ok} error={sp.error} />
      <form action={uploadAssetAction} className="card mb-6 grid gap-3 p-4 sm:grid-cols-5 sm:items-end">
        <input type="hidden" name="back" value={back} />
        <Field label="Arquivos"><input type="file" name="files" multiple className="input" accept="image/*,video/mp4,video/quicktime,.ttf,.otf" /></Field>
        <Field label="Tipo">
          <select name="role" className="input" defaultValue="PHOTO">
            <option value="PHOTO">Fotografia</option>
            <option value="REFERENCE">Referência visual</option>
            <option value="CHARACTER_REFERENCE">Referência do personagem</option>
            <option value="APPROVED_PIECE">Peça aprovada</option>
            <option value="GRAPHIC_ELEMENT">Elemento gráfico</option>
            <option value="LOGO_TRANSPARENT">Logotipo (transparente)</option>
            <option value="LOGO_PRIMARY">Logotipo principal</option>
          </select>
        </Field>
        <Field label="Tags"><input name="tags" className="input" placeholder="família, home office" /></Field>
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="approved" /> Aprovado para uso automático</label>
        <SubmitButton pendingText="Enviando…">Enviar</SubmitButton>
      </form>
      <div className="mb-4 flex flex-wrap gap-2">
        {FILTERS.map((f) => (
          <Link key={f.key} href={`/media?role=${f.key}`} className={`rounded-full px-3 py-1.5 text-sm ${f.key === filter.key ? "bg-navy text-white" : "bg-white ring-1 ring-slate-200"}`}>{f.label}</Link>
        ))}
      </div>
      {assets.length === 0 ? (
        <Empty title={published ? "Nenhum arquivo publicado ainda" : "Nada por aqui ainda"} />
      ) : (
        <>
        <BulkBar
          formId="bulk-media"
          action={bulkMediaAction}
          back={back}
          noun={["arquivo", "arquivos"]}
          ops={[
            { op: "approve_posts", label: "Aprovar publicações", className: "btn-accent btn-sm", confirm: "Aprovar e agendar as publicações que usam os {n} arquivo(s) selecionado(s)?", pendingText: "Aprovando…" },
            { op: "publish_posts", label: "Publicar agora", className: "btn-primary btn-sm", confirm: "Aprovar e publicar AGORA as publicações que usam os {n} arquivo(s) selecionado(s)?", pendingText: "Enviando…" },
            { op: "approve", label: "Aprovar para uso automático" },
            { op: "unapprove", label: "Remover aprovação" },
            { op: "delete", label: "Excluir", className: "btn-danger btn-sm", confirm: "Excluir {n} arquivo(s)? Publicações não publicadas que os usam voltam para aprovação.", pendingText: "Excluindo…" },
          ]}
        />
        <ul className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
          {assets.map((a) => (
            <li key={a.id} className="card relative overflow-hidden">
              <div className="absolute left-2 top-2 z-10 rounded-md bg-white/90 p-1 shadow"><BulkCheckbox formId="bulk-media" id={a.id} label={a.title ?? a.originalName ?? "arquivo"} /></div>
              {a.kind === "IMAGE" ? (
                <Link href={`/media/${a.id}?back=${encodeURIComponent(back)}`} title="Editar">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={mediaPath(a.storageKey)} alt={a.title ?? ""} className="aspect-square w-full bg-slate-100 object-contain" />
                </Link>
              ) : a.kind === "VIDEO" ? (
                <video src={mediaPath(a.storageKey)} className="aspect-square w-full bg-black object-contain" controls preload="metadata" />
              ) : (
                <div className="flex aspect-square items-center justify-center bg-slate-100 text-sm">{a.mimeType}</div>
              )}
              <div className="space-y-1 p-2 text-xs">
                <div className="truncate font-medium">{a.title ?? a.originalName}</div>
                <div className="text-ink-mute">{a.role} · {a.width && a.height ? `${a.width}×${a.height}` : ""} · {a._count.postMedia} uso(s)</div>
                {a.postMedia[0] && (
                  <Link href={`/posts/${a.postMedia[0].post.id}`} className="block truncate text-emerald-700 hover:underline">
                    ✓ publicado{a.postMedia[0].post.scheduledAt ? ` em ${formatDate(a.postMedia[0].post.scheduledAt, brand.timezone)}` : ""}: {a.postMedia[0].post.title ?? a.postMedia[0].post.theme}
                  </Link>
                )}
                <div className="flex flex-wrap gap-x-2 gap-y-1">
                  <form action={toggleAssetApprovalAction}><input type="hidden" name="id" value={a.id} /><input type="hidden" name="back" value={back} /><button className={a.isApproved ? "text-emerald-700" : "text-accent"}>{a.isApproved ? "✓ aprovado" : "aprovar"}</button></form>
                  <Link href={`/media/${a.id}?back=${encodeURIComponent(back)}`} className="font-medium text-accent">editar</Link>
                  <a href={mediaPath(a.storageKey)} download className="text-accent">baixar</a>
                  <form action={deleteAssetAction}><input type="hidden" name="id" value={a.id} /><input type="hidden" name="back" value={back} /><SubmitButton className="text-red-600" confirm="Excluir este arquivo? Se ele estiver em alguma publicação ainda não publicada, ela volta para aprovação para gerar a arte de novo.">excluir</SubmitButton></form>
                </div>
              </div>
            </li>
          ))}
        </ul>
        </>
      )}
    </div>
  );
}
