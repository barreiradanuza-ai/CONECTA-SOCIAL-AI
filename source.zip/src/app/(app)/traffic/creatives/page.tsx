import { requireBrand } from "@/lib/auth";
import { PageHeader } from "@/components/ui";
import { TrafficTabs, Section, AdStatus, EmptyTraffic } from "@/components/traffic";
import { latestSnapshot } from "@/server/traffic/service";
import { brl, int, pct } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function CreativesPage({ searchParams }: { searchParams: Promise<{ sort?: string }> }) {
  const { brand } = await requireBrand();
  const { sort = "spend" } = await searchParams;
  const snap = await latestSnapshot(brand.id);
  if (!snap) {
    return (
      <div>
        <PageHeader title="Campanhas e criativos" />
        <TrafficTabs current="creatives" />
        <EmptyTraffic reason="no-data" />
      </div>
    );
  }
  const key = (["spend", "conversations", "cpl", "ctr"] as const).find((k) => k === sort) ?? "spend";
  const ads = [...snap.ads].sort((a, b) => {
    if (key === "cpl") return (a.cpl ?? Infinity) - (b.cpl ?? Infinity);
    return ((b[key] as number | null) ?? -1) - ((a[key] as number | null) ?? -1);
  });
  const withConv = snap.ads.filter((a) => a.cpl != null);
  const best = withConv.length ? withConv.reduce((x, y) => (x.cpl! <= y.cpl! ? x : y)) : null;

  return (
    <div>
      <PageHeader title="Campanhas e criativos" subtitle="Desempenho acumulado de cada anúncio. O melhor criativo alimenta a IA de conteúdo." />
      <TrafficTabs current="creatives" />

      {best && (
        <div className="mb-6 flex flex-wrap items-center gap-4 rounded-2xl bg-gradient-to-r from-navy to-navy-600 p-5 text-white">
          {best.thumb && <img src={best.thumb} alt="" className="h-20 w-20 rounded-xl object-cover" />}
          <div className="min-w-0 flex-1">
            <div className="text-[11px] font-semibold uppercase tracking-wide text-cyan">Melhor custo por conversa</div>
            <div className="truncate text-lg font-bold">{best.name}</div>
            <div className="text-sm text-white/80">{best.campaign}</div>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold">{brl(best.cpl)}</div>
            <div className="text-xs text-white/70">{int(best.conversations)} conversas · {brl(best.spend)}</div>
          </div>
        </div>
      )}

      <Section
        title={`Anúncios (${snap.ads.length})`}
        action={
          <div className="flex gap-1 text-xs">
            {[["spend", "Gasto"], ["conversations", "Conversas"], ["cpl", "Custo/conv."], ["ctr", "CTR"]].map(([k, l]) => (
              <a key={k} href={`?sort=${k}`} className={`rounded-full px-2.5 py-1 font-semibold ${key === k ? "bg-navy text-white" : "bg-slate-100 text-ink-soft"}`}>{l}</a>
            ))}
          </div>
        }
      >
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {ads.map((a) => (
            <article key={a.id} className="overflow-hidden rounded-2xl border border-slate-200">
              <div className="flex aspect-[4/3] items-center justify-center bg-navy-50">
                {a.thumb ? <img src={a.thumb} alt={a.name} className="h-full w-full object-cover" /> : <span className="text-xs text-ink-mute">sem prévia</span>}
              </div>
              <div className="p-4">
                <div className="mb-1 flex items-start justify-between gap-2">
                  <h3 className="line-clamp-2 text-sm font-semibold">{a.name}</h3>
                  <AdStatus status={a.status} />
                </div>
                <p className="mb-3 truncate text-xs text-ink-mute">{a.campaign}</p>
                <dl className="grid grid-cols-3 gap-2 text-xs">
                  <div><dt className="text-ink-mute">Gasto</dt><dd className="font-semibold tabular-nums">{brl(a.spend)}</dd></div>
                  <div><dt className="text-ink-mute">Conversas</dt><dd className="font-semibold tabular-nums">{int(a.conversations)}</dd></div>
                  <div><dt className="text-ink-mute">Custo/conv.</dt><dd className="font-semibold tabular-nums">{brl(a.cpl)}</dd></div>
                  <div><dt className="text-ink-mute">Impressões</dt><dd className="tabular-nums">{int(a.impressions)}</dd></div>
                  <div><dt className="text-ink-mute">CTR</dt><dd className="tabular-nums">{pct(a.ctr)}</dd></div>
                  <div><dt className="text-ink-mute">CPC</dt><dd className="tabular-nums">{brl(a.cpc)}</dd></div>
                </dl>
                {a.reviewNote && <p className="mt-3 rounded-lg bg-red-50 p-2 text-xs text-red-800">{a.reviewNote}</p>}
              </div>
            </article>
          ))}
        </div>
      </Section>
    </div>
  );
}
