import { requireBrand } from "@/lib/auth";
import { PageHeader } from "@/components/ui";
import { TrafficTabs, Section, AdStatus, EmptyTraffic } from "@/components/traffic";
import { latestSnapshot } from "@/server/traffic/service";
import { brl, int, pct } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function CreativesPage({ searchParams }: { searchParams: Promise<{ sort?: string; c?: string; s?: string }> }) {
  const { brand } = await requireBrand();
  const { sort = "spend", c: campF, s: setF } = await searchParams;
  const snap = await latestSnapshot(brand.id);
  if (!snap) {
    return (
      <div>
        <PageHeader title="Campanhas e criativos" />
        <TrafficTabs current="creatives" />
        <EmptyTraffic reason="no-data" />
      </div>
    );
  }
  const key = (["spend", "conversations", "cpl", "ctr"] as const).find((k) => k === sort) ?? "spend";
  const adsets = snap.adsets ?? [];
  const visibleSets = adsets.filter((x) => !campF || x.campaignId === campF);
  const filtered = snap.ads.filter((a) => (!campF || a.campaignId === campF) && (!setF || a.adsetId === setF));
  const ads = [...filtered].sort((a, b) => {
    if (key === "cpl") return (a.cpl ?? Infinity) - (b.cpl ?? Infinity);
    return ((b[key] as number | null) ?? -1) - ((a[key] as number | null) ?? -1);
  });
  const withConv = filtered.filter((a) => a.cpl != null);
  const best = withConv.length ? withConv.reduce((x, y) => (x.cpl! <= y.cpl! ? x : y)) : null;
  const qs = (o: Record<string, string | undefined>) => {
    const p = new URLSearchParams();
    const m = { sort: key, c: campF, s: setF, ...o };
    for (const [k, v] of Object.entries(m)) if (v) p.set(k, v);
    return `?${p.toString()}`;
  };
  // Agrupa por conjunto (ou por campanha, se o snapshot ainda não tem conjuntos).
  const groups: { id: string; title: string; sub: string; set?: (typeof adsets)[number]; ads: typeof ads }[] = [];
  for (const a of ads) {
    const gid = a.adsetId ?? `c:${a.campaignId}`;
    let g = groups.find((x) => x.id === gid);
    if (!g) {
      const set = adsets.find((x) => x.id === a.adsetId);
      g = { id: gid, title: a.adset ?? a.campaign, sub: a.adset ? a.campaign : "conjunto não identificado (aguarde a próxima sincronização)", set, ads: [] };
      groups.push(g);
    }
    g.ads.push(a);
  }
  const chip = (active: boolean) => `rounded-full px-3 py-1 text-xs font-semibold ${active ? "bg-navy text-white" : "bg-white text-ink-soft ring-1 ring-slate-200"}`;

  return (
    <div>
      <PageHeader title="Campanhas e criativos" subtitle="Desempenho acumulado de cada anúncio. O melhor criativo alimenta a IA de conteúdo." />
      <TrafficTabs current="creatives" />

      <div className="mb-3 flex flex-wrap items-center gap-2">
        <span className="w-20 text-xs font-semibold uppercase tracking-wide text-ink-mute">Campanha</span>
        <a href={qs({ c: undefined, s: undefined })} className={chip(!campF)}>Todas</a>
        {snap.campaigns.map((c) => (
          <a key={c.id} href={qs({ c: c.id, s: undefined })} className={chip(campF === c.id)}>{c.name}</a>
        ))}
      </div>
      {visibleSets.length > 0 && (
        <div className="mb-6 flex flex-wrap items-center gap-2">
          <span className="w-20 text-xs font-semibold uppercase tracking-wide text-ink-mute">Conjunto</span>
          <a href={qs({ s: undefined })} className={chip(!setF)}>Todos</a>
          {visibleSets.map((x) => (
            <a key={x.id} href={qs({ s: x.id })} className={chip(setF === x.id)}>{x.name}</a>
          ))}
        </div>
      )}

      {best && (
        <div className="mb-6 flex flex-wrap items-center gap-4 rounded-2xl bg-gradient-to-r from-navy to-navy-600 p-5 text-white">
          {best.thumb && <img src={best.thumb} alt="" className="h-20 w-20 rounded-xl object-cover" />}
          <div className="min-w-0 flex-1">
            <div className="text-[11px] font-semibold uppercase tracking-wide text-cyan">Melhor custo por conversa</div>
            <div className="truncate text-lg font-bold">{best.name}</div>
            <div className="text-sm text-white/80">{best.campaign}</div>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold">{brl(best.cpl)}</div>
            <div className="text-xs text-white/70">{int(best.conversations)} conversas · {brl(best.spend)}</div>
          </div>
        </div>
      )}

      <Section
        title={`Anúncios (${filtered.length})`}
        subtitle="Agrupados por conjunto de anúncios"
        action={
          <div className="flex gap-1 text-xs">
            {[["spend", "Gasto"], ["conversations", "Conversas"], ["cpl", "Custo/conv."], ["ctr", "CTR"]].map(([k, l]) => (
              <a key={k} href={qs({ sort: k })} className={`rounded-full px-2.5 py-1 font-semibold ${key === k ? "bg-navy text-white" : "bg-slate-100 text-ink-soft"}`}>{l}</a>
            ))}
          </div>
        }
      >
        {groups.length === 0 && <p className="text-sm text-ink-soft">Nenhum anúncio neste filtro.</p>}
        <div className="space-y-8">
          {groups.map((g) => (
            <div key={g.id}>
              <div className="mb-3 flex flex-wrap items-end justify-between gap-3 border-b border-slate-200 pb-3">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold text-navy">{g.title}</h3>
                    {g.set && <AdStatus status={g.set.status} />}
                  </div>
                  <p className="text-xs text-ink-mute">{g.sub}{g.set?.audience ? ` · ${g.set.audience}` : ""}</p>
                </div>
                {g.set && (
                  <dl className="flex gap-5 text-xs">
                    <div><dt className="text-ink-mute">Gasto</dt><dd className="font-semibold tabular-nums">{brl(g.set.spend)}</dd></div>
                    <div><dt className="text-ink-mute">Conversas</dt><dd className="font-semibold tabular-nums">{int(g.set.conversations)}</dd></div>
                    <div><dt className="text-ink-mute">Custo/conv.</dt><dd className="font-semibold tabular-nums">{brl(g.set.cpl)}</dd></div>
                    <div><dt className="text-ink-mute">CTR</dt><dd className="tabular-nums">{pct(g.set.ctr)}</dd></div>
                    <div><dt className="text-ink-mute">Freq.</dt><dd className="tabular-nums">{g.set.frequency?.toFixed(2) ?? "—"}</dd></div>
                  </dl>
                )}
              </div>
              <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
                {g.ads.map((a) => (
                  <article key={a.id} className="overflow-hidden rounded-2xl border border-slate-200">
                    <div className="flex aspect-[4/3] items-center justify-center bg-navy-50">
                      {a.thumb ? <img src={a.thumb} alt={a.name} className="h-full w-full object-cover" /> : <span className="text-xs text-ink-mute">sem prévia</span>}
                    </div>
                    <div className="p-4">
                      <div className="mb-1 flex items-start justify-between gap-2">
                        <h4 className="line-clamp-2 text-sm font-semibold">{a.name}</h4>
                        <AdStatus status={a.status} />
                      </div>
                      <p className="mb-3 truncate text-xs text-ink-mute">{a.campaign}{a.adset ? ` › ${a.adset}` : ""}</p>
                      <dl className="grid grid-cols-3 gap-2 text-xs">
                        <div><dt className="text-ink-mute">Gasto</dt><dd className="font-semibold tabular-nums">{brl(a.spend)}</dd></div>
                        <div><dt className="text-ink-mute">Conversas</dt><dd className="font-semibold tabular-nums">{int(a.conversations)}</dd></div>
                        <div><dt className="text-ink-mute">Custo/conv.</dt><dd className="font-semibold tabular-nums">{brl(a.cpl)}</dd></div>
                        <div><dt className="text-ink-mute">Impressões</dt><dd className="tabular-nums">{int(a.impressions)}</dd></div>
                        <div><dt className="text-ink-mute">CTR</dt><dd className="tabular-nums">{pct(a.ctr)}</dd></div>
                        <div><dt className="text-ink-mute">CPC</dt><dd className="tabular-nums">{brl(a.cpc)}</dd></div>
                      </dl>
                      {a.reviewNote && <p className="mt-3 rounded-lg bg-red-50 p-2 text-xs text-red-800">{a.reviewNote}</p>}
                    </div>
                  </article>
                ))}
              </div>
            </div>
          ))}
        </div>
      </Section>
    </div>
  );
}
