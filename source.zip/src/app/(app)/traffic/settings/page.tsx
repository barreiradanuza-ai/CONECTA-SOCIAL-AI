import Link from "next/link";
import { requireBrand } from "@/lib/auth";
import { PageHeader, Flash, Field, IntegrationState } from "@/components/ui";
import { SubmitButton } from "@/components/client";
import { TrafficTabs, Section } from "@/components/traffic";
import { trafficSettings } from "@/server/traffic/service";
import { getSecret } from "@/server/integrations";
import { formatDateTime } from "@/lib/time";
import { saveTrafficSettingsAction } from "../actions";

export const dynamic = "force-dynamic";

export default async function TrafficSettingsPage({ searchParams }: { searchParams: Promise<{ ok?: string; error?: string }> }) {
  const { auth, brand } = await requireBrand("ADMIN");
  const sp = await searchParams;
  const s = await trafficSettings(brand.id);
  const [metaToken, anthropic] = await Promise.all([getSecret(auth.orgId, "META_ADS_ACCESS_TOKEN").then((v) => v || process.env.META_ACCESS_TOKEN), getSecret(auth.orgId, "ANTHROPIC_API_KEY")]);
  const since = s.sinceDate ? s.sinceDate.toLocaleDateString("en-CA", { timeZone: brand.timezone }) : "";

  return (
    <div>
      <PageHeader title="Configuração do tráfego" subtitle="Conta de anúncio, teto de investimento e autonomia da IA." />
      <TrafficTabs current="settings" />
      <Flash ok={sp.ok} error={sp.error} />
      <div className="grid gap-6 lg:grid-cols-3">
        <form action={saveTrafficSettingsAction} className="card space-y-5 p-6 lg:col-span-2">
          <Field label="Contas de anúncio" hint="IDs numéricos, separados por vírgula (ex.: 939785565862711).">
            <input name="accountIds" className="input" defaultValue={s.accountIds.join(", ")} />
          </Field>
          <div className="grid gap-5 sm:grid-cols-3">
            <Field label="Teto diário total (R$)" hint="A IA nunca recomenda passar disso.">
              <input name="dailyCap" className="input" defaultValue={(s.dailyCapCents / 100).toFixed(2).replace(".", ",")} />
            </Field>
            <Field label="Considerar campanhas desde" hint="Ignora campanhas antigas.">
              <input name="sinceDate" type="date" className="input" defaultValue={since} />
            </Field>
            <Field label="Análise da IA a cada (horas)">
              <input name="aiEveryHours" type="number" min={1} max={48} className="input" defaultValue={s.aiEveryHours} />
            </Field>
          </div>
          <label className="flex items-start gap-3 rounded-xl border border-slate-200 p-4">
            <input type="checkbox" name="autoExecute" defaultChecked={s.autoExecute} className="mt-1" />
            <span className="text-sm">
              <strong>Permitir que a IA pause sozinha anúncios claramente improdutivos</strong>
              <span className="block text-ink-soft">Só vale para ações nível AUTO, com confiança alta, do tipo “pausar anúncio”. Tudo o mais (orçamento, campanhas, criativos) continua pedindo sua aprovação. Cada execução fica registrada.</span>
            </span>
          </label>
          <SubmitButton>Salvar</SubmitButton>
        </form>

        <div className="space-y-6">
          <Section title="Conexões">
            <ul className="space-y-3 text-sm">
              <li className="flex items-center justify-between"><span>Token do Meta Ads</span><IntegrationState state={metaToken ? "ok" : "missing"} /></li>
              <li className="flex items-center justify-between"><span>IA (Anthropic)</span><IntegrationState state={anthropic ? "ok" : "missing"} /></li>
              <li className="flex items-center justify-between"><span>Última sincronização</span><span className="text-xs text-ink-mute">{formatDateTime(s.lastSyncAt, brand.timezone)}</span></li>
            </ul>
            {s.lastSyncError && <p className="mt-3 rounded-lg bg-red-50 p-2 text-xs text-red-800">{s.lastSyncError}</p>}
            <Link href="/settings/integrations" className="btn-ghost btn-sm mt-4">Cadastrar chaves</Link>
          </Section>
          <Section title="Como a IA decide">
            <ol className="list-decimal space-y-1 pl-4 text-sm text-ink-soft">
              <li>Observa campanhas, anúncios, série diária e alertas.</li>
              <li>Cruza com ofertas aprovadas e com o conteúdo orgânico.</li>
              <li>Separa fato, hipótese e recomendação.</li>
              <li>Classifica: AUTO, precisa de aprovação ou bloqueada.</li>
              <li>Registra decisão, execução e resultado.</li>
            </ol>
          </Section>
        </div>
      </div>
    </div>
  );
}
