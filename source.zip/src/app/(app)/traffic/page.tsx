import { Fragment } from "react";
import Link from "next/link";
import { requireBrand } from "@/lib/auth";
import { db } from "@/lib/db";
import { PageHeader, Flash } from "@/components/ui";
import { SubmitButton } from "@/components/client";
import { TrafficTabs, Kpi, Section, Funnel, DualBars, EmptyTraffic, AdStatus } from "@/components/traffic";
import { trafficSettings, latestSnapshot, dailyTotals, sumTotals, computeAlerts } from "@/server/traffic/service";
import { getSecret } from "@/server/integrations";
import { brl, int, pct, delta } from "@/lib/format";
import { formatDateTime } from "@/lib/time";
import { syncNowAction } from "./actions";

export const dynamic = "force-dynamic";

const PERIODS = { "7": 7, "14": 14, "30": 30 } as const;

export default async function TrafficPage({ searchParams }: { searchParams: Promise<{ p?: string; ok?: string; error?: string }> }) {
  const { auth, brand } = await requireBrand();
  const sp = await searchParams;
  const days = PERIODS[(sp.p ?? "7") as keyof typeof PERIODS] ?? 7;
  const s = await trafficSettings(brand.id);
  const token = (await getSecret(auth.orgId, "META_ADS_ACCESS_TOKEN")) || process.env.META_ACCESS_TOKEN;
  const snap = await latestSnapshot(brand.id);
  const cap = s.dailyCapCents / 100;

  const header = (
    <PageHeader
      title="Tráfego pago"
      subtitle={<>Meta Ads → WhatsApp · teto diário {brl(cap)}{s.lastSyncAt && <> · atualizado {formatDateTime(s.lastSyncAt, brand.timezone)}</>}</>}
      actions={
        <form action={syncNowAction}>
          <SubmitButton className="btn-ghost" pendingText="Atualizando…">Atualizar agora</SubmitButton>
        </form>
      }
    />
  );

  if (!s.accountIds.length || !token || !snap) {
    return (
      <div>
        {header}
        <TrafficTabs current="overview" />
        <Flash ok={sp.ok} error={sp.error ?? s.lastSyncError ?? undefined} />
        <EmptyTraffic reason={!s.accountIds.length ? "no-account" : !token ? "no-token" : s.lastSyncError ? "error" : "no-data"} />
      </div>
    );
  }

  const [series, prevSeries, lastAnalysis, pendingRecs] = await Promise.all([
    dailyTotals(brand.id, days),
    dailyTotals(brand.id, days * 2),
    db.trafficAnalysis.findFirst({ where: { brandId: brand.id, error: null }, orderBy: { createdAt: "desc" } }),
    db.trafficRecommendation.count({ where: { brandId: brand.id, status: "PENDING", level: "APPROVAL" } }),
  ]);
  const cur = sumTotals(series);
  const prev = sumTotals(prevSeries.slice(0, days));
  const alerts = computeAlerts(snap, cap);
  const pacing = cap ? Math.min(100, (snap.today.spend / cap) * 100) : 0;
  const fmtDay = (d: string) => `${d.slice(8, 10)}/${d.slice(5, 7)}`;

  return (
    <div>
      {header}
      <TrafficTabs current="overview" />
      <Flash ok={sp.ok} error={sp.error} />

      <div className="mb-4 flex flex-wrap items-center gap-2 text-sm">
        <span className="text-ink-mute">Período:</span>
        {Object.keys(PERIODS).map((k) => (
          <Link key={k} href={`/traffic?p=${k}`} className={`rounded-full px-3 py-1 font-semibold ${String(days) === k ? "bg-navy text-white" : "bg-white text-ink-soft ring-1 ring-slate-200"}`}>
            {k} dias
          </Link>
        ))}
        <span className="text-xs text-ink-mute">comparado aos {days} dias anteriores</span>
      </div>

      <div className="mb-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        <Kpi tone="navy" label="Investimento" value={brl(cur.spend)} change={delta(cur.spend, prev.spend)} goodWhen="up" hint={`${days} dias`} />
        <Kpi label="Conversas no WhatsApp" value={int(cur.conversations)} change={delta(cur.conversations, prev.conversations)} />
        <Kpi label="Custo por conversa" value={brl(cur.cpl)} change={delta(cur.cpl, prev.cpl)} goodWhen="down" />
        <Kpi label="CTR" value={pct(cur.ctr)} change={delta(cur.ctr, prev.ctr)} hint={`CPC ${brl(cur.cpc)}`} />
        <Kpi label="CPM" value={brl(cur.cpm)} change={delta(cur.cpm, prev.cpm)} goodWhen="down" hint={`${int(cur.impressions)} impressões`} />
      </div>

      <div className="mb-6 grid gap-6 lg:grid-cols-3">
        <Section title="Investimento e conversas por dia" subtitle="Fonte: Meta Ads (série diária por campanha)" className="lg:col-span-2">
          <DualBars data={series.map((d) => ({ label: fmtDay(d.date), a: d.spend, b: d.conversations }))} a={{ name: "Investimento", fmt: brl }} b={{ name: "Conversas", fmt: (v) => int(v) }} />
        </Section>
        <Section title="Hoje" subtitle={snap.today.date.split("-").reverse().join("/")}>
          <div className="text-3xl font-bold tabular-nums">{brl(snap.today.spend)}</div>
          <div className="mt-1 text-sm text-ink-soft">de {brl(cap)} autorizados por dia</div>
          <div className="mt-3 h-3 overflow-hidden rounded-full bg-slate-100">
            <div className={`h-full rounded-full ${pacing >= 90 ? "bg-red-500" : "bg-accent"}`} style={{ width: `${pacing}%` }} />
          </div>
          <dl className="mt-4 grid grid-cols-2 gap-3 text-sm">
            <div><dt className="text-xs text-ink-mute">Conversas hoje</dt><dd className="font-semibold">{int(snap.today.conversations)}</dd></div>
            <div><dt className="text-xs text-ink-mute">Orçamento ativo</dt><dd className="font-semibold">{brl(snap.today.activeBudget)}/dia</dd></div>
          </dl>
        </Section>
      </div>

      <div className="mb-6 grid gap-6 lg:grid-cols-3">
        <Section title="Funil" subtitle={`${days} dias · etapas após a conversa dependem do CRM (Data Crazy)`} className="lg:col-span-2">
          <Funnel
            steps={[
              { label: "Impressões", value: cur.impressions },
              { label: "Cliques", value: cur.clicks },
              { label: "Conversas", value: cur.conversations },
              { label: "Leads", value: null, note: "aguardando integração com o CRM" },
              { label: "Qualificados", value: null, note: "aguardando integração com o CRM" },
              { label: "Vendas", value: null, note: "aguardando integração com o CRM" },
              { label: "Instalações", value: null, note: "aguardando integração com o CRM" },
            ]}
          />
        </Section>
        <Section title="IA gestora" action={<Link href="/traffic/ai" className="text-sm font-semibold text-accent">Abrir</Link>}>
          {lastAnalysis ? (
            <>
              <p className="text-sm leading-relaxed text-ink-soft">{lastAnalysis.diagnosis}</p>
              <p className="mt-2 text-xs text-ink-mute">Análise de {formatDateTime(lastAnalysis.createdAt, brand.timezone)}</p>
            </>
          ) : (
            <p className="text-sm text-ink-soft">Nenhuma análise ainda. A IA analisa a cada {s.aiEveryHours}h (precisa da chave da Anthropic com crédito).</p>
          )}
          {pendingRecs > 0 && <Link href="/traffic/ai" className="btn-accent btn-sm mt-3">{pendingRecs} ação(ões) aguardando aprovação</Link>}
        </Section>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <Section title="Campanhas e conjuntos" subtitle="Acumulado desde a criação · clique no conjunto para ver os criativos dele" className="lg:col-span-2" action={<Link href="/traffic/creatives" className="text-sm font-semibold text-accent">Ver criativos</Link>}>
          <div className="overflow-x-auto">
            <table className="table">
              <thead><tr><th>Campanha</th><th>Status</th><th>Orç./dia</th><th>Gasto</th><th>Conversas</th><th>Custo/conv.</th><th>CTR</th><th>Freq.</th></tr></thead>
              <tbody>
                {snap.campaigns.map((c) => (
                  <Fragment key={c.id}>
                    <tr>
                      <td className="font-medium">{c.name}</td>
                      <td><AdStatus status={c.status} /></td>
                      <td className="tabular-nums">{brl(c.dailyBudget)}</td>
                      <td className="tabular-nums">{brl(c.spend)}</td>
                      <td className="tabular-nums">{int(c.conversations)}</td>
                      <td className="tabular-nums">{brl(c.cpl)}</td>
                      <td className="tabular-nums">{pct(c.ctr)}</td>
                      <td className="tabular-nums">{c.frequency?.toFixed(2) ?? "—"}</td>
                    </tr>
                    {(snap.adsets ?? []).filter((x) => x.campaignId === c.id).map((x) => (
                      <tr key={x.id} className="text-ink-soft">
                        <td className="pl-6">
                          <Link href={`/traffic/creatives?c=${c.id}&s=${x.id}`} className="hover:text-accent">↳ {x.name}</Link>
                          {x.audience && <div className="text-[11px] text-ink-mute">{x.audience}</div>}
                        </td>
                        <td><AdStatus status={x.status} /></td>
                        <td className="tabular-nums">{x.dailyBudget ? brl(x.dailyBudget) : "—"}</td>
                        <td className="tabular-nums">{brl(x.spend)}</td>
                        <td className="tabular-nums">{int(x.conversations)}</td>
                        <td className="tabular-nums">{brl(x.cpl)}</td>
                        <td className="tabular-nums">{pct(x.ctr)}</td>
                        <td className="tabular-nums">{x.frequency?.toFixed(2) ?? "—"}</td>
                      </tr>
                    ))}
                  </Fragment>
                ))}
                {snap.campaigns.length === 0 && <tr><td colSpan={8} className="text-ink-soft">Nenhuma campanha no período configurado.</td></tr>}
              </tbody>
            </table>
          </div>
        </Section>
        <Section title="Alertas" subtitle="Regras objetivas, recalculadas a cada sincronização">
          {alerts.length === 0 ? (
            <p className="text-sm text-ink-soft">Nenhum alerta agora.</p>
          ) : (
            <ul className="space-y-2">
              {alerts.map((a) => (
                <li key={a.key} className={`rounded-xl p-3 text-sm ${a.level === "alto" ? "bg-red-50 text-red-900" : a.level === "medio" ? "bg-amber-50 text-amber-900" : "bg-slate-50"}`}>
                  <div className="font-semibold">{a.subject}</div>
                  <div className="text-xs">{a.text}</div>
                </li>
              ))}
            </ul>
          )}
          {snap.warnings.length > 0 && <p className="mt-3 text-xs text-ink-mute">{snap.warnings.join(" · ")}</p>}
        </Section>
      </div>
    </div>
  );
}
