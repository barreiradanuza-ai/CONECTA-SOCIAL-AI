"use server";
import { db } from "@/lib/db";
import { requireBrand } from "@/lib/auth";
import { runAction, str, int } from "@/lib/actions";
import { audit } from "@/server/audit";
import { syncBrand, executeRecommendation, trafficSettings, EXECUTABLE } from "@/server/traffic/service";
import { analyzeTraffic } from "@/server/traffic/ai";

export async function syncNowAction() {
  const { brand } = await requireBrand("EDITOR");
  return runAction("/traffic", async () => `Dados atualizados — ${await syncBrand(brand.id)}.`);
}

export async function analyzeNowAction() {
  const { auth, brand } = await requireBrand("EDITOR");
  return runAction("/traffic/ai", async () => {
    const r = await analyzeTraffic(brand.id, "manual");
    await audit(auth.orgId, "traffic.analyze", { userId: auth.user.id, meta: { result: r } });
    return `Análise concluída — ${r}.`;
  });
}

/** approve = aprova e executa (quando executável); reject = rejeita; done = marcado como feito manualmente. */
export async function decideAction(form: FormData) {
  const { auth, brand } = await requireBrand("ADMIN");
  const id = str(form, "id");
  const decision = str(form, "decision");
  return runAction("/traffic/ai", async () => {
    const rec = await db.trafficRecommendation.findFirst({ where: { id, brandId: brand.id } });
    if (!rec) throw new Error("Recomendação não encontrada.");
    if (!["PENDING", "FAILED"].includes(rec.status)) throw new Error("Esta recomendação já foi decidida.");
    const note = str(form, "note") || null;
    if (decision === "reject") {
      await db.trafficRecommendation.update({ where: { id }, data: { status: "REJECTED", decidedById: auth.user.id, decidedAt: new Date(), result: note } });
      await audit(auth.orgId, "traffic.reject", { userId: auth.user.id, entity: "TrafficRecommendation", entityId: id, meta: { title: rec.title, note } });
      return "Recomendação rejeitada. A IA não vai repeti-la sem mudança de condições.";
    }
    if (decision === "done") {
      await db.trafficRecommendation.update({ where: { id }, data: { status: "EXECUTED", decidedById: auth.user.id, decidedAt: new Date(), executedAt: new Date(), result: note ?? "Executada manualmente no Gerenciador de Anúncios." } });
      await audit(auth.orgId, "traffic.manual_done", { userId: auth.user.id, entity: "TrafficRecommendation", entityId: id, meta: { title: rec.title } });
      return "Registrado como executado manualmente.";
    }
    if (decision === "approve") {
      if (rec.level === "BLOCKED") throw new Error("Recomendação bloqueada: não pode ser aprovada para execução.");
      if (!EXECUTABLE.includes(rec.actionType)) throw new Error("Ação manual: faça no Gerenciador de Anúncios e clique em “Já fiz”.");
      await db.trafficRecommendation.update({ where: { id }, data: { status: "APPROVED", decidedById: auth.user.id, decidedAt: new Date() } });
      const r = await executeRecommendation(id, { userId: auth.user.id, label: auth.user.name });
      return `Aprovada e executada: ${r}`;
    }
    throw new Error("Decisão inválida.");
  });
}

export async function saveTrafficSettingsAction(form: FormData) {
  const { auth, brand } = await requireBrand("ADMIN");
  return runAction("/traffic/settings", async () => {
    await trafficSettings(brand.id);
    const accountIds = str(form, "accountIds")
      .split(/[\s,;]+/)
      .map((s) => s.replace(/^act_/, "").trim())
      .filter((s) => /^\d{5,}$/.test(s));
    const capReais = Number(str(form, "dailyCap").replace(/\./g, "").replace(",", "."));
    if (!Number.isFinite(capReais) || capReais <= 0) throw new Error("Informe um teto diário válido.");
    const since = str(form, "sinceDate");
    const data = {
      accountIds,
      dailyCapCents: Math.round(capReais * 100),
      sinceDate: since ? new Date(`${since}T00:00:00-03:00`) : null,
      aiEveryHours: int(form, "aiEveryHours", 6, 1, 48),
      autoExecute: form.get("autoExecute") === "on",
    };
    await db.trafficSettings.update({ where: { brandId: brand.id }, data });
    await audit(auth.orgId, "traffic.settings", { userId: auth.user.id, meta: { ...data, sinceDate: since || null } });
    return "Configuração do gestor de tráfego salva.";
  });
}
