import { requireBrand, hasRole } from "@/lib/auth";
import { db } from "@/lib/db";
import { PageHeader, Flash } from "@/components/ui";
import { SubmitButton } from "@/components/client";
import { TrafficTabs, Section, LevelBadge, RecStatusBadge } from "@/components/traffic";
import { trafficSettings, EXECUTABLE } from "@/server/traffic/service";
import { formatDateTime } from "@/lib/time";
import { brl } from "@/lib/format";
import { analyzeNowAction, decideAction } from "../actions";

export const dynamic = "force-dynamic";

const ACTION_LABEL: Record<string, string> = {
  PAUSE_AD: "Pausar anúncio",
  PAUSE_CAMPAIGN: "Pausar campanha",
  ACTIVATE_AD: "Ativar anúncio",
  SET_CAMPAIGN_BUDGET: "Alterar orçamento",
  NEW_CREATIVE: "Pedir novo criativo à IA de conteúdo",
  NEW_VIDEO: "Pedir vídeo da persona (MiniMax)",
  BOOST_POST: "Impulsionar post orgânico",
  MANUAL: "Ação manual",
};

export default async function TrafficAiPage({ searchParams }: { searchParams: Promise<{ ok?: string; error?: string }> }) {
  const { auth, brand } = await requireBrand();
  const sp = await searchParams;
  const canDecide = hasRole(auth, "ADMIN");
  const s = await trafficSettings(brand.id);
  const [last, lastError, history] = await Promise.all([
    db.trafficAnalysis.findFirst({ where: { brandId: brand.id, error: null }, orderBy: { createdAt: "desc" }, include: { recs: { orderBy: { createdAt: "asc" } } } }),
    db.trafficAnalysis.findFirst({ where: { brandId: brand.id }, orderBy: { createdAt: "desc" } }),
    db.trafficRecommendation.findMany({ where: { brandId: brand.id, status: { in: ["EXECUTED", "REJECTED", "FAILED"] } }, orderBy: { updatedAt: "desc" }, take: 30 }),
  ]);
  const failedLatest = lastError?.error ? lastError : null;

  return (
    <div>
      <PageHeader
        title="IA gestora de tráfego"
        subtitle={<>Analisa a conta a cada {s.aiEveryHours}h · cruza anúncios, conteúdo orgânico e ofertas aprovadas · nunca passa do teto de {brl(s.dailyCapCents / 100)}/dia</>}
        actions={
          <form action={analyzeNowAction}>
            <SubmitButton className="btn-accent" pendingText="Analisando…">Analisar agora</SubmitButton>
          </form>
        }
      />
      <TrafficTabs current="ai" />
      <Flash ok={sp.ok} error={sp.error} />
      {failedLatest && <div className="mb-4 rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-800">Última tentativa ({formatDateTime(failedLatest.createdAt, brand.timezone)}) falhou: {failedLatest.error}</div>}

      {!last ? (
        <div className="card p-8 text-center text-sm text-ink-soft">Nenhuma análise concluída ainda.</div>
      ) : (
        <>
          <div className="mb-6 grid gap-6 lg:grid-cols-3">
            <section className="rounded-2xl bg-gradient-to-br from-navy to-navy-600 p-6 text-white lg:col-span-2">
              <div className="text-[11px] font-semibold uppercase tracking-widest text-cyan">Diagnóstico</div>
              <p className="mt-2 leading-relaxed">{last.diagnosis}</p>
              {last.nextReview && <p className="mt-4 text-sm text-white/75"><strong className="text-white">Próxima revisão:</strong> {last.nextReview}</p>}
              <p className="mt-4 text-xs text-white/50">{formatDateTime(last.createdAt, brand.timezone)} · {last.trigger === "manual" ? "pedida manualmente" : "automática"} · {last.model}</p>
            </section>
            <Section title="Enviado à IA de conteúdo" subtitle="Aprendizados dos anúncios que orientam os próximos posts">
              <p className="text-sm leading-relaxed text-ink-soft">{last.contentBrief || "Sem aprendizados suficientes ainda."}</p>
            </Section>
          </div>

          <h2 className="mb-3 text-lg font-bold">Recomendações</h2>
          {last.recs.length === 0 && <div className="card mb-6 p-6 text-sm text-ink-soft">Nenhuma ação recomendada agora — com os dados atuais, o melhor é não mexer.</div>}
          <div className="mb-8 space-y-4">
            {last.recs.map((r) => {
              const executable = EXECUTABLE.includes(r.actionType) && r.level !== "BLOCKED";
              const open = ["PENDING", "FAILED"].includes(r.status);
              return (
                <article key={r.id} className="card p-5">
                  <div className="flex flex-wrap items-center gap-2">
                    <LevelBadge level={r.level} />
                    <RecStatusBadge status={r.status} />
                    <span className="badge bg-slate-100 text-slate-700">confiança {r.confidence}</span>
                    <span className="badge bg-accent-soft text-accent">{ACTION_LABEL[r.actionType] ?? r.actionType}{r.value != null && ["SET_CAMPAIGN_BUDGET", "BOOST_POST"].includes(r.actionType) ? ` → ${brl(r.value)}/dia` : ""}</span>
                  </div>
                  <h3 className="mt-2 text-base font-semibold">{r.title}</h3>
                  {r.targetName && <p className="text-xs text-ink-mute">Alvo: {r.targetName}{r.targetId ? ` (${r.targetId})` : ""}</p>}
                  {r.actionType === "BOOST_POST" && r.targetId && <a href={`/posts/${r.targetId}`} className="text-xs text-accent underline">ver o post</a>}
                  <p className="mt-2 text-sm">{r.action}</p>
                  <dl className="mt-3 grid gap-3 text-sm md:grid-cols-2">
                    {[["Evidências (fatos)", r.evidence], ["Motivo", r.reason], ["Hipótese", r.hypothesis], ["Impacto esperado", r.impact], ["Risco", r.risk]].filter(([, v]) => v).map(([k, v]) => (
                      <div key={k} className="rounded-xl bg-slate-50 p-3"><dt className="text-[11px] font-semibold uppercase tracking-wide text-ink-mute">{k}</dt><dd className="mt-1 text-ink-soft">{v}</dd></div>
                    ))}
                  </dl>
                  {r.result && <p className={`mt-3 rounded-lg p-2 text-sm ${r.status === "FAILED" ? "bg-red-50 text-red-800" : "bg-emerald-50 text-emerald-800"}`}>{r.result}</p>}
                  {open && canDecide && (
                    <form action={decideAction} className="mt-4 flex flex-wrap items-center gap-2 border-t border-slate-100 pt-4">
                      <input type="hidden" name="id" value={r.id} />
                      <input name="note" placeholder="Observação (opcional)" className="input max-w-xs py-1.5" />
                      {executable && <SubmitButton name="decision" value="approve" className="btn-accent btn-sm" pendingText="Executando…" confirm="Aprovar e executar agora na Meta?">Aprovar e executar</SubmitButton>}
                      {!executable && r.level !== "BLOCKED" && <SubmitButton name="decision" value="done" className="btn-primary btn-sm">Já fiz no Gerenciador</SubmitButton>}
                      <SubmitButton name="decision" value="reject" className="btn-ghost btn-sm">Rejeitar</SubmitButton>
                    </form>
                  )}
                </article>
              );
            })}
          </div>
        </>
      )}

      <Section title="Histórico de decisões" subtitle="Memória da IA: ela não repete o que foi rejeitado sem motivo novo">
        {history.length === 0 ? (
          <p className="text-sm text-ink-soft">Nenhuma decisão registrada.</p>
        ) : (
          <table className="table">
            <thead><tr><th>Quando</th><th>Recomendação</th><th>Status</th><th>Resultado</th></tr></thead>
            <tbody>
              {history.map((h) => (
                <tr key={h.id}>
                  <td className="whitespace-nowrap text-xs">{formatDateTime(h.executedAt ?? h.decidedAt ?? h.updatedAt, brand.timezone)}</td>
                  <td className="font-medium">{h.title}</td>
                  <td><RecStatusBadge status={h.status} /></td>
                  <td className="max-w-md text-xs text-ink-soft">{h.result}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Section>
    </div>
  );
}
