import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { waMeLink, messageWithRef } from "@/server/whatsapp";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, { params }: { params: Promise<{ code: string }> }) {
  const { code } = await params;
  const link = await db.trackingLink.findUnique({ where: { code }, include: { brand: { include: { whatsapp: true } }, campaign: true } });
  const wa = link?.brand.whatsapp;
  if (!link || !wa?.phoneE164) return new NextResponse("Link inválido", { status: 404 });
  await db.linkClick.create({ data: { linkId: link.id, converted: true } });
  if (wa.crmWebhookUrl) {
    // Integração futura com CRM (ex.: Data Crazy): evento anônimo com a origem
    fetch(wa.crmWebhookUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ event: "whatsapp_click", ref: code, postId: link.postId, campaign: link.campaign?.slug ?? null, network: link.network, brand: link.brand.slug, at: new Date().toISOString() }),
      signal: AbortSignal.timeout(5000),
    }).catch(() => {});
  }
  return NextResponse.redirect(waMeLink(wa.phoneE164, messageWithRef(link.message ?? wa.defaultMessage, code)), 302);
}
