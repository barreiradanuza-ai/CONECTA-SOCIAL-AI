import { notFound, redirect } from "next/navigation";
import { headers } from "next/headers";
import { db } from "@/lib/db";
import { waMeLink, messageWithRef } from "@/server/whatsapp";

export const dynamic = "force-dynamic";

// Página intermediária própria: conta o acesso (sem IP/dados pessoais) e leva ao WhatsApp.
export default async function TrackingPage({ params }: { params: Promise<{ code: string }> }) {
  const { code } = await params;
  const link = await db.trackingLink.findUnique({ where: { code }, include: { brand: { include: { whatsapp: true } } } });
  const wa = link?.brand.whatsapp;
  if (!link || !wa?.phoneE164) notFound();

  const h = await headers();
  const ua = h.get("user-agent") ?? "";
  const isBot = /bot|crawl|spider|facebookexternalhit|preview/i.test(ua);
  if (!isBot) {
    await db.linkClick.create({
      data: { linkId: link.id, device: /mobile|android|iphone/i.test(ua) ? "mobile" : "desktop", referrer: (h.get("referer") ?? "").slice(0, 200) || null },
    });
  }
  if (!wa.landingEnabled) redirect(waMeLink(wa.phoneE164, messageWithRef(link.message ?? wa.defaultMessage, code)));

  return (
    <main className="flex min-h-screen items-center justify-center bg-gradient-to-br from-navy to-navy-600 p-4">
      <div className="card w-full max-w-md p-8 text-center">
        <div className="text-xs font-semibold uppercase tracking-widest text-accent">{link.brand.name}</div>
        <h1 className="mt-2 text-2xl font-bold">Fale com um especialista</h1>
        <p className="mt-2 text-sm text-ink-soft">{wa.ctaText}</p>
        <a href={`/r/${code}/go`} className="btn-accent mt-6 w-full py-3 text-base">Continuar para o WhatsApp</a>
        <p className="mt-6 text-[11px] leading-relaxed text-ink-mute">
          Registramos apenas a contagem anônima deste acesso (sem IP, cookies de rastreamento ou dados pessoais) para medir quais conteúdos ajudam mais as pessoas. A mensagem inicial inclui um código de referência da campanha. Seus dados no WhatsApp seguem a política de privacidade de {link.brand.name}. <a className="underline" href="/privacidade">Saiba mais</a>.
        </p>
      </div>
    </main>
  );
}
