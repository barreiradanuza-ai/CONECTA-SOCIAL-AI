export const metadata = { title: "Privacidade — Conecta Social AI" };

export default function Privacidade() {
  return (
    <main className="mx-auto max-w-2xl p-6 text-sm leading-relaxed">
      <h1 className="mb-4 text-2xl font-bold">Privacidade e dados</h1>
      <p className="mb-3">Esta ferramenta é usada pela empresa para gerenciar suas redes sociais. Nos links de atendimento por WhatsApp registramos apenas a contagem anônima de acessos (data, tipo de dispositivo e página de origem), sem endereço IP, sem cookies de rastreamento e sem dados pessoais.</p>
      <p className="mb-3">A mensagem inicial enviada ao WhatsApp contém um código de referência que indica a campanha de origem. As conversas no WhatsApp são tratadas pela empresa conforme sua própria política de privacidade e a LGPD (Lei 13.709/2018).</p>
      <p className="mb-3">Registros de acesso são mantidos pelo período de retenção configurado (padrão de 12 meses) e depois excluídos automaticamente.</p>
      <p>Para exercer seus direitos de titular, entre em contato pelos canais oficiais da empresa.</p>
    </main>
  );
}
