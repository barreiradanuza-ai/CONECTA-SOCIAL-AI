"use server";
import type { Prisma } from "@prisma/client";
import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { env } from "@/lib/env";
import { hashPassword, safeEqual } from "@/lib/crypto";
import { createSession } from "@/lib/auth";
import { CONECTA_AQUI_DEFAULTS, ensureBrandDefaults, importBundledBrandLogos, importBundledPersonaAssets, slugify } from "@/server/brand";
import { audit } from "@/server/audit";
import { PERSONA_PILLAR_WEIGHTS } from "@/server/planner-core";

export async function setupAction(form: FormData) {
  if ((await db.user.count()) > 0) redirect("/login");
  const fail = (m: string) => redirect("/setup?error=" + encodeURIComponent(m));
  if (process.env.NODE_ENV === "production" && !env.setupToken) fail("Defina a variável SETUP_TOKEN no servidor para liberar o primeiro acesso.");
  if (env.setupToken && !safeEqual(String(form.get("token") ?? ""), env.setupToken)) fail("Código de instalação inválido.");
  const orgName = String(form.get("org") ?? "").trim();
  const name = String(form.get("name") ?? "").trim();
  const email = String(form.get("email") ?? "").trim().toLowerCase();
  const password = String(form.get("password") ?? "");
  if (!orgName || !name || !email.includes("@")) fail("Preencha todos os campos.");
  if (password.length < 10) fail("A senha precisa ter ao menos 10 caracteres.");

  const { org, user } = await db.$transaction(async (tx) => {
    const org = await tx.organization.create({ data: { name: orgName, slug: slugify(orgName) || "org" } });
    const user = await tx.user.create({ data: { email, name, passwordHash: hashPassword(password) } });
    await tx.membership.create({ data: { userId: user.id, orgId: org.id, role: "OWNER" } });
    const d = CONECTA_AQUI_DEFAULTS;
    await tx.brand.create({
      data: {
        orgId: org.id,
        name: d.name,
        slug: slugify(d.name),
        website: d.website,
        slogan: d.slogan,
        description: d.description,
        positioning: d.positioning,
        toneOfVoice: d.toneOfVoice,
        targetAudience: d.targetAudience,
        communicationPillars: d.communicationPillars,
        visualGuidelines: d.visualGuidelines,
        defaultHashtags: d.defaultHashtags,
        colors: d.colors,
        personaEnabled: d.personaEnabled,
        personaBible: d.personaBible,
        personaVisual: d.personaVisual,
        personaName: d.personaName,
        seriesTitle: d.seriesTitle,
        colorsConfirmed: d.colorsConfirmed,
      },
    });
    return { org, user };
  });
  const brand = await db.brand.findFirstOrThrow({ where: { orgId: org.id } });
  await ensureBrandDefaults(brand.id);
  // Com personagem: entretenimento como pilar principal
  await db.automationSettings.update({ where: { brandId: brand.id }, data: { pillarWeights: PERSONA_PILLAR_WEIGHTS as unknown as Prisma.InputJsonValue, approvalRequiredPillars: ["OFFERS", "STORYTELLING"], carouselsPerWeek: 3 } });
  await importBundledBrandLogos(org.id, brand.id).catch((e) => console.error("[setup] logotipos", e));
  await importBundledPersonaAssets(org.id, brand.id).catch((e) => console.error("[setup] imagens do personagem", e));
  await audit(org.id, "setup.complete", { userId: user.id });
  await createSession(user.id, org.id);
  redirect("/onboarding");
}
