import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { env } from "@/lib/env";
import { setupAction } from "./actions";

export const dynamic = "force-dynamic";

export default async function SetupPage({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  if ((await db.user.count()) > 0) redirect("/login");
  const { error } = await searchParams;
  return (
    <main className="flex min-h-screen items-center justify-center bg-gradient-to-br from-navy to-navy-600 p-4">
      <form action={setupAction} className="card w-full max-w-md p-8">
        <div className="text-xs font-semibold uppercase tracking-widest text-accent">Primeiro acesso</div>
        <h1 className="mt-1 text-2xl font-bold">Criar conta administradora</h1>
        <p className="mt-1 text-sm text-ink-soft">A organização e a marca Conecta Aqui serão criadas com a configuração inicial, que você poderá revisar em seguida.</p>
        {error && <p className="mt-4 rounded-lg bg-red-50 p-3 text-sm text-red-700">{error}</p>}
        <div className="mt-6 space-y-4">
          {(env.setupToken || process.env.NODE_ENV === "production") && (
            <div>
              <label className="label">Código de instalação (SETUP_TOKEN)</label>
              <input className="input" name="token" required />
            </div>
          )}
          <div>
            <label className="label">Nome da organização</label>
            <input className="input" name="org" defaultValue="Conecta Aqui" required />
          </div>
          <div>
            <label className="label">Seu nome</label>
            <input className="input" name="name" required />
          </div>
          <div>
            <label className="label">E-mail</label>
            <input className="input" name="email" type="email" required />
          </div>
          <div>
            <label className="label">Senha (mín. 10 caracteres)</label>
            <input className="input" name="password" type="password" minLength={10} required />
          </div>
        </div>
        <button className="btn-primary mt-6 w-full">Criar e continuar</button>
      </form>
    </main>
  );
}
