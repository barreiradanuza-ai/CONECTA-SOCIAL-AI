import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { getAuth } from "@/lib/auth";
import { loginAction } from "./actions";

export const dynamic = "force-dynamic";

export default async function LoginPage({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  if (await getAuth()) redirect("/central");
  const users = await db.user.count();
  if (users === 0) redirect("/setup");
  const { error } = await searchParams;
  return (
    <main className="flex min-h-screen items-center justify-center bg-gradient-to-br from-navy to-navy-600 p-4">
      <form action={loginAction} className="card w-full max-w-sm p-8">
        <div className="mb-6">
          <img src="/brand/logo-colorido.png" alt="Conecta Aqui" className="mb-4 h-16 w-auto" />
          <div className="text-xs font-semibold uppercase tracking-widest text-accent">Central de Performance</div>
          <h1 className="mt-1 text-2xl font-bold">Entrar</h1>
          <p className="mt-1 text-sm text-ink-soft">Conteúdo, tráfego pago e resultados em um só lugar.</p>
        </div>
        {error && <p className="mb-4 rounded-lg bg-red-50 p-3 text-sm text-red-700">{error}</p>}
        <label className="label" htmlFor="email">E-mail</label>
        <input className="input mb-4" id="email" name="email" type="email" autoComplete="email" required />
        <label className="label" htmlFor="password">Senha</label>
        <input className="input mb-6" id="password" name="password" type="password" autoComplete="current-password" required />
        <button className="btn-primary w-full" type="submit">Entrar</button>
        <a className="mt-4 block text-center text-sm text-ink-soft underline" href="/recuperar">Esqueci minha senha</a>
      </form>
    </main>
  );
}
