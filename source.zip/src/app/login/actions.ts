"use server";
import { redirect } from "next/navigation";
import { headers } from "next/headers";
import { db } from "@/lib/db";
import { verifyPassword } from "@/lib/crypto";
import { createSession, destroySession } from "@/lib/auth";
import { audit } from "@/server/audit";

// Limitação simples de tentativas por e-mail (memória do processo)
const attempts = new Map<string, { n: number; until: number }>();

export async function loginAction(form: FormData) {
  const email = String(form.get("email") ?? "").trim().toLowerCase();
  const password = String(form.get("password") ?? "");
  const a = attempts.get(email);
  if (a && a.until > Date.now() && a.n >= 5) redirect("/login?error=" + encodeURIComponent("Muitas tentativas. Aguarde 15 minutos."));

  const user = await db.user.findUnique({ where: { email }, include: { memberships: { orderBy: { createdAt: "asc" } } } });
  if (!user || !user.isActive || !verifyPassword(password, user.passwordHash) || !user.memberships[0]) {
    attempts.set(email, { n: (a?.n ?? 0) + 1, until: Date.now() + 15 * 60_000 });
    redirect("/login?error=" + encodeURIComponent("E-mail ou senha inválidos."));
  }
  attempts.delete(email);
  const orgId = user.memberships[0].orgId;
  await createSession(user.id, orgId);
  await db.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } });
  const ua = (await headers()).get("user-agent")?.slice(0, 120);
  await audit(orgId, "auth.login", { userId: user.id, meta: { ua } });
  redirect("/central");
}

export async function logoutAction() {
  await destroySession();
  redirect("/login");
}
