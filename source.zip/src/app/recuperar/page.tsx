import { resetAction } from "./actions";

export const dynamic = "force-dynamic";

export default async function RecoverPage({ searchParams }: { searchParams: Promise<{ error?: string; ok?: string }> }) {
  const { error, ok } = await searchParams;
  return (
    <main className="flex min-h-screen items-center justify-center bg-gradient-to-br from-navy to-navy-600 p-4">
      <form action={resetAction} className="card w-full max-w-sm p-8">
        <div className="mb-6">
          <div className="text-xs font-semibold uppercase tracking-widest text-accent">Conecta Social AI</div>
          <h1 className="mt-1 text-2xl font-bold">Redefinir senha</h1>
          <p className="mt-1 text-sm text-ink-soft">Use o código de instalação (variável SETUP_TOKEN no Railway).</p>
        </div>
        {ok ? (
          <p className="mb-4 rounded-lg bg-green-50 p-3 text-sm text-green-800">
            Senha redefinida. Entre com o e-mail <b>{ok}</b> e a nova senha. <a className="underline" href="/login">Ir para o login</a>
          </p>
        ) : (
          <>
            {error && <p className="mb-4 rounded-lg bg-red-50 p-3 text-sm text-red-700">{error}</p>}
            <label className="label" htmlFor="token">Código de instalação</label>
            <input className="input mb-4" id="token" name="token" type="password" autoComplete="off" required />
            <label className="label" htmlFor="password">Nova senha (mín. 10 caracteres)</label>
            <input className="input mb-4" id="password" name="password" type="password" autoComplete="new-password" minLength={10} required />
            <label className="label" htmlFor="confirm">Repita a nova senha</label>
            <input className="input mb-6" id="confirm" name="confirm" type="password" autoComplete="new-password" minLength={10} required />
            <button className="btn-primary w-full" type="submit">Redefinir</button>
          </>
        )}
      </form>
    </main>
  );
}
