"use server";
import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { env } from "@/lib/env";
import { hashPassword, safeEqual } from "@/lib/crypto";
import { audit } from "@/server/audit";

// Redefinição de senha do dono usando o código de instalação (SETUP_TOKEN), que só existe no Railway.
let tries = { n: 0, until: 0 };

export async function resetAction(form: FormData) {
  const fail = (m: string) => redirect("/recuperar?error=" + encodeURIComponent(m));
  if (tries.until > Date.now() && tries.n >= 5) fail("Muitas tentativas. Aguarde 15 minutos.");
  if (!env.setupToken) fail("Defina a variável SETUP_TOKEN no Railway para usar a recuperação.");
  const token = String(form.get("token") ?? "").trim();
  const password = String(form.get("password") ?? "");
  const confirm = String(form.get("confirm") ?? "");
  if (!safeEqual(token, env.setupToken!)) {
    tries = { n: (tries.until > Date.now() ? tries.n : 0) + 1, until: Date.now() + 15 * 60_000 };
    fail("Código de instalação inválido.");
  }
  if (password.length < 10) fail("A nova senha precisa ter ao menos 10 caracteres.");
  if (password !== confirm) fail("As senhas não conferem.");

  const owner = await db.membership.findFirst({ where: { role: "OWNER" }, orderBy: { createdAt: "asc" }, include: { user: true } });
  if (!owner) fail("Nenhuma conta de dono encontrada.");
  await db.user.update({ where: { id: owner!.userId }, data: { passwordHash: hashPassword(password), isActive: true } });
  tries = { n: 0, until: 0 };
  await audit(owner!.orgId, "auth.password_reset", { userId: owner!.userId, meta: { via: "setup_token" } });
  redirect("/recuperar?ok=" + encodeURIComponent(owner!.user.email));
}
