// Worker de automação (processo separado do servidor web).
// Executa tarefas periódicas com lock distribuído no banco (TaskState), permitindo
// mais de uma instância sem execução duplicada. Não depende de navegador aberto.
import { db } from "@/lib/db";
import { enqueueDuePosts, processQueue } from "@/server/automation/publisher";
import { planAllBrands, produceDue, approvalReminders } from "@/server/automation/autopilot";
import { collectAccountMetrics, collectPostMetrics, analyzeBrand } from "@/server/automation/metrics";
import { applyRetention, checkTokens } from "@/server/automation/maintenance";
import { syncAll } from "@/server/traffic/service";
import { analyzeDue } from "@/server/traffic/ai";
import { radarDaily } from "@/server/radar/radar";
import { processVideoJobs } from "@/server/video/jobs";
import { writeForApprovedTrends } from "@/server/writers/room";

type Task = { name: string; everyMs: number; lockMs: number; run: () => Promise<string | number | void> };

const MIN = 60_000;
const HOUR = 60 * MIN;

const tasks: Task[] = [
  { name: "publish.enqueue", everyMs: 30_000, lockMs: 5 * MIN, run: async () => `enfileiradas: ${await enqueueDuePosts()}` },
  { name: "publish.process", everyMs: 20_000, lockMs: 15 * MIN, run: async () => `processadas: ${await processQueue(10)}` },
  { name: "autopilot.plan", everyMs: 6 * HOUR, lockMs: 60 * MIN, run: planAllBrands },
  { name: "autopilot.produce", everyMs: 15 * MIN, lockMs: 60 * MIN, run: produceDue },
  { name: "approval.reminders", everyMs: 3 * HOUR, lockMs: 10 * MIN, run: async () => approvalReminders() },
  { name: "metrics.posts", everyMs: 6 * HOUR, lockMs: 60 * MIN, run: async () => `snapshots: ${await collectPostMetrics()}` },
  { name: "metrics.accounts", everyMs: 24 * HOUR, lockMs: 30 * MIN, run: collectAccountMetrics },
  {
    name: "insights.weekly",
    everyMs: 7 * 24 * HOUR,
    lockMs: 60 * MIN,
    run: async () => {
      const brands = await db.automationSettings.findMany({ where: { autopilotEnabled: true } });
      for (const b of brands) await analyzeBrand(b.brandId).catch((e) => console.error("[insights]", e));
      return `marcas analisadas: ${brands.length}`;
    },
  },
  { name: "radar.daily", everyMs: 60 * MIN, lockMs: 30 * MIN, run: radarDaily },
  { name: "writers.room", everyMs: 10 * MIN, lockMs: 30 * MIN, run: writeForApprovedTrends },
  { name: "video.process", everyMs: 30_000, lockMs: 15 * MIN, run: processVideoJobs },
  { name: "traffic.sync", everyMs: 15 * MIN, lockMs: 10 * MIN, run: syncAll },
  { name: "traffic.ai", everyMs: 30 * MIN, lockMs: 20 * MIN, run: analyzeDue },
  { name: "tokens.check", everyMs: 24 * HOUR, lockMs: 30 * MIN, run: checkTokens },
  { name: "retention", everyMs: 24 * HOUR, lockMs: 30 * MIN, run: async () => JSON.stringify(await applyRetention()) },
];

async function claim(task: Task): Promise<boolean> {
  const now = new Date();
  await db.taskState.upsert({ where: { name: task.name }, create: { name: task.name }, update: {} });
  const res = await db.taskState.updateMany({
    where: {
      name: task.name,
      AND: [
        { OR: [{ lockedUntil: null }, { lockedUntil: { lt: now } }] },
        { OR: [{ lastRunAt: null }, { lastRunAt: { lt: new Date(now.getTime() - task.everyMs) } }] },
      ],
    },
    data: { lockedUntil: new Date(now.getTime() + task.lockMs) },
  });
  return res.count === 1;
}

async function runTask(task: Task) {
  if (!(await claim(task))) return;
  const started = Date.now();
  try {
    const msg = await task.run();
    await db.taskState.update({
      where: { name: task.name },
      data: { lastRunAt: new Date(), lockedUntil: null, lastOk: true, lastMessage: msg ? String(msg).slice(0, 1000) : "ok", runs: { increment: 1 } },
    });
    if (!task.name.startsWith("publish.") && msg) console.log(`[worker] ${task.name} ok em ${Date.now() - started}ms — ${msg ?? ""}`);
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    console.error(`[worker] ${task.name} falhou:`, msg);
    await db.taskState.update({
      where: { name: task.name },
      data: { lastRunAt: new Date(), lockedUntil: null, lastOk: false, lastMessage: msg.slice(0, 1000), runs: { increment: 1 } },
    });
  }
}

let stopping = false;
async function loop() {
  console.log(`[worker] iniciado — ${tasks.length} tarefas registradas`);
  while (!stopping) {
    // Publicação roda em paralelo às tarefas longas (produção/planejamento) para não atrasar horários.
    const fast = tasks.filter((t) => t.name.startsWith("publish."));
    const slow = tasks.filter((t) => !t.name.startsWith("publish."));
    void Promise.all(slow.map(runTask)).catch((e) => console.error(e));
    for (const t of fast) await runTask(t);
    await new Promise((r) => setTimeout(r, 10_000));
  }
}

for (const sig of ["SIGINT", "SIGTERM"] as const) {
  process.on(sig, async () => {
    console.log(`[worker] ${sig} recebido, encerrando...`);
    stopping = true;
    await db.$disconnect();
    process.exit(0);
  });
}

loop().catch((e) => {
  console.error("[worker] erro fatal", e);
  process.exit(1);
});
