// IA GESTORA DE TRÁFEGO — analisa a conta, cruza com conteúdo orgânico e ofertas aprovadas,
// e devolve diagnóstico + recomendações com nível de autorização. Também gera o "brief"
// que alimenta a IA de conteúdo (ponte entre os dois pilares).
import { z } from "zod";
import { db } from "@/lib/db";
import { structured } from "@/server/ai/anthropic";
import { validOffers } from "@/server/brand";
import { notify } from "@/server/notifications";
import { computeAlerts, dailyTotals, executeRecommendation, latestSnapshot, sumTotals, trafficSettings } from "./service";

const SYSTEM = `Você é o GESTOR DE TRÁFEGO sênior (AI Performance Engine) da marca, uma buscadora/consultoria de planos de internet residencial no Brasil.
Funil: META ADS → WHATSAPP → LEAD → LEAD QUALIFICADO → VENDA → INSTALAÇÃO.
Hierarquia: 1) instalações, vendas, CPA, receita; 2) leads qualificados, CPQL; 3) conversas, CPL; 4) CTR, CPC, CPM (só diagnóstico).

REGRAS INVIOLÁVEIS
- Use SOMENTE os dados fornecidos. Nunca invente números, vendas, leads ou resultados.
- Se não houver dados de CRM (vendas/qualificados), diga isso e nunca trate conversa como venda.
- Teto diário total = "teto_diario". Nunca recomende ultrapassá-lo; se for necessário, nível BLOCKED.
- Com dados insuficientes (menos de ~R$50 gastos, <1.000 impressões ou <72h de veiculação), prefira NÃO ALTERAR e diga o que monitorar.
- Não repita recomendação já rejeitada, a menos que as condições tenham mudado (explique o que mudou).
- Diferencie FATO (dado), HIPÓTESE e RECOMENDAÇÃO.
- Ofertas: só cite ofertas da lista "ofertas_aprovadas". Oferta não aprovada = BLOCKED.
- Níveis: AUTO = baixo risco (ex.: pausar anúncio claramente improdutivo com evidência forte); APPROVAL = precisa de aprovação humana (orçamento, estrutura, público, criativo novo); BLOCKED = não pode ser feito.
- action_type: PAUSE_AD, PAUSE_CAMPAIGN, ACTIVATE_AD, SET_CAMPAIGN_BUDGET (value = novo orçamento diário em reais), NEW_CREATIVE (imagem; action = briefing: ângulo, mensagem, formato), NEW_VIDEO (vídeo curto da persona falando; action = ideia/roteiro do vídeo para anúncio), BOOST_POST (impulsionar um post orgânico vencedor; target_id = id do post em conteudo_organico_30d, target_name = tema; value = verba diária sugerida em reais, dentro do teto), MANUAL (qualquer outra coisa).
- O conteúdo orgânico é o laboratório: post com alcance/interações claramente acima da média é candidato a BOOST_POST (sempre APPROVAL). Criativo pago com fadiga (frequência alta, CTR caindo) pede NEW_CREATIVE ou NEW_VIDEO inspirado nos vencedores.
- Para ações sobre objetos, preencha target_id com o id exato fornecido nos dados.
- Máximo de 5 recomendações, por impacto. Zero é válido.
- "brief_conteudo": 3 a 6 frases para a IA de conteúdo orgânico — ângulos, mensagens e formatos que performam (ou não) nos anúncios, com números. Se não houver dados suficientes, diga isso.`;

const recSchema = z.object({
  title: z.string().min(3),
  level: z.enum(["AUTO", "APPROVAL", "BLOCKED"]).catch("APPROVAL"),
  confidence: z.string().catch("baixa"),
  action_type: z.enum(["PAUSE_AD", "PAUSE_CAMPAIGN", "ACTIVATE_AD", "SET_CAMPAIGN_BUDGET", "NEW_CREATIVE", "NEW_VIDEO", "BOOST_POST", "MANUAL"]).catch("MANUAL"),
  target_id: z.string().optional().nullable(),
  target_name: z.string().optional().nullable(),
  value: z.number().optional().nullable(),
  action: z.string(),
  reason: z.string().optional().default(""),
  evidence: z.string().optional().default(""),
  hypothesis: z.string().optional().default(""),
  impact: z.string().optional().default(""),
  risk: z.string().optional().default(""),
});
const outSchema = z.object({
  diagnostico: z.string(),
  proxima_revisao: z.string().optional().default(""),
  brief_conteudo: z.string().optional().default(""),
  recomendacoes: z.array(recSchema).max(8).default([]),
});

const str = { type: "string" };
const TOOL_SCHEMA = {
  type: "object",
  properties: {
    diagnostico: { type: "string", description: "3-6 frases: situação, o que funciona, o que preocupa, o que ainda não dá para concluir" },
    proxima_revisao: { type: "string", description: "quando e o que olhar na próxima análise" },
    brief_conteudo: { type: "string", description: "aprendizados para a IA de conteúdo orgânico" },
    recomendacoes: {
      type: "array",
      maxItems: 5,
      items: {
        type: "object",
        properties: {
          title: str,
          level: { type: "string", enum: ["AUTO", "APPROVAL", "BLOCKED"] },
          confidence: { type: "string", enum: ["baixa", "média", "alta"] },
          action_type: { type: "string", enum: ["PAUSE_AD", "PAUSE_CAMPAIGN", "ACTIVATE_AD", "SET_CAMPAIGN_BUDGET", "NEW_CREATIVE", "NEW_VIDEO", "BOOST_POST", "MANUAL"] },
          target_id: str,
          target_name: str,
          value: { type: "number" },
          action: { type: "string", description: "o que fazer, concreto" },
          reason: str,
          evidence: { type: "string", description: "Fato: números exatos dos dados" },
          hypothesis: str,
          impact: str,
          risk: str,
        },
        required: ["title", "level", "confidence", "action_type", "action", "evidence"],
      },
    },
  },
  required: ["diagnostico", "recomendacoes"],
};

const r2 = (v: number | null | undefined) => (v == null ? null : Math.round(v * 100) / 100);

export async function analyzeTraffic(brandId: string, trigger: "auto" | "manual" = "auto") {
  const brand = await db.brand.findUniqueOrThrow({ where: { id: brandId } });
  const s = await trafficSettings(brandId);
  const snap = await latestSnapshot(brandId);
  if (!snap) throw new Error("Ainda não há dados da conta de anúncios. Configure a conta e aguarde a primeira sincronização.");

  const since30 = new Date(Date.now() - 30 * 86400_000);
  const [d7, d14, offers, organic, prev, decisions] = await Promise.all([
    dailyTotals(brandId, 7),
    dailyTotals(brandId, 14),
    validOffers(brandId),
    db.postTarget.findMany({
      where: { post: { brandId }, status: "PUBLISHED", publishedAt: { gte: since30 } },
      include: { post: { select: { id: true, theme: true, title: true, pillar: true, format: true } }, metrics: { orderBy: { collectedAt: "desc" }, take: 1 } },
      take: 60,
    }),
    db.trafficAnalysis.findFirst({ where: { brandId, error: null }, orderBy: { createdAt: "desc" }, include: { recs: true } }),
    db.trafficRecommendation.findMany({ where: { brandId, status: { in: ["REJECTED", "EXECUTED", "FAILED"] } }, orderBy: { decidedAt: "desc" }, take: 20 }),
  ]);

  const organicTop = organic
    .map((t) => ({ id: t.post.id, tema: t.post.title ?? t.post.theme, pilar: t.post.pillar, formato: t.post.format, rede: t.network, link: t.permalink, publicado: t.publishedAt, alcance: t.metrics[0]?.reach ?? null, visualizacoes: t.metrics[0]?.views ?? null, interacoes: t.metrics[0]?.interactions ?? null }))
    .sort((a, b) => (b.interacoes ?? 0) - (a.interacoes ?? 0))
    .slice(0, 10);

  const payload = {
    agora: new Date().toISOString(),
    marca: brand.name,
    teto_diario: s.dailyCapCents / 100,
    considerar_desde: snap.since,
    crm_conectado: false,
    hoje: snap.today,
    ultimos_7_dias: sumTotals(d7),
    ultimos_14_dias_por_dia: d14,
    campanhas: snap.campaigns.map((c) => ({ id: c.id, nome: c.name, status: c.status, objetivo: c.objective, orcamento_diario: c.dailyBudget, criada: c.createdAt, gasto: r2(c.spend), impressoes: c.impressions, alcance: c.reach, frequencia: r2(c.frequency), cliques: c.clicks, ctr: r2(c.ctr), cpc: r2(c.cpc), cpm: r2(c.cpm), conversas: c.conversations, custo_por_conversa: r2(c.cpl) })),
    anuncios: snap.ads.map((a) => ({ id: a.id, nome: a.name, campanha_id: a.campaignId, status: a.status, revisao: a.reviewNote, gasto: r2(a.spend), impressoes: a.impressions, cliques: a.clicks, ctr: r2(a.ctr), cpc: r2(a.cpc), frequencia: r2(a.frequency), conversas: a.conversations, custo_por_conversa: r2(a.cpl) })),
    alertas_automaticos: computeAlerts(snap, s.dailyCapCents / 100).map((a) => `${a.level}: ${a.subject} — ${a.text}`),
    ofertas_aprovadas: offers.map((o) => ({ operadora: o.operator, plano: o.planName, mbps: o.speedMbps, preco: o.priceCents / 100, validade: o.validUntil.toISOString().slice(0, 10) })),
    conteudo_organico_30d: organicTop,
    decisoes_anteriores: decisions.map((d) => ({ titulo: d.title, status: d.status, resultado: d.result, em: d.decidedAt ?? d.executedAt })),
    analise_anterior: prev ? { em: prev.createdAt, diagnostico: prev.diagnosis, recomendacoes: prev.recs.map((r) => `${r.title} [${r.status}]`) } : null,
  };

  let data: z.infer<typeof outSchema>;
  let model: string;
  try {
    const r = await structured({
      orgId: brand.orgId,
      system: SYSTEM,
      prompt: `Analise a conta e responda chamando a ferramenta.\n\n${JSON.stringify(payload)}`,
      toolName: "registrar_analise",
      toolDescription: "Registra o diagnóstico, o brief para conteúdo e as recomendações do gestor de tráfego.",
      schema: TOOL_SCHEMA,
      validator: outSchema,
      maxTokens: 6000,
    });
    data = r.data;
    model = r.model;
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    await db.trafficAnalysis.create({ data: { brandId, error: msg.slice(0, 2000), trigger } });
    throw e;
  }

  // Recomendações antigas ainda pendentes deixam de valer
  await db.trafficRecommendation.updateMany({ where: { brandId, status: "PENDING" }, data: { status: "SUPERSEDED" } });
  const analysis = await db.trafficAnalysis.create({
    data: {
      brandId,
      model,
      trigger,
      diagnosis: data.diagnostico,
      nextReview: data.proxima_revisao,
      contentBrief: data.brief_conteudo,
      recs: {
        create: data.recomendacoes.slice(0, 5).map((x) => ({
          brandId,
          title: x.title,
          level: x.level,
          confidence: x.confidence,
          actionType: x.action_type,
          targetId: x.target_id || null,
          targetName: x.target_name || null,
          value: x.value ?? null,
          action: x.action,
          reason: x.reason,
          evidence: x.evidence,
          hypothesis: x.hypothesis,
          impact: x.impact,
          risk: x.risk,
        })),
      },
    },
    include: { recs: true },
  });

  // Execução automática: SOMENTE pausar anúncio, nível AUTO, confiança alta, com opção ligada
  let auto = 0;
  if (s.autoExecute) {
    for (const r of analysis.recs.filter((x) => x.level === "AUTO" && x.actionType === "PAUSE_AD" && x.confidence === "alta" && x.targetId)) {
      if (!snap.ads.some((a) => a.id === r.targetId)) continue;
      try {
        await executeRecommendation(r.id, { label: "IA (AUTO)" });
        auto++;
      } catch (e) {
        console.error("[traffic.ai] auto-execução falhou", r.id, e);
      }
    }
  }

  const pending = analysis.recs.filter((r) => r.level === "APPROVAL").length;
  if (pending) await notify({ orgId: brand.orgId, brandId, level: "WARNING", title: `IA de tráfego: ${pending} ação(ões) aguardando sua aprovação`, body: data.diagnostico.slice(0, 300), link: "/traffic/ai" });
  return `${brand.name}: ${analysis.recs.length} recomendações${auto ? `, ${auto} executada(s) automaticamente` : ""}`;
}

/** Roda a análise nas marcas cujo intervalo venceu. */
export async function analyzeDue() {
  const list = await db.trafficSettings.findMany({ where: { NOT: { accountIds: { isEmpty: true } }, brand: { isActive: true } } });
  const out: string[] = [];
  for (const s of list) {
    const last = await db.trafficAnalysis.findFirst({ where: { brandId: s.brandId }, orderBy: { createdAt: "desc" } });
    if (last && Date.now() - last.createdAt.getTime() < s.aiEveryHours * 3600_000) continue;
    try {
      out.push(await analyzeTraffic(s.brandId, "auto"));
    } catch (e) {
      out.push(`erro: ${e instanceof Error ? e.message.slice(0, 200) : e}`);
    }
  }
  return out.join("; ") || "nada a analisar";
}
