// Meta Marketing API — leitura da conta e execução de ações aprovadas (pausar/ativar/orçamento).
import { getSecret, MissingCredentialError } from "@/server/integrations";

const V = process.env.META_ADS_API_VERSION || "v21.0";
const BASE = process.env.META_GRAPH_BASE || "https://graph.facebook.com";
export const TZ = "America/Sao_Paulo";

export async function adsToken(orgId: string) {
  const t = (await getSecret(orgId, "META_ADS_ACCESS_TOKEN")) || process.env.META_ACCESS_TOKEN?.trim();
  if (!t) throw new MissingCredentialError("token do Meta Ads (META_ADS_ACCESS_TOKEN)");
  return t;
}

type Params = Record<string, string | number>;

async function get(token: string, path: string, params: Params = {}): Promise<any> {
  const url = new URL(`${BASE}/${V}/${path}`);
  for (const [k, v] of Object.entries(params)) url.searchParams.set(k, String(v));
  url.searchParams.set("access_token", token);
  const rows: any[] = [];
  let next: string | null = url.toString();
  let pages = 0;
  while (next && pages++ < 10) {
    const r = await fetch(next, { signal: AbortSignal.timeout(25_000) });
    const j: any = await r.json();
    if (j.error) throw new Error(`Meta API: ${j.error.message} (code ${j.error.code})`);
    if (!Array.isArray(j.data)) return j;
    rows.push(...j.data);
    next = j.paging?.next ?? null;
  }
  return rows;
}

async function post(token: string, path: string, body: Params) {
  const form = new URLSearchParams();
  for (const [k, v] of Object.entries(body)) form.set(k, String(v));
  form.set("access_token", token);
  const r = await fetch(`${BASE}/${V}/${path}`, { method: "POST", body: form, signal: AbortSignal.timeout(25_000) });
  const j: any = await r.json();
  if (j.error) throw new Error(`Meta API: ${j.error.message} (code ${j.error.code})`);
  return j;
}

const num = (v: unknown) => (v == null || v === "" ? null : Number(v));
const CONV = ["onsite_conversion.messaging_conversation_started_7d", "onsite_conversion.total_messaging_connection"];
export function conversations(actions: any): number | null {
  if (!Array.isArray(actions)) return null;
  const a = actions.find((x: any) => x.action_type === CONV[0]) ?? actions.find((x: any) => x.action_type === CONV[1]);
  return a ? Number(a.value) : null;
}

export type Metrics = {
  spend: number;
  impressions: number | null;
  clicks: number | null;
  ctr: number | null;
  cpc: number | null;
  cpm: number | null;
  reach: number | null;
  frequency: number | null;
  conversations: number | null;
  cpl: number | null;
};

function metrics(i: any): Metrics {
  const spend = num(i?.spend) ?? 0;
  const conv = conversations(i?.actions);
  return {
    spend,
    impressions: num(i?.impressions),
    clicks: num(i?.clicks),
    ctr: num(i?.ctr),
    cpc: num(i?.cpc),
    cpm: num(i?.cpm),
    reach: num(i?.reach),
    frequency: num(i?.frequency),
    conversations: conv,
    cpl: conv ? spend / conv : null,
  };
}

export type CampaignRow = Metrics & { accountId: string; account: string; id: string; name: string; status: string; objective: string | null; dailyBudget: number | null; createdAt: string | null };
export type AdRow = Metrics & { accountId: string; id: string; name: string; campaignId: string; campaign: string; status: string; reviewNote: string | null; thumb: string | null };
export type AccountSnapshot = {
  collectedAt: string;
  since: string | null;
  campaigns: CampaignRow[];
  ads: AdRow[];
  today: { date: string; spend: number; conversations: number; activeBudget: number };
  warnings: string[];
};

export const isoDay = (d: Date) => d.toLocaleDateString("en-CA", { timeZone: TZ });

function reviewNote(a: any): string | null {
  const g = a?.ad_review_feedback?.global;
  const v = Array.isArray(g) ? g : g ? Object.values(g) : [];
  return v.length ? String(v[0]) : null;
}

/** Lê campanhas, anúncios, métricas acumuladas e o gasto de hoje. */
export async function fetchAccount(token: string, accountIds: string[], since: Date | null): Promise<AccountSnapshot> {
  const today = isoDay(new Date());
  const sinceKey = since ? since.toISOString() : "";
  const out: AccountSnapshot = { collectedAt: new Date().toISOString(), since: since ? isoDay(since) : null, campaigns: [], ads: [], today: { date: today, spend: 0, conversations: 0, activeBudget: 0 }, warnings: [] };
  const todayRange = JSON.stringify({ since: today, until: today });
  const insF = "campaign_id,spend,impressions,clicks,ctr,cpc,cpm,reach,frequency,actions";
  for (const acc of accountIds) {
    const info = await get(token, `act_${acc}`, { fields: "name,currency" });
    const accName = info.name || acc;
    const adFields = "id,name,effective_status,campaign_id,created_time";
    const [camps, ads, sets, ci, ai, ti] = await Promise.all([
      get(token, `act_${acc}/campaigns`, { fields: "id,name,effective_status,objective,daily_budget,created_time", limit: 200 }),
      get(token, `act_${acc}/ads`, { fields: `${adFields},ad_review_feedback,creative.thumbnail_width(400).thumbnail_height(400){thumbnail_url,image_url}`, limit: 200 }).catch(async (e: Error) => {
        out.warnings.push(`Prévia dos criativos indisponível: ${e.message}`);
        return get(token, `act_${acc}/ads`, { fields: adFields, limit: 200 });
      }),
      get(token, `act_${acc}/adsets`, { fields: "id,campaign_id,effective_status,daily_budget", limit: 200 }).catch(() => []),
      get(token, `act_${acc}/insights`, { level: "campaign", date_preset: "maximum", limit: 200, fields: insF }),
      get(token, `act_${acc}/insights`, { level: "ad", date_preset: "maximum", limit: 500, fields: "ad_id,spend,impressions,clicks,ctr,cpc,cpm,frequency,actions" }),
      get(token, `act_${acc}/insights`, { level: "campaign", time_range: todayRange, limit: 200, fields: "campaign_id,spend,actions" }),
    ]);
    const keep = new Map<string, string>();
    for (const c of camps as any[]) {
      if (sinceKey && (c.created_time ?? "") < sinceKey) continue;
      keep.set(c.id, c.name);
      const active = c.effective_status === "ACTIVE";
      const setBudget = (sets as any[]).filter((s) => s.campaign_id === c.id && s.effective_status === "ACTIVE").reduce((t, s) => t + (Number(s.daily_budget) || 0) / 100, 0);
      const budget = c.daily_budget ? Number(c.daily_budget) / 100 : setBudget || null;
      if (active && budget) out.today.activeBudget += budget;
      const td = (ti as any[]).find((x) => x.campaign_id === c.id);
      out.today.spend += num(td?.spend) ?? 0;
      out.today.conversations += conversations(td?.actions) ?? 0;
      out.campaigns.push({ accountId: acc, account: accName, id: c.id, name: c.name, status: c.effective_status, objective: c.objective ?? null, dailyBudget: budget, createdAt: c.created_time ?? null, ...metrics((ci as any[]).find((x) => x.campaign_id === c.id)) });
    }
    for (const a of ads as any[]) {
      if (!keep.has(a.campaign_id)) continue;
      const cr = a.creative ?? {};
      out.ads.push({ accountId: acc, id: a.id, name: a.name, campaignId: a.campaign_id, campaign: keep.get(a.campaign_id)!, status: a.effective_status, reviewNote: reviewNote(a), thumb: cr.image_url || cr.thumbnail_url || null, ...metrics((ai as any[]).find((x) => x.ad_id === a.id)) });
    }
  }
  return out;
}

export type DailyRow = { date: string; campaignId: string; campaignName: string; spend: number; impressions: number; clicks: number; conversations: number };

/** Série diária por campanha dos últimos `days` dias. */
export async function fetchDaily(token: string, accountIds: string[], days: number, since: Date | null): Promise<DailyRow[]> {
  const until = isoDay(new Date());
  const startD = new Date(Date.now() - (days - 1) * 86400_000);
  let start = isoDay(startD);
  if (since && isoDay(since) > start) start = isoDay(since);
  const rows: DailyRow[] = [];
  for (const acc of accountIds) {
    const data = await get(token, `act_${acc}/insights`, { level: "campaign", time_range: JSON.stringify({ since: start, until }), time_increment: 1, limit: 500, fields: "campaign_id,campaign_name,spend,impressions,clicks,actions,date_start" });
    for (const d of data as any[]) {
      rows.push({ date: d.date_start, campaignId: d.campaign_id, campaignName: d.campaign_name ?? d.campaign_id, spend: num(d.spend) ?? 0, impressions: num(d.impressions) ?? 0, clicks: num(d.clicks) ?? 0, conversations: conversations(d.actions) ?? 0 });
    }
  }
  return rows;
}

// ───────────── Execução (somente após aprovação ou regra AUTO de baixo risco) ─────────────

export async function setStatus(token: string, objectId: string, status: "PAUSED" | "ACTIVE") {
  return post(token, objectId, { status });
}

export async function setCampaignDailyBudget(token: string, campaignId: string, reais: number) {
  return post(token, campaignId, { daily_budget: Math.round(reais * 100) });
}

export async function readObject(token: string, objectId: string, fields: string) {
  return get(token, objectId, { fields });
}
