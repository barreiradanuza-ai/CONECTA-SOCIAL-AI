// "Instagram API com Login do Instagram": conecta a conta profissional do Instagram
// diretamente (sem depender de Página do Facebook). Token de longa duração (60 dias),
// renovado automaticamente pelo worker.
import { env } from "@/lib/env";
import { getSecret } from "@/server/integrations";
import { graph } from "@/server/meta/graph";

export const IG_LOGIN_SCOPES = ["instagram_business_basic", "instagram_business_content_publish", "instagram_business_manage_insights"];

export function igRedirectUri() {
  return `${env.appUrl}/api/instagram/oauth/callback`;
}

export async function igLoginConfig(orgId: string) {
  const [appId, appSecret] = await Promise.all([getSecret(orgId, "INSTAGRAM_APP_ID"), getSecret(orgId, "INSTAGRAM_APP_SECRET")]);
  return appId && appSecret ? { appId, appSecret } : null;
}

export function igBuildAuthUrl(appId: string, state: string) {
  const u = new URL("https://www.instagram.com/oauth/authorize");
  u.searchParams.set("client_id", appId);
  u.searchParams.set("redirect_uri", igRedirectUri());
  u.searchParams.set("response_type", "code");
  u.searchParams.set("scope", IG_LOGIN_SCOPES.join(","));
  u.searchParams.set("state", state);
  u.searchParams.set("enable_fb_login", "0");
  u.searchParams.set("force_authentication", "1");
  return u.toString();
}

async function readJson(res: Response) {
  const text = await res.text();
  let json: any = {};
  try {
    json = text ? JSON.parse(text) : {};
  } catch {
    json = { raw: text };
  }
  if (!res.ok || json.error || json.error_message) {
    const msg = json.error_message || json.error?.message || json.error_description || `Instagram HTTP ${res.status}`;
    throw new Error(msg);
  }
  return json;
}

/** Troca o código por token curto e depois por token de longa duração (60 dias). */
export async function igExchangeCode(cfg: { appId: string; appSecret: string }, code: string) {
  const form = new URLSearchParams({
    client_id: cfg.appId,
    client_secret: cfg.appSecret,
    grant_type: "authorization_code",
    redirect_uri: igRedirectUri(),
    code: code.replace(/#_$/, ""),
  });
  const shortRes = await readJson(
    await fetch("https://api.instagram.com/oauth/access_token", { method: "POST", body: form, signal: AbortSignal.timeout(30_000) }),
  );
  const short = Array.isArray(shortRes.data) ? shortRes.data[0] : shortRes;
  if (!short?.access_token) throw new Error("O Instagram não devolveu o token de acesso.");
  const perms: string[] = Array.isArray(short.permissions) ? short.permissions : String(short.permissions ?? "").split(",").map((s: string) => s.trim()).filter(Boolean);

  const u = new URL("https://graph.instagram.com/access_token");
  u.searchParams.set("grant_type", "ig_exchange_token");
  u.searchParams.set("client_secret", cfg.appSecret);
  u.searchParams.set("access_token", short.access_token);
  const long = await readJson(await fetch(u, { signal: AbortSignal.timeout(30_000) }));
  return {
    token: String(long.access_token),
    expiresAt: long.expires_in ? new Date(Date.now() + Number(long.expires_in) * 1000) : new Date(Date.now() + 60 * 86400_000),
    scopes: perms.length ? perms : IG_LOGIN_SCOPES,
  };
}

/** Renova um token de longa duração (precisa ter mais de 24h e não estar vencido). */
export async function igRefreshToken(token: string) {
  const u = new URL("https://graph.instagram.com/refresh_access_token");
  u.searchParams.set("grant_type", "ig_refresh_token");
  u.searchParams.set("access_token", token);
  const r = await readJson(await fetch(u, { signal: AbortSignal.timeout(30_000) }));
  return { token: String(r.access_token), expiresAt: new Date(Date.now() + Number(r.expires_in ?? 60 * 86400) * 1000) };
}

export async function igProfile(token: string) {
  const r = await graph<{ id: string; user_id?: string | number; username?: string; name?: string; profile_picture_url?: string; account_type?: string }>("me", {
    token,
    params: { fields: "id,user_id,username,name,profile_picture_url,account_type" },
  });
  return {
    id: String(r.user_id ?? r.id),
    username: r.username,
    name: r.name || r.username || "Instagram",
    picture: r.profile_picture_url,
    accountType: r.account_type,
  };
}
