import type { Brand, Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { DEFAULT_PILLAR_WEIGHTS } from "@/server/planner-core";
import { CONECTA_AQUI_PERSONA } from "@/server/persona-conecta";
import type { BrandContext } from "@/server/ai/agent";

export async function ensureBrandDefaults(brandId: string) {
  await db.automationSettings.upsert({
    where: { brandId },
    create: { brandId, pillarWeights: DEFAULT_PILLAR_WEIGHTS as unknown as Prisma.InputJsonValue },
    update: {},
  });
  await db.whatsAppConfig.upsert({ where: { brandId }, create: { brandId }, update: {} });
}

export async function getBrandContext(brand: Brand): Promise<BrandContext> {
  const [whatsapp, insight, episodes, trends, refs] = await Promise.all([
    db.whatsAppConfig.findUnique({ where: { brandId: brand.id } }),
    db.performanceInsight.findFirst({ where: { brandId: brand.id }, orderBy: { createdAt: "desc" } }),
    db.post.findMany({
      where: { brandId: brand.id, pillar: "STORYTELLING", episodeSummary: { not: null }, status: { not: "CANCELED" } },
      orderBy: { episodeNumber: "desc" },
      take: 10,
      select: { episodeNumber: true, episodeSummary: true },
    }),
    db.trendNote.findMany({ where: { brandId: brand.id, status: "APPROVED", validUntil: { gte: new Date() } }, orderBy: { createdAt: "desc" }, take: 15 }),
    db.mediaAsset.count({ where: { brandId: brand.id, role: "CHARACTER_REFERENCE" } }),
  ]);
  const adAnalysis = await db.trafficAnalysis.findFirst({ where: { brandId: brand.id, error: null, contentBrief: { not: null } }, orderBy: { createdAt: "desc" }, select: { contentBrief: true } });
  return {
    brand,
    whatsapp,
    insight,
    seriesMemory: episodes.reverse().map((e) => ({ episode: e.episodeNumber ?? 0, summary: e.episodeSummary! })),
    trends: trends.map((t) => `${t.title ? `${t.title}: ` : ""}${t.text}${t.angle ? ` [ângulo da persona: ${t.angle}]` : ""}${t.sourceUrl ? ` (fonte: ${t.sourceUrl})` : ""}`),
    hasCharacterRefs: refs > 0,
    adLearnings: adAnalysis?.contentBrief ?? null,
  };
}

/** Ofertas aprovadas e dentro da validade na data informada. */
export async function validOffers(brandId: string, at = new Date()) {
  return db.offer.findMany({
    where: { brandId, status: "APPROVED", validFrom: { lte: at }, validUntil: { gte: at } },
    orderBy: { validUntil: "asc" },
  });
}

export function slugify(s: string) {
  return s
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 60);
}

/** Importa os logotipos oficiais que acompanham o projeto (assets/brand). */
export async function importBundledBrandLogos(orgId: string, brandId: string) {
  const fs = await import("node:fs/promises");
  const path = await import("node:path");
  const { saveAsset } = await import("@/server/media");
  const items = [
    { file: "logo-colorido.png", role: "LOGO_PRIMARY" as const, title: "Logotipo colorido (fundo claro)" },
    { file: "logo-branco.png", role: "LOGO_TRANSPARENT" as const, title: "Logotipo branco (fundo escuro/foto)" },
  ];
  for (const it of items) {
    try {
      const buffer = await fs.readFile(path.join(process.cwd(), "assets", "brand", it.file));
      await saveAsset({ orgId, brandId, buffer, mimeType: "image/png", kind: "IMAGE", role: it.role, originalName: it.file, title: it.title, isApproved: true });
    } catch (e) {
      console.warn("[setup] logotipo", it.file, e);
    }
  }
}

/** Importa as imagens oficiais do personagem que acompanham o projeto (assets/persona). */
export async function importBundledPersonaAssets(orgId: string, brandId: string) {
  const fs = await import("node:fs/promises");
  const path = await import("node:path");
  const { saveAsset } = await import("@/server/media");
  const dir = path.join(process.cwd(), "assets", "persona");
  let files: string[] = [];
  try {
    files = (await fs.readdir(dir)).filter((f) => /\.(jpe?g|png)$/i.test(f)).sort().reverse();
  } catch {
    return 0;
  }
  for (const f of files) {
    const buffer = await fs.readFile(path.join(dir, f));
    // O uniforme com logotipo fica como referência visual (não alimenta a geração, para evitar texto/logo inventado na imagem)
    const isUniform = f.includes("uniforme");
    await saveAsset({
      orgId,
      brandId,
      buffer,
      mimeType: f.endsWith(".png") ? "image/png" : "image/jpeg",
      kind: "IMAGE",
      role: isUniform ? "REFERENCE" : "CHARACTER_REFERENCE",
      originalName: f,
      title: `Personagem — ${f.replace(/^\d+-|\.(jpe?g|png)$/g, "").replace(/-/g, " ")}`,
      tags: ["personagem"],
      isApproved: true,
    });
  }
  return files.length;
}

/** Configuração inicial da marca Conecta Aqui (valores confirmáveis no onboarding). */
export const CONECTA_AQUI_DEFAULTS = {
  name: "Conecta Aqui",
  website: "https://www.conectaaqui.net.br/",
  slogan: "Encontre a internet ideal para a sua casa",
  description:
    "A Conecta Aqui simplifica a contratação de internet fibra óptica. Atua como comparador especialista e consultoria imparcial, conectando cada cliente às ofertas disponíveis no seu endereço, com acompanhamento até a instalação.",
  positioning:
    "Não somos apenas revendedores de planos: somos o especialista ao lado do cliente para escolher a conexão adequada, considerando cobertura no endereço, qualidade e estabilidade, velocidade necessária, custo-benefício, condições comerciais e facilidade de contratação.",
  toneOfVoice:
    "Consultivo, humano, claro e confiável. Moderno e acessível, sem jargões técnicos desnecessários e sem exageros promocionais. A marca NÃO divulga ofertas, planos, preços ou promoções nas redes: o convite é sempre para conversar com um especialista.",
  targetAudience: "Famílias e profissionais em home office que querem contratar ou trocar a internet residencial e buscam orientação imparcial.",
  communicationPillars: [
    "Transparência e confiança",
    "Facilidade e agilidade na contratação",
    "Atendimento humano e consultivo",
    "Comparação inteligente de operadoras",
    "Economia com qualidade de conexão",
    "Acompanhamento do cliente até a instalação",
  ],
  visualGuidelines:
    "Moderno, tecnológico, elegante, comercial e acessível. Composição equilibrada, hierarquia tipográfica clara, textos curtos, boa legibilidade no celular, elementos tecnológicos discretos, uso estratégico das cores da marca, fotos de conectividade, famílias e trabalho remoto. CTA visível sem poluição visual.",
  defaultHashtags: ["internetfibra", "conectaaqui", "wifi"],
  personaEnabled: true,
  personaName: "Claudinho",
  seriesTitle: "Claudinho Já Sabia",
  personaBible: CONECTA_AQUI_PERSONA,
  personaVisual:
    "Homem brasileiro de uns 28 anos, pele clara levemente bronzeada, cabelo castanho-escuro volumoso e cacheado (topete ondulado), sobrancelhas grossas e bem desenhadas, bigode fino e marcante com pontas levemente curvadas, barba rala por fazer, olhos castanhos, argolas prateadas nas duas orelhas, corrente prateada fina com pingente, anel escuro e smartwatch preto. Figurino principal: camisa preta de tecido texturizado com brilho metálico, aberta sobre camiseta preta, calça preta pantalona de pregas, cinto preto e tênis preto e branco. Figurino alternativo (situações de trabalho): camisa polo azul-royal da Conecta Aqui com crachá. Expressões teatrais: sobrancelha arqueada, sorriso de canto irônico, mão no queixo, olhar de quem já sabe de tudo. Cenário recorrente: estúdio/sala de criador de conteúdo à noite, estante com livros e plantas pendentes, luz quente de luminárias, letreiro neon azul, janela com cidade ao entardecer, sofá escuro com almofada xadrez preto e branco e almofada pink.",
  // #071b45 vem do site oficial; as demais foram extraídas do logotipo oficial (azul-royal, ciano das ondas, azul do texto).
  colors: { primary: "#071b45", secondary: "#0062dd", accent: "#00c8f0", background: "#f3f7ff", text: "#0b2c86" },
  colorsConfirmed: true,
};
