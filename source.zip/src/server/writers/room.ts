// SALA DE ROTEIRISTAS — a IA roteirista-chefe transforma cada pauta (viral do Brasil ou do mundo)
// em roteiros completos da persona, ligando o assunto ao universo da conexão/internet.
// Pesquisa o contexto na web, escreve 3 ângulos diferentes, avalia e reescreve o melhor.
import type { Prisma } from "@prisma/client";
import { z } from "zod";
import { db } from "@/lib/db";
import { researchStructured } from "@/server/ai/research";
import { brandSystemPrompt } from "@/server/ai/agent";
import { getBrandContext } from "@/server/brand";
import { notify } from "@/server/notifications";

export const WRITER_MODEL = () => process.env.ANTHROPIC_WRITER_MODEL || undefined; // ex.: um modelo Opus para máxima criatividade

const beat = z.object({ ato: z.string(), visual: z.string(), fala: z.string().optional().default(""), texto_tela: z.string().optional().default("") });
const scriptSchema = z.object({
  title: z.string().min(3),
  format: z.enum(["REEL", "CAROUSEL", "STORY"]).catch("REEL"),
  angle: z.string(),
  bridge: z.string(),
  framework: z.string(),
  hooks: z.array(z.string()).min(2).max(5),
  beats: z.array(beat).min(3).max(9),
  speech_15s: z.string().min(5),
  visual_prompt_en: z.string().min(10),
  caption: z.string().min(10),
  cta: z.string().optional().default(""),
  hashtags: z.array(z.string()).max(8).optional().default([]),
  score: z.number().min(0).max(10),
  critique: z.string(),
});
const outSchema = z.object({ scripts: z.array(scriptSchema).min(1).max(4) });

const str = { type: "string" };
const TOOL_SCHEMA = {
  type: "object",
  properties: {
    scripts: {
      type: "array",
      minItems: 1,
      maxItems: 3,
      items: {
        type: "object",
        properties: {
          title: { type: "string", description: "título interno do episódio" },
          format: { type: "string", enum: ["REEL", "CAROUSEL", "STORY"] },
          angle: { type: "string", description: "o ângulo criativo em 1 frase" },
          bridge: { type: "string", description: "como o assunto vira história do universo conectado (internet, Wi-Fi, streaming, WhatsApp, lives)" },
          framework: { type: "string", description: "estrutura usada (ex.: gancho-mistério-virada, falsa premissa, antes/depois, POV, lista absurda, investigação)" },
          hooks: { type: "array", items: str, description: "3 ganchos alternativos para o 1º segundo, cada um com até 12 palavras" },
          beats: {
            type: "array",
            description: "atos do episódio: gancho, situação comum, elemento estranho, investigação, virada, comentário sarcástico, encerramento",
            items: { type: "object", properties: { ato: str, visual: str, fala: str, texto_tela: str }, required: ["ato", "visual"] },
          },
          speech_15s: { type: "string", description: "fala EXATA do personagem para um clipe de até 15 s (máx. 34 palavras), em português do Brasil" },
          visual_prompt_en: { type: "string", description: "cena do clipe de 15 s em inglês: cenário, enquadramento vertical, gestos, expressão, movimento de câmera; sem textos/logos" },
          caption: { type: "string", description: "legenda do Instagram pronta, com quebra de linha, até 3 emojis, CTA natural" },
          cta: str,
          hashtags: { type: "array", items: str },
          score: { type: "number", description: "nota honesta 0-10 de potencial viral + encaixe na marca" },
          critique: { type: "string", description: "o que pode falhar e o que você melhorou na reescrita" },
        },
        required: ["title", "format", "angle", "bridge", "framework", "hooks", "beats", "speech_15s", "visual_prompt_en", "caption", "score", "critique"],
      },
    },
  },
  required: ["scripts"],
};

const WRITER_RULES = `
VOCÊ AGORA É O ROTEIRISTA-CHEFE E COPYWRITER DA MARCA — nível de quem escreve campanhas premiadas e virais de redes sociais.

MISSÃO: pegar qualquer acontecimento viral (do Brasil ou do mundo) e transformá-lo em entretenimento do personagem, onde a CONEXÃO (internet, Wi-Fi, streaming, WhatsApp, lives, redes) aparece como parte natural da história — nunca como anúncio.

MÉTODO (siga em silêncio, entregue só o resultado):
1. Entenda o assunto de verdade (use a busca na web para confirmar fatos, detalhes curiosos e o que as pessoas estão comentando).
2. Encontre 3 PONTES diferentes entre o assunto e a vida conectada (ex.: quem viu ao vivo × quem viu travando; o grupo da família reagindo; o print que viralizou; a live que caiu no momento decisivo; o vizinho que "rouba" o Wi-Fi para assistir).
3. Para cada ponte, escreva um episódio com estrutura clara: gancho no 1º segundo → situação comum → elemento estranho → investigação/escalada → virada → comentário sarcástico → encerramento memorável.
4. Escreva 3 ganchos por roteiro (pergunta intrigante, afirmação absurda, "POV", revelação parcial). O melhor vem primeiro.
5. Critique cada roteiro como um diretor exigente (clichê? previsível? longo? parece propaganda?) e REESCREVA antes de entregar.

REGRAS DE COPY
- Português do Brasil coloquial, frases curtas, ritmo de Reels. Humor de observação, sarcasmo elegante, suspense cômico.
- Fala do clipe de 15 s: no máximo 34 palavras, falada pelo personagem olhando para a câmera.
- A marca pode aparecer no máximo uma vez, de forma leve, ou nem aparecer. Nada de "contrate já".
- Nunca invente fatos, falas de pessoas reais, números, preços ou promoções. Não imite nem cite nome de celebridade como se ela tivesse dito algo.
- Nada de tragédia, política, religião, crimes, pessoas comuns expostas, crianças ou conteúdo sexual. Se o assunto encostar nisso, mude o ângulo para o comportamento das pessoas conectadas, ou descarte.
- Não use músicas, personagens ou marcas protegidas como parte do roteiro.
`;

export async function writeScripts(brandId: string, input: { trendId?: string | null; brief?: string | null; count?: number }) {
  const brand = await db.brand.findUniqueOrThrow({ where: { id: brandId } });
  const ctx = await getBrandContext(brand);
  const trend = input.trendId ? await db.trendNote.findFirst({ where: { id: input.trendId, brandId } }) : null;
  const [recentScripts, topOrganic, lastAds] = await Promise.all([
    db.script.findMany({ where: { brandId, createdAt: { gte: new Date(Date.now() - 30 * 86400_000) } }, orderBy: { createdAt: "desc" }, take: 30, select: { title: true, framework: true } }),
    db.postTarget.findMany({
      where: { post: { brandId }, status: "PUBLISHED", publishedAt: { gte: new Date(Date.now() - 45 * 86400_000) } },
      include: { post: { select: { title: true, theme: true, format: true } }, metrics: { orderBy: { collectedAt: "desc" }, take: 1 } },
      take: 80,
    }),
    db.trafficAnalysis.findFirst({ where: { brandId, error: null, contentBrief: { not: null } }, orderBy: { createdAt: "desc" }, select: { contentBrief: true } }),
  ]);
  const winners = topOrganic
    .map((t) => ({ tema: t.post.title ?? t.post.theme, formato: t.post.format, interacoes: t.metrics[0]?.interactions ?? 0, views: t.metrics[0]?.views ?? 0 }))
    .sort((a, b) => b.interacoes - a.interacoes)
    .slice(0, 8);

  const count = Math.min(3, Math.max(1, input.count ?? 3));
  const prompt = [
    trend
      ? `PAUTA (${trend.scope === "GLOBAL" ? "viral mundial" : "Brasil"}): ${trend.title ?? ""}\nFato: ${trend.text}\nFonte: ${trend.sourceUrl ?? "—"}\nÂngulo sugerido pelo radar: ${trend.angle ?? "—"}\nPonte sugerida: ${trend.bridge ?? "—"}`
      : `PEDIDO: ${input.brief}`,
    trend && input.brief ? `PEDIDO ADICIONAL: ${input.brief}` : "",
    winners.length ? `CONTEÚDOS ORGÂNICOS QUE MAIS ENGAJARAM (aprenda o que funciona): ${winners.map((w) => `${w.tema} [${w.formato}, ${w.interacoes} interações]`).join(" | ")}` : "",
    lastAds?.contentBrief ? `APRENDIZADOS DOS ANÚNCIOS: ${lastAds.contentBrief}` : "",
    recentScripts.length ? `ROTEIROS JÁ ESCRITOS NOS ÚLTIMOS 30 DIAS (não repita ângulo nem estrutura): ${recentScripts.map((r) => `${r.title} (${r.framework ?? "—"})`).join(" | ")}` : "",
    `Escreva ${count} roteiro(s) com pontes e estruturas DIFERENTES entre si, do melhor para o pior. Priorize REEL; use CAROUSEL ou STORY só quando o assunto pedir.`,
  ]
    .filter(Boolean)
    .join("\n\n");

  const r = await researchStructured({
    orgId: brand.orgId,
    system: `${brandSystemPrompt(ctx)}\n${WRITER_RULES}`,
    prompt,
    toolName: "entregar_roteiros",
    toolDescription: "Entrega os roteiros finais, já criticados e reescritos.",
    schema: TOOL_SCHEMA,
    validator: outSchema,
    maxSearches: trend || input.brief ? 6 : 3,
    maxTokens: 12000,
    model: WRITER_MODEL(),
  });

  const created = [];
  for (const sc of r.data.scripts.slice(0, count)) {
    created.push(
      await db.script.create({
        data: {
          brandId,
          trendId: trend?.id ?? null,
          title: sc.title,
          format: sc.format,
          angle: sc.angle,
          bridge: sc.bridge,
          framework: sc.framework,
          hooks: sc.hooks,
          beats: sc.beats as unknown as Prisma.InputJsonValue,
          speech: sc.speech_15s,
          visualPrompt: sc.visual_prompt_en,
          caption: sc.caption,
          cta: sc.cta || null,
          hashtags: sc.hashtags.map((h) => h.replace(/^#/, "")),
          score: Math.round(sc.score),
          critique: sc.critique,
          model: r.model,
        },
      }),
    );
  }
  if (trend) await db.trendNote.update({ where: { id: trend.id }, data: { scriptsAt: new Date() } });
  return created;
}

/** Tarefa do worker: escreve roteiros para pautas aprovadas que ainda não viraram roteiro (até 3 por ciclo). */
export async function writeForApprovedTrends() {
  const trends = await db.trendNote.findMany({
    where: { status: "APPROVED", scriptsAt: null, validUntil: { gte: new Date() }, createdAt: { gte: new Date(Date.now() - 7 * 86400_000) } },
    orderBy: [{ fitScore: "desc" }, { createdAt: "desc" }],
    take: 3,
  });
  const out: string[] = [];
  for (const t of trends) {
    try {
      const list = await writeScripts(t.brandId, { trendId: t.id, count: 3 });
      out.push(`${t.title}: ${list.length} roteiros`);
      const brand = await db.brand.findUnique({ where: { id: t.brandId } });
      if (brand) await notify({ orgId: brand.orgId, brandId: brand.id, level: "INFO", title: `Novos roteiros: ${t.title}`, body: list.map((l) => `${l.title} (nota ${l.score})`).join(" · "), link: "/studio/scripts" });
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      // Sem chave/crédito: tenta de novo no próximo ciclo, sem marcar a pauta.
      if (/credit balance|Credencial ausente|401|403/i.test(msg)) {
        out.push(`pausado: ${msg.slice(0, 120)}`);
        break;
      }
      // Outros erros: marca para não travar a fila (dá para reescrever manualmente).
      await db.trendNote.update({ where: { id: t.id }, data: { scriptsAt: new Date() } });
      out.push(`${t.title}: erro — ${msg.slice(0, 120)}`);
    }
  }
  return out.join("; ");
}
