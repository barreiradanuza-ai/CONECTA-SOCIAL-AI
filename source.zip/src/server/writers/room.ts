// SALA DE ROTEIRISTAS — a IA roteirista-chefe transforma cada pauta em roteiros de DICA PRÁTICA demonstrada
// (Reels/carrossel), com gancho forte, passos claros e precisão técnica; a marca aparece só quando fizer sentido.
// Pesquisa o contexto na web, escreve 3 ângulos diferentes, avalia e reescreve o melhor.
import type { Prisma } from "@prisma/client";
import { z } from "zod";
import { db } from "@/lib/db";
import { FUNNEL_GUIDE } from "@/server/ai/strategy";
import { researchStructured } from "@/server/ai/research";
import { brandSystemPrompt } from "@/server/ai/agent";
import { getBrandContext } from "@/server/brand";
import { notify } from "@/server/notifications";
import { BRIDGE_TOOLKIT, CREATIVE_MODEL } from "@/server/ai/creative";
import { ACCURACY_RULES } from "@/server/ai/strategy";
import { VIDEO_SCENE_GUIDE } from "@/server/ai/visual-rules";

export const WRITER_MODEL = () => CREATIVE_MODEL();

const beat = z.object({ ato: z.string(), visual: z.string(), fala: z.string().optional().default(""), texto_tela: z.string().optional().default("") });
const scriptSchema = z.object({
  title: z.string().min(3),
  format: z.enum(["REEL", "CAROUSEL", "STORY"]).catch("REEL"),
  angle: z.string(),
  bridge: z.string(),
  framework: z.string(),
  hooks: z.array(z.string()).min(2).max(5),
  beats: z.array(beat).min(3).max(9),
  speech_15s: z.string().min(5),
  visual_prompt_en: z.string().min(10),
  caption: z.string().min(10),
  cta: z.string().optional().default(""),
  hashtags: z.array(z.string()).max(8).optional().default([]),
  score: z.number().min(0).max(10),
  critique: z.string(),
});
const outSchema = z.object({ scripts: z.array(scriptSchema).min(1).max(4) });

const str = { type: "string" };
const TOOL_SCHEMA = {
  type: "object",
  properties: {
    scripts: {
      type: "array",
      minItems: 1,
      maxItems: 3,
      items: {
        type: "object",
        properties: {
          title: { type: "string", description: "título interno do roteiro (o problema/descoberta)" },
          format: { type: "string", enum: ["REEL", "CAROUSEL", "STORY"] },
          angle: { type: "string", description: "o ângulo criativo em 1 frase" },
          bridge: { type: "string", description: "formato do repertório usado e, se o assunto permitir, a ligação natural com conexão, cobertura, Wi-Fi residencial ou escolha de plano (ou 'só utilidade')" },
          framework: { type: "string", description: "estrutura usada (ex.: problema-passos-resultado, recurso escondido, erro comum, mito ou verdade, antes/depois, Android × iPhone, checklist)" },
          hooks: { type: "array", items: str, description: "3 ganchos alternativos para o 1º segundo, cada um com até 12 palavras" },
          beats: {
            type: "array",
            description: "etapas do vídeo: gancho (problema/descoberta), contexto em 1 frase, passos da demonstração (1 por etapa, com o que aparece na tela e o texto_tela legível), resultado, cuidado/expectativa honesta, fechamento",
            items: { type: "object", properties: { ato: str, visual: str, fala: str, texto_tela: str }, required: ["ato", "visual"] },
          },
          speech_15s: { type: "string", description: "fala EXATA do vídeo de 22 a 28 s (50 a 65 palavras, frases curtas e completas), em português do Brasil: gancho → passos principais → resultado → cuidado → fechamento" },
          visual_prompt_en: { type: "string", description: "cena do vídeo em inglês: UM plano contínuo só com o personagem (sem montagem nem outras pessoas), cenário doméstico, plano médio vertical com o rosto na metade de cima, gestos, movimento de câmera suave; sem textos legíveis nem logos" },
          caption: { type: "string", description: "legenda do Instagram pronta: gancho, passos numerados por escrito (caminhos de Android/iPhone quando diferentes), cuidado, CTA natural (salvar/compartilhar), até 3 emojis" },
          cta: str,
          hashtags: { type: "array", items: str },
          score: { type: "number", description: "nota honesta 0-10 de utilidade + potencial de salvar/compartilhar + precisão" },
          critique: { type: "string", description: "o que pode falhar e o que você melhorou na reescrita" },
        },
        required: ["title", "format", "angle", "bridge", "framework", "hooks", "beats", "speech_15s", "visual_prompt_en", "caption", "score", "critique"],
      },
    },
  },
  required: ["scripts"],
};

const WRITER_RULES = () => `
VOCÊ AGORA É O ROTEIRISTA-CHEFE DE UM CANAL DE DICAS PRÁTICAS DE TECNOLOGIA — no nível dos melhores criadores de dicas rápidas e tutoriais do Brasil (referências de formato: Jornada Top, TechTudo, Canaltech, TecMundo, Olhar Digital, Tecnoblog — observe a abordagem, nunca copie conteúdos, roteiros ou identidade visual).

MISSÃO: transformar cada pauta em um conteúdo que ajude o público geral — inclusive quem não domina tecnologia — a resolver um problema comum ou descobrir uma funcionalidade útil do celular, do Wi-Fi, da TV, dos apps ou da conexão. A marca ganha confiança pela utilidade; ela aparece só quando fizer sentido.

MÉTODO (siga em silêncio, entregue só o resultado):
1. Entenda o assunto de verdade e CONFIRME os passos na busca (site oficial do fabricante/app, portais de referência). Anote se o caminho muda entre Android e iPhone, marcas de TV ou versões de sistema.
2. Gere pelo menos 6 abordagens usando formatos DIFERENTES do repertório abaixo; aplique o teste de qualidade e fique com as melhores (cada roteiro com um formato diferente — diga qual no campo bridge).
3. Estrutura de cada roteiro: gancho no 1º segundo (problema real, dúvida frequente ou descoberta) → contexto em uma frase → demonstração passo a passo (uma ação por etapa, o que aparece na tela e o TEXTO NA TELA curto e legível) → resultado → cuidado/expectativa honesta → fechamento com CTA útil.
4. Escreva 3 ganchos por roteiro (pergunta direta, "você sabia?", erro comum, "pare de fazer isso", antes/depois). O melhor vem primeiro.
5. Critique cada roteiro como um editor exigente (o passo está certo? vale para qual aparelho? uma pessoa leiga acompanha? promete demais? parece propaganda?) e REESCREVA antes de entregar.

${BRIDGE_TOOLKIT}
${ACCURACY_RULES}

REGRAS DE COPY
- Português do Brasil simples e coloquial, frases curtas, ritmo de Reels. Nada de jargão sem explicação.
- Texto na tela: no máximo ~8 palavras por passo, legível no celular.
- Fala do vídeo: de 22 a 28 segundos (50 a 65 palavras, nunca menos de 48), olhando para a câmera — o gancho, os passos principais (um por frase curta), o resultado, o cuidado e um fechamento que convida a ENVIAR o vídeo para alguém (envio por mensagem é o sinal que mais aumenta o alcance; ex.: "manda pra quem vive culpando o Wi-Fi"). Vídeos educativos com menos de 20 s não ensinam: não encurte.
- ${VIDEO_SCENE_GUIDE} Os passos aparecem em cartões e legendas aplicados pelo app depois, nunca dentro da cena.
- Se houver personagem da marca, ele APRESENTA a dica com a personalidade dele (observador, irônico), mas a demonstração é o centro.
- A marca pode aparecer no máximo uma vez, de forma natural (qualidade da conexão, cobertura, Wi-Fi de casa, escolha de plano), ou nem aparecer. Nada de "contrate já".
- Nunca invente fatos, passos, nomes de menu, números, preços ou promoções. Não atribua falas a pessoas reais.
- Seja duro na nota: 8+ só se a dica for realmente útil, correta e com cara de "vou salvar".
- Nada de tragédia, política, religião, crimes, pessoas comuns expostas, crianças, conteúdo sexual, nem truques para acessar redes ou contas alheias.
- Não use músicas, personagens ou marcas protegidas como parte do roteiro.
`;

export async function writeScripts(brandId: string, input: { trendId?: string | null; brief?: string | null; count?: number }) {
  const brand = await db.brand.findUniqueOrThrow({ where: { id: brandId } });
  const ctx = await getBrandContext(brand);
  const trend = input.trendId ? await db.trendNote.findFirst({ where: { id: input.trendId, brandId } }) : null;
  const [recentScripts, topOrganic, lastAds] = await Promise.all([
    db.script.findMany({ where: { brandId, createdAt: { gte: new Date(Date.now() - 30 * 86400_000) } }, orderBy: { createdAt: "desc" }, take: 30, select: { title: true, framework: true } }),
    db.postTarget.findMany({
      where: { post: { brandId }, status: "PUBLISHED", publishedAt: { gte: new Date(Date.now() - 45 * 86400_000) } },
      include: { post: { select: { title: true, theme: true, format: true } }, metrics: { orderBy: { collectedAt: "desc" }, take: 1 } },
      take: 80,
    }),
    db.trafficAnalysis.findFirst({ where: { brandId, error: null, contentBrief: { not: null } }, orderBy: { createdAt: "desc" }, select: { contentBrief: true } }),
  ]);
  const winners = topOrganic
    .map((t) => ({ tema: t.post.title ?? t.post.theme, formato: t.post.format, interacoes: t.metrics[0]?.interactions ?? 0, views: t.metrics[0]?.views ?? 0 }))
    .sort((a, b) => b.interacoes - a.interacoes)
    .slice(0, 8);

  const count = Math.min(3, Math.max(1, input.count ?? 3));
  const prompt = [
    trend
      ? `PAUTA (${trend.lane === "NICHE" ? "dica prática de tecnologia e conexão" : "assunto do momento que rende uma dica prática"}; ${trend.scope === "GLOBAL" ? "viral mundial" : "Brasil"}): ${trend.title ?? ""}\nFato: ${trend.text}\nFonte: ${trend.sourceUrl ?? "—"}\nÂngulo sugerido pelo radar: ${trend.angle ?? "—"}\nPonte sugerida: ${trend.bridge ?? "—"}${trend.funnelStage ? `\nFunção estratégica: ${FUNNEL_GUIDE[trend.funnelStage]}` : ""}\nO roteiro precisa ensinar algo prático e correto: o problema, os passos (com o que muda entre aparelhos) e o resultado.`
      : `PEDIDO: ${input.brief}`,
    trend && input.brief ? `PEDIDO ADICIONAL: ${input.brief}` : "",
    winners.length ? `CONTEÚDOS ORGÂNICOS QUE MAIS ENGAJARAM (aprenda o que funciona): ${winners.map((w) => `${w.tema} [${w.formato}, ${w.interacoes} interações]`).join(" | ")}` : "",
    lastAds?.contentBrief ? `APRENDIZADOS DOS ANÚNCIOS: ${lastAds.contentBrief}` : "",
    recentScripts.length ? `ROTEIROS JÁ ESCRITOS NOS ÚLTIMOS 30 DIAS (não repita ângulo nem estrutura): ${recentScripts.map((r) => `${r.title} (${r.framework ?? "—"})`).join(" | ")}` : "",
    `Escreva ${count} roteiro(s) com formatos e estruturas DIFERENTES entre si, do melhor para o pior. Priorize REEL de demonstração; use CAROUSEL quando o passo a passo for longo ou valer a pena salvar; STORY só para enquete/quiz.`,
  ]
    .filter(Boolean)
    .join("\n\n");

  const r = await researchStructured({
    orgId: brand.orgId,
    system: `${brandSystemPrompt(ctx)}\n${WRITER_RULES()}`,
    prompt,
    toolName: "entregar_roteiros",
    toolDescription: "Entrega os roteiros finais, já criticados e reescritos.",
    schema: TOOL_SCHEMA,
    validator: outSchema,
    maxSearches: trend || input.brief ? 5 : 3,
    maxTokens: count > 1 ? 12000 : 6000,
    model: WRITER_MODEL(),
  });

  const created = [];
  for (const sc of r.data.scripts.slice(0, count)) {
    created.push(
      await db.script.create({
        data: {
          brandId,
          trendId: trend?.id ?? null,
          title: sc.title,
          format: sc.format,
          angle: sc.angle,
          bridge: sc.bridge,
          framework: sc.framework,
          hooks: sc.hooks,
          beats: sc.beats as unknown as Prisma.InputJsonValue,
          speech: sc.speech_15s,
          visualPrompt: sc.visual_prompt_en,
          caption: sc.caption,
          cta: sc.cta || null,
          hashtags: sc.hashtags.map((h) => h.replace(/^#/, "")),
          score: Math.round(sc.score),
          critique: sc.critique,
          model: r.model,
        },
      }),
    );
  }
  if (trend) await db.trendNote.update({ where: { id: trend.id }, data: { scriptsAt: new Date() } });
  return created;
}

/** Tarefa do worker: escreve roteiros para pautas aprovadas que ainda não viraram roteiro (até 3 por ciclo). */
export async function writeForApprovedTrends() {
  const trends = await db.trendNote.findMany({
    where: { status: "APPROVED", scriptsAt: null, validUntil: { gte: new Date() }, createdAt: { gte: new Date(Date.now() - 7 * 86400_000) } },
    orderBy: [{ fitScore: "desc" }, { createdAt: "desc" }],
    take: 3,
  });
  const out: string[] = [];
  for (const t of trends) {
    try {
      // Automático: 1 roteiro por pauta (com 3 ganchos). "Escrever 3 roteiros" continua disponível manualmente.
      const list = await writeScripts(t.brandId, { trendId: t.id, count: 1 });
      out.push(`${t.title}: ${list.length} roteiros`);
      const brand = await db.brand.findUnique({ where: { id: t.brandId } });
      if (brand) await notify({ orgId: brand.orgId, brandId: brand.id, level: "INFO", title: `Novos roteiros: ${t.title}`, body: list.map((l) => `${l.title} (nota ${l.score})`).join(" · "), link: "/studio/scripts" });
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      // Sem chave/crédito: tenta de novo no próximo ciclo, sem marcar a pauta.
      if (/credit balance|Credencial ausente|401|403/i.test(msg)) {
        out.push(`pausado: ${msg.slice(0, 120)}`);
        break;
      }
      // Outros erros: marca para não travar a fila (dá para reescrever manualmente).
      await db.trendNote.update({ where: { id: t.id }, data: { scriptsAt: new Date() } });
      out.push(`${t.title}: erro — ${msg.slice(0, 120)}`);
    }
  }
  return out.join("; ");
}
