// Operações de ciclo de vida das publicações (usadas pela interface).
import type { Network, Pillar, PostFormat } from "@prisma/client";
import { db } from "@/lib/db";
import { audit } from "@/server/audit";

const EDITABLE = ["PLANNED", "DRAFT", "PENDING_APPROVAL", "APPROVED", "SCHEDULED", "FAILED", "CANCELED"] as const;

export async function getPostForOrg(orgId: string, postId: string) {
  const p = await db.post.findFirst({ where: { id: postId, orgId } });
  if (!p) throw new Error("Publicação não encontrada.");
  return p;
}

export async function approvePost(orgId: string, userId: string, postId: string) {
  const p = await getPostForOrg(orgId, postId);
  const v = p.validation as { errors?: string[] } | null;
  if (!p.title) throw new Error("Gere o conteúdo antes de aprovar.");
  if (v?.errors?.length) throw new Error(`Corrija os problemas de validação antes de aprovar: ${v.errors[0]}`);
  const composed = await db.postMedia.count({ where: { postId, purpose: { in: ["COMPOSED", "SLIDE", "VIDEO"] } } });
  if (!composed) throw new Error("A publicação não tem peça final.");
  if (p.pillar === "OFFERS" && p.offerId) {
    const o = await db.offer.findUnique({ where: { id: p.offerId } });
    const at = p.scheduledAt ?? new Date();
    if (!o || o.status !== "APPROVED" || o.validUntil < at || o.validFrom > at) throw new Error("A oferta vinculada não está aprovada ou não é válida na data.");
  }
  let scheduledAt = p.scheduledAt;
  if (!scheduledAt || scheduledAt < new Date()) scheduledAt = new Date(Date.now() + 5 * 60_000);
  await db.post.update({ where: { id: postId }, data: { status: "SCHEDULED", approvedById: userId, approvedAt: new Date(), scheduledAt } });
  await db.postTarget.updateMany({ where: { postId, status: { in: ["PENDING", "CANCELED"] } }, data: { status: "PENDING", lastError: null } });
  await audit(orgId, "post.approve", { userId, entity: "Post", entityId: postId });
}

export async function rejectToDraft(orgId: string, userId: string, postId: string) {
  await getPostForOrg(orgId, postId);
  await db.post.update({ where: { id: postId }, data: { status: "DRAFT", approvedAt: null, approvedById: null } });
  await audit(orgId, "post.unapprove", { userId, entity: "Post", entityId: postId });
}

export async function reschedulePost(orgId: string, userId: string, postId: string, at: Date) {
  const p = await getPostForOrg(orgId, postId);
  if (["PUBLISHED", "PUBLISHING", "PARTIALLY_PUBLISHED"].includes(p.status)) throw new Error("Publicação já publicada não pode ser reagendada.");
  await db.post.update({ where: { id: postId }, data: { scheduledAt: at, timeReason: "Definido manualmente" } });
  await audit(orgId, "post.reschedule", { userId, entity: "Post", entityId: postId, meta: { at: at.toISOString() } });
}

export async function cancelPost(orgId: string, userId: string, postId: string) {
  const p = await getPostForOrg(orgId, postId);
  if (["PUBLISHED", "PUBLISHING"].includes(p.status)) throw new Error("Não é possível cancelar uma publicação já publicada ou em publicação.");
  await db.post.update({ where: { id: postId }, data: { status: "CANCELED" } });
  await db.postTarget.updateMany({ where: { postId, status: { in: ["PENDING", "QUEUED", "FAILED"] } }, data: { status: "CANCELED" } });
  await audit(orgId, "post.cancel", { userId, entity: "Post", entityId: postId });
}

export async function publishNow(orgId: string, userId: string, postId: string) {
  const p = await getPostForOrg(orgId, postId);
  if (!p.approvedAt) throw new Error("Aprove a publicação antes de publicar.");
  await db.post.update({ where: { id: postId }, data: { status: "SCHEDULED", scheduledAt: new Date() } });
  await audit(orgId, "post.publish_now", { userId, entity: "Post", entityId: postId });
}

export async function retryTarget(orgId: string, userId: string, targetId: string) {
  const t = await db.postTarget.findFirst({ where: { id: targetId, post: { orgId } }, include: { post: true } });
  if (!t) throw new Error("Destino não encontrado.");
  if (t.status === "PUBLISHED" || t.externalId) throw new Error("Este destino já foi publicado — nova tentativa evitada para não duplicar.");
  await db.postTarget.update({ where: { id: targetId }, data: { status: "QUEUED", nextRetryAt: new Date(), lastError: null } });
  await db.post.update({ where: { id: t.postId }, data: { status: "PUBLISHING" } });
  await audit(orgId, "target.retry", { userId, entity: "PostTarget", entityId: targetId });
}

export async function updatePostContent(
  orgId: string,
  userId: string,
  postId: string,
  data: { title?: string; subtitle?: string; cta?: string; theme?: string; captions?: Partial<Record<Network, string>>; hashtags?: string[]; layout?: string; slides?: { title: string; body: string }[] },
) {
  const p = await getPostForOrg(orgId, postId);
  if (!EDITABLE.includes(p.status as (typeof EDITABLE)[number])) throw new Error("Esta publicação não pode mais ser editada.");
  await db.post.update({
    where: { id: postId },
    data: {
      title: data.title,
      subtitle: data.subtitle,
      cta: data.cta,
      theme: data.theme,
      hashtags: data.hashtags,
      layout: data.layout,
      slides: data.slides as any,
      // Edição volta para aprovação (conteúdo mudou)
      status: p.status === "PLANNED" ? "PLANNED" : "PENDING_APPROVAL",
      approvedAt: null,
      approvedById: null,
    },
  });
  for (const [network, caption] of Object.entries(data.captions ?? {})) {
    await db.postTarget.updateMany({ where: { postId, network: network as Network }, data: { caption } });
  }
  await audit(orgId, "post.edit", { userId, entity: "Post", entityId: postId });
}

export async function createManualPost(input: {
  orgId: string;
  userId: string;
  brandId: string;
  pillar: Pillar;
  format: PostFormat;
  theme: string;
  objective?: string;
  networks: Network[];
  scheduledAt?: Date | null;
  offerId?: string | null;
  campaignId?: string | null;
}) {
  const post = await db.post.create({
    data: {
      orgId: input.orgId,
      brandId: input.brandId,
      pillar: input.pillar,
      format: input.format,
      theme: input.theme,
      objective: input.objective,
      scheduledAt: input.scheduledAt ?? null,
      offerId: input.offerId ?? null,
      campaignId: input.campaignId ?? null,
      origin: "HUMAN",
      status: "PLANNED",
      targets: { create: input.networks.map((network) => ({ network })) },
    },
  });
  await audit(input.orgId, "post.create", { userId: input.userId, entity: "Post", entityId: post.id });
  return post;
}
