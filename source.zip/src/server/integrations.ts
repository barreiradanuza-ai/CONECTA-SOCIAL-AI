// Resolução de chaves de API: primeiro a chave cadastrada (criptografada) pela organização,
// depois a variável de ambiente do servidor. Nunca enviadas ao navegador.
import { db } from "@/lib/db";
import { decrypt, encrypt } from "@/lib/crypto";

export const SECRET_KEYS = [
  { key: "ANTHROPIC_API_KEY", label: "Anthropic (Claude) — textos e planejamento" },
  { key: "OPENAI_API_KEY", label: "OpenAI — geração de imagens" },
  { key: "META_ADS_ACCESS_TOKEN", label: "Meta Ads — token do usuário do sistema (gestor de tráfego)" },
  { key: "MINIMAX_API_KEY", label: "MiniMax — voz e vídeo da persona" },
  { key: "SERPAPI_API_KEY", label: "SerpApi — Google Trends Brasil e notícias (radar)" },
  { key: "APIFY_TOKEN", label: "Apify — tendências do TikTok/Instagram (radar)" },
] as const;

export type SecretKey = (typeof SECRET_KEYS)[number]["key"];

export async function getSecret(orgId: string, key: SecretKey): Promise<string | undefined> {
  const row = await db.integrationSecret.findUnique({ where: { orgId_key: { orgId, key } } });
  if (row) {
    try {
      return decrypt(row.valueEnc);
    } catch {
      /* segue para env */
    }
  }
  const v = process.env[key];
  return v && v.trim() ? v.trim() : undefined;
}

export async function setSecret(orgId: string, key: SecretKey, value: string | null) {
  if (!value) {
    await db.integrationSecret.deleteMany({ where: { orgId, key } });
    return;
  }
  await db.integrationSecret.upsert({
    where: { orgId_key: { orgId, key } },
    create: { orgId, key, valueEnc: encrypt(value) },
    update: { valueEnc: encrypt(value) },
  });
}

export async function secretStatus(orgId: string) {
  const rows = await db.integrationSecret.findMany({ where: { orgId } });
  return SECRET_KEYS.map((s) => ({
    ...s,
    source: rows.some((r) => r.key === s.key) ? "painel" : process.env[s.key] ? "servidor" : null,
  }));
}

export class MissingCredentialError extends Error {
  constructor(what: string) {
    super(`Credencial ausente: ${what}. Cadastre em Configurações → Integrações.`);
    this.name = "MissingCredentialError";
  }
}
