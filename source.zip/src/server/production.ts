// Produção de uma publicação: texto (IA) → fundo (IA ou biblioteca) → composição → validação →
// decisão de aprovação. Usado pelo piloto automático e pelos estúdios.
import type { Network, Post, Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { sha256 } from "@/lib/crypto";
import { generatePostContent } from "@/server/ai/agent";
import { generateImage, generateWithReferences } from "@/server/ai/images";
import { getBrandContext, validOffers } from "@/server/brand";
import { checkCommercialText, checkForbiddenTerms, formatBRL, isOfferValid } from "@/server/guard";
import { loadBrandKit, prepareBackground, renderCreative } from "@/server/creative/composer";
import { creativeFormatFor, FORMAT_SPEC } from "@/server/creative/formats";
import { validateCopy, validateImage, type ValidationReport } from "@/server/creative/validate";
import { saveAsset } from "@/server/media";
import { getObject, deleteObject } from "@/server/storage";
import { bioLink, createTrackingLink, trackingUrl } from "@/server/whatsapp";
import { formatDate } from "@/lib/time";

export type ProduceOptions = {
  regenerateText?: boolean;
  regenerateImage?: boolean;
  backgroundAssetId?: string;
  extraInstructions?: string;
  actor?: "autopilot" | "user";
};

function normalizeTag(t: string) {
  return t.replace(/^#+/, "").replace(/\s+/g, "").toLowerCase();
}

export function buildCaptions(input: {
  captionInstagram: string;
  captionFacebook: string;
  hashtags: string[];
  maxHashtagsIg: number;
  ctaText?: string | null;
  fbLink?: string | null;
  hasWhatsapp: boolean;
}) {
  const tags = [...new Set(input.hashtags.map(normalizeTag).filter(Boolean))];
  const igTags = tags.slice(0, input.maxHashtagsIg).map((t) => `#${t}`).join(" ");
  const fbTags = tags.slice(0, 3).map((t) => `#${t}`).join(" ");
  let ig = input.captionInstagram.trim();
  let fb = input.captionFacebook.trim();
  if (input.hasWhatsapp && !/link na bio/i.test(ig)) ig += `\n\n${input.ctaText ? `${input.ctaText} ` : ""}Link na bio.`;
  if (input.hasWhatsapp && input.fbLink && !fb.includes(input.fbLink)) fb += `\n\n${input.ctaText ?? "Fale com um especialista pelo WhatsApp:"}\n${input.fbLink}`;
  if (igTags) ig += `\n\n${igTags}`;
  if (fbTags) fb += `\n\n${fbTags}`;
  return { ig: ig.slice(0, 2200), fb };
}

async function linkMedia(postId: string, assetId: string, purpose: string, position = 0) {
  await db.postMedia.create({ data: { postId, assetId, purpose, position } });
}

async function clearComposed(postId: string) {
  const old = await db.postMedia.findMany({ where: { postId, purpose: { in: ["COMPOSED", "SLIDE", "COVER"] } }, include: { asset: true } });
  await db.postMedia.deleteMany({ where: { id: { in: old.map((o) => o.id) } } });
  for (const o of old) {
    const stillUsed = await db.postMedia.count({ where: { assetId: o.assetId } });
    if (!stillUsed && !o.asset.isApproved) {
      await db.mediaAsset.delete({ where: { id: o.assetId } }).catch(() => {});
      await deleteObject(o.asset.storageKey).catch(() => {});
    }
  }
}

export async function producePost(postId: string, opts: ProduceOptions = {}) {
  const post = await db.post.findUniqueOrThrow({ where: { id: postId }, include: { brand: true, offer: true, targets: true, media: { include: { asset: true } } } });
  const brand = post.brand;
  const settings = await db.automationSettings.findUniqueOrThrow({ where: { brandId: brand.id } });
  const ctx = await getBrandContext(brand);
  const networks: Network[] = post.targets.length ? post.targets.map((t) => t.network) : ["INSTAGRAM", "FACEBOOK"];
  const previousStatus = post.status;

  await db.post.update({ where: { id: post.id }, data: { status: "GENERATING", generationError: null } });

  try {
    // Oferta: somente aprovada e válida na data de publicação
    let offer = post.offer;
    const when = post.scheduledAt ?? new Date();
    if (post.pillar === "OFFERS" && (!offer || !isOfferValid(offer, when))) {
      const offers = await validOffers(brand.id, when);
      offer = offers[0] ?? null;
      if (offer) await db.post.update({ where: { id: post.id }, data: { offerId: offer.id } });
    }

    // Links rastreáveis (WhatsApp) por publicação/rede
    const hasWhatsapp = !!ctx.whatsapp?.phoneE164;
    let fbLink: string | null = null;
    if (hasWhatsapp && networks.includes("FACEBOOK")) {
      const existing = await db.trackingLink.findFirst({ where: { postId: post.id, network: "FACEBOOK" } });
      const link = existing ?? (await createTrackingLink({ orgId: post.orgId, brandId: brand.id, postId: post.id, campaignId: post.campaignId, network: "FACEBOOK" }));
      fbLink = trackingUrl(link.code);
    }
    if (hasWhatsapp) await bioLink(post.orgId, brand.id);

    // 1) Texto
    const needsText = opts.regenerateText || !post.title || !post.targets.some((t) => t.caption);
    let current: Post = post;
    if (needsText) {
      const recent = await db.post.findMany({
        where: { brandId: brand.id, id: { not: post.id }, title: { not: null } },
        orderBy: { createdAt: "desc" },
        take: 60,
        select: { title: true },
      });
      const { data, model } = await generatePostContent(post.orgId, ctx, {
        pillar: post.pillar,
        format: post.format,
        theme: post.theme,
        objective: post.objective,
        networks,
        offer,
        recentTitles: recent.map((r) => r.title!).filter(Boolean),
        maxHashtags: settings.maxHashtagsInstagram,
        trackingUrl: fbLink,
        extraInstructions: opts.extraInstructions,
      });
      const captions = buildCaptions({
        captionInstagram: data.caption_instagram,
        captionFacebook: data.caption_facebook,
        hashtags: [...data.hashtags, ...brand.defaultHashtags],
        maxHashtagsIg: settings.maxHashtagsInstagram,
        ctaText: ctx.whatsapp?.ctaText,
        fbLink,
        hasWhatsapp,
      });
      const layout = post.format === "CAROUSEL" ? "carousel" : post.format === "STORY" ? (data.layout === "question-card" ? "question-card" : "story") : offer && post.pillar === "OFFERS" ? "offer" : data.layout === "offer" || data.layout === "carousel" || data.layout === "story" ? "hero-bottom" : data.layout;
      current = await db.post.update({
        where: { id: post.id },
        data: {
          title: data.title,
          subtitle: data.subtitle,
          cta: data.cta,
          hashtags: data.hashtags.map(normalizeTag),
          imagePrompt: data.image_prompt,
          artDirection: data.art_direction,
          layout,
          slides: post.format === "CAROUSEL" ? (data.slides as unknown as Prisma.InputJsonValue) : undefined,
          reelScript: data.reel_script || null,
          episodeSummary: post.pillar === "STORYTELLING" ? data.episode_summary || null : undefined,
          episodeNumber:
            post.pillar === "STORYTELLING" && !post.episodeNumber
              ? ((await db.post.aggregate({ where: { brandId: brand.id, pillar: "STORYTELLING" }, _max: { episodeNumber: true } }))._max.episodeNumber ?? 0) + 1
              : undefined,
          aiModel: model,
          contentHash: sha256(`${post.pillar}|${data.title.toLowerCase().trim()}`),
        },
      });
      for (const n of networks) {
        await db.postTarget.upsert({
          where: { postId_network: { postId: post.id, network: n } },
          create: { postId: post.id, network: n, caption: n === "INSTAGRAM" ? captions.ig : captions.fb },
          update: { caption: n === "INSTAGRAM" ? captions.ig : captions.fb },
        });
      }
    }

    // 2) Fundo
    let backgroundAssetId = opts.backgroundAssetId ?? post.media.find((m) => m.purpose === "BACKGROUND")?.assetId;
    if (opts.backgroundAssetId || opts.regenerateImage) {
      await db.postMedia.deleteMany({ where: { postId: post.id, purpose: "BACKGROUND" } });
    }
    if (opts.regenerateImage || !backgroundAssetId || opts.backgroundAssetId) {
      if (!opts.backgroundAssetId) {
        const colors = brand.colors as Record<string, string>;
        const prompt = `${current.imagePrompt ?? current.theme}. Art direction: ${current.artDirection ?? "modern, clean, bright"}. Subtle color accents harmonizing with ${colors.primary ?? "#071b45"} and ${colors.accent ?? "#1f7bff"}. Photorealistic, high quality, mobile-first composition.`;
        // Personagem recorrente: usa as imagens oficiais de referência para manter a aparência entre episódios
        const usesCharacter = brand.personaEnabled && (post.pillar === "STORYTELLING" || post.format === "STORY");
        const refAssets = usesCharacter
          ? await db.mediaAsset.findMany({ where: { brandId: brand.id, role: "CHARACTER_REFERENCE", kind: "IMAGE" }, orderBy: { createdAt: "desc" }, take: 4 })
          : [];
        const img = refAssets.length
          ? await generateWithReferences({
              orgId: post.orgId,
              prompt: `${prompt}${brand.personaVisual ? ` Character: ${brand.personaVisual}.` : ""}`,
              references: await Promise.all(refAssets.map(async (a) => ({ buffer: await getObject(a.storageKey), mimeType: a.mimeType, name: a.originalName ?? `ref.${a.mimeType.split("/")[1]}` }))),
              orientation: "portrait",
            })
          : await generateImage({ orgId: post.orgId, prompt, orientation: "portrait" });
        const asset = await saveAsset({
          orgId: post.orgId,
          brandId: brand.id,
          buffer: img.buffer,
          mimeType: "image/jpeg",
          kind: "IMAGE",
          role: "GENERATED",
          source: "AI",
          prompt: img.prompt,
          title: current.theme,
          tags: [post.pillar.toLowerCase()],
        });
        backgroundAssetId = asset.id;
      }
      await linkMedia(post.id, backgroundAssetId!, "BACKGROUND");
    }

    // 3) Vídeo para Reels (somente da biblioteca; não se assume geração de vídeo por IA)
    let reelNeedsVideo = false;
    if (post.format === "REEL" && !post.media.some((m) => m.purpose === "VIDEO")) {
      const video = await db.mediaAsset.findFirst({
        where: { brandId: brand.id, kind: "VIDEO", isApproved: true, postMedia: { none: {} } },
        orderBy: { createdAt: "asc" },
      });
      if (video) await linkMedia(post.id, video.id, "VIDEO");
      else reelNeedsVideo = true;
    }

    // 4) Composição
    await clearComposed(post.id);
    const kit = await loadBrandKit(brand);
    const bgAsset = await db.mediaAsset.findUniqueOrThrow({ where: { id: backgroundAssetId! } });
    const bgBuf = await getObject(bgAsset.storageKey);
    const cf = creativeFormatFor(post.format);
    const spec = FORMAT_SPEC[cf];
    const bgSrc = await prepareBackground(bgBuf, spec.width, spec.height);
    const offerView = offer
      ? {
          operator: offer.operator,
          speed: String(offer.speedMbps),
          price: formatBRL(offer.priceCents),
          period: offer.pricePeriod,
          benefits: offer.benefits,
          footnote: `Oferta válida até ${formatDate(offer.validUntil, brand.timezone)}. ${offer.restrictions ? offer.restrictions + " " : ""}Consulte a disponibilidade para seu endereço.`,
        }
      : null;

    const reports: ValidationReport[] = [];
    const layout = current.layout ?? "hero-bottom";
    const lightOverImage = ["hero-bottom", "story"].includes(layout);

    if (post.format === "CAROUSEL") {
      const slides = ((current.slides as { title: string; body: string }[] | null) ?? []).slice(0, 8);
      const isEpisode = post.pillar === "STORYTELLING";
      const all = [
        { kind: "cover" as const, title: current.title ?? post.theme, body: current.subtitle ?? "" },
        // Episódio: os 7 atos entram inteiros; demais carrosséis: o 1º slide da IA é capa (já desenhada)
        ...slides.filter((_, i) => isEpisode || i > 0 || slides.length < 3).map((s) => ({ kind: "content" as const, ...s })),
      ];
      if (all.length < 3) all.push({ kind: "content", title: current.subtitle ?? "", body: "" });
      all.push(
        isEpisode
          ? { kind: "final", title: "Continua…", body: brand.seriesTitle ? `${brand.seriesTitle} — ${brand.name}` : brand.name }
          : { kind: "final", title: "Ficou com dúvida?", body: ctx.whatsapp?.ctaText ?? "Fale com um especialista." },
      );
      const total = Math.min(all.length, 10);
      for (let i = 0; i < total; i++) {
        const s = all[i];
        const buf = await renderCreative(kit, {
          width: spec.width,
          height: spec.height,
          layout: "carousel",
          backgroundSrc: s.kind === "cover" ? bgSrc : null,
          title: s.kind === "cover" ? s.title : current.title ?? "",
          subtitle: s.kind === "cover" ? (isEpisode && current.episodeNumber ? `${brand.seriesTitle ?? brand.personaName ?? "Episódio"} · Ep. ${current.episodeNumber}` : current.subtitle) : null,
          cta: s.kind === "final" ? current.cta : s.kind === "cover" ? (isEpisode ? "Arraste e descubra" : "Arraste para o lado") : null,
          slide: { index: i + 1, total, title: s.title, body: s.body, kind: s.kind },
        });
        reports.push(await validateImage(buf, cf, { hasLogo: kit.hasLogo, layout: "carousel", lightTextOverImage: s.kind === "cover" }));
        const a = await saveAsset({ orgId: post.orgId, brandId: brand.id, buffer: buf, mimeType: "image/jpeg", kind: "IMAGE", role: "COMPOSED", source: "COMPOSED", title: `${current.title} — ${i + 1}/${total}` });
        await linkMedia(post.id, a.id, "SLIDE", i);
      }
    } else {
      const buf = await renderCreative(kit, {
        width: spec.width,
        height: spec.height,
        layout,
        backgroundSrc: bgSrc,
        title: current.title ?? post.theme,
        subtitle: current.subtitle,
        cta: current.cta,
        offer: layout === "offer" ? offerView : null,
      });
      reports.push(await validateImage(buf, cf, { hasLogo: kit.hasLogo, layout, lightTextOverImage: lightOverImage }));
      const a = await saveAsset({ orgId: post.orgId, brandId: brand.id, buffer: buf, mimeType: "image/jpeg", kind: "IMAGE", role: "COMPOSED", source: "COMPOSED", title: current.title ?? post.theme });
      await linkMedia(post.id, a.id, post.format === "REEL" ? "COVER" : "COMPOSED");
    }

    // 5) Validação de texto e guarda comercial
    const targets = await db.postTarget.findMany({ where: { postId: post.id } });
    const texts = [current.title, current.subtitle, current.cta, ...targets.map((t) => t.caption), ...((current.slides as any[]) ?? []).flatMap((s: any) => [s.title, s.body])].filter(Boolean) as string[];
    const guard = checkCommercialText(texts, offer ?? null, when);
    const forbidden = checkForbiddenTerms(texts, brand.forbiddenTerms);
    const copy = validateCopy({
      title: current.title,
      captionInstagram: targets.find((t) => t.network === "INSTAGRAM")?.caption,
      hashtags: current.hashtags,
      maxHashtags: settings.maxHashtagsInstagram,
    });
    const errors = [...reports.flatMap((r) => r.errors), ...copy.errors, ...guard.violations, ...forbidden];
    if (post.pillar === "OFFERS" && !offer) errors.push("Publicação de oferta sem oferta aprovada e válida para a data.");
    const warnings = [...new Set([...reports.flatMap((r) => r.warnings), ...copy.warnings])];

    // 6) Decisão de aprovação
    const reasons: string[] = [];
    if (settings.mode === "SUPERVISED") reasons.push("Modo supervisionado: toda publicação requer aprovação.");
    if (settings.approvalRequiredPillars.includes(post.pillar)) reasons.push("Pilar configurado para exigir aprovação humana.");
    if (settings.approvalRequiredFormats.includes(post.format)) reasons.push("Formato configurado para exigir aprovação humana.");
    if (post.origin === "HUMAN") reasons.push("Publicação criada manualmente.");
    if (errors.length) reasons.push("A validação automática encontrou problemas.");
    if (reelNeedsVideo) reasons.push("Reels aguardando vídeo aprovado na biblioteca.");
    if (opts.actor === "user" && !reasons.length) reasons.push("Gerado ou ajustado manualmente: revise e aprove para agendar.");

    const autoOk = reasons.length === 0 && post.scheduledAt && post.scheduledAt > new Date();
    const status = reelNeedsVideo ? "DRAFT" : autoOk ? "SCHEDULED" : "PENDING_APPROVAL";
    await db.post.update({
      where: { id: post.id },
      data: {
        status,
        approvalRequired: !autoOk,
        approvalReasons: reasons,
        approvedAt: autoOk ? new Date() : null,
        approvedById: null,
        validation: { ok: errors.length === 0, errors, warnings, checkedAt: new Date().toISOString() },
        generationError: null,
      },
    });
    if (autoOk) await db.postTarget.updateMany({ where: { postId: post.id, status: { in: ["PENDING", "FAILED", "CANCELED"] } }, data: { status: "PENDING" } });
    return { status, errors, warnings, reasons };
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    await db.post.update({
      where: { id: post.id },
      data: { status: previousStatus === "GENERATING" ? "PLANNED" : previousStatus, generationError: msg.slice(0, 2000) },
    });
    throw e;
  }
}
