// Piloto automático: planeja, produz e agenda sem intervenção diária.
import { db } from "@/lib/db";
import { ensureCalendar } from "./planner";
import { producePost } from "@/server/production";
import { notify } from "@/server/notifications";
import { MissingCredentialError } from "@/server/integrations";

function activeAutopilot() {
  const now = new Date();
  return db.automationSettings.findMany({
    where: { autopilotEnabled: true, brand: { isActive: true }, OR: [{ pausedUntil: null }, { pausedUntil: { lt: now } }] },
    include: { brand: true },
  });
}

export async function planAllBrands() {
  const results: string[] = [];
  for (const s of await activeAutopilot()) {
    try {
      const r = await ensureCalendar(s.brandId);
      results.push(`${s.brand.name}: +${r.created}`);
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      results.push(`${s.brand.name}: erro`);
      await notify({ orgId: s.brand.orgId, brandId: s.brandId, level: e instanceof MissingCredentialError ? "WARNING" : "ERROR", title: "Falha no planejamento automático", body: msg, link: "/calendar" });
    }
  }
  return results.join("; ") || "nenhuma marca com piloto automático";
}

/** Gera conteúdo das publicações planejadas que entram na janela de produção. */
export async function produceDue() {
  const out: string[] = [];
  for (const s of await activeAutopilot()) {
    const until = new Date(Date.now() + s.productionLeadDays * 86400_000);
    const cooldown = new Date(Date.now() - 2 * 3600_000);
    const posts = await db.post.findMany({
      where: {
        brandId: s.brandId,
        status: "PLANNED",
        scheduledAt: { gt: new Date(), lte: until },
        OR: [{ generationError: null }, { updatedAt: { lt: cooldown } }],
      },
      orderBy: { scheduledAt: "asc" },
      take: s.maxGenerationsPerRun,
    });
    let pending = 0;
    let scheduled = 0;
    for (const p of posts) {
      try {
        const r = await producePost(p.id, { actor: "autopilot" });
        if (r.status === "SCHEDULED") scheduled++;
        else pending++;
      } catch (e) {
        const msg = e instanceof Error ? e.message : String(e);
        console.error("[autopilot] produção falhou", p.id, msg);
        if (e instanceof MissingCredentialError) {
          await notify({ orgId: s.brand.orgId, brandId: s.brandId, level: "WARNING", title: "Piloto automático sem credenciais", body: msg, link: "/settings/integrations" });
          break;
        }
      }
    }
    if (pending) {
      await notify({
        orgId: s.brand.orgId,
        brandId: s.brandId,
        level: "WARNING",
        title: `${pending} publicação(ões) aguardando aprovação`,
        body: "Revise e aprove para manter o calendário em dia.",
        link: "/posts?status=PENDING_APPROVAL",
      });
    }
    out.push(`${s.brand.name}: ${scheduled} agendadas, ${pending} p/ aprovação`);
  }
  return out.join("; ") || "nada a produzir";
}

/** Alerta publicações aguardando aprovação cujo horário está próximo/passou. */
export async function approvalReminders() {
  const soon = new Date(Date.now() + 3 * 3600_000);
  const rows = await db.post.groupBy({
    by: ["orgId", "brandId"],
    where: { status: "PENDING_APPROVAL", scheduledAt: { lte: soon } },
    _count: true,
  });
  for (const r of rows) {
    await notify({ orgId: r.orgId, brandId: r.brandId, level: "WARNING", title: `${r._count} publicação(ões) precisam de aprovação nas próximas 3h`, link: "/posts?status=PENDING_APPROVAL" });
  }
}
