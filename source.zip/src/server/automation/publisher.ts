// Fila de publicação confiável baseada no banco:
// - claims atômicos (updateMany com condição de status) evitam publicação duplicada entre workers;
// - cada tentativa é registrada; erros transitórios têm novas tentativas com backoff;
// - resultados incertos são reconciliados consultando a própria Meta antes de republicar.
import type { Network, PostTarget } from "@prisma/client";
import { db } from "@/lib/db";
import { decrypt } from "@/lib/crypto";
import { signedMediaUrl } from "@/server/storage";
import { GraphError } from "@/server/meta/graph";
import { fbReconcile, igPublishingQuota, igReconcile, publishFacebook, publishInstagram, type PublishInput } from "@/server/meta/publish";
import { notify } from "@/server/notifications";
import { isOfferValid } from "@/server/guard";

const MAX_ATTEMPTS = 4;
const backoffMs = (attempt: number) => Math.min(60, 2 ** attempt * 2) * 60_000; // 4, 8, 16... min

/** Move publicações vencidas (SCHEDULED e aprovadas) para a fila. */
export async function enqueueDuePosts() {
  const now = new Date();
  const due = await db.post.findMany({
    where: { status: "SCHEDULED", scheduledAt: { lte: now }, approvedAt: { not: null } },
    include: { offer: true, brand: { include: { automation: true } } },
    take: 50,
  });
  let queued = 0;
  for (const p of due) {
    // Pausa de automação respeitada apenas para itens gerados pela IA
    const paused = p.brand.automation?.pausedUntil && p.brand.automation.pausedUntil > now;
    if (paused && p.origin === "AI") continue;
    if (p.offerId && (!p.offer || !isOfferValid(p.offer, now))) {
      await db.post.update({ where: { id: p.id }, data: { status: "PENDING_APPROVAL", approvalReasons: ["Oferta vencida ou não aprovada no momento da publicação."] } });
      await notify({ orgId: p.orgId, brandId: p.brandId, level: "WARNING", title: "Publicação de oferta bloqueada", body: `"${p.title}" não foi publicada: a oferta não está válida.`, link: `/posts/${p.id}` });
      continue;
    }
    const claimed = await db.post.updateMany({ where: { id: p.id, status: "SCHEDULED" }, data: { status: "PUBLISHING" } });
    if (!claimed.count) continue;
    await db.postTarget.updateMany({ where: { postId: p.id, status: "PENDING" }, data: { status: "QUEUED", nextRetryAt: now } });
    queued++;
  }
  return queued;
}

async function accountFor(brandId: string, network: Network, current: string | null) {
  if (current) {
    const a = await db.socialAccount.findUnique({ where: { id: current } });
    if (a && a.status === "ACTIVE") return a;
  }
  return db.socialAccount.findFirst({ where: { brandId, network, status: "ACTIVE" }, orderBy: { createdAt: "asc" } });
}

async function buildInput(target: PostTarget & { post: { id: string; format: any } }): Promise<PublishInput> {
  const media = await db.postMedia.findMany({ where: { postId: target.postId }, include: { asset: true }, orderBy: { position: "asc" } });
  const ttl = 60 * 60 * 6;
  const slides = media.filter((m) => m.purpose === "SLIDE");
  const composed = media.filter((m) => m.purpose === "COMPOSED");
  const video = media.find((m) => m.purpose === "VIDEO");
  const cover = media.find((m) => m.purpose === "COVER");
  const format = target.post.format as PublishInput["format"];
  let items: PublishInput["media"] = [];
  if (format === "CAROUSEL") items = slides.map((m) => ({ kind: "IMAGE" as const, url: signedMediaUrl(m.asset.storageKey, ttl) }));
  else if (format === "REEL") items = video ? [{ kind: "VIDEO", url: signedMediaUrl(video.asset.storageKey, ttl) }] : [];
  else items = composed.slice(0, 1).map((m) => ({ kind: "IMAGE" as const, url: signedMediaUrl(m.asset.storageKey, ttl) }));
  if (!items.length) throw new GraphError("Publicação sem mídia final.", 400);
  return { format, caption: target.caption ?? "", media: items, coverUrl: cover ? signedMediaUrl(cover.asset.storageKey, ttl) : undefined, existingContainerId: target.externalContainerId };
}

export async function processTarget(targetId: string) {
  // Claim atômico
  const claimed = await db.postTarget.updateMany({
    where: { id: targetId, status: "QUEUED", externalId: null },
    data: { status: "PUBLISHING", attempts: { increment: 1 } },
  });
  if (!claimed.count) return;
  const target = await db.postTarget.findUniqueOrThrow({ where: { id: targetId }, include: { post: true } });
  const attempt = await db.publishAttempt.create({ data: { targetId } });
  const post = target.post;

  const finish = async (ok: boolean, data: Partial<PostTarget>, err?: { code?: string; message: string; detail?: unknown }) => {
    await db.postTarget.update({ where: { id: targetId }, data });
    await db.publishAttempt.update({
      where: { id: attempt.id },
      data: { finishedAt: new Date(), success: ok, errorCode: err?.code, errorMessage: err?.message, detail: (err?.detail as any) ?? undefined },
    });
    await settlePost(post.id);
  };

  try {
    const account = await accountFor(post.brandId, target.network, target.socialAccountId);
    if (!account) throw new GraphError(`Nenhuma conta ${target.network === "INSTAGRAM" ? "do Instagram" : "do Facebook"} conectada e ativa para esta marca.`, 400, 190);
    const token = decrypt(account.accessTokenEnc);

    // Reconciliação antes de nova tentativa (evita duplicidade após timeout)
    if (target.attempts > 0 || target.externalContainerId) {
      const rec =
        target.network === "INSTAGRAM"
          ? target.externalContainerId
            ? await igReconcile(account.externalId, token, target.externalContainerId, target.caption ?? "")
            : null
          : await fbReconcile(account.externalId, token, target.caption ?? "", new Date(Date.now() - 2 * 86400_000));
      if (rec) {
        await finish(true, { status: "PUBLISHED", externalId: rec.externalId, permalink: rec.permalink, publishedAt: new Date(), socialAccountId: account.id, lastError: null }, { message: "Reconciliado: já estava publicado." });
        return;
      }
    }

    if (target.network === "INSTAGRAM") {
      const quota = await igPublishingQuota(account.externalId, token);
      if (quota && quota.used >= quota.total) {
        await finish(false, { status: "QUEUED", nextRetryAt: new Date(Date.now() + 60 * 60_000), lastError: "Limite de publicações da API atingido (24h). Nova tentativa em 1h." }, { code: "QUOTA", message: "Limite de publicação atingido" });
        return;
      }
    }

    const input = await buildInput(target);
    const res = target.network === "INSTAGRAM" ? await publishInstagram(account.externalId, token, input) : await publishFacebook(account.externalId, token, input);

    if (res.status === "processing") {
      // Vídeo ainda processando: volta para a fila com o container salvo (não recria)
      await finish(false, { status: "QUEUED", externalContainerId: res.containerId, nextRetryAt: new Date(Date.now() + 2 * 60_000), socialAccountId: account.id, lastError: "Vídeo em processamento pela Meta." }, { code: "PROCESSING", message: "Container em processamento" });
      return;
    }
    await finish(true, {
      status: "PUBLISHED",
      externalId: res.externalId,
      externalContainerId: res.containerId ?? target.externalContainerId,
      permalink: res.permalink,
      publishedAt: new Date(),
      socialAccountId: account.id,
      lastError: null,
      nextRetryAt: null,
    });
  } catch (e) {
    const ge = e instanceof GraphError ? e : null;
    const message = e instanceof Error ? e.message : String(e);
    const retryable = ge ? ge.retryable : true;
    const attempts = target.attempts; // já incrementado no claim
    const willRetry = retryable && attempts < MAX_ATTEMPTS;
    if (ge?.authError) {
      await db.socialAccount.updateMany({ where: { brandId: post.brandId, network: target.network, status: "ACTIVE" }, data: { status: "ERROR", lastError: message } });
    }
    await finish(
      false,
      { status: willRetry ? "QUEUED" : "FAILED", nextRetryAt: willRetry ? new Date(Date.now() + backoffMs(attempts)) : null, lastError: message },
      { code: ge ? `${ge.code ?? ge.status}${ge.subcode ? `/${ge.subcode}` : ""}` : "ERR", message, detail: ge ? { status: ge.status, type: ge.type, fbtrace: ge.fbtraceId } : undefined },
    );
    if (!willRetry) {
      await notify({
        orgId: post.orgId,
        brandId: post.brandId,
        level: "ERROR",
        title: `Falha ao publicar no ${target.network === "INSTAGRAM" ? "Instagram" : "Facebook"}`,
        body: `"${post.title ?? post.theme}": ${message}`,
        link: `/posts/${post.id}`,
      });
    }
  }
}

/** Consolida o status da publicação a partir dos destinos. */
export async function settlePost(postId: string) {
  const targets = await db.postTarget.findMany({ where: { postId } });
  const active = targets.filter((t) => !["CANCELED", "SKIPPED"].includes(t.status));
  if (!active.length) return;
  if (active.some((t) => ["QUEUED", "PUBLISHING"].includes(t.status))) return;
  const published = active.filter((t) => t.status === "PUBLISHED").length;
  const status = published === active.length ? "PUBLISHED" : published > 0 ? "PARTIALLY_PUBLISHED" : "FAILED";
  await db.post.update({ where: { id: postId }, data: { status } });
}

/** Processa destinos na fila cujo horário de tentativa chegou. */
export async function processQueue(limit = 10) {
  const now = new Date();
  // Recupera destinos presos em PUBLISHING (worker reiniciado no meio)
  await db.postTarget.updateMany({
    where: { status: "PUBLISHING", updatedAt: { lt: new Date(now.getTime() - 15 * 60_000) } },
    data: { status: "QUEUED", nextRetryAt: now, lastError: "Tentativa interrompida; será reconciliada antes de repetir." },
  });
  const ready = await db.postTarget.findMany({
    where: { status: "QUEUED", OR: [{ nextRetryAt: null }, { nextRetryAt: { lte: now } }] },
    orderBy: { nextRetryAt: "asc" },
    take: limit,
    select: { id: true },
  });
  for (const t of ready) await processTarget(t.id);
  return ready.length;
}
