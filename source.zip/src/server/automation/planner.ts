// Mantém sempre N dias (padrão 30) de calendário planejado por marca.
import { db } from "@/lib/db";
import { buildSlots, bestHourFromHistory, rebalancePillars, type PlannerSettings } from "@/server/planner-core";
import { planThemes } from "@/server/ai/agent";
import { getBrandContext, validOffers } from "@/server/brand";
import { seasonalInRange } from "@/server/ai/seasonal";
import { localDateKey, zonedParts } from "@/lib/time";
import { getSecret } from "@/server/integrations";

export async function ensureCalendar(brandId: string, opts: { maxNew?: number } = {}) {
  const brand = await db.brand.findUniqueOrThrow({ where: { id: brandId } });
  const s = await db.automationSettings.findUniqueOrThrow({ where: { brandId } });
  const now = new Date();
  const horizonEnd = new Date(now.getTime() + s.planningHorizonDays * 86400_000);

  const [offers, videoCount] = await Promise.all([
    validOffers(brandId, now),
    db.mediaAsset.count({ where: { brandId, kind: "VIDEO", isApproved: true, postMedia: { none: {} } } }),
  ]);

  // Ajuste de horário do feed com base no histórico (quando houver amostra suficiente)
  const feedTimes = [...s.feedTimes];
  let timeReason = "Horário padrão configurado (dados históricos insuficientes).";
  const history = await db.metricSnapshot.findMany({
    where: { target: { post: { brandId, format: { in: ["FEED_IMAGE", "CAROUSEL"] } }, status: "PUBLISHED" } },
    orderBy: { collectedAt: "desc" },
    take: 400,
    include: { target: { select: { id: true, publishedAt: true } } },
  });
  const latestByTarget = new Map<string, (typeof history)[number]>();
  for (const h of history) if (!latestByTarget.has(h.targetId)) latestByTarget.set(h.targetId, h);
  const best = bestHourFromHistory(
    [...latestByTarget.values()]
      .filter((h) => h.target.publishedAt)
      .map((h) => ({ hour: zonedParts(h.target.publishedAt!, brand.timezone).hour, interactions: h.interactions ?? 0, views: h.views ?? 0 })),
  );
  if (best && feedTimes.length === 1) {
    feedTimes[0] = `${String(best.hour).padStart(2, "0")}:00`;
    timeReason = best.reason;
  }

  const settings: PlannerSettings = {
    timezone: brand.timezone,
    horizonDays: s.planningHorizonDays,
    igFeedPerDay: s.igFeedPerDay,
    fbFeedPerDay: s.fbFeedPerDay,
    storiesPerDay: s.storiesPerDay,
    reelsPerWeek: s.reelsPerWeek,
    carouselsPerWeek: s.carouselsPerWeek,
    storiesToFacebook: s.storiesToFacebook,
    feedTimes,
    fbOnlyTimes: s.fbOnlyTimes,
    storyTimes: s.storyTimes,
    reelTimes: s.reelTimes,
    reelWeekdays: s.reelWeekdays,
    pillarWeights: (s.pillarWeights ?? {}) as PlannerSettings["pillarWeights"],
    hasValidOffers: offers.length > 0,
    // Reels entram no calendário se houver vídeo na biblioteca OU se a IA de vídeo da persona estiver pronta
    hasReelVideos: videoCount > 0 || (s.videoEnabled && s.videoAutoForReels && !!(await getSecret(brand.orgId, "MINIMAX_API_KEY")) && (await db.mediaAsset.count({ where: { brandId, role: "CHARACTER_REFERENCE" } })) > 0),
    personaEnabled: brand.personaEnabled && !!brand.personaBible,
  };

  const slots = buildSlots(now, settings);
  const existing = await db.post.findMany({
    where: { brandId, scheduledAt: { gte: new Date(now.getTime() - 14 * 86400_000), lte: horizonEnd }, status: { not: "CANCELED" } },
    select: { scheduledAt: true, format: true, pillar: true },
  });
  // Deduplicação por dia e grupo de formato (robusta a mudanças de horário)
  const group = (f: string) => (f === "CAROUSEL" || f === "FEED_IMAGE" ? "FEED" : f);
  const taken = new Map<string, number>();
  for (const p of existing) {
    const k = `${localDateKey(p.scheduledAt!, brand.timezone)}|${group(p.format)}`;
    taken.set(k, (taken.get(k) ?? 0) + 1);
  }
  const rawMissing = slots
    .filter((sl) => {
      const k = `${sl.dateKey}|${group(sl.format)}`;
      const n = taken.get(k) ?? 0;
      if (n > 0) {
        taken.set(k, n - 1);
        return false;
      }
      return true;
    })
    .slice(0, opts.maxNew ?? 150);
  // Mantém a distribuição de pilares considerando o que já existe (renovação diária contínua)
  const missing = rebalancePillars(
    rawMissing,
    existing.map((p) => ({ pillar: p.pillar, kind: p.format === "STORY" ? ("story" as const) : ("other" as const) })),
    settings.pillarWeights,
    settings.hasValidOffers,
    settings.personaEnabled,
  );
  if (!missing.length) return { created: 0 };

  const ctx = await getBrandContext(brand);
  const recent = await db.post.findMany({ where: { brandId, createdAt: { gte: new Date(now.getTime() - 120 * 86400_000) } }, select: { theme: true }, take: 200, orderBy: { createdAt: "desc" } });
  const seasonal = seasonalInRange(now, horizonEnd);

  let created = 0;
  const BATCH = 40;
  for (let i = 0; i < missing.length; i += BATCH) {
    const chunk = missing.slice(i, i + BATCH);
    const themes = await planThemes(
      brand.orgId,
      ctx,
      chunk.map((sl, idx) => ({ index: idx, date: sl.dateKey, pillar: sl.pillar, format: sl.format })),
      recent.map((r) => r.theme),
      seasonal,
    );
    const byIdx = new Map(themes.map((t) => [t.index, t]));
    for (let k = 0; k < chunk.length; k++) {
      const sl = chunk[k];
      const t = byIdx.get(k);
      if (!t) continue;
      const offerId = sl.pillar === "OFFERS" ? offers.find((o) => o.validUntil >= sl.scheduledAt)?.id ?? null : null;
      if (sl.pillar === "OFFERS" && !offerId) continue; // nunca planejar oferta sem oferta válida na data
      await db.post.create({
        data: {
          orgId: brand.orgId,
          brandId,
          pillar: sl.pillar,
          format: sl.format,
          theme: t.theme,
          objective: t.objective,
          scheduledAt: sl.scheduledAt,
          timeReason: sl.kind === "feed" ? timeReason : "Horário padrão configurado.",
          offerId,
          origin: "AI",
          status: "PLANNED",
          targets: { create: sl.networks.map((network) => ({ network })) },
        },
      });
      recent.unshift({ theme: t.theme });
      created++;
    }
  }
  return { created };
}

