import { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { env } from "@/lib/env";
import { decrypt, encrypt } from "@/lib/crypto";
import { debugToken, metaConfigured } from "@/server/meta/oauth";
import { graph, GraphError, isInstagramLoginToken } from "@/server/meta/graph";
import { igRefreshToken } from "@/server/instagram/oauth";
import { notify } from "@/server/notifications";

/** Verifica validade dos tokens das contas conectadas e alerta antes de expirar. */
export async function checkTokens() {
  const accounts = await db.socialAccount.findMany({ where: { status: { in: ["ACTIVE", "ERROR"] } } });
  for (const a of accounts) {
    try {
      const token = decrypt(a.accessTokenEnc);
      if (isInstagramLoginToken(token)) {
        await checkInstagramLoginAccount(a, token);
        continue;
      }
      if (!metaConfigured()) continue;
      const info = await debugToken(token);
      const expiresAt = info.expires_at ? new Date(info.expires_at * 1000) : null;
      if (!info.is_valid) {
        await db.socialAccount.update({ where: { id: a.id }, data: { status: "EXPIRED", lastCheckedAt: new Date(), lastError: info.error?.message ?? "Token inválido" } });
        await notify({ orgId: a.orgId, brandId: a.brandId, level: "ERROR", title: `Reconecte ${a.name}`, body: "O acesso à conta expirou ou foi revogado. As publicações para esta conta estão pausadas.", link: "/settings/accounts" });
        continue;
      }
      // Teste leve de leitura
      await graph(a.externalId, { token, params: { fields: "id" } });
      await db.socialAccount.update({ where: { id: a.id }, data: { status: "ACTIVE", lastCheckedAt: new Date(), tokenExpiresAt: expiresAt, scopes: info.scopes ?? a.scopes, lastError: null } });
      if (expiresAt && expiresAt.getTime() - Date.now() < 7 * 86400_000) {
        await notify({ orgId: a.orgId, brandId: a.brandId, level: "WARNING", title: `Acesso de ${a.name} expira em breve`, body: "Reconecte a conta para evitar interrupções.", link: "/settings/accounts" });
      }
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      const auth = e instanceof GraphError && e.authError;
      await db.socialAccount.update({ where: { id: a.id }, data: { status: auth ? "ERROR" : a.status, lastCheckedAt: new Date(), lastError: msg } });
    }
  }
}

/** Conta conectada pelo Login do Instagram: renova o token (60 dias) quando faltar menos de 20 dias. */
async function checkInstagramLoginAccount(a: { id: string; orgId: string; brandId: string; name: string; externalId: string; tokenExpiresAt: Date | null }, token: string) {
  let current = token;
  let expiresAt = a.tokenExpiresAt;
  if (!expiresAt || expiresAt.getTime() - Date.now() < 20 * 86400_000) {
    try {
      const r = await igRefreshToken(token);
      current = r.token;
      expiresAt = r.expiresAt;
    } catch (e) {
      if (expiresAt && expiresAt.getTime() < Date.now()) {
        await db.socialAccount.update({ where: { id: a.id }, data: { status: "EXPIRED", lastCheckedAt: new Date(), lastError: e instanceof Error ? e.message : "Token vencido" } });
        await notify({ orgId: a.orgId, brandId: a.brandId, level: "ERROR", title: `Reconecte ${a.name}`, body: "O acesso ao Instagram expirou. Clique em Reconectar Instagram.", link: "/settings/accounts" });
        return;
      }
    }
  }
  await graph(a.externalId, { token: current, params: { fields: "id" } });
  await db.socialAccount.update({
    where: { id: a.id },
    data: { status: "ACTIVE", lastCheckedAt: new Date(), lastError: null, tokenExpiresAt: expiresAt, ...(current !== token ? { accessTokenEnc: encrypt(current) } : {}) },
  });
}

/** Política de retenção (LGPD): remove dados operacionais antigos. */
export async function applyRetention() {
  const days = env.retentionDays;
  const cutoff = new Date(Date.now() - days * 86400_000);
  const r1 = await db.linkClick.deleteMany({ where: { createdAt: { lt: cutoff } } });
  const r2 = await db.notification.deleteMany({ where: { createdAt: { lt: new Date(Date.now() - 90 * 86400_000) }, readAt: { not: null } } });
  const r3 = await db.oAuthPending.deleteMany({ where: { expiresAt: { lt: new Date() } } });
  const r4 = await db.publishAttempt.updateMany({ where: { startedAt: { lt: new Date(Date.now() - 180 * 86400_000) } }, data: { detail: Prisma.DbNull } });
  const r5 = await db.auditLog.deleteMany({ where: { createdAt: { lt: new Date(Date.now() - 2 * 365 * 86400_000) } } });
  return { clicks: r1.count, notifications: r2.count, oauth: r3.count, attempts: r4.count, audit: r5.count };
}
