import type { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { decrypt } from "@/lib/crypto";
import { GraphError } from "@/server/meta/graph";
import { accountFollowers, facebookPostMetrics, instagramMediaMetrics } from "@/server/meta/insights";
import { analyzePerformance } from "@/server/ai/agent";
import { getBrandContext } from "@/server/brand";
import { PILLAR_LABEL, FORMAT_LABEL } from "@/lib/labels";
import { zonedParts } from "@/lib/time";
import { notify } from "@/server/notifications";

/** Coleta métricas das publicações dos últimos 30 dias (stories: somente nas primeiras 24h). */
export async function collectPostMetrics(limit = 200) {
  const since = new Date(Date.now() - 30 * 86400_000);
  const targets = await db.postTarget.findMany({
    where: { status: "PUBLISHED", externalId: { not: null }, publishedAt: { gte: since } },
    include: { post: true, socialAccount: true },
    orderBy: { publishedAt: "desc" },
    take: limit,
  });
  let ok = 0;
  for (const t of targets) {
    if (!t.socialAccount || t.socialAccount.status !== "ACTIVE") continue;
    if (t.post.format === "STORY" && t.publishedAt && Date.now() - t.publishedAt.getTime() > 26 * 3600_000) continue;
    try {
      const token = decrypt(t.socialAccount.accessTokenEnc);
      const m = t.network === "INSTAGRAM" ? await instagramMediaMetrics(t.externalId!, token, t.post.format) : await facebookPostMetrics(t.externalId!, token);
      const clicks = await db.linkClick.count({ where: { converted: false, link: { postId: t.postId, OR: [{ network: t.network }, { network: null }] } } });
      await db.metricSnapshot.create({
        data: {
          targetId: t.id,
          views: m.views,
          reach: m.reach,
          likes: m.likes,
          comments: m.comments,
          shares: m.shares,
          saves: m.saves,
          interactions: m.interactions,
          clicks: clicks || m.clicks,
          raw: m.raw as Prisma.InputJsonValue,
        },
      });
      ok++;
    } catch (e) {
      if (e instanceof GraphError && e.authError) {
        await db.socialAccount.update({ where: { id: t.socialAccount.id }, data: { status: "ERROR", lastError: e.message } });
      }
      console.warn("[metrics] falha em", t.id, e instanceof Error ? e.message : e);
    }
  }
  return ok;
}

export async function collectAccountMetrics() {
  const accounts = await db.socialAccount.findMany({ where: { status: "ACTIVE" } });
  const today = new Date(new Date().toISOString().slice(0, 10) + "T00:00:00Z");
  for (const a of accounts) {
    try {
      const r = await accountFollowers(a.network, a.externalId, decrypt(a.accessTokenEnc));
      await db.accountMetricSnapshot.upsert({
        where: { socialAccountId_date: { socialAccountId: a.id, date: today } },
        create: { socialAccountId: a.id, date: today, followers: r.followers, mediaCount: r.mediaCount, raw: r.raw as Prisma.InputJsonValue },
        update: { followers: r.followers, mediaCount: r.mediaCount, raw: r.raw as Prisma.InputJsonValue },
      });
    } catch (e) {
      console.warn("[metrics] conta", a.id, e instanceof Error ? e.message : e);
    }
  }
}

type Row = { pillar: string; format: string; network: string; hour: number; views: number; interactions: number; comments: number; clicks: number };

export async function performanceRows(brandId: string, since: Date): Promise<Row[]> {
  const brand = await db.brand.findUniqueOrThrow({ where: { id: brandId } });
  const targets = await db.postTarget.findMany({
    where: { post: { brandId }, status: "PUBLISHED", publishedAt: { gte: since } },
    include: { post: true, metrics: { orderBy: { collectedAt: "desc" }, take: 1 } },
  });
  return targets
    .filter((t) => t.metrics[0])
    .map((t) => {
      const m = t.metrics[0];
      return {
        pillar: t.post.pillar,
        format: t.post.format,
        network: t.network,
        hour: zonedParts(t.publishedAt!, brand.timezone).hour,
        views: m.views ?? 0,
        interactions: m.interactions ?? 0,
        comments: m.comments ?? 0,
        clicks: m.clicks ?? 0,
      };
    });
}

export function aggregate(rows: Row[], key: keyof Row) {
  const map = new Map<string, { n: number; views: number; interactions: number; comments: number; clicks: number }>();
  for (const r of rows) {
    const k = String(r[key]);
    const cur = map.get(k) ?? { n: 0, views: 0, interactions: 0, comments: 0, clicks: 0 };
    cur.n++;
    cur.views += r.views;
    cur.interactions += r.interactions;
    cur.comments += r.comments;
    cur.clicks += r.clicks;
    map.set(k, cur);
  }
  return [...map.entries()].map(([k, v]) => ({
    key: k,
    posts: v.n,
    views: v.views,
    interactions: v.interactions,
    comments: v.comments,
    clicks: v.clicks,
    engagementRate: v.views ? v.interactions / v.views : null, // interações ÷ visualizações
  }));
}

/** Análise semanal com IA → PerformanceInsight usado no próximo planejamento. */
export async function analyzeBrand(brandId: string) {
  const brand = await db.brand.findUniqueOrThrow({ where: { id: brandId } });
  const periodEnd = new Date();
  const periodStart = new Date(periodEnd.getTime() - 60 * 86400_000);
  const rows = await performanceRows(brandId, periodStart);
  if (rows.length < 5) return null;
  const label = (map: Record<string, string>) => (a: ReturnType<typeof aggregate>) => a.map((x) => ({ ...x, key: map[x.key] ?? x.key }));
  const data = {
    sample: rows.length,
    definition: "engagementRate = interações ÷ visualizações (views) por publicação, somadas no grupo",
    byPillar: label(PILLAR_LABEL)(aggregate(rows, "pillar")),
    byFormat: label(FORMAT_LABEL)(aggregate(rows, "format")),
    byHour: aggregate(rows, "hour"),
    byNetwork: aggregate(rows, "network"),
  };
  const ctx = await getBrandContext(brand);
  const res = await analyzePerformance(brand.orgId, { ...ctx, insight: null }, data);
  const saved = await db.performanceInsight.create({
    data: { brandId, periodStart, periodEnd, summary: res.summary, data: data as unknown as Prisma.InputJsonValue, recommendations: res.recommendations as unknown as Prisma.InputJsonValue },
  });
  await notify({ orgId: brand.orgId, brandId, level: "INFO", title: "Nova análise de desempenho disponível", link: "/reports" });
  return saved;
}
