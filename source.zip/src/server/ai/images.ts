// Geração de imagens (OpenAI Images API). O provedor é isolado aqui para permitir troca futura.
// A IA gera SOMENTE a fotografia/ilustração de fundo, sem textos: títulos, preços, CTA e logotipo
// são aplicados depois pelo motor de composição, garantindo ortografia e números corretos.
import { env } from "@/lib/env";
import { getSecret, MissingCredentialError } from "@/server/integrations";

export type ImageOrientation = "portrait" | "square" | "landscape";

const SIZE: Record<ImageOrientation, string> = { portrait: "1024x1536", square: "1024x1024", landscape: "1536x1024" };

export const NO_TEXT_SUFFIX =
  " Absolutely no text, letters, numbers, words, logos, watermarks or brand marks anywhere in the image. Leave clean negative space for later typography.";

export async function generateImage(opts: { orgId: string; prompt: string; orientation?: ImageOrientation }): Promise<{ buffer: Buffer; model: string; prompt: string }> {
  const apiKey = await getSecret(opts.orgId, "OPENAI_API_KEY");
  if (!apiKey) throw new MissingCredentialError("chave da OpenAI (OPENAI_API_KEY)");
  const model = env.ai.openaiImageModel;
  const prompt = opts.prompt.trim() + NO_TEXT_SUFFIX;

  let lastErr: unknown;
  for (let attempt = 0; attempt < 3; attempt++) {
    const res = await fetch("https://api.openai.com/v1/images/generations", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model,
        prompt,
        size: SIZE[opts.orientation ?? "portrait"],
        quality: env.ai.openaiImageQuality,
        n: 1,
        output_format: "jpeg",
      }),
      signal: AbortSignal.timeout(240_000),
    });
    if (res.ok) {
      const json: any = await res.json();
      const item = json.data?.[0];
      if (item?.b64_json) return { buffer: Buffer.from(item.b64_json, "base64"), model, prompt };
      if (item?.url) {
        const img = await fetch(item.url);
        return { buffer: Buffer.from(await img.arrayBuffer()), model, prompt };
      }
      throw new Error("Resposta de imagem vazia.");
    }
    const text = await res.text();
    lastErr = new Error(`OpenAI Images ${res.status}: ${text.slice(0, 400)}`);
    if (![429, 500, 502, 503].includes(res.status)) throw lastErr;
    await new Promise((r) => setTimeout(r, 3000 * 2 ** attempt));
  }
  throw lastErr;
}

/**
 * Gera uma cena usando imagens de referência (ex.: o personagem da marca), para manter
 * consistência visual entre episódios. Usa o endpoint de edição com múltiplas imagens de entrada.
 */
export async function generateWithReferences(opts: {
  orgId: string;
  prompt: string;
  references: { buffer: Buffer; mimeType: string; name: string }[];
  orientation?: ImageOrientation;
}): Promise<{ buffer: Buffer; model: string; prompt: string }> {
  if (!opts.references.length) return generateImage(opts);
  const apiKey = await getSecret(opts.orgId, "OPENAI_API_KEY");
  if (!apiKey) throw new MissingCredentialError("chave da OpenAI (OPENAI_API_KEY)");
  const model = env.ai.openaiImageModel;
  const prompt =
    opts.prompt.trim() +
    " Keep the recurring character exactly consistent with the reference images (face, hair, style, proportions). Use the references only for the character's identity; create a new scene." +
    NO_TEXT_SUFFIX;

  let lastErr: unknown;
  for (let attempt = 0; attempt < 3; attempt++) {
    const form = new FormData();
    form.set("model", model);
    form.set("prompt", prompt);
    form.set("size", SIZE[opts.orientation ?? "portrait"]);
    form.set("quality", env.ai.openaiImageQuality);
    form.set("n", "1");
    for (const r of opts.references.slice(0, 4)) {
      form.append("image[]", new Blob([new Uint8Array(r.buffer)], { type: r.mimeType }), r.name);
    }
    const res = await fetch("https://api.openai.com/v1/images/edits", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}` },
      body: form,
      signal: AbortSignal.timeout(300_000),
    });
    if (res.ok) {
      const json: any = await res.json();
      const item = json.data?.[0];
      if (item?.b64_json) return { buffer: Buffer.from(item.b64_json, "base64"), model, prompt };
      if (item?.url) return { buffer: Buffer.from(await (await fetch(item.url)).arrayBuffer()), model, prompt };
      throw new Error("Resposta de imagem vazia.");
    }
    const text = await res.text();
    lastErr = new Error(`OpenAI Images (edits) ${res.status}: ${text.slice(0, 400)}`);
    if (![429, 500, 502, 503].includes(res.status)) throw lastErr;
    await new Promise((r) => setTimeout(r, 3000 * 2 ** attempt));
  }
  throw lastErr;
}
