// Geração de imagens pela MiniMax (image-01). A OpenAI fica desligada; só é usada com IMAGE_PROVIDER=openai
// ou, como reserva, com IMAGE_FALLBACK=openai.
// A IA gera SOMENTE a fotografia/ilustração de fundo, sem textos: títulos, preços, CTA e logotipo
// são aplicados depois pelo motor de composição, garantindo ortografia e números corretos.
import { env } from "@/lib/env";
import { getSecret, MissingCredentialError } from "@/server/integrations";
import { minimaxHosts, rememberMinimaxHost, isMinimaxAuthError } from "@/server/video/minimax";

export type ImageOrientation = "portrait" | "square" | "landscape";

const SIZE: Record<ImageOrientation, string> = { portrait: "1024x1536", square: "1024x1024", landscape: "1536x1024" };

export const NO_TEXT_SUFFIX =
  " Absolutely no text, letters, numbers, words, logos, watermarks or brand marks anywhere in the image. Leave clean negative space for later typography.";

async function openaiGenerate(opts: { orgId: string; prompt: string; orientation?: ImageOrientation }): Promise<{ buffer: Buffer; model: string; prompt: string }> {
  const apiKey = await getSecret(opts.orgId, "OPENAI_API_KEY");
  if (!apiKey) throw new MissingCredentialError("chave da OpenAI (OPENAI_API_KEY)");
  const model = env.ai.openaiImageModel;
  const prompt = opts.prompt.trim() + NO_TEXT_SUFFIX;

  let lastErr: unknown;
  for (let attempt = 0; attempt < 3; attempt++) {
    const res = await fetch("https://api.openai.com/v1/images/generations", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model,
        prompt,
        size: SIZE[opts.orientation ?? "portrait"],
        quality: env.ai.openaiImageQuality,
        n: 1,
        output_format: "jpeg",
      }),
      signal: AbortSignal.timeout(240_000),
    });
    if (res.ok) {
      const json: any = await res.json();
      const item = json.data?.[0];
      if (item?.b64_json) return { buffer: Buffer.from(item.b64_json, "base64"), model, prompt };
      if (item?.url) {
        const img = await fetch(item.url);
        return { buffer: Buffer.from(await img.arrayBuffer()), model, prompt };
      }
      throw new Error("Resposta de imagem vazia.");
    }
    const text = await res.text();
    lastErr = new Error(`OpenAI Images ${res.status}: ${text.slice(0, 400)}`);
    if (![429, 500, 502, 503].includes(res.status)) throw lastErr;
    await new Promise((r) => setTimeout(r, 3000 * 2 ** attempt));
  }
  throw lastErr;
}

/**
 * Gera uma cena usando imagens de referência (ex.: o personagem da marca), para manter
 * consistência visual entre episódios. Usa o endpoint de edição com múltiplas imagens de entrada.
 */
async function openaiWithReferences(opts: {
  orgId: string;
  prompt: string;
  references: { buffer: Buffer; mimeType: string; name: string }[];
  orientation?: ImageOrientation;
}): Promise<{ buffer: Buffer; model: string; prompt: string }> {
  if (!opts.references.length) return openaiGenerate(opts);
  const apiKey = await getSecret(opts.orgId, "OPENAI_API_KEY");
  if (!apiKey) throw new MissingCredentialError("chave da OpenAI (OPENAI_API_KEY)");
  const model = env.ai.openaiImageModel;
  const prompt =
    opts.prompt.trim() +
    " Keep the recurring character exactly consistent with the reference images (face, hair, style, proportions). Use the references only for the character's identity; create a new scene." +
    NO_TEXT_SUFFIX;

  let lastErr: unknown;
  for (let attempt = 0; attempt < 3; attempt++) {
    const form = new FormData();
    form.set("model", model);
    form.set("prompt", prompt);
    form.set("size", SIZE[opts.orientation ?? "portrait"]);
    form.set("quality", env.ai.openaiImageQuality);
    form.set("n", "1");
    for (const r of opts.references.slice(0, 4)) {
      form.append("image[]", new Blob([new Uint8Array(r.buffer)], { type: r.mimeType }), r.name);
    }
    const res = await fetch("https://api.openai.com/v1/images/edits", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}` },
      body: form,
      signal: AbortSignal.timeout(300_000),
    });
    if (res.ok) {
      const json: any = await res.json();
      const item = json.data?.[0];
      if (item?.b64_json) return { buffer: Buffer.from(item.b64_json, "base64"), model, prompt };
      if (item?.url) return { buffer: Buffer.from(await (await fetch(item.url)).arrayBuffer()), model, prompt };
      throw new Error("Resposta de imagem vazia.");
    }
    const text = await res.text();
    lastErr = new Error(`OpenAI Images (edits) ${res.status}: ${text.slice(0, 400)}`);
    if (![429, 500, 502, 503].includes(res.status)) throw lastErr;
    await new Promise((r) => setTimeout(r, 3000 * 2 ** attempt));
  }
  throw lastErr;
}

// ---------------- MiniMax (image-01) ----------------
const MINIMAX_IMAGE_MODEL = process.env.MINIMAX_IMAGE_MODEL || "image-01";
const MINIMAX_RATIO: Record<ImageOrientation, string> = { portrait: "3:4", square: "1:1", landscape: "4:3" };

async function minimaxImage(opts: {
  orgId: string;
  prompt: string;
  orientation?: ImageOrientation;
  reference?: { buffer: Buffer; mimeType: string } | null;
}): Promise<{ buffer: Buffer; model: string; prompt: string }> {
  const apiKey = await getSecret(opts.orgId, "MINIMAX_API_KEY");
  if (!apiKey) throw new MissingCredentialError("chave da MiniMax (MINIMAX_API_KEY)");
  // O limite do prompt na MiniMax é 1500 caracteres: preserva o sufixo "sem texto"
  const prompt = opts.prompt.trim().slice(0, 1500 - NO_TEXT_SUFFIX.length) + NO_TEXT_SUFFIX;
  const body: any = {
    model: MINIMAX_IMAGE_MODEL,
    prompt,
    aspect_ratio: MINIMAX_RATIO[opts.orientation ?? "portrait"],
    response_format: "base64",
    n: 1,
    prompt_optimizer: false,
  };
  if (opts.reference) {
    body.subject_reference = [{ type: "character", image_file: `data:${opts.reference.mimeType};base64,${opts.reference.buffer.toString("base64")}` }];
  }
  const key = apiKey.trim();
  let lastErr: unknown;
  for (const host of minimaxHosts()) {
    for (let attempt = 0; attempt < 3; attempt++) {
      const res = await fetch(`${host}/v1/image_generation`, {
        method: "POST",
        headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(240_000),
      });
      const text = await res.text();
      let j: any = null;
      try {
        j = JSON.parse(text);
      } catch {}
      const code = j?.base_resp?.status_code;
      const msg = String(j?.base_resp?.status_msg ?? text.slice(0, 300));
      if (res.ok && (code == null || code === 0)) {
        rememberMinimaxHost(host);
        const b64 = j?.data?.image_base64?.[0];
        if (b64) return { buffer: Buffer.from(String(b64), "base64"), model: MINIMAX_IMAGE_MODEL, prompt };
        const url = j?.data?.image_urls?.[0];
        if (url) return { buffer: Buffer.from(await (await fetch(url)).arrayBuffer()), model: MINIMAX_IMAGE_MODEL, prompt };
        throw new Error("MiniMax Images: resposta sem imagem.");
      }
      lastErr = new Error(`MiniMax Images ${res.status}: ${msg}`);
      if (isMinimaxAuthError(res.status, code, msg)) break; // tenta o outro endereço da MiniMax
      // 1002 = limite de requisições; 1000/1013 = erro interno (tentar de novo)
      const retry = [429, 500, 502, 503].includes(res.status) || [1000, 1002, 1013].includes(Number(code));
      if (!retry) throw lastErr;
      await new Promise((r) => setTimeout(r, 3000 * 2 ** attempt));
    }
  }
  throw lastErr;
}

// ---------------- Roteador de provedores ----------------
type Provider = "minimax" | "openai";

async function providerOrder(orgId: string): Promise<Provider[]> {
  // Padrão: somente MiniMax. OpenAI só entra se IMAGE_PROVIDER=openai ou se IMAGE_FALLBACK=openai.
  const pref: Provider = (process.env.IMAGE_PROVIDER || "minimax").toLowerCase() === "openai" ? "openai" : "minimax";
  const order: Provider[] = [pref];
  if (pref === "minimax" && (process.env.IMAGE_FALLBACK || "").toLowerCase() === "openai") order.push("openai");
  const available: Provider[] = [];
  for (const p of order) {
    const k = await getSecret(orgId, p === "minimax" ? "MINIMAX_API_KEY" : "OPENAI_API_KEY");
    if (k) available.push(p);
  }
  if (!available.length) throw new MissingCredentialError(pref === "minimax" ? "chave da MiniMax (MINIMAX_API_KEY)" : "chave da OpenAI (OPENAI_API_KEY)");
  return available;
}

async function withFallback<T>(orgId: string, run: (p: Provider) => Promise<T>): Promise<T> {
  const errors: string[] = [];
  for (const p of await providerOrder(orgId)) {
    try {
      return await run(p);
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      errors.push(msg);
      console.error(`[images] ${p} falhou: ${msg.slice(0, 300)}`);
    }
  }
  throw new Error(errors.join(" | "));
}

export async function generateImage(opts: { orgId: string; prompt: string; orientation?: ImageOrientation }): Promise<{ buffer: Buffer; model: string; prompt: string }> {
  return withFallback(opts.orgId, (p) => (p === "minimax" ? minimaxImage(opts) : openaiGenerate(opts)));
}

/**
 * Gera uma cena com o personagem da marca usando imagens de referência, para manter a aparência entre episódios.
 * MiniMax: usa a primeira referência como "subject_reference" (personagem). OpenAI: endpoint de edição com até 4 referências.
 */
export async function generateWithReferences(opts: {
  orgId: string;
  prompt: string;
  references: { buffer: Buffer; mimeType: string; name: string }[];
  orientation?: ImageOrientation;
}): Promise<{ buffer: Buffer; model: string; prompt: string }> {
  if (!opts.references.length) return generateImage(opts);
  return withFallback(opts.orgId, (p) =>
    p === "minimax"
      ? minimaxImage({
          ...opts,
          prompt: opts.prompt.trim() + " Keep the recurring character exactly consistent with the reference (face, hair, style, proportions); create a new scene.",
          reference: opts.references[0],
        })
      : openaiWithReferences(opts),
  );
}
