// Repertório criativo compartilhado pelo RADAR e pela SALA DE ROTEIRISTAS.
// Diretriz atual: conteúdo PRÁTICO e ÚTIL (dicas, tutoriais, truques, proteção, escolha de plano),
// com ganchos fortes e demonstração — utilidade primeiro, entretenimento como tempero.

/** Modelo usado nas tarefas criativas (radar e roteiros). Configurável; cai no modelo padrão se não existir. */
export const CREATIVE_MODEL = () => process.env.ANTHROPIC_CREATIVE_MODEL || process.env.ANTHROPIC_WRITER_MODEL || "claude-opus-5";

// O nome da constante foi mantido (é importada pelo Radar e pela Sala de Roteiristas).
export const BRIDGE_TOOLKIT = `
REPERTÓRIO DE GANCHOS E FORMATOS ÚTEIS (combine e varie; nunca repita o mesmo em sequência)
1. O PROBLEMA QUE TODO MUNDO TEM: "Seu celular vive dizendo que o armazenamento está cheio?" → a solução segura em passos.
2. O RECURSO ESCONDIDO: "Seu celular já faz isso e você não sabia" → onde fica, como ativar, para que serve.
3. O ERRO COMUM: "Pare de fazer isso com o seu roteador" → por que atrapalha e o que fazer no lugar.
4. MITO OU VERDADE: crença popular (Wi-Fi, bateria, 5G, velocidade, limpar o celular) → resposta correta e explicada.
5. ANTES × DEPOIS: o problema na tela e o resultado depois do passo a passo (sinal, espaço liberado, TV espelhando).
6. CHECKLIST: "3 coisas para conferir antes de culpar a operadora" / "antes de contratar internet".
7. ANDROID × IPHONE: o mesmo objetivo com os dois caminhos lado a lado (ou versões separadas).
8. TESTE NA HORA: como medir a velocidade, ver quem está no Wi-Fi, descobrir se o problema é o celular ou a internet.
9. PROTEÇÃO: o golpe que está circulando ou a configuração que protege o WhatsApp e as contas — sempre no ângulo de prevenção.
10. TRADUZINDO O TÉCNICO: velocidade, Mega, franquia, cobertura, fibra, 2,4 GHz × 5 GHz explicados com comparação do dia a dia.
11. PARA QUEM NÃO É DE TECNOLOGIA: "Mostre para seus pais/avós" — passo a passo bem simples, uma ação por vez.
12. PERGUNTA DO SEGUIDOR: responder uma dúvida frequente como se alguém tivesse perguntado nos comentários.

TESTE DE QUALIDADE (aplique a cada ideia antes de entregar)
- Teste da utilidade: depois de ver, a pessoa consegue FAZER algo novo ou entende algo que não entendia?
- Teste do salvamento: alguém salvaria para usar depois ou mandaria para um parente que precisa?
- Teste da precisão: os passos existem de verdade? Está claro para qual sistema/aparelho vale? Não promete o que não entrega (ex.: "libere espaço e a internet fica mais rápida" é PROIBIDO)?
- Teste da clareza: uma pessoa que não domina tecnologia acompanha sem travar? Uma ação por passo, nomes de menu reais.
- Teste do gancho: os 2 primeiros segundos/primeira linha mostram um problema real ou uma descoberta curiosa?
- Proibido: clickbait que não entrega, "truque secreto" falso, apps de limpeza/aceleradores, desativar segurança ou atualizações, "fique conectado", "velocidade para tudo", propaganda disfarçada de dica.

EXEMPLOS DE NÍVEL
- FRACO: "Dicas para melhorar sua internet! Contrate a fibra certa." (genérico, propaganda)
- FORTE: "O Wi-Fi não chega no quarto? Antes de trocar de plano, muda o roteador de lugar: alto, no centro da casa e longe do micro-ondas e de espelhos. Testa de novo — se continuar fraco, aí sim vale ver cobertura e equipamento." (problema real + passos + diagnóstico honesto + ligação natural com o negócio)
- FRACO: "Limpe seu celular e deixe a internet voando!" (promessa falsa)
- FORTE: "Celular sem espaço? Antes de sair apagando foto, veja o que realmente ocupa: no iPhone, Ajustes → Geral → Armazenamento do iPhone (dá para 'Desinstalar App' e manter os dados); no Android, Configurações → Armazenamento (o nome muda conforme a marca). E não: liberar espaço não aumenta a velocidade da internet — mas deixa o celular respirar." (descoberta + caminhos reais nos dois sistemas + expectativa honesta)
`;
