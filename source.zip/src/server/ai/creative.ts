// Repertório criativo compartilhado pelo RADAR e pela SALA DE ROTEIRISTAS.
// Objetivo: pontes surpreendentes e verdadeiras entre o assunto do momento e a vida conectada,
// fugindo do óbvio ("a internet caiu na hora H").

/** Modelo usado nas tarefas criativas (radar e roteiros). Configurável; cai no modelo padrão se não existir. */
export const CREATIVE_MODEL = () => process.env.ANTHROPIC_CREATIVE_MODEL || process.env.ANTHROPIC_WRITER_MODEL || "claude-opus-5";

export const BRIDGE_TOOLKIT = `
REPERTÓRIO DE PONTES (mecânicas criativas — combine, distorça, invente novas)
1. O DELAY: o vizinho gritou antes; o spoiler chegou pelo grupo antes da imagem; quem vê 8 segundos atrasado vive em outra realidade.
2. O OBJETO CONECTADO COMO PERSONAGEM: o roteador que tem opinião, o Wi-Fi com ciúme, o "carregando…" como vilão, a barrinha de sinal como termômetro emocional.
3. O RITUAL DIGITAL: o print antes de apagar, o "visto por último" estratégico, o áudio de 8 minutos, o "digitando…" que some, o modo avião como fuga.
4. O GRUPO DA FAMÍLIA / DO TRABALHO / DO CONDOMÍNIO: quem manda primeiro, quem manda fake, quem só reage com figurinha.
5. A SENHA DO WI-FI: moeda social, pedido de casamento, teste de amizade, visita que só vem pela senha.
6. O ALGORITMO: "o feed sabe", o vídeo que te encontrou, a bolha que decide o que é viral.
7. ESCALA ABSURDA: aplicar a lógica do assunto a algo doméstico e conectado (a final do reality × a disputa pelo controle da TV; o recorde mundial × o recorde de abas abertas).
8. A MÁQUINA DO TEMPO: como isso seria vivido em 2005 (discada, lan house, Orkut) × hoje.
9. INVERSÃO: o assunto contado do ponto de vista da conexão, do celular, do cabo, do sinal.
10. O CÚMPLICE INVISÍVEL: a conexão como a testemunha de tudo o que aconteceu naquela noite.
11. MICROCOMPORTAMENTO: o gesto que todo mundo faz e ninguém admite (erguer o celular pra pegar sinal, reiniciar o roteador "com fé", ficar perto da janela).
12. DETALHE LATERAL: em vez do fato principal, o detalhe curioso que as pessoas estão comentando nas redes.

TESTE DE QUALIDADE (aplique a cada ideia antes de entregar)
- Teste do bocejo: se qualquer marca de internet teria feito essa ponte, jogue fora.
- Teste da verdade: a situação é reconhecível? A pessoa pensa "sou eu".
- Teste da virada: existe um momento de surpresa ou uma frase citável?
- Teste do print: alguém mandaria isso no grupo?
- Proibido (clichês gastos): "a internet caiu na hora H" (só se tiver virada inédita), "fique conectado", "conexão que aproxima", "velocidade para tudo", trocadilhos óbvios com "rede", "sinal", "baixar".

EXEMPLOS DE NÍVEL
- FRACO: "Final do campeonato — assista sem travar com a nossa internet." (óbvio, propaganda)
- FORTE: "O gol aconteceu 3 vezes na sua rua: primeiro no grito do vizinho com fibra, depois no do vizinho com 4G, e por último na sua TV. Você foi o último a saber de algo que já tinha acontecido." (delay + microcomportamento + frase citável)
- FRACO: "Todo mundo comentando o show — compartilhe com seus amigos."
- FORTE: "O show acabou há 2 horas e o grupo da família ainda está mandando o mesmo vídeo tremido — 11 vezes, cada um de um ângulo pior." (ritual digital + escala absurda)
`;
