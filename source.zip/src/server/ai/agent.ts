// Agente editorial: gera seus próprios prompts internos a partir da identidade da marca,
// dos pilares, do histórico e das métricas — sem exigir instruções diárias do administrador.
import { z } from "zod";
import type { Brand, Offer, PerformanceInsight, Pillar, WhatsAppConfig } from "@prisma/client";
import { structured } from "./anthropic";
import { PILLAR_LABEL, FORMAT_LABEL } from "@/lib/labels";
import { formatBRL } from "@/server/guard";
import { formatDate } from "@/lib/time";
import type { SeasonalDate } from "./seasonal";
import { ACCURACY_RULES, FUNNEL_GUIDE, PRIORITY_THEMES, strategyText } from "./strategy";
import { FUNNEL_LABEL } from "@/lib/labels";

export const LAYOUTS = ["hero-bottom", "split-panel", "question-card", "offer", "carousel", "story"] as const;

export type BrandContext = {
  brand: Brand;
  whatsapp: WhatsAppConfig | null;
  insight: PerformanceInsight | null;
  /** Resumos dos episódios anteriores (continuidade da série do personagem). */
  seriesMemory?: { episode: number; summary: string }[];
  /** Pautas verificadas cadastradas pelo administrador (únicos "acontecimentos" que a IA pode citar). */
  trends?: string[];
  /** Há imagens oficiais de referência do personagem? */
  hasCharacterRefs?: boolean;
  /** Aprendizados vindos da IA de tráfego (anúncios pagos). */
  adLearnings?: string | null;
};

const ALL_PILLARS = ["EDUCATION", "ENGAGEMENT", "AUTHORITY", "OFFERS", "INSTITUTIONAL", "SEASONAL", "STORYTELLING"] as const;

export function personaActive(ctx: BrandContext) {
  return !!(ctx.brand.personaEnabled && ctx.brand.personaBible);
}

const PILLAR_GUIDE: Record<string, string> = {
  EDUCATION:
    "Dica prática / tutorial: resolver um problema comum ou ensinar uma funcionalidade útil (celular, Wi-Fi, TV, apps, conexão), com passos curtos, nomes de menus reais e diferença entre Android e iPhone (ou marcas de TV) quando houver. É o pilar principal do perfil.",
  ENGAGEMENT:
    "Participação autêntica em torno de tecnologia do dia a dia: enquete, quiz, mito ou verdade, 'qual é a sua maior dúvida com o celular/Wi-Fi?', pedido de sugestão para a próxima dica. Nunca pedir curtidas/compartilhamentos de forma artificial.",
  AUTHORITY:
    "Explicar com simplicidade o que as pessoas não entendem sobre conexão: velocidade, Mega, cobertura, franquia, fibra óptica, Wi-Fi 2,4 × 5 GHz, roteador, fatores que afetam a internet dentro de casa e como escolher o plano certo para a família. Mostrar que a marca entende e compara de forma imparcial.",
  OFFERS: "Apresentar SOMENTE a oferta cadastrada fornecida, sem inventar nada. Cobertura depende do endereço.",
  INSTITUTIONAL:
    "Mostrar como a Conecta Aqui ajuda: um buscador que compara planos e operadoras disponíveis no endereço da pessoa e orienta a escolha. Tom útil, sem propaganda agressiva.",
  SEASONAL:
    "Dica útil ligada à data ou ao momento (viagem: economizar dados; Black Friday: comprar celular/TV com segurança; volta às aulas: Wi-Fi para estudar; jogos e finais: assistir na TV sem travar). Nunca inventar notícias.",
  STORYTELLING:
    "Dica apresentada pelo personagem da marca: uma situação cotidiana curta e bem-humorada (o celular sem espaço, a TV que não espelha, o parente pedindo a senha do Wi-Fi) que leva a uma solução prática e correta. A utilidade é o centro; o humor é o tempero. Nunca parecer anúncio.",
};

function personaBlock(ctx: BrandContext) {
  const b = ctx.brand;
  const name = b.personaName?.trim() || "o personagem";
  return [
    `PERSONAGEM DA MARCA — ${name}${b.seriesTitle ? ` (série "${b.seriesTitle}")` : ""}. Bíblia do personagem (siga à risca):`,
    b.personaBible!.slice(0, 8000),
    b.personaVisual && `Aparência do personagem: ${b.personaVisual}`,
    `PAPEL DO PERSONAGEM NA DIRETRIZ ATUAL (prevalece sobre a bíblia): ele é o APRESENTADOR das dicas práticas — o amigo esperto que "já sabia" o truque e mostra como fazer. A personalidade dele (observador, irônico, teatral) dá o tom, mas o conteúdo é útil, correto e demonstrável. Mistério e mini-novela só como abertura curta para chegar à dica.`,
    `Regras: inteligente sem parecer professoral, sarcástico sem ser cruel; as informações técnicas precisam estar corretas.`,
    `Cuidados: o humor nunca é sobre a sexualidade dele nem sobre estereótipos de grupos; nunca ridicularize pessoas reais identificáveis nem exponha pessoas privadas; nada de conteúdo ofensivo, discriminatório ou difamatório. Referências de cinema (Tarantino, Hitchcock, Agatha Christie etc.) são inspiração estrutural, nunca citação, cópia de cenas, falas ou personagens.`,
    ctx.seriesMemory?.length
      ? `Dicas já apresentadas pelo personagem (não repita a mesma dica nem a mesma situação; pode retomar bordões e personagens secundários): ${ctx.seriesMemory.map((e) => `Ep.${e.episode}: ${e.summary}`).join(" | ")}`
      : `Primeiras dicas do personagem: apresente-o pela ação (mostrando o truque), não por descrição.`,
  ]
    .filter(Boolean)
    .join("\n");
}

export function brandSystemPrompt(ctx: BrandContext): string {
  const b = ctx.brand;
  const colors = b.colors as Record<string, string>;
  return [
    `Você é o estrategista de conteúdo e social media sênior da marca "${b.name}" para Instagram e Facebook no Brasil — um perfil de DICAS PRÁTICAS de tecnologia e conectividade para o público geral (inclusive quem não domina tecnologia), no estilo de canais como Jornada Top, TechTudo e Canaltech, sem copiar ninguém.`,
    `Escreva sempre em português do Brasil, com ortografia impecável.`,
    b.description && `Sobre a marca: ${b.description}`,
    b.positioning && `Posicionamento: ${b.positioning}`,
    b.slogan && `Slogan: ${b.slogan}`,
    b.targetAudience && `Público: ${b.targetAudience}`,
    b.toneOfVoice && `Tom de voz: ${b.toneOfVoice}`,
    b.communicationPillars.length && `Pilares de comunicação: ${b.communicationPillars.join("; ")}.`,
    b.visualGuidelines && `Diretrizes visuais: ${b.visualGuidelines}`,
    colors && `Cores da marca: ${Object.entries(colors).map(([k, v]) => `${k} ${v}`).join(", ")}.`,
    b.forbiddenTerms.length && `Nunca use estes termos: ${b.forbiddenTerms.join(", ")}.`,
    ctx.whatsapp?.ctaText && `CTA padrão para WhatsApp: "${ctx.whatsapp.ctaText}"`,
    ctx.insight && `Aprendizados recentes de desempenho (correlações, não causas): ${ctx.insight.summary.slice(0, 1500)}`,
    ctx.adLearnings && `Aprendizados dos anúncios pagos (Meta Ads, enviados pelo gestor de tráfego; correlações, não causas): ${ctx.adLearnings.slice(0, 1500)}`,
    `ESTRATÉGIA EDITORIAL DA MARCA (siga em todo conteúdo; em conflito, as REGRAS INEGOCIÁVEIS abaixo prevalecem):\n${strategyText(b.contentStrategy)}`,
    personaActive(ctx) && personaBlock(ctx),
    ctx.trends?.length
      ? `PAUTAS VERIFICADAS PELO ADMINISTRADOR (únicos acontecimentos reais que você pode citar): ${ctx.trends.join(" | ")}`
      : `Não há pautas de acontecimentos reais verificadas: trabalhe com dicas e dúvidas atemporais (os temas prioritários), sem citar notícias, lançamentos, virais ou pessoas reais específicas.`,
    ACCURACY_RULES,
    `REGRAS INEGOCIÁVEIS:`,
    `- Nunca invente preços, velocidades comerciais, benefícios, prazos, promoções, disponibilidade ou condições. Só use dados de oferta explicitamente fornecidos.`,
    `- Quando a cobertura depender do endereço, use "Consulte a disponibilidade para seu endereço."`,
    `- Não cite notícias, estatísticas ou pesquisas específicas que não foram fornecidas.`,
    `- Não mencione nomes de outras marcas da empresa; cada marca tem identidade própria.`,
    `- Textos de arte curtos e impactantes; legendas claras, escaneáveis, sem excesso de emojis (máx. 3).`,
    `- Prompts de imagem em inglês, fotográficos, SEM qualquer texto/letra/logo/interface legível na imagem (telas de celular e TV aparecem desfocadas, apagadas ou de ângulo); temas: mãos usando o celular, celular e Smart TV, roteador e Wi-Fi em casa, famílias brasileiras e pessoas de todas as idades usando tecnologia no dia a dia.`,
  ]
    .filter(Boolean)
    .join("\n");
}

// ───────────── Planejamento de temas ─────────────

const themesSchema = z.object({
  items: z.array(
    z.object({
      index: z.number().int(),
      theme: z.string().min(3),
      objective: z.string().min(3),
      angle: z.string().optional().default(""),
      hook: z.string().optional().default(""),
      central_idea: z.string().optional().default(""),
      cta: z.string().optional().default(""),
      note: z.string().optional().default(""),
    }),
  ),
});

export async function planThemes(
  orgId: string,
  ctx: BrandContext,
  slots: { index: number; date: string; pillar: string; format: string; funnel?: string | null }[],
  recentThemes: string[],
  seasonal: SeasonalDate[],
) {
  const prompt = [
    `Planeje as publicações abaixo como Head de Conteúdo. Cada item já tem data, função estratégica, pilar e formato definidos.`,
    `Base de temas (diretriz central — a maior parte do calendário sai daqui, com ângulos, aparelhos e situações variadas; um mesmo tema prioritário pode render vários posts diferentes, mas nunca em sequência): ${PRIORITY_THEMES.join("; ")}.`,
    `Todo tema começa por um problema real, uma dúvida frequente ou uma descoberta curiosa, e entrega algo que a pessoa consegue fazer ou entender. Não planeje conteúdo sobre inteligência artificial, marketing digital ou ferramentas para profissionais. Quando o passo a passo for diferente entre Android e iPhone (ou marcas de TV), indique na note se deve haver versões separadas.`,
    `Funções estratégicas (o PORQUÊ do post — é o que mais importa):`,
    ...Object.entries(FUNNEL_GUIDE).map(([k, v]) => `- ${FUNNEL_LABEL[k]}: ${v}`),
    `Para cada item entregue: theme (tema específico), objective (o resultado esperado, ligado à função), angle (o ângulo novo que torna o assunto interessante), hook (a primeira frase/primeiro segundo, curto e forte), central_idea (a ideia central em 1–2 frases), cta (chamada coerente com a função) e note (observação de produção: referência visual, cuidado, variação).`,
    `Nenhum item existe só para "manter frequência": se o tema não cumprir a função com clareza, troque o tema. Nunca coloque temas parecidos em sequência nem no mesmo dia; revisite assuntos estratégicos com ângulos novos.`,
    `Pilares (o assunto/universo do post):`,
    `Diretrizes por pilar:`,
    ...Object.entries(PILLAR_GUIDE).map(([k, v]) => `- ${PILLAR_LABEL[k]}: ${v}`),
    seasonal.length ? `Datas comemorativas no período (use no pilar Sazonal, na data ou até 3 dias antes): ${seasonal.map((s) => `${s.date} ${s.name} (${s.angle})`).join("; ")}.` : `Não há datas comemorativas no período; no pilar Sazonal use hábitos digitais e comportamento.`,
    `Evite repetir ou parafrasear estes temas recentes: ${recentThemes.slice(0, 80).join(" | ") || "(nenhum)"}.`,
    `Varie aparelhos (Android, iPhone, computador, Smart TV, roteador), ângulos e situações do dia a dia. Stories devem ser leves e interativos (enquete, quiz, "você sabia?").`,
    personaActive(ctx) &&
      `Itens do pilar "${PILLAR_LABEL.STORYTELLING}": o personagem apresenta uma dica prática a partir de uma situação cotidiana curta, ex.: "Por que a TV da sala não acha o celular?" → como espelhar no Android e no iPhone. A dica é o centro; a situação é o gancho.`,
    `Itens:`,
    ...slots.map((s) => `#${s.index} | ${s.date} | ${s.funnel ? FUNNEL_LABEL[s.funnel] : "livre"} | ${PILLAR_LABEL[s.pillar]} | ${FORMAT_LABEL[s.format]}`),
  ].filter(Boolean).join("\n");

  const { data } = await structured({
    orgId,
    system: brandSystemPrompt(ctx),
    prompt,
    toolName: "salvar_temas",
    toolDescription: "Salva o planejamento estratégico de cada item do calendário.",
    schema: {
      type: "object",
      properties: {
        items: {
          type: "array",
          items: {
            type: "object",
            properties: {
              index: { type: "integer" },
              theme: { type: "string", description: "Tema específico da publicação" },
              objective: { type: "string", description: "Resultado esperado, coerente com a função estratégica" },
              angle: { type: "string", description: "Ângulo novo/abordagem" },
              hook: { type: "string", description: "Primeira frase ou primeiro segundo" },
              central_idea: { type: "string", description: "Ideia central em 1–2 frases" },
              cta: { type: "string", description: "Chamada para ação coerente com a função" },
              note: { type: "string", description: "Observação de produção" },
            },
            required: ["index", "theme", "objective", "angle", "hook", "central_idea", "cta"],
          },
        },
      },
      required: ["items"],
    },
    validator: themesSchema,
    maxTokens: 12000,
  });
  return data.items;
}

// ───────────── Conteúdo completo de uma publicação ─────────────

// Limites aplicados cortando o excesso (em vez de descartar a geração inteira e pagar de novo)
const cut = (max: number) => z.string().transform((v) => (v.length > max ? v.slice(0, max - 1).trimEnd() + "…" : v));
const postSchema = z.object({
  title: z.string().min(2).pipe(cut(90)),
  subtitle: cut(160).default(""),
  cta: z.string().min(2).pipe(cut(80)),
  caption_instagram: z.string().min(10).pipe(cut(2200)),
  caption_facebook: z.string().min(10).pipe(cut(5000)),
  hashtags: z.array(z.string()).transform((h) => h.slice(0, 30)),
  image_prompt: z.string().min(10),
  art_direction: z.string().min(5),
  layout: z.enum(LAYOUTS).catch("hero-bottom"),
  slides: z.array(z.object({ title: cut(80), body: cut(260) })).optional().default([]),
  reel_script: z.string().optional().default(""),
  video_speech: z.string().optional().default(""),
  video_visual_prompt: z.string().optional().default(""),
  episode_summary: z.string().optional().default(""),
});
export type GeneratedPost = z.infer<typeof postSchema>;

export async function generatePostContent(
  orgId: string,
  ctx: BrandContext,
  input: {
    pillar: string;
    format: string;
    theme: string;
    objective?: string | null;
    funnelStage?: string | null;
    angle?: string | null;
    hook?: string | null;
    centralIdea?: string | null;
    ctaPlan?: string | null;
    strategyNote?: string | null;
    networks: string[];
    offer?: Offer | null;
    recentTitles: string[];
    maxHashtags: number;
    trackingUrl?: string | null;
    extraInstructions?: string;
  },
): Promise<{ data: GeneratedPost; model: string }> {
  const o = input.offer;
  const offerBlock = o
    ? [
        `OFERTA APROVADA (use exatamente estes dados, nada além):`,
        `- Operadora: ${o.operator}${o.planName ? ` — plano ${o.planName}` : ""}`,
        `- Velocidade: ${o.speedMbps} Mega`,
        `- Preço: ${formatBRL(o.priceCents)}${o.pricePeriod}`,
        `- Benefícios: ${o.benefits.join("; ") || "(nenhum informado)"}`,
        `- Condições: ${o.conditions ?? "(não informadas)"}`,
        `- Regiões: ${o.regions.join(", ") || "consultar disponibilidade"}`,
        `- Válida até: ${formatDate(o.validUntil)}`,
        `- Restrições: ${o.restrictions ?? "(não informadas)"}`,
        `O preço e a velocidade serão desenhados na arte pelo sistema; no título, destaque o benefício principal.`,
      ].join("\n")
    : `Esta publicação NÃO tem oferta: não mencione preços, descontos, promoções, brindes ou prazos.`;

  const formatGuide: Record<string, string> = {
    FEED_IMAGE: "Post de imagem única 4:5: dica rápida, 'você sabia?', mito ou verdade ou checklist curto. Título até 45 caracteres com o problema ou a descoberta; subtítulo até 90 com a solução em uma frase. A legenda traz o passo a passo completo (passos numerados e curtos, caminhos de Android e iPhone quando forem diferentes).",
    CAROUSEL: "Carrossel PASSO A PASSO de 5 a 7 slides (slides[]), feito para ser salvo: slide 1 é a capa com o problema/descoberta; depois 1 passo por slide (título curto até 40, corpo até 180, com o nome real do menu/botão); quando Android e iPhone forem diferentes, separe os caminhos; penúltimo slide com o cuidado/observação (o que NÃO fazer, expectativa honesta); último slide com o fechamento e o CTA (salvar/compartilhar ou, se fizer sentido, a ligação natural com conexão e planos). Use layout 'carousel'.",
    STORY: "Story 9:16. Título até 40 caracteres, texto mínimo, convite à interação (enquete, quiz, 'você sabia?', 'qual sua dúvida?'). Use layout 'story'.",
    REEL: "Reels de DEMONSTRAÇÃO: reel_script de 20–45s em cenas numeradas — gancho com o problema ou a descoberta nos 2 primeiros segundos, a demonstração passo a passo (o que aparece na tela do celular/TV e o TEXTO NA TELA de cada passo, curto e legível), o resultado e o cuidado, e o fechamento. Título para a capa e legenda com os passos por escrito. Preencha também video_speech (fala COMPLETA do vídeo, de 22 a 28 segundos — entre 50 e 65 palavras, nunca menos de 48: gancho com o problema → os passos principais, um por frase curta, com os nomes reais dos menus → o resultado → um cuidado → fechamento curto) e video_visual_prompt (a cena do clipe, em inglês, sem textos legíveis).",
  };
  const storyGuide: Record<string, string> = {
    CAROUSEL:
      "DICA DO PERSONAGEM EM CARROSSEL — 6 a 7 slides (slides[]): 1) gancho com a situação cotidiana ou a pergunta (o nome do post), 2) o problema explicado em uma frase, 3 a 5) o passo a passo (1 passo por slide, nome real do menu; caminhos de Android e iPhone separados quando forem diferentes), 6) o cuidado/expectativa honesta com o comentário irônico do personagem, 7) fechamento (salvar/compartilhar; a conexão/Conecta Aqui só se fizer sentido). title de cada slide até 40 caracteres; body até 180. Use layout 'carousel'.",
    FEED_IMAGE:
      "DICA DO PERSONAGEM EM IMAGEM ÚNICA — o título é o gancho (até 45 caracteres); a legenda abre com a situação em 1–2 frases na voz dele e entrega o passo a passo numerado, terminando com uma pergunta que gere conversa.",
    STORY: "STORY DO PERSONAGEM — enquete, quiz ou 'você sabia?' sobre a dica (até 40 caracteres) + convite a responder. Layout 'story'.",
    REEL: "REELS COM O PERSONAGEM APRESENTANDO A DICA — reel_script em cenas numeradas (15–45s): gancho de 2s com a situação ou a descoberta, demonstração passo a passo com TEXTO NA TELA, resultado, cuidado e fechamento com a frase dele.",
  };


  const prompt = [
    `Crie a publicação completa.`,
    `Pilar: ${PILLAR_LABEL[input.pillar]} — ${PILLAR_GUIDE[input.pillar]}`,
    `Formato: ${FORMAT_LABEL[input.format]} — ${input.pillar === "STORYTELLING" && personaActive(ctx) ? storyGuide[input.format] : formatGuide[input.format]}`,
    input.pillar === "STORYTELLING" && `episode_summary: resuma em 1–2 frases a situação e a dica ensinada (para não repetir nas próximas).`,
    input.funnelStage && `Função estratégica: ${FUNNEL_GUIDE[input.funnelStage] ?? input.funnelStage}`,
    `Tema: ${input.theme}`,
    input.objective && `Objetivo: ${input.objective}`,
    input.angle && `Ângulo: ${input.angle}`,
    input.hook && `Hook planejado (use ou melhore, mantendo a força nos primeiros segundos/linha): ${input.hook}`,
    input.centralIdea && `Ideia central: ${input.centralIdea}`,
    input.ctaPlan && `CTA planejado: ${input.ctaPlan}`,
    input.strategyNote && `Observação do planejamento: ${input.strategyNote}`,
    `Redes: ${input.networks.join(" e ")}. Adapte a linguagem: Instagram mais direto e visual (hashtags ao final, sem link clicável — use "link na bio"); Facebook um pouco mais explicativo, pode conter o link ${input.trackingUrl ?? "(link do WhatsApp será inserido pelo sistema)"}.`,
    offerBlock,
    `Hashtags: no máximo ${input.maxHashtags}, relevantes, sem o símbolo repetido (ex.: "internetfibra").`,
    `Layouts disponíveis: hero-bottom (foto com título sobreposto), split-panel (foto + painel), question-card (pergunta em destaque, ideal para engajamento), offer (somente com oferta), carousel, story.`,
    `Evite títulos parecidos com: ${input.recentTitles.slice(0, 15).join(" | ") || "(nenhum)"}.`,
    `image_prompt: descreva em inglês uma fotografia realista que ilustre a situação da dica (mãos segurando o celular, celular e TV na sala, roteador na estante, pessoa de qualquer idade usando o aparelho), composição com área limpa para texto, luz natural, pessoas brasileiras diversas quando fizer sentido; telas sem texto legível.`,
    ACCURACY_RULES,
    personaActive(ctx) && (input.pillar === "STORYTELLING" || input.format === "STORY")
      ? ctx.hasCharacterRefs
        ? `Na image_prompt, coloque o personagem recorrente na cena do gancho (expressão teatral, cenário cotidiano brasileiro, luz cinematográfica), descrevendo roupa e ação; a identidade visual dele vem das imagens de referência oficiais.`
        : `Ainda NÃO há imagens oficiais do personagem: na image_prompt, mostre-o apenas de forma indireta (de costas, mãos segurando o celular, silhueta, reflexo, detalhes do ambiente) — nunca o rosto — para não criar uma aparência que depois mude.`
      : false,
    input.extraInstructions && `Instruções adicionais do administrador: ${input.extraInstructions}`,
  ]
    .filter(Boolean)
    .join("\n");

  return structured({
    orgId,
    system: brandSystemPrompt(ctx),
    prompt,
    toolName: "salvar_publicacao",
    toolDescription: "Salva o conteúdo completo da publicação.",
    schema: {
      type: "object",
      properties: {
        title: { type: "string", description: "Título principal da arte" },
        subtitle: { type: "string", description: "Texto secundário da arte" },
        cta: { type: "string", description: "Chamada para ação curta para a arte" },
        caption_instagram: { type: "string" },
        caption_facebook: { type: "string" },
        hashtags: { type: "array", items: { type: "string" } },
        image_prompt: { type: "string" },
        art_direction: { type: "string", description: "Direção de arte: enquadramento, clima, cores, hierarquia" },
        layout: { type: "string", enum: [...LAYOUTS] },
        slides: {
          type: "array",
          items: { type: "object", properties: { title: { type: "string" }, body: { type: "string" } }, required: ["title", "body"] },
        },
        reel_script: { type: "string" },
        video_speech: { type: "string", description: "Somente Reels: fala exata e completa do personagem para o vídeo de 22 a 28 s (50 a 65 palavras, frases curtas e completas), português do Brasil, sem preços" },
        video_visual_prompt: { type: "string", description: "Somente Reels: cena do clipe em inglês (cenário, enquadramento vertical, gestos, expressão, movimento de câmera), sem textos ou logos" },
      },
      required: ["title", "subtitle", "cta", "caption_instagram", "caption_facebook", "hashtags", "image_prompt", "art_direction", "layout"],
    },
    validator: postSchema,
  });
}

// ───────────── Ideias sob demanda (AI Content Studio) ─────────────

const ideasSchema = z.object({
  ideas: z.array(
    z.object({
      theme: z.string(),
      objective: z.string(),
      pillar: z.enum(ALL_PILLARS),
      format: z.enum(["FEED_IMAGE", "CAROUSEL", "STORY", "REEL"]),
      hook: z.string(),
    }),
  ),
});

export async function generateIdeas(orgId: string, ctx: BrandContext, opts: { pillar?: string; count: number; hint?: string; recentThemes: string[]; hasOffers: boolean }) {
  const { data } = await structured({
    orgId,
    system: brandSystemPrompt(ctx),
    prompt: [
      `Sugira ${opts.count} ideias de conteúdo${opts.pillar ? ` do pilar ${PILLAR_LABEL[opts.pillar]}` : " distribuídas entre os pilares (a maioria em Educação)"}.`,
      `Parta dos temas prioritários da diretriz (${PRIORITY_THEMES.join("; ")}), sempre com um problema real, dúvida frequente ou descoberta curiosa e algo que a pessoa consegue fazer. Nada de IA, marketing digital ou ferramentas para profissionais.`,
      ...Object.entries(PILLAR_GUIDE).map(([k, v]) => `- ${PILLAR_LABEL[k]}: ${v}`),
      opts.hasOffers ? "" : "Não há ofertas cadastradas e válidas: não sugira ideias do pilar Ofertas.",
      opts.hint && `Direcionamento: ${opts.hint}`,
      `Evite: ${opts.recentThemes.slice(0, 60).join(" | ") || "(nada)"}`,
    ].filter(Boolean).join("\n"),
    toolName: "salvar_ideias",
    toolDescription: "Salva a lista de ideias.",
    schema: {
      type: "object",
      properties: {
        ideas: {
          type: "array",
          items: {
            type: "object",
            properties: {
              theme: { type: "string" },
              objective: { type: "string" },
              pillar: { type: "string", enum: [...ALL_PILLARS] },
              format: { type: "string", enum: ["FEED_IMAGE", "CAROUSEL", "STORY", "REEL"] },
              hook: { type: "string", description: "Gancho/título provisório" },
            },
            required: ["theme", "objective", "pillar", "format", "hook"],
          },
        },
      },
      required: ["ideas"],
    },
    validator: ideasSchema,
  });
  return data.ideas;
}

// ───────────── Análise de desempenho ─────────────

const analysisSchema = z.object({
  summary: z.string(),
  recommendations: z.array(z.object({ title: z.string(), detail: z.string(), confidence: z.enum(["baixa", "média", "alta"]) })),
});

export async function analyzePerformance(orgId: string, ctx: BrandContext, aggregates: unknown) {
  const { data } = await structured({
    orgId,
    system: brandSystemPrompt(ctx),
    prompt: [
      `Analise os dados agregados de desempenho abaixo (JSON) e produza um resumo e recomendações para o próximo calendário.`,
      `Regras: trate padrões como correlações, nunca como prova de causa; mencione o tamanho da amostra; se a amostra for pequena, diga que a confiança é baixa;`,
      `não atribua vendas a publicações; recomende testes (A/B de horário, formato, tema) quando apropriado.`,
      JSON.stringify(aggregates).slice(0, 30000),
    ].filter(Boolean).join("\n"),
    toolName: "salvar_analise",
    toolDescription: "Salva a análise de desempenho.",
    schema: {
      type: "object",
      properties: {
        summary: { type: "string" },
        recommendations: {
          type: "array",
          items: {
            type: "object",
            properties: { title: { type: "string" }, detail: { type: "string" }, confidence: { type: "string", enum: ["baixa", "média", "alta"] } },
            required: ["title", "detail", "confidence"],
          },
        },
      },
      required: ["summary", "recommendations"],
    },
    validator: analysisSchema,
  });
  return data;
}

// ───────────── Roteiro de Reels sob demanda ─────────────

const reelScriptSchema = z.object({ reel_script: z.string().min(20) });

export async function generateReelScript(
  orgId: string,
  ctx: BrandContext,
  input: {
    pillar: Pillar;
    theme: string;
    objective?: string | null;
    hook?: string | null;
    centralIdea?: string | null;
    ctaPlan?: string | null;
    currentScript?: string | null;
    instructions?: string | null;
    offerText?: string | null;
  },
) {
  const story = input.pillar === "STORYTELLING" && personaActive(ctx);
  const prompt = [
    `Escreva um NOVO roteiro de Reels (vídeo vertical 9:16) para a publicação abaixo. Entregue somente o roteiro em reel_script.`,
    story
      ? `Formato: o personagem apresenta a dica — cenas numeradas (15–45s) com tempo de cada cena, enquadramento/ação, falas curtas e o TEXTO NA TELA de cada passo; situação cotidiana como gancho nos 2 primeiros segundos e, em seguida, a demonstração correta.`
      : `Formato: Reels de DEMONSTRAÇÃO, 15–45s, em cenas numeradas com tempo de cada cena, o que aparece na tela (celular, TV, roteador), o TEXTO NA TELA de cada passo (curto e legível) e as falas; gancho com o problema ou a descoberta nos 2 primeiros segundos.`,
    `Quando o caminho for diferente entre Android e iPhone (ou marcas de TV), mostre os dois ou deixe claro para qual vale.`,
    ACCURACY_RULES,
    `Termine com uma linha "TEXTO FINAL NA TELA: ..." com um convite útil (salvar, mandar para quem precisa ou, se fizer sentido, comparar opções de internet com a marca).`,
    `Pilar: ${PILLAR_LABEL[input.pillar]} — ${PILLAR_GUIDE[input.pillar] ?? ""}`,
    `Tema: ${input.theme}`,
    input.objective && `Objetivo: ${input.objective}`,
    input.hook && `Hook planejado (use ou melhore): ${input.hook}`,
    input.centralIdea && `Ideia central: ${input.centralIdea}`,
    input.ctaPlan && `CTA planejado: ${input.ctaPlan}`,
    input.offerText
      ? `Oferta aprovada (única que pode ser citada, sem alterar nenhum dado): ${input.offerText}`
      : `Não há oferta aprovada: NÃO cite preços, velocidades comerciais, promoções, descontos nem prazos.`,
    input.currentScript && `Roteiro anterior (crie uma versão diferente, com outro gancho e outra estrutura, salvo se as instruções pedirem só ajustes):\n${input.currentScript.slice(0, 6000)}`,
    input.instructions && `Instruções do administrador (prioridade máxima): ${input.instructions}`,
  ]
    .filter(Boolean)
    .join("\n");

  const { data, model } = await structured({
    orgId,
    system: brandSystemPrompt(ctx),
    prompt,
    toolName: "salvar_roteiro",
    toolDescription: "Salva o roteiro do Reels.",
    schema: { type: "object", properties: { reel_script: { type: "string" } }, required: ["reel_script"] },
    validator: reelScriptSchema,
    maxTokens: 3000,
  });
  return { script: data.reel_script.trim(), model };
}

const sceneSchema = z.object({ scene: z.string().min(5) });

/** Reescreve uma única cena do roteiro, mantendo a coerência com as demais. */
export async function rewriteReelScene(
  orgId: string,
  ctx: BrandContext,
  input: { theme: string; scenes: string[]; index: number; instructions?: string | null; offerText?: string | null },
) {
  const numbered = input.scenes.map((s, i) => `[PARTE ${i + 1}${i === input.index ? " — REESCREVER" : ""}]\n${s}`).join("\n\n");
  const prompt = [
    `Roteiro de Reels sobre "${input.theme}". Reescreva SOMENTE a PARTE ${input.index + 1}, mantendo-a coerente com as partes anteriores e seguintes (que não mudam).`,
    `Mantenha o mesmo formato da parte original (marcação de cena e tempo, ação/enquadramento, falas). Devolva só o texto da parte em scene, sem o rótulo [PARTE].`,
    input.offerText
      ? `Oferta aprovada (única que pode ser citada, sem alterar nenhum dado): ${input.offerText}`
      : `Não cite preços, velocidades comerciais, promoções, descontos nem prazos.`,
    input.instructions ? `Instruções do administrador para esta parte (prioridade máxima): ${input.instructions}` : `Crie uma versão diferente e mais forte desta parte.`,
    `Roteiro completo:\n${numbered.slice(0, 9000)}`,
  ].join("\n");
  const { data } = await structured({
    orgId,
    system: brandSystemPrompt(ctx),
    prompt,
    toolName: "salvar_cena",
    toolDescription: "Salva a parte reescrita do roteiro.",
    schema: { type: "object", properties: { scene: { type: "string" } }, required: ["scene"] },
    validator: sceneSchema,
    maxTokens: 1500,
  });
  return data.scene.trim();
}
