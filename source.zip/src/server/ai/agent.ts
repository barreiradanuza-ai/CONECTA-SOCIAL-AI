// Agente editorial: gera seus próprios prompts internos a partir da identidade da marca,
// dos pilares, do histórico e das métricas — sem exigir instruções diárias do administrador.
import { z } from "zod";
import type { Brand, Offer, PerformanceInsight, WhatsAppConfig } from "@prisma/client";
import { structured } from "./anthropic";
import { PILLAR_LABEL, FORMAT_LABEL } from "@/lib/labels";
import { formatBRL } from "@/server/guard";
import { formatDate } from "@/lib/time";
import type { SeasonalDate } from "./seasonal";

export const LAYOUTS = ["hero-bottom", "split-panel", "question-card", "offer", "carousel", "story"] as const;

export type BrandContext = {
  brand: Brand;
  whatsapp: WhatsAppConfig | null;
  insight: PerformanceInsight | null;
  /** Resumos dos episódios anteriores (continuidade da série do personagem). */
  seriesMemory?: { episode: number; summary: string }[];
  /** Pautas verificadas cadastradas pelo administrador (únicos "acontecimentos" que a IA pode citar). */
  trends?: string[];
  /** Há imagens oficiais de referência do personagem? */
  hasCharacterRefs?: boolean;
};

const ALL_PILLARS = ["EDUCATION", "ENGAGEMENT", "AUTHORITY", "OFFERS", "INSTITUTIONAL", "SEASONAL", "STORYTELLING"] as const;

export function personaActive(ctx: BrandContext) {
  return !!(ctx.brand.personaEnabled && ctx.brand.personaBible);
}

const PILLAR_GUIDE: Record<string, string> = {
  EDUCATION: "Ajudar o consumidor a entender internet: velocidades, Wi-Fi, tecnologias, dispositivos, o que observar antes de contratar.",
  ENGAGEMENT: "Estimular participação autêntica (perguntas, enquetes, quizzes). Nunca pedir curtidas/compartilhamentos de forma artificial.",
  AUTHORITY: "Demonstrar o valor da consultoria especializada e da comparação imparcial entre operadoras.",
  OFFERS: "Apresentar SOMENTE a oferta cadastrada fornecida, sem inventar nada. Cobertura depende do endereço.",
  INSTITUTIONAL: "Mostrar quem é a marca, como funciona a consultoria e o acompanhamento até a instalação.",
  SEASONAL: "Conectar a marca a datas comemorativas e hábitos digitais verificáveis. Nunca inventar notícias.",
  STORYTELLING:
    "Episódio da mini-novela do personagem da marca: entretenimento puro, humor, suspense e observação do comportamento humano. A marca aparece como consequência natural da história (a conexão que permite ao personagem descobrir, investigar, assistir, conversar). Nunca parecer anúncio.",
};

function personaBlock(ctx: BrandContext) {
  const b = ctx.brand;
  const name = b.personaName?.trim() || "o personagem";
  return [
    `PERSONAGEM DA MARCA — ${name}${b.seriesTitle ? ` (série "${b.seriesTitle}")` : ""}. Bíblia do personagem (siga à risca):`,
    b.personaBible!.slice(0, 8000),
    b.personaVisual && `Aparência do personagem: ${b.personaVisual}`,
    `Regras de convivência do personagem com os demais pilares: conteúdos educativos, de autoridade e engajamento podem ser narrados na voz dele — inteligente sem parecer professoral, sarcástico sem ser cruel —, mas mantenha as informações técnicas corretas.`,
    `Cuidados: o humor nunca é sobre a sexualidade dele nem sobre estereótipos de grupos; nunca ridicularize pessoas reais identificáveis nem exponha pessoas privadas; nada de conteúdo ofensivo, discriminatório ou difamatório. Referências de cinema (Tarantino, Hitchcock, Agatha Christie etc.) são inspiração estrutural, nunca citação, cópia de cenas, falas ou personagens.`,
    ctx.seriesMemory?.length
      ? `Continuidade da série — episódios anteriores (mantenha coerência, retome personagens secundários e piadas internas quando fizer sentido, sem repetir tramas): ${ctx.seriesMemory.map((e) => `Ep.${e.episode}: ${e.summary}`).join(" | ")}`
      : `Esta é a estreia da série: apresente o personagem pela ação, não por descrição.`,
  ]
    .filter(Boolean)
    .join("\n");
}

export function brandSystemPrompt(ctx: BrandContext): string {
  const b = ctx.brand;
  const colors = b.colors as Record<string, string>;
  return [
    `Você é o estrategista de conteúdo e social media sênior da marca "${b.name}" para Instagram e Facebook no Brasil.`,
    `Escreva sempre em português do Brasil, com ortografia impecável.`,
    b.description && `Sobre a marca: ${b.description}`,
    b.positioning && `Posicionamento: ${b.positioning}`,
    b.slogan && `Slogan: ${b.slogan}`,
    b.targetAudience && `Público: ${b.targetAudience}`,
    b.toneOfVoice && `Tom de voz: ${b.toneOfVoice}`,
    b.communicationPillars.length && `Pilares de comunicação: ${b.communicationPillars.join("; ")}.`,
    b.visualGuidelines && `Diretrizes visuais: ${b.visualGuidelines}`,
    colors && `Cores da marca: ${Object.entries(colors).map(([k, v]) => `${k} ${v}`).join(", ")}.`,
    b.forbiddenTerms.length && `Nunca use estes termos: ${b.forbiddenTerms.join(", ")}.`,
    ctx.whatsapp?.ctaText && `CTA padrão para WhatsApp: "${ctx.whatsapp.ctaText}"`,
    ctx.insight && `Aprendizados recentes de desempenho (correlações, não causas): ${ctx.insight.summary.slice(0, 1500)}`,
    personaActive(ctx) && personaBlock(ctx),
    ctx.trends?.length
      ? `PAUTAS VERIFICADAS PELO ADMINISTRADOR (únicos acontecimentos reais que você pode citar): ${ctx.trends.join(" | ")}`
      : `Não há pautas de acontecimentos reais verificadas: use apenas situações cotidianas arquetípicas (grupo da família no WhatsApp, vizinho, trabalho, relacionamentos), sem citar fatos, virais ou pessoas reais específicas.`,
    `REGRAS INEGOCIÁVEIS:`,
    `- Nunca invente preços, velocidades comerciais, benefícios, prazos, promoções, disponibilidade ou condições. Só use dados de oferta explicitamente fornecidos.`,
    `- Quando a cobertura depender do endereço, use "Consulte a disponibilidade para seu endereço."`,
    `- Não cite notícias, estatísticas ou pesquisas específicas que não foram fornecidas.`,
    `- Não mencione nomes de outras marcas da empresa; cada marca tem identidade própria.`,
    `- Textos de arte curtos e impactantes; legendas claras, escaneáveis, sem excesso de emojis (máx. 3).`,
    `- Prompts de imagem em inglês, fotográficos, SEM qualquer texto/letra/logo na imagem; temas: conectividade, tecnologia, famílias brasileiras, trabalho remoto, estudo, lazer.`,
  ]
    .filter(Boolean)
    .join("\n");
}

// ───────────── Planejamento de temas ─────────────

const themesSchema = z.object({
  items: z.array(z.object({ index: z.number().int(), theme: z.string().min(3), objective: z.string().min(3) })),
});

export async function planThemes(
  orgId: string,
  ctx: BrandContext,
  slots: { index: number; date: string; pillar: string; format: string }[],
  recentThemes: string[],
  seasonal: SeasonalDate[],
) {
  const prompt = [
    `Planeje temas para as publicações abaixo. Cada item já tem data, pilar e formato definidos.`,
    `Diretrizes por pilar:`,
    ...Object.entries(PILLAR_GUIDE).map(([k, v]) => `- ${PILLAR_LABEL[k]}: ${v}`),
    seasonal.length ? `Datas comemorativas no período (use no pilar Sazonal, na data ou até 3 dias antes): ${seasonal.map((s) => `${s.date} ${s.name} (${s.angle})`).join("; ")}.` : `Não há datas comemorativas no período; no pilar Sazonal use hábitos digitais e comportamento.`,
    `Evite repetir ou parafrasear estes temas recentes: ${recentThemes.slice(0, 80).join(" | ") || "(nenhum)"}.`,
    `Varie ângulos, perguntas e situações do dia a dia. Stories devem ser leves e interativos.`,
    personaActive(ctx) &&
      `Itens do pilar "${PILLAR_LABEL.STORYTELLING}": o tema é a premissa do episódio (situação banal + mistério cômico), ex.: "Por que a tia saiu do grupo da família às 3h da manhã?". Distribua ganchos variados (WhatsApp, vizinhança, trabalho, relacionamentos, família, cultura pop genérica) e pense em arcos que se conectem entre episódios.`,
    `Itens:`,
    ...slots.map((s) => `#${s.index} | ${s.date} | ${PILLAR_LABEL[s.pillar]} | ${FORMAT_LABEL[s.format]}`),
  ].filter(Boolean).join("\n");

  const { data } = await structured({
    orgId,
    system: brandSystemPrompt(ctx),
    prompt,
    toolName: "salvar_temas",
    toolDescription: "Salva o tema e o objetivo estratégico de cada item do calendário.",
    schema: {
      type: "object",
      properties: {
        items: {
          type: "array",
          items: {
            type: "object",
            properties: {
              index: { type: "integer" },
              theme: { type: "string", description: "Tema específico da publicação" },
              objective: { type: "string", description: "Objetivo estratégico (ex.: educar, gerar conversa, gerar lead)" },
            },
            required: ["index", "theme", "objective"],
          },
        },
      },
      required: ["items"],
    },
    validator: themesSchema,
    maxTokens: 12000,
  });
  return data.items;
}

// ───────────── Conteúdo completo de uma publicação ─────────────

const postSchema = z.object({
  title: z.string().min(2).max(90),
  subtitle: z.string().max(160).default(""),
  cta: z.string().min(2).max(80),
  caption_instagram: z.string().min(10).max(2200),
  caption_facebook: z.string().min(10).max(5000),
  hashtags: z.array(z.string()).max(30),
  image_prompt: z.string().min(10),
  art_direction: z.string().min(5),
  layout: z.enum(LAYOUTS),
  slides: z.array(z.object({ title: z.string().max(80), body: z.string().max(260) })).optional().default([]),
  reel_script: z.string().optional().default(""),
  episode_summary: z.string().optional().default(""),
});
export type GeneratedPost = z.infer<typeof postSchema>;

export async function generatePostContent(
  orgId: string,
  ctx: BrandContext,
  input: {
    pillar: string;
    format: string;
    theme: string;
    objective?: string | null;
    networks: string[];
    offer?: Offer | null;
    recentTitles: string[];
    maxHashtags: number;
    trackingUrl?: string | null;
    extraInstructions?: string;
  },
): Promise<{ data: GeneratedPost; model: string }> {
  const o = input.offer;
  const offerBlock = o
    ? [
        `OFERTA APROVADA (use exatamente estes dados, nada além):`,
        `- Operadora: ${o.operator}${o.planName ? ` — plano ${o.planName}` : ""}`,
        `- Velocidade: ${o.speedMbps} Mega`,
        `- Preço: ${formatBRL(o.priceCents)}${o.pricePeriod}`,
        `- Benefícios: ${o.benefits.join("; ") || "(nenhum informado)"}`,
        `- Condições: ${o.conditions ?? "(não informadas)"}`,
        `- Regiões: ${o.regions.join(", ") || "consultar disponibilidade"}`,
        `- Válida até: ${formatDate(o.validUntil)}`,
        `- Restrições: ${o.restrictions ?? "(não informadas)"}`,
        `O preço e a velocidade serão desenhados na arte pelo sistema; no título, destaque o benefício principal.`,
      ].join("\n")
    : `Esta publicação NÃO tem oferta: não mencione preços, descontos, promoções, brindes ou prazos.`;

  const formatGuide: Record<string, string> = {
    FEED_IMAGE: "Post de imagem única 4:5. Título até 45 caracteres, subtítulo até 90.",
    CAROUSEL: "Carrossel educativo de 5 a 7 slides (slides[]): slide 1 é capa com gancho; os demais com título curto (até 40) e corpo até 180 caracteres; último slide com CTA. Use layout 'carousel'.",
    STORY: "Story 9:16. Título até 40 caracteres, texto mínimo, convite à interação (enquete/pergunta). Use layout 'story'.",
    REEL: "Reels: escreva reel_script com roteiro de 15–30s em cenas (gancho nos 2 primeiros segundos), título para a capa e legenda.",
  };
  const storyGuide: Record<string, string> = {
    CAROUSEL:
      "EPISÓDIO EM CARROSSEL — exatamente 7 slides (slides[]), um por ato: 1) gancho imediato, 2) situação aparentemente comum, 3) elemento estranho ou intrigante, 4) investigação/escalada, 5) virada, 6) comentário sarcástico do personagem, 7) encerramento memorável (a conexão/Conecta Aqui aparece só como parte natural do universo). title de cada slide até 40 caracteres; body até 180, como fala ou narração curta com ritmo de roteiro. Use layout 'carousel'. O título da capa (title) é o nome do episódio.",
    FEED_IMAGE:
      "EPISÓDIO EM IMAGEM ÚNICA — o título é o gancho (até 45 caracteres); a legenda conta a mini-história nos 7 atos em parágrafos curtos, terminando com uma pergunta que gere conversa espontânea.",
    STORY: "STORY DO PERSONAGEM — cliffhanger ou bastidor da investigação em uma frase (até 40 caracteres) + convite a responder (enquete/pergunta). Layout 'story'.",
    REEL: "EPISÓDIO EM REELS — reel_script com os 7 atos em cenas numeradas (15–45s), falas curtas, indicações de enquadramento e cortes com ritmo; gancho nos 2 primeiros segundos.",
  };

  const prompt = [
    `Crie a publicação completa.`,
    `Pilar: ${PILLAR_LABEL[input.pillar]} — ${PILLAR_GUIDE[input.pillar]}`,
    `Formato: ${FORMAT_LABEL[input.format]} — ${input.pillar === "STORYTELLING" && personaActive(ctx) ? storyGuide[input.format] : formatGuide[input.format]}`,
    input.pillar === "STORYTELLING" && `episode_summary: resuma o episódio em 1–2 frases (trama, personagens secundários e virada) para a memória da série.`,
    `Tema: ${input.theme}`,
    input.objective && `Objetivo: ${input.objective}`,
    `Redes: ${input.networks.join(" e ")}. Adapte a linguagem: Instagram mais direto e visual (hashtags ao final, sem link clicável — use "link na bio"); Facebook um pouco mais explicativo, pode conter o link ${input.trackingUrl ?? "(link do WhatsApp será inserido pelo sistema)"}.`,
    offerBlock,
    `Hashtags: no máximo ${input.maxHashtags}, relevantes, sem o símbolo repetido (ex.: "internetfibra").`,
    `Layouts disponíveis: hero-bottom (foto com título sobreposto), split-panel (foto + painel), question-card (pergunta em destaque, ideal para engajamento), offer (somente com oferta), carousel, story.`,
    `Evite títulos parecidos com: ${input.recentTitles.slice(0, 40).join(" | ") || "(nenhum)"}.`,
    `image_prompt: descreva em inglês uma fotografia/ilustração realista, composição com área limpa para texto, luz natural, pessoas brasileiras diversas quando fizer sentido, estética moderna e tecnológica discreta.`,
    personaActive(ctx) && (input.pillar === "STORYTELLING" || input.format === "STORY")
      ? ctx.hasCharacterRefs
        ? `Na image_prompt, coloque o personagem recorrente na cena do gancho (expressão teatral, cenário cotidiano brasileiro, luz cinematográfica), descrevendo roupa e ação; a identidade visual dele vem das imagens de referência oficiais.`
        : `Ainda NÃO há imagens oficiais do personagem: na image_prompt, mostre-o apenas de forma indireta (de costas, mãos segurando o celular, silhueta, reflexo, detalhes do ambiente) — nunca o rosto — para não criar uma aparência que depois mude.`
      : false,
    input.extraInstructions && `Instruções adicionais do administrador: ${input.extraInstructions}`,
  ]
    .filter(Boolean)
    .join("\n");

  return structured({
    orgId,
    system: brandSystemPrompt(ctx),
    prompt,
    toolName: "salvar_publicacao",
    toolDescription: "Salva o conteúdo completo da publicação.",
    schema: {
      type: "object",
      properties: {
        title: { type: "string", description: "Título principal da arte" },
        subtitle: { type: "string", description: "Texto secundário da arte" },
        cta: { type: "string", description: "Chamada para ação curta para a arte" },
        caption_instagram: { type: "string" },
        caption_facebook: { type: "string" },
        hashtags: { type: "array", items: { type: "string" } },
        image_prompt: { type: "string" },
        art_direction: { type: "string", description: "Direção de arte: enquadramento, clima, cores, hierarquia" },
        layout: { type: "string", enum: [...LAYOUTS] },
        slides: {
          type: "array",
          items: { type: "object", properties: { title: { type: "string" }, body: { type: "string" } }, required: ["title", "body"] },
        },
        reel_script: { type: "string" },
      },
      required: ["title", "subtitle", "cta", "caption_instagram", "caption_facebook", "hashtags", "image_prompt", "art_direction", "layout"],
    },
    validator: postSchema,
  });
}

// ───────────── Ideias sob demanda (AI Content Studio) ─────────────

const ideasSchema = z.object({
  ideas: z.array(
    z.object({
      theme: z.string(),
      objective: z.string(),
      pillar: z.enum(ALL_PILLARS),
      format: z.enum(["FEED_IMAGE", "CAROUSEL", "STORY", "REEL"]),
      hook: z.string(),
    }),
  ),
});

export async function generateIdeas(orgId: string, ctx: BrandContext, opts: { pillar?: string; count: number; hint?: string; recentThemes: string[]; hasOffers: boolean }) {
  const { data } = await structured({
    orgId,
    system: brandSystemPrompt(ctx),
    prompt: [
      `Sugira ${opts.count} ideias de conteúdo${opts.pillar ? ` do pilar ${PILLAR_LABEL[opts.pillar]}` : " distribuídas entre os pilares"}.`,
      ...Object.entries(PILLAR_GUIDE).map(([k, v]) => `- ${PILLAR_LABEL[k]}: ${v}`),
      opts.hasOffers ? "" : "Não há ofertas cadastradas e válidas: não sugira ideias do pilar Ofertas.",
      opts.hint && `Direcionamento: ${opts.hint}`,
      `Evite: ${opts.recentThemes.slice(0, 60).join(" | ") || "(nada)"}`,
    ].filter(Boolean).join("\n"),
    toolName: "salvar_ideias",
    toolDescription: "Salva a lista de ideias.",
    schema: {
      type: "object",
      properties: {
        ideas: {
          type: "array",
          items: {
            type: "object",
            properties: {
              theme: { type: "string" },
              objective: { type: "string" },
              pillar: { type: "string", enum: [...ALL_PILLARS] },
              format: { type: "string", enum: ["FEED_IMAGE", "CAROUSEL", "STORY", "REEL"] },
              hook: { type: "string", description: "Gancho/título provisório" },
            },
            required: ["theme", "objective", "pillar", "format", "hook"],
          },
        },
      },
      required: ["ideas"],
    },
    validator: ideasSchema,
  });
  return data.ideas;
}

// ───────────── Análise de desempenho ─────────────

const analysisSchema = z.object({
  summary: z.string(),
  recommendations: z.array(z.object({ title: z.string(), detail: z.string(), confidence: z.enum(["baixa", "média", "alta"]) })),
});

export async function analyzePerformance(orgId: string, ctx: BrandContext, aggregates: unknown) {
  const { data } = await structured({
    orgId,
    system: brandSystemPrompt(ctx),
    prompt: [
      `Analise os dados agregados de desempenho abaixo (JSON) e produza um resumo e recomendações para o próximo calendário.`,
      `Regras: trate padrões como correlações, nunca como prova de causa; mencione o tamanho da amostra; se a amostra for pequena, diga que a confiança é baixa;`,
      `não atribua vendas a publicações; recomende testes (A/B de horário, formato, tema) quando apropriado.`,
      JSON.stringify(aggregates).slice(0, 30000),
    ].filter(Boolean).join("\n"),
    toolName: "salvar_analise",
    toolDescription: "Salva a análise de desempenho.",
    schema: {
      type: "object",
      properties: {
        summary: { type: "string" },
        recommendations: {
          type: "array",
          items: {
            type: "object",
            properties: { title: { type: "string" }, detail: { type: "string" }, confidence: { type: "string", enum: ["baixa", "média", "alta"] } },
            required: ["title", "detail", "confidence"],
          },
        },
      },
      required: ["summary", "recommendations"],
    },
    validator: analysisSchema,
  });
  return data;
}
