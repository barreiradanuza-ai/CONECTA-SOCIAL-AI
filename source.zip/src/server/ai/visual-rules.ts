// Regras visuais aplicadas a TODA geração de imagem e de vídeo, e a checagem automática do resultado.
// Motivo: as IAs de imagem/vídeo erram com frequência em texto embutido (letras, legendas, caixas) e em
// física/anatomia (celular segurado ao contrário, tela virada para o lado errado, mãos deformadas).
import { z } from "zod";
import { FAST_MODEL, structured } from "@/server/ai/anthropic";

/** Sem nenhum texto ou elemento gráfico gerado pela IA (títulos, legendas e cartões são aplicados pelo app). */
export const NO_TEXT_RULES =
  "Absolutely no text of any kind: no letters, words, numbers, captions, subtitles, titles, labels, signs, speech bubbles, logos, watermarks, stickers, text boxes, banners, frames, borders, UI overlays or graphic elements. Any screen (phone, TV, laptop) shows only a soft, blurred, abstract glow, never readable text, icons or app interfaces.";

/** Física e anatomia corretas — os erros mais comuns das IAs de imagem. */
export const REALISM_RULES =
  "Physically and anatomically correct: natural hands with five fingers and a relaxed, believable grip. A smartphone is always held the right way: its SCREEN faces the person who is using it and the BACK of the phone (with the camera lenses) faces away from that person; never show the person looking at the back of the phone. A TV screen faces the sofa/viewer; a laptop screen faces the person typing; a router stands upright with its antennas up. One device per hand, no duplicated, floating, melted or merged objects, no extra fingers or limbs. Keep the composition simple: one main person and one main device, clear and uncluttered.";

/** Enquadramento dos vídeos do personagem: rosto na metade de cima (a parte de baixo recebe legendas e cartões). */
export const VIDEO_FRAMING_RULES =
  "Framing: vertical medium shot; the character's head and face stay in the UPPER HALF of the frame (eyes roughly one third from the top) for the whole clip; the lower 40% of the frame shows only torso, hands or a plain background, because captions are added there later. Keep the camera steady with gentle movement only.";

/** Versão curta (o prompt da MiniMax tem limite de 1500 caracteres). */
export const COMPACT_IMAGE_RULES =
  " Realistic and physically correct: natural hands with five fingers; a phone's SCREEN faces the person using it and its BACK with the camera faces away from them; TV and laptop screens face their user. One main person, one main device, simple composition. No text at all: no letters, numbers, captions, signs, logos, text boxes, banners or UI; screens show only a soft blurred glow.";

/** Regras curtas para o vídeo do personagem (o prompt do vídeo também tem limite de tamanho). */
export const COMPACT_VIDEO_RULES =
  "One single continuous shot of the same character only (no montage, no scene changes, no other people). Vertical medium shot: the face stays in the upper half of the frame; the lower 40% shows only torso, hands or plain background. Physically correct: natural hands with five fingers; if a phone appears, its screen faces the character and its back with the camera faces the viewer. No text of any kind: no captions, subtitles, letters, signs, logos, text boxes, banners or UI; screens show only a soft blurred glow.";

/** Orientação em português para quem escreve a cena do vídeo (prompts de roteiro). */
export const VIDEO_SCENE_GUIDE =
  "A cena do vídeo (em inglês) é UM plano contínuo só com o personagem, sem montagem, sem cortes para outras cenas e sem outras pessoas; plano médio vertical com o rosto na metade de cima do quadro (a parte de baixo recebe legendas); gestos simples; se aparecer celular, a tela fica virada para o personagem e o verso com a câmera para quem assiste; sem textos, placas, legendas ou elementos gráficos.";

/** Orientação em português para quem escreve o prompt de imagem. */
export const IMAGE_SCENE_GUIDE =
  "Cena simples (uma pessoa principal e um aparelho principal), física correta: a tela do celular sempre virada para quem o usa e o verso com a câmera para fora; TV e notebook com a tela virada para quem assiste/digita; mãos naturais; descreva isso explicitamente no prompt. Telas com brilho desfocado, sem texto, ícones ou interface legíveis; nenhum texto, placa ou elemento gráfico na imagem.";

/** Sufixo para prompts de imagem (respeitando limites de tamanho do provedor). */
export function imageRules(maxLen?: number) {
  const full = ` ${REALISM_RULES} ${NO_TEXT_RULES} Leave clean negative space for later typography.`;
  return maxLen && full.length > maxLen ? ` ${REALISM_RULES} ${NO_TEXT_RULES}`.slice(0, maxLen) : full;
}

const checkSchema = z.object({
  ok: z.boolean(),
  problems: z.array(z.string()).default([]),
  fix: z.string().default(""),
});
export type VisualCheck = z.infer<typeof checkSchema>;

/**
 * Checagem visual por IA (barata): procura texto/caixas embutidos e erros de física/anatomia.
 * Nunca lança erro — em falha, considera aprovada (não trava a produção).
 */
export async function inspectVisual(orgId: string, images: Buffer[], context: string): Promise<VisualCheck> {
  try {
    const sharp = (await import("sharp")).default;
    const small = await Promise.all(images.slice(0, 4).map((b) => sharp(b).rotate().resize(768, 768, { fit: "inside" }).jpeg({ quality: 80 }).toBuffer()));
    const { data } = await structured({
      orgId,
      model: FAST_MODEL(),
      system: "Você é o controle de qualidade visual de uma marca. Seja rigoroso com erros visíveis e objetivos; não reprove por gosto ou estilo.",
      prompt: [
        `Imagem(ns) gerada(s) por IA para: ${context.slice(0, 500)}`,
        "Reprove (ok=false) somente se houver pelo menos um destes erros visíveis:",
        "1. Qualquer texto, letra, número, legenda, placa, logotipo, caixa de texto, balão ou elemento gráfico embutido na imagem (texto borrado/ilegível também conta; telas com interface legível também contam).",
        "2. Celular segurado ao contrário (a pessoa olhando para o verso/câmera do aparelho, ou a tela virada para o lado oposto da pessoa), TV/notebook virados para o lado errado, aparelho flutuando ou fundido à mão.",
        "3. Mãos ou dedos deformados (dedos a mais/a menos, mãos fundidas), membros extras, rosto deformado, objetos duplicados ou derretidos.",
        "problems: liste os erros encontrados em português, curtos. fix: UMA frase em inglês para acrescentar ao prompt e evitar esses erros na próxima geração (ex.: \"The phone screen must face the girl; we see the back of the phone with its camera.\").",
      ].join("\n"),
      toolName: "checagem_visual",
      toolDescription: "Registra o resultado da checagem visual.",
      schema: {
        type: "object",
        properties: { ok: { type: "boolean" }, problems: { type: "array", items: { type: "string" } }, fix: { type: "string" } },
        required: ["ok", "problems", "fix"],
      },
      validator: checkSchema,
      maxTokens: 600,
      images: small.map((data) => ({ data, mimeType: "image/jpeg" })),
    });
    return data.ok ? { ok: true, problems: [], fix: "" } : data;
  } catch (e) {
    console.warn("[visual-check] checagem não realizada", e instanceof Error ? e.message.slice(0, 200) : e);
    return { ok: true, problems: [], fix: "" };
  }
}
