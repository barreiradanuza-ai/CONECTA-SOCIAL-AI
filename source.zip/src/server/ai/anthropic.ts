// Cliente mínimo da API Messages da Anthropic (fetch, sem SDK) com saída estruturada via tool use.
import type { z } from "zod";
import { env } from "@/lib/env";
import { getSecret, MissingCredentialError } from "@/server/integrations";

type JsonSchema = Record<string, unknown>;

const API = "https://api.anthropic.com/v1/messages";

export async function post(apiKey: string, body: Record<string, unknown>) {
  let lastErr: unknown;
  for (let attempt = 0; attempt < 4; attempt++) {
    const res = await fetch(API, {
      method: "POST",
      headers: { "x-api-key": apiKey, "anthropic-version": "2023-06-01", "content-type": "application/json" },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(180_000),
    });
    if (res.ok) return res.json();
    const text = await res.text();
    lastErr = new Error(`Anthropic ${res.status}: ${text.slice(0, 500)}`);
    if (![429, 500, 502, 503, 529].includes(res.status)) throw lastErr;
    await new Promise((r) => setTimeout(r, 2000 * 2 ** attempt));
  }
  throw lastErr;
}

/**
 * Chama o modelo forçando uma ferramenta, e valida a resposta com zod.
 * Retorna o objeto tipado e o id do modelo usado.
 */
export async function structured<T>(opts: {
  orgId: string;
  system: string;
  prompt: string;
  toolName: string;
  toolDescription: string;
  schema: JsonSchema;
  validator: z.ZodType<T, z.ZodTypeDef, any>;
  maxTokens?: number;
  model?: string;
}): Promise<{ data: T; model: string }> {
  const apiKey = await getSecret(opts.orgId, "ANTHROPIC_API_KEY");
  if (!apiKey) throw new MissingCredentialError("chave da Anthropic (ANTHROPIC_API_KEY)");
  const model = opts.model || env.ai.anthropicModel;
  const tool = { name: opts.toolName, description: opts.toolDescription, input_schema: opts.schema };
  const base = {
    model,
    max_tokens: opts.maxTokens ?? 8000,
    system: opts.system,
    tools: [tool],
  };

  let json: any;
  try {
    json = await post(apiKey, {
      ...base,
      tool_choice: { type: "tool", name: opts.toolName },
      messages: [{ role: "user", content: opts.prompt }],
    });
  } catch (e) {
    // Alguns modelos/configurações não aceitam tool_choice forçado; tenta com "any".
    if (String(e).includes("tool_choice")) {
      json = await post(apiKey, {
        ...base,
        tool_choice: { type: "any" },
        messages: [{ role: "user", content: `${opts.prompt}\n\nResponda chamando a ferramenta ${opts.toolName}.` }],
      });
    } else throw e;
  }

  const block = (json.content ?? []).find((c: any) => c.type === "tool_use" && c.name === opts.toolName);
  if (!block) throw new Error("O modelo não retornou a estrutura esperada.");
  const parsed = opts.validator.safeParse(block.input);
  if (!parsed.success) {
    throw new Error(`Resposta da IA fora do formato: ${parsed.error.issues.slice(0, 3).map((i) => `${i.path.join(".")}: ${i.message}`).join("; ")}`);
  }
  return { data: parsed.data, model: json.model ?? model };
}
