// Estratégia editorial ("Head de Conteúdo"): cada publicação tem uma função clara no crescimento do perfil.
// O texto da estratégia é editável por marca (Configurações → Automação → Estratégia editorial).
//
// POSICIONAMENTO ATUAL (out/2026): "Diretriz central de conteúdo — Conecta Aqui".
// Conteúdo prático e útil para o público geral (celular, Wi-Fi, TV, apps, segurança, escolha de plano).
// A marca conquista confiança pela utilidade; a venda é consequência e nunca o centro.

/** Versão da diretriz — usada pela migração única que aplica o novo posicionamento às marcas já cadastradas. */
export const CONTENT_DIRECTIVE_VERSION = "utilidade-2026-10";

/** Os 15 temas prioritários da diretriz (usados no planejamento, nas ideias, no Radar e nos roteiros). */
export const PRIORITY_THEMES = [
  "Como liberar espaço no celular com segurança",
  "Como conectar o celular à televisão",
  "Como melhorar o sinal do Wi-Fi em casa",
  "Como descobrir se a internet está lenta",
  "Como economizar dados móveis",
  "Como conectar dispositivos ao Wi-Fi",
  "Como resolver problemas comuns de conexão",
  "Como compartilhar a internet do celular",
  "Como identificar dispositivos conectados à rede",
  "Como assistir a vídeos e conteúdos na TV",
  "Como proteger o WhatsApp e as contas pessoais",
  "Como usar melhor Android, iPhone, computador e Smart TV",
  "Como escolher um plano de internet adequado às necessidades da família",
  "Como entender velocidade, cobertura, franquia, fibra óptica e diferenças entre planos",
  "Quais fatores podem afetar a qualidade da conexão dentro de casa",
];

/** Referências editoriais públicas (inspiração de formato e abordagem — nunca copiar). */
export const EDITORIAL_REFERENCES = [
  "Jornada Top (@jornadatop): ganchos, dicas rápidas e demonstrações de truques de celular",
  "TechTudo (@techtudo): tutoriais e soluções para dúvidas cotidianas",
  "Canaltech (@canaltech): novidades de dispositivos e serviços digitais",
  "TecMundo (@tecmundo): curiosidades, segurança e tecnologia acessível",
  "Olhar Digital (@olhardigital): tendências, conectividade e novidades",
  "Tecnoblog (@tecnoblog): telecomunicações, internet, celulares e serviços",
];

/** Regras de precisão técnica que valem para TODA geração de texto (planejamento, legendas, roteiros, radar). */
export const ACCURACY_RULES = `PRECISÃO TÉCNICA (inegociável — nunca sacrifique a precisão para ganhar visualizações)
- Escreva sempre "Wi-Fi" (nunca a forma fonética como "uái-fái"), inclusive na fala do vídeo: a voz do personagem já pronuncia em inglês automaticamente.
- Não prometa que liberar armazenamento deixa a internet mais rápida. Diferencie sempre: desempenho do celular, falta de espaço, sinal do Wi-Fi, dados móveis e velocidade contratada da conexão.
- Não recomende aplicativos de limpeza, "otimizadores", "aceleradores de internet" ou antivírus duvidosos; não mande desativar recursos essenciais (atualizações, segurança, backup, localização de emergência) nem procedimentos que possam causar perda de dados (sem antes orientar o backup).
- Quando o caminho mudar entre Android e iPhone (ou entre marcas de celular/TV e versões de sistema), diga isso e mostre os dois caminhos, ou deixe claro para qual sistema é a dica. Se os nomes dos menus variam por fabricante, avise ("o nome pode mudar conforme a marca").
- Use nomes de menus e recursos que realmente existem. Na dúvida sobre um passo, descreva de forma genérica e segura em vez de inventar.
- Não invente dados, estatísticas, preços, rankings, velocidades de plano ou promessas comerciais.`;

export const FUNNEL_GUIDE: Record<string, string> = {
  ATTRACTION:
    "ATRAÇÃO — alcançar quem ainda não conhece a marca com uma dica que todo mundo quer saber (truque de celular, Wi-Fi melhor, celular na TV, espaço liberado). Começa por um problema real ou uma descoberta curiosa; precisa fazer sentido para um desconhecido e dar vontade de SALVAR e COMPARTILHAR. CTA: salvar para usar depois, mandar para quem precisa.",
  AUTHORITY:
    "AUTORIDADE — mostrar que a marca entende de conexão: explicar com simplicidade e precisão velocidade, cobertura, franquia, fibra óptica, Wi-Fi, roteador, o que afeta a internet dentro de casa e como escolher um plano para a família. Nada de jargão sem explicação nem dados inventados. CTA: salvar, comentar a dúvida.",
  RELATIONSHIP:
    "RELACIONAMENTO — gerar identificação e conversa a partir de situações que o público vive com a tecnologia (o celular sem espaço, a senha do Wi-Fi, o parente que pede ajuda com a TV). Perguntas genuínas, enquetes, 'você sabia?', pedidos de dúvidas para os próximos vídeos. CTA: comentar, responder, sugerir a próxima dica.",
  CONVERSION:
    "CONVERSÃO — de forma leve e natural, quando o assunto permitir: ligar a dica à qualidade da conexão, à cobertura ou à escolha do plano e convidar a comparar opções para o próprio endereço ou tirar dúvidas no WhatsApp. Nunca citar preço, velocidade de plano, desconto, promoção ou prazo (a menos que exista uma oferta aprovada fornecida explicitamente).",
};

export const DEFAULT_CONTENT_STRATEGY = `DIRETRIZ CENTRAL DE CONTEÚDO — CONECTA AQUI
A Conecta Aqui é um buscador de planos de internet e serviços de telecomunicações no Brasil. O conteúdo deve alcançar o público geral, incluindo pessoas que não dominam tecnologia, mas usam celular, internet, Wi-Fi, televisão, aplicativos e serviços digitais todos os dias.
Não concentre a estratégia em inteligência artificial, marketing digital ou ferramentas para profissionais. A prioridade é criar conteúdos práticos que ajudem as pessoas a resolver problemas comuns e descobrir funcionalidades úteis.

TEMAS PRIORITÁRIOS
${PRIORITY_THEMES.map((t, i) => `${i + 1}. ${t}.`).join("\n")}

REFERÊNCIAS DE CONTEÚDO (formato e abordagem; nunca copie conteúdos, roteiros ou identidade visual)
${EDITORIAL_REFERENCES.map((r) => `- ${r}.`).join("\n")}

REGRAS PARA CRIAÇÃO
- Cada publicação começa com um problema real, uma dúvida frequente ou uma descoberta que desperte curiosidade.
- Demonstre o procedimento sempre que possível. Linguagem simples, passos curtos e numerados, textos legíveis na tela.
- Quando houver diferenças entre Android e iPhone, ou entre marcas e modelos de TV, explique a compatibilidade e crie versões específicas quando necessário.
- Não prometa que liberar armazenamento deixará a internet mais rápida. Diferencie desempenho do celular, falta de espaço, Wi-Fi, dados móveis e velocidade da conexão.
- Não recomende aplicativos de limpeza duvidosos, desativação de recursos essenciais ou procedimentos que possam causar perda de dados.
- Verifique informações técnicas e use fontes confiáveis.

CONEXÃO COM O NEGÓCIO
- A Conecta Aqui deve ser reconhecida como a marca que ajuda as pessoas a aproveitar melhor a tecnologia e a internet.
- Quando o assunto permitir, conecte a dica a qualidade da conexão, cobertura, Wi-Fi residencial ou escolha de planos — de forma natural. Nem todo conteúdo precisa vender ou mencionar planos de internet.
- Objetivo: conquistar confiança pela utilidade e tornar a Conecta Aqui referência para quem quer encontrar e comparar opções de conectividade.
- Crie conteúdos com potencial de alcance, compartilhamento e salvamento, mas nunca sacrifique a precisão técnica para conseguir visualizações.

FORMATOS
- Reels: dica demonstrada em 15–45s (gancho nos 2 primeiros segundos, passos na tela, resultado).
- Carrossel: passo a passo salvável (capa com o problema, 1 passo por slide, cuidado/observação, fechamento).
- Imagem única: dica rápida, "você sabia?", mito ou verdade, checklist curto.

REGRAS GERAIS
- Nenhum post existe apenas para "manter frequência": se não houver função clara, troque a ideia.
- Não coloque conteúdos parecidos em sequência; revisite os temas prioritários com ângulos, aparelhos e situações novas.
- Não cite preços, velocidades de plano ou promoções; não faça afirmações comparativas ("o maior", "o melhor") sem comprovação.`;

export function strategyText(custom: string | null | undefined) {
  return (custom?.trim() || DEFAULT_CONTENT_STRATEGY).slice(0, 6000);
}
