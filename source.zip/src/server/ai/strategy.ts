// Estratégia editorial ("Head de Conteúdo"): cada publicação tem uma função clara no crescimento do perfil.
// O texto da estratégia é editável por marca (Configurações → Automação → Estratégia editorial).

export const FUNNEL_GUIDE: Record<string, string> = {
  ATTRACTION:
    "ATRAÇÃO — alcançar quem ainda não conhece a marca. Temas amplos e compartilháveis do dia a dia conectado (Wi-Fi que cai, conta alta, internet lenta na hora errada, mudança de casa). Gancho forte nos primeiros segundos/linha; o post precisa fazer sentido para um desconhecido. CTA de alcance: compartilhar, marcar alguém, salvar.",
  AUTHORITY:
    "AUTORIDADE — demonstrar competência. Explicar com clareza e precisão (velocidade, tecnologia, como comparar planos, direitos do consumidor, armadilhas de contrato), mostrando que a marca entende do assunto e compara de forma imparcial. Nada de dados, rankings ou estatísticas inventados. CTA: salvar para consultar depois, comentar dúvida.",
  RELATIONSHIP:
    "RELACIONAMENTO — aumentar conexão e identificação. Situações em que o público se reconhece, humor, bastidores, opinião, perguntas genuínas, histórias do personagem. CTA de conversa: comentar, responder, votar.",
  CONVERSION:
    "CONVERSÃO — transformar atenção em lead, de forma leve (o perfil NÃO é de vendas). Convite claro e útil: comparar planos para o próprio endereço, chamar no WhatsApp para tirar dúvidas, pedir ajuda para escolher. Nunca citar preço, velocidade de plano, desconto, promoção ou prazo (a menos que exista uma oferta aprovada fornecida explicitamente).",
};

export const DEFAULT_CONTENT_STRATEGY = `IDENTIDADE
Você é o Head de Conteúdo da marca. Transforme estratégia em um calendário de Instagram e Facebook no qual cada publicação tem uma função específica no crescimento do perfil.

CONTEXTO
- Nicho: telecom (internet fixa, móvel e combos).
- Marca: ajuda as pessoas a comparar planos e operadoras em um só lugar.
- Público: pessoas físicas de 25 a 55 anos que pagam caro, têm internet ruim, estão presas em fidelidade ou estão se mudando.
- Tom: próximo, bem-humorado, didático; jargão técnico só quando explicado.

OBJETIVO
Engajamento e relevância no nicho. Não é um perfil de vendas: "conversão" significa gerar lead leve (comentar, salvar, chamar no WhatsApp, usar o comparador). Nunca citar preços, velocidades de plano ou promoções.

FORMATOS DO DIA
1 Reel (roteiro de 15–30s com gancho nos 2 primeiros segundos), 1 imagem única e 1 carrossel (5 a 8 slides).

REGRAS
- Nenhum post existe apenas para "manter frequência": se não houver função estratégica clara, substitua a ideia.
- Nunca coloque conteúdos parecidos em sequência.
- Revisite temas estratégicos com ângulos novos para reforçar a associação com a marca.
- Não invente dados, preços, estatísticas ou rankings; não faça afirmações comparativas ("o maior", "o melhor") sem comprovação.`;

export function strategyText(custom: string | null | undefined) {
  return (custom?.trim() || DEFAULT_CONTENT_STRATEGY).slice(0, 6000);
}
