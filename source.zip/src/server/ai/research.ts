// Chamada ao Claude com a ferramenta oficial de busca na web (server tool) + saída estruturada.
// O modelo pesquisa quantas vezes precisar (até maxSearches) e, no fim, chama a ferramenta de registro.
import type { z } from "zod";
import { env } from "@/lib/env";
import { getSecret, MissingCredentialError } from "@/server/integrations";
import { post } from "./anthropic";

type JsonSchema = Record<string, unknown>;

export async function researchStructured<T>(opts: {
  orgId: string;
  system: string;
  prompt: string;
  toolName: string;
  toolDescription: string;
  schema: JsonSchema;
  validator: z.ZodType<T, z.ZodTypeDef, any>;
  maxSearches?: number;
  maxTokens?: number;
  model?: string;
}): Promise<{ data: T; model: string; searches: number; sources: string[] }> {
  const apiKey = await getSecret(opts.orgId, "ANTHROPIC_API_KEY");
  if (!apiKey) throw new MissingCredentialError("chave da Anthropic (ANTHROPIC_API_KEY)");
  const model = opts.model || env.ai.anthropicModel;
  const saveTool = { name: opts.toolName, description: opts.toolDescription, input_schema: opts.schema };
  const searchTool = {
    type: "web_search_20250305",
    name: "web_search",
    max_uses: opts.maxSearches ?? 15,
    user_location: { type: "approximate", country: "BR", timezone: "America/Sao_Paulo" },
  };
  const messages: any[] = [{ role: "user", content: opts.prompt }];
  let searches = 0;
  const sources = new Set<string>();
  let useSearch = true; // a organização tem a busca disponível
  let forceSave = false;

  const collect = (content: any[]) => {
    for (const b of content ?? []) {
      if (b.type === "server_tool_use" && b.name === "web_search") searches++;
      if (b.type === "web_search_tool_result" && Array.isArray(b.content)) for (const r of b.content) if (r?.url) sources.add(r.url);
    }
  };
  const findSave = (content: any[]) => (content ?? []).find((c: any) => c.type === "tool_use" && c.name === opts.toolName);

  let json: any;
  for (let turn = 0; turn < 5; turn++) {
    try {
      json = await post(apiKey, {
        model,
        max_tokens: opts.maxTokens ?? 8000,
        system: opts.system,
        tools: useSearch ? [searchTool, saveTool] : [saveTool],
        tool_choice: forceSave || !useSearch ? { type: "tool", name: opts.toolName } : { type: "auto" },
        messages,
      });
    } catch (e) {
      // Se a busca na web não estiver habilitada na organização da Anthropic, segue sem ela.
      if (useSearch && turn === 0 && /web_search|server tool|tool type/i.test(String(e))) {
        useSearch = false;
        continue;
      }
      throw e;
    }
    collect(json.content);
    if (findSave(json.content)) break;
    messages.push({ role: "assistant", content: json.content });
    if (json.stop_reason === "pause_turn") continue; // busca longa: o modelo continua de onde parou
    messages.push({ role: "user", content: `Agora registre o resultado chamando a ferramenta ${opts.toolName}.` });
    forceSave = true; // força o registro na próxima volta
  }

  const block = findSave(json?.content);
  if (!block) throw new Error("A IA não registrou o resultado da pesquisa.");
  const parsed = opts.validator.safeParse(block.input);
  if (!parsed.success) throw new Error(`Resposta da IA fora do formato: ${parsed.error.issues.slice(0, 3).map((i) => `${i.path.join(".")}: ${i.message}`).join("; ")}`);
  return { data: parsed.data, model: json.model ?? model, searches, sources: [...sources] };
}
