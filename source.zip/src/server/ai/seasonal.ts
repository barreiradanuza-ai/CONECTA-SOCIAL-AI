// Datas comemorativas brasileiras relevantes para o público (calculadas, não inventadas).
// Usadas pelo agente editorial para o pilar "Sazonal". Eventos noticiosos NÃO entram aqui.

export type SeasonalDate = { date: string; name: string; angle: string };

function nthWeekdayOfMonth(year: number, month: number, weekday: number, n: number) {
  const first = new Date(Date.UTC(year, month - 1, 1)).getUTCDay();
  const day = 1 + ((weekday - first + 7) % 7) + (n - 1) * 7;
  return day;
}

function lastWeekdayOfMonth(year: number, month: number, weekday: number) {
  const last = new Date(Date.UTC(year, month, 0));
  const diff = (last.getUTCDay() - weekday + 7) % 7;
  return last.getUTCDate() - diff;
}

const pad = (n: number) => String(n).padStart(2, "0");

export function seasonalDates(year: number): SeasonalDate[] {
  const d = (m: number, day: number) => `${year}-${pad(m)}-${pad(day)}`;
  const blackFriday = nthWeekdayOfMonth(year, 11, 5, 4);
  return [
    { date: d(1, 1), name: "Ano Novo", angle: "metas digitais e casa conectada para o novo ano" },
    { date: d(2, 1), name: "Volta às aulas (período)", angle: "internet estável para estudos e aulas online" },
    { date: d(3, 15), name: "Dia do Consumidor", angle: "direitos e escolha consciente de planos de internet" },
    { date: d(4, 7), name: "Dia Mundial da Saúde", angle: "bem-estar digital e uso equilibrado de telas" },
    { date: d(5, 1), name: "Dia do Trabalho", angle: "home office produtivo com boa conexão" },
    { date: d(5, nthWeekdayOfMonth(year, 5, 0, 2)), name: "Dia das Mães", angle: "família conectada, chamadas de vídeo sem travar" },
    { date: d(5, 17), name: "Dia Mundial das Telecomunicações", angle: "como a conectividade mudou o dia a dia" },
    { date: d(6, 12), name: "Dia dos Namorados", angle: "maratona de filmes e séries a dois sem travar" },
    { date: d(8, nthWeekdayOfMonth(year, 8, 0, 2)), name: "Dia dos Pais", angle: "jogos, esportes e streaming em família" },
    { date: d(8, 15), name: "Dia da Informática", angle: "curiosidades de tecnologia e dicas de rede" },
    { date: d(8, 29), name: "Dia do Gamer", angle: "latência, estabilidade e velocidade para jogos online" },
    { date: d(9, 15), name: "Dia do Cliente", angle: "atendimento consultivo e acompanhamento até a instalação" },
    { date: d(10, 12), name: "Dia das Crianças", angle: "segurança digital e controle parental no Wi-Fi" },
    { date: d(11, blackFriday), name: "Black Friday", angle: "comparar antes de contratar; atenção a condições" },
    { date: d(12, 25), name: "Natal", angle: "casa cheia, muitos dispositivos conectados" },
    { date: d(12, 31), name: "Réveillon", angle: "retrospectiva e planejamento da casa conectada" },
    { date: d(11, lastWeekdayOfMonth(year, 11, 1)), name: "Cyber Monday", angle: "compras online seguras e rápidas" },
  ];
}

export function seasonalInRange(start: Date, end: Date): SeasonalDate[] {
  const years = new Set([start.getUTCFullYear(), end.getUTCFullYear()]);
  const s = start.toISOString().slice(0, 10);
  const e = end.toISOString().slice(0, 10);
  return [...years].flatMap(seasonalDates).filter((x) => x.date >= s && x.date <= e).sort((a, b) => a.date.localeCompare(b.date));
}
