import type { Network } from "@prisma/client";
import { db } from "@/lib/db";
import { env } from "@/lib/env";
import { randomCode } from "@/lib/crypto";

export function waMeLink(phoneE164: string, message: string) {
  const phone = phoneE164.replace(/\D/g, "");
  return `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
}

export function trackingUrl(code: string) {
  return `${env.appUrl}/r/${code}`;
}

export async function createTrackingLink(input: { orgId: string; brandId: string; postId?: string; campaignId?: string | null; network?: Network; label?: string; message?: string }) {
  for (let i = 0; i < 5; i++) {
    try {
      return await db.trackingLink.create({ data: { ...input, code: randomCode(7) } });
    } catch (e: any) {
      if (e?.code !== "P2002") throw e; // colisão de código: tenta outro
    }
  }
  throw new Error("Não foi possível gerar link de rastreamento.");
}

/** Link "da bio" da marca (um por marca), usado nas legendas do Instagram. */
export async function bioLink(orgId: string, brandId: string) {
  const existing = await db.trackingLink.findFirst({ where: { brandId, label: "bio", postId: null } });
  return existing ?? createTrackingLink({ orgId, brandId, label: "bio" });
}

/** Mensagem inicial com referência de origem, para atribuição no atendimento/CRM. */
export function messageWithRef(base: string, code: string) {
  return `${base}\n\n(ref: ${code})`;
}
