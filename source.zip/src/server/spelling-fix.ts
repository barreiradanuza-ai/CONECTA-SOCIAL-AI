// Corrige textos já gravados com a grafia fonética ("Uái-Fái") para "Wi-Fi". Roda no início do worker;
// é barato e idempotente (só mexe no que ainda estiver errado). A gravação passa pelo db, que aplica a grafia.
import { db } from "@/lib/db";
import { fixDeep } from "@/lib/spelling";

const POST_FIELDS = ["theme", "objective", "angle", "hook", "centralIdea", "ctaPlan", "strategyNote", "title", "subtitle", "cta", "hashtags", "imagePrompt", "videoSpeech", "artDirection", "slides", "reelScript", "episodeSummary"] as const;

export async function fixStoredSpelling(): Promise<string> {
  const postIds = await db.$queryRaw<{ id: string }[]>`SELECT id FROM "Post" p WHERE p::text ~* 'u[áa]i[ -]?f[áa]i'`;
  for (const { id } of postIds) {
    const p = await db.post.findUnique({ where: { id }, select: Object.fromEntries(POST_FIELDS.map((f) => [f, true])) as any });
    if (!p) continue;
    const data: Record<string, unknown> = {};
    for (const f of POST_FIELDS) if ((p as any)[f] !== null && (p as any)[f] !== undefined) data[f] = (p as any)[f];
    await db.post.update({ where: { id }, data: fixDeep(data) as any });
  }
  const targetIds = await db.$queryRaw<{ id: string }[]>`SELECT id FROM "PostTarget" WHERE caption ~* 'u[áa]i[ -]?f[áa]i'`;
  for (const { id } of targetIds) {
    const t = await db.postTarget.findUnique({ where: { id }, select: { caption: true } });
    if (t?.caption) await db.postTarget.update({ where: { id }, data: { caption: t.caption } });
  }
  return postIds.length || targetIds.length ? `grafia "Wi-Fi" corrigida em ${postIds.length} publicação(ões) e ${targetIds.length} legenda(s)` : "";
}
