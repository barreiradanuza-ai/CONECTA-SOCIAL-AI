// Fluxo oficial de autorização (Facebook Login / Facebook Login for Business).
// Obtém token de usuário de longa duração e, a partir dele, tokens de Página (sem expiração)
// e as contas profissionais do Instagram vinculadas às Páginas.
import { env } from "@/lib/env";
import { graph } from "./graph";

export const META_SCOPES = [
  "pages_show_list",
  "pages_read_engagement",
  "pages_manage_posts",
  "read_insights",
  "instagram_basic",
  "instagram_content_publish",
  "instagram_manage_insights",
  "business_management",
];

export function redirectUri() {
  return `${env.appUrl}/api/meta/oauth/callback`;
}

export function metaConfigured() {
  return !!(env.meta.appId && env.meta.appSecret);
}

export function buildAuthUrl(state: string) {
  const u = new URL(`https://www.facebook.com/${env.meta.graphVersion}/dialog/oauth`);
  u.searchParams.set("client_id", env.meta.appId!);
  u.searchParams.set("redirect_uri", redirectUri());
  u.searchParams.set("state", state);
  u.searchParams.set("response_type", "code");
  if (env.meta.loginConfigId) u.searchParams.set("config_id", env.meta.loginConfigId);
  else u.searchParams.set("scope", META_SCOPES.join(","));
  return u.toString();
}

export async function exchangeCode(code: string) {
  const short = await graph<{ access_token: string; expires_in?: number }>("oauth/access_token", {
    params: { client_id: env.meta.appId, client_secret: env.meta.appSecret, redirect_uri: redirectUri(), code },
  });
  const long = await graph<{ access_token: string; expires_in?: number }>("oauth/access_token", {
    params: { grant_type: "fb_exchange_token", client_id: env.meta.appId, client_secret: env.meta.appSecret, fb_exchange_token: short.access_token },
  });
  return { userToken: long.access_token, expiresAt: long.expires_in ? new Date(Date.now() + long.expires_in * 1000) : null };
}

export type DiscoveredPage = {
  id: string;
  name: string;
  accessToken: string;
  picture?: string;
  tasks?: string[];
  instagram?: { id: string; username?: string; name?: string; picture?: string } | null;
};

export async function discoverPages(userToken: string): Promise<DiscoveredPage[]> {
  const pages: DiscoveredPage[] = [];
  let next: string | undefined = "me/accounts";
  const params = {
    fields: "id,name,access_token,tasks,picture{url},instagram_business_account{id,username,name,profile_picture_url}",
    limit: 50,
  };
  while (next) {
    const res: any = await graph(next, { token: userToken, params: next === "me/accounts" ? params : undefined });
    for (const p of res.data ?? []) {
      pages.push({
        id: p.id,
        name: p.name,
        accessToken: p.access_token,
        picture: p.picture?.data?.url,
        tasks: p.tasks,
        instagram: p.instagram_business_account
          ? {
              id: p.instagram_business_account.id,
              username: p.instagram_business_account.username,
              name: p.instagram_business_account.name,
              picture: p.instagram_business_account.profile_picture_url,
            }
          : null,
      });
    }
    next = res.paging?.next;
  }
  return pages;
}

/** Diagnóstico de token (validade e escopos concedidos). */
export async function debugToken(token: string) {
  const appToken = `${env.meta.appId}|${env.meta.appSecret}`;
  const res = await graph<{ data: { is_valid: boolean; expires_at?: number; scopes?: string[]; error?: { message: string } } }>("debug_token", {
    params: { input_token: token, access_token: appToken },
  });
  return res.data;
}
