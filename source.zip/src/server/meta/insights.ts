// Coleta de métricas pelas APIs oficiais. As métricas disponíveis mudam entre versões
// (ex.: "impressions" foi substituída por "views"), então a coleta é tolerante: pede o
// conjunto atual e, se a API recusar, tenta métrica a métrica e guarda o que vier.
import { graph, GraphError } from "./graph";

export type Metrics = {
  views?: number;
  reach?: number;
  likes?: number;
  comments?: number;
  shares?: number;
  saves?: number;
  interactions?: number;
  clicks?: number;
  raw: Record<string, unknown>;
};

async function insightsTolerant(objectId: string, token: string, metrics: string[], extra: Record<string, string> = {}) {
  const out: Record<string, number> = {};
  const read = (data: any[]) => {
    for (const m of data ?? []) {
      const v = m.values?.[0]?.value ?? m.total_value?.value;
      if (typeof v === "number") out[m.name] = v;
      else if (v && typeof v === "object") out[m.name] = Object.values(v as Record<string, number>).reduce((a, b) => a + (Number(b) || 0), 0);
    }
  };
  try {
    const r = await graph<{ data: any[] }>(`${objectId}/insights`, { token, params: { metric: metrics.join(","), ...extra } });
    read(r.data);
  } catch (e) {
    if (e instanceof GraphError && e.authError) throw e;
    for (const m of metrics) {
      try {
        const r = await graph<{ data: any[] }>(`${objectId}/insights`, { token, params: { metric: m, ...extra } });
        read(r.data);
      } catch {
        /* métrica indisponível para este objeto */
      }
    }
  }
  return out;
}

export async function instagramMediaMetrics(mediaId: string, token: string, format: string): Promise<Metrics> {
  const metrics =
    format === "STORY"
      ? ["views", "reach", "replies", "shares", "total_interactions", "follows", "profile_visits"]
      : format === "REEL"
        ? ["views", "reach", "likes", "comments", "shares", "saved", "total_interactions"]
        : ["views", "reach", "likes", "comments", "shares", "saved", "total_interactions", "profile_visits", "follows"];
  const ins = await insightsTolerant(mediaId, token, metrics);
  let fields: any = {};
  try {
    fields = await graph(mediaId, { token, params: { fields: "like_count,comments_count" } });
  } catch {
    /* ignore */
  }
  return {
    views: ins.views,
    reach: ins.reach,
    likes: ins.likes ?? fields.like_count,
    comments: ins.comments ?? ins.replies ?? fields.comments_count,
    shares: ins.shares,
    saves: ins.saved,
    interactions: ins.total_interactions,
    raw: { ...ins, ...fields },
  };
}

export async function facebookPostMetrics(postId: string, token: string): Promise<Metrics> {
  let fields: any = {};
  try {
    fields = await graph(postId, {
      token,
      params: { fields: "reactions.summary(total_count).limit(0),comments.summary(total_count).limit(0),shares" },
    });
  } catch (e) {
    if (e instanceof GraphError && e.authError) throw e;
  }
  const ins = await insightsTolerant(postId, token, ["post_media_view", "post_total_media_view_unique", "post_clicks", "post_reactions_by_type_total"]);
  const likes = fields.reactions?.summary?.total_count ?? ins.post_reactions_by_type_total;
  const comments = fields.comments?.summary?.total_count;
  const shares = fields.shares?.count;
  const interactions = [likes, comments, shares].some((x) => typeof x === "number") ? (likes ?? 0) + (comments ?? 0) + (shares ?? 0) : undefined;
  return {
    views: ins.post_media_view,
    reach: ins.post_total_media_view_unique,
    likes,
    comments,
    shares,
    interactions,
    clicks: ins.post_clicks,
    raw: { ...ins, reactions: likes, comments, shares },
  };
}

export async function accountFollowers(network: "INSTAGRAM" | "FACEBOOK", id: string, token: string) {
  if (network === "INSTAGRAM") {
    const r = await graph<{ followers_count?: number; media_count?: number }>(id, { token, params: { fields: "followers_count,media_count" } });
    return { followers: r.followers_count, mediaCount: r.media_count, raw: r };
  }
  const r = await graph<{ followers_count?: number; fan_count?: number }>(id, { token, params: { fields: "followers_count,fan_count" } });
  return { followers: r.followers_count ?? r.fan_count, mediaCount: undefined, raw: r };
}
