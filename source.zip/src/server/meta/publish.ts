// Publicação via APIs oficiais: Instagram Content Publishing e Facebook Pages API.
import { graph, GraphError, sleep } from "./graph";

export type PublishMedia = { kind: "IMAGE" | "VIDEO"; url: string };
export type PublishInput = {
  format: "FEED_IMAGE" | "CAROUSEL" | "STORY" | "REEL";
  caption: string;
  media: PublishMedia[]; // na ordem
  coverUrl?: string;
  existingContainerId?: string | null;
};
export type PublishResult =
  | { status: "published"; externalId: string; permalink?: string; containerId?: string }
  | { status: "processing"; containerId: string };

// ───────────────────────── Instagram ─────────────────────────

async function igContainerStatus(containerId: string, token: string) {
  return graph<{ status_code: string; status?: string }>(containerId, { token, params: { fields: "status_code,status" } });
}

async function igWaitReady(containerId: string, token: string, maxMs: number): Promise<"FINISHED" | "IN_PROGRESS"> {
  const start = Date.now();
  let delay = 1500;
  while (Date.now() - start < maxMs) {
    const s = await igContainerStatus(containerId, token);
    if (s.status_code === "FINISHED" || s.status_code === "PUBLISHED") return "FINISHED";
    if (s.status_code === "ERROR" || s.status_code === "EXPIRED") {
      throw new GraphError(`Container do Instagram com status ${s.status_code}: ${s.status ?? ""}`, 400);
    }
    await sleep(delay);
    delay = Math.min(delay * 1.6, 10_000);
  }
  return "IN_PROGRESS";
}

export async function igPublishingQuota(igUserId: string, token: string) {
  try {
    const r = await graph<{ data: { quota_usage: number; config?: { quota_total: number } }[] }>(`${igUserId}/content_publishing_limit`, {
      token,
      params: { fields: "quota_usage,config" },
    });
    const d = r.data?.[0];
    return d ? { used: d.quota_usage, total: d.config?.quota_total ?? 100 } : null;
  } catch {
    return null;
  }
}

export async function publishInstagram(igUserId: string, token: string, input: PublishInput): Promise<PublishResult> {
  let containerId = input.existingContainerId ?? null;

  if (!containerId) {
    if (input.format === "CAROUSEL") {
      if (input.media.length < 2 || input.media.length > 10) throw new GraphError("Carrossel precisa de 2 a 10 itens.", 400);
      const children: string[] = [];
      for (const m of input.media) {
        const c = await graph<{ id: string }>(`${igUserId}/media`, {
          method: "POST",
          token,
          body: m.kind === "VIDEO" ? { media_type: "VIDEO", video_url: m.url, is_carousel_item: true } : { image_url: m.url, is_carousel_item: true },
        });
        children.push(c.id);
      }
      for (const c of children) await igWaitReady(c, token, 120_000);
      const parent = await graph<{ id: string }>(`${igUserId}/media`, {
        method: "POST",
        token,
        body: { media_type: "CAROUSEL", children: children.join(","), caption: input.caption },
      });
      containerId = parent.id;
    } else if (input.format === "STORY") {
      const m = input.media[0];
      const c = await graph<{ id: string }>(`${igUserId}/media`, {
        method: "POST",
        token,
        body: m.kind === "VIDEO" ? { media_type: "STORIES", video_url: m.url } : { media_type: "STORIES", image_url: m.url },
      });
      containerId = c.id;
    } else if (input.format === "REEL") {
      const m = input.media.find((x) => x.kind === "VIDEO");
      if (!m) throw new GraphError("Reels exige um arquivo de vídeo.", 400);
      const c = await graph<{ id: string }>(`${igUserId}/media`, {
        method: "POST",
        token,
        body: { media_type: "REELS", video_url: m.url, caption: input.caption, share_to_feed: true, ...(input.coverUrl ? { cover_url: input.coverUrl } : {}) },
      });
      containerId = c.id;
    } else {
      const c = await graph<{ id: string }>(`${igUserId}/media`, { method: "POST", token, body: { image_url: input.media[0].url, caption: input.caption } });
      containerId = c.id;
    }
  }

  const ready = await igWaitReady(containerId, token, input.format === "REEL" ? 90_000 : 60_000);
  if (ready === "IN_PROGRESS") return { status: "processing", containerId };

  const pub = await graph<{ id: string }>(`${igUserId}/media_publish`, { method: "POST", token, body: { creation_id: containerId } });
  let permalink: string | undefined;
  try {
    const info = await graph<{ permalink?: string }>(pub.id, { token, params: { fields: "permalink" } });
    permalink = info.permalink;
  } catch {
    /* permalink indisponível para stories em alguns casos */
  }
  return { status: "published", externalId: pub.id, permalink, containerId };
}

/** Reconciliação: se o container já foi publicado (ex.: timeout na resposta), localiza a mídia. */
export async function igReconcile(igUserId: string, token: string, containerId: string, caption: string): Promise<{ externalId: string; permalink?: string } | null> {
  try {
    const s = await igContainerStatus(containerId, token);
    if (s.status_code !== "PUBLISHED") return null;
    const recent = await graph<{ data: { id: string; caption?: string; permalink?: string }[] }>(`${igUserId}/media`, {
      token,
      params: { fields: "id,caption,permalink,timestamp", limit: 10 },
    });
    const head = caption.slice(0, 60);
    const match = recent.data.find((m) => (m.caption ?? "").startsWith(head));
    return match ? { externalId: match.id, permalink: match.permalink } : null;
  } catch {
    return null;
  }
}

// ───────────────────────── Facebook (Página) ─────────────────────────

async function fbPermalink(id: string, token: string) {
  try {
    const r = await graph<{ permalink_url?: string }>(id, { token, params: { fields: "permalink_url" } });
    return r.permalink_url;
  } catch {
    return undefined;
  }
}

export async function publishFacebook(pageId: string, token: string, input: PublishInput): Promise<PublishResult> {
  if (input.format === "FEED_IMAGE") {
    const r = await graph<{ id: string; post_id?: string }>(`${pageId}/photos`, {
      method: "POST",
      token,
      body: { url: input.media[0].url, message: input.caption, published: true },
    });
    const id = r.post_id ?? r.id;
    return { status: "published", externalId: id, permalink: await fbPermalink(id, token) };
  }

  if (input.format === "CAROUSEL") {
    const ids: string[] = [];
    for (const m of input.media.filter((x) => x.kind === "IMAGE")) {
      const p = await graph<{ id: string }>(`${pageId}/photos`, { method: "POST", token, body: { url: m.url, published: false } });
      ids.push(p.id);
    }
    const r = await graph<{ id: string }>(`${pageId}/feed`, {
      method: "POST",
      token,
      body: { message: input.caption, attached_media: ids.map((media_fbid) => ({ media_fbid })) },
    });
    return { status: "published", externalId: r.id, permalink: await fbPermalink(r.id, token) };
  }

  if (input.format === "STORY") {
    const m = input.media[0];
    if (m.kind === "VIDEO") throw new GraphError("Stories em vídeo no Facebook ainda não implementados neste app.", 400);
    const p = await graph<{ id: string }>(`${pageId}/photos`, { method: "POST", token, body: { url: m.url, published: false } });
    const r = await graph<{ post_id?: string; id?: string; success?: boolean }>(`${pageId}/photo_stories`, { method: "POST", token, body: { photo_id: p.id } });
    return { status: "published", externalId: r.post_id ?? r.id ?? p.id };
  }

  // REEL — fluxo de upload em 3 fases com file_url hospedado
  const video = input.media.find((x) => x.kind === "VIDEO");
  if (!video) throw new GraphError("Reels exige um arquivo de vídeo.", 400);
  const start = await graph<{ video_id: string; upload_url: string }>(`${pageId}/video_reels`, { method: "POST", token, body: { upload_phase: "start" } });
  const up = await fetch(start.upload_url, { method: "POST", headers: { Authorization: `OAuth ${token}`, file_url: video.url }, signal: AbortSignal.timeout(120_000) });
  if (!up.ok) throw new GraphError(`Falha no upload do vídeo (${up.status}): ${(await up.text()).slice(0, 200)}`, up.status);
  await graph(`${pageId}/video_reels`, {
    method: "POST",
    token,
    body: { upload_phase: "finish", video_id: start.video_id, video_state: "PUBLISHED", description: input.caption },
  });
  return { status: "published", externalId: start.video_id, permalink: `https://www.facebook.com/reel/${start.video_id}` };
}

/** Reconciliação no Facebook: procura publicação recente com a mesma mensagem. */
export async function fbReconcile(pageId: string, token: string, caption: string, since: Date): Promise<{ externalId: string; permalink?: string } | null> {
  try {
    const r = await graph<{ data: { id: string; message?: string; permalink_url?: string }[] }>(`${pageId}/published_posts`, {
      token,
      params: { fields: "id,message,permalink_url,created_time", limit: 10, since: Math.floor(since.getTime() / 1000) },
    });
    const head = caption.slice(0, 60);
    const m = r.data.find((p) => (p.message ?? "").startsWith(head));
    return m ? { externalId: m.id, permalink: m.permalink_url } : null;
  } catch {
    return null;
  }
}
