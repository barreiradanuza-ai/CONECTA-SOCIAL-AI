// Cliente da Graph API da Meta (fetch). Tokens nunca são logados.
import crypto from "node:crypto";
import { env } from "@/lib/env";

export class GraphError extends Error {
  constructor(
    message: string,
    public status: number,
    public code?: number,
    public subcode?: number,
    public type?: string,
    public fbtraceId?: string,
  ) {
    super(message);
    this.name = "GraphError";
  }
  /** Erros transitórios que valem nova tentativa automática. */
  get retryable() {
    if (this.status >= 500 || this.status === 429) return true;
    return [1, 2, 4, 17, 32, 341, 368, 613, 9007].includes(this.code ?? -1) || this.subcode === 2207051 /* IG: tente novamente */;
  }
  /** Token inválido/expirado ou permissão revogada. */
  get authError() {
    return this.code === 190 || this.code === 10 || this.code === 200 || (this.code ?? 0) === 102;
  }
}

export function graphBase() {
  return `https://graph.facebook.com/${env.meta.graphVersion}`;
}

function appSecretProof(token: string) {
  const secret = env.meta.appSecret;
  return secret ? crypto.createHmac("sha256", secret).update(token).digest("hex") : undefined;
}

export async function graph<T = any>(
  path: string,
  opts: { method?: "GET" | "POST" | "DELETE"; token?: string; params?: Record<string, string | number | boolean | undefined>; body?: Record<string, unknown>; timeoutMs?: number } = {},
): Promise<T> {
  const url = new URL(path.startsWith("http") ? path : `${graphBase()}/${path.replace(/^\//, "")}`);
  for (const [k, v] of Object.entries(opts.params ?? {})) if (v !== undefined) url.searchParams.set(k, String(v));
  const headers: Record<string, string> = {};
  if (opts.token) {
    headers.Authorization = `Bearer ${opts.token}`;
    const proof = appSecretProof(opts.token);
    if (proof) url.searchParams.set("appsecret_proof", proof);
  }
  let body: string | undefined;
  if (opts.body) {
    headers["Content-Type"] = "application/json";
    body = JSON.stringify(opts.body);
  }
  const res = await fetch(url, { method: opts.method ?? "GET", headers, body, signal: AbortSignal.timeout(opts.timeoutMs ?? 60_000) });
  const text = await res.text();
  let json: any = {};
  try {
    json = text ? JSON.parse(text) : {};
  } catch {
    json = { raw: text };
  }
  if (!res.ok || json.error) {
    const e = json.error ?? {};
    throw new GraphError(e.error_user_msg || e.message || `Graph API HTTP ${res.status}`, res.status, e.code, e.error_subcode, e.type, e.fbtrace_id);
  }
  return json as T;
}

export const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
