// Estado honesto das integrações e da configuração (usado no dashboard e no onboarding).
import type { Brand } from "@prisma/client";
import { db } from "@/lib/db";
import { getSecret } from "@/server/integrations";
import { metaConfigured } from "@/server/meta/oauth";
import { storageDriver } from "@/server/storage";

export async function setupStatus(orgId: string, brand: Brand) {
  const [logos, accounts, whatsapp, automation, anthropic, openai, worker, confirmedColors] = await Promise.all([
    db.mediaAsset.count({ where: { brandId: brand.id, role: { in: ["LOGO_PRIMARY", "LOGO_TRANSPARENT"] } } }),
    db.socialAccount.findMany({ where: { brandId: brand.id } }),
    db.whatsAppConfig.findUnique({ where: { brandId: brand.id } }),
    db.automationSettings.findUnique({ where: { brandId: brand.id } }),
    getSecret(orgId, "ANTHROPIC_API_KEY"),
    getSecret(orgId, "OPENAI_API_KEY"),
    db.taskState.findUnique({ where: { name: "publish.enqueue" } }),
    Promise.resolve(brand.colorsConfirmed),
  ]);
  const workerAlive = !!worker?.lastRunAt && Date.now() - worker.lastRunAt.getTime() < 3 * 60_000;
  const ig = accounts.filter((a) => a.network === "INSTAGRAM");
  const fb = accounts.filter((a) => a.network === "FACEBOOK");
  const steps = [
    { key: "identity", label: "Identidade visual: logotipo e cores confirmadas", done: logos > 0 && confirmedColors, href: "/settings/brand" },
    { key: "ai", label: "Chaves de IA (Anthropic e OpenAI)", done: !!anthropic && !!openai, href: "/settings/integrations" },
    { key: "meta", label: "Facebook e Instagram conectados", done: ig.some((a) => a.status === "ACTIVE") && fb.some((a) => a.status === "ACTIVE"), href: "/settings/accounts" },
    { key: "whatsapp", label: "WhatsApp comercial", done: !!whatsapp?.phoneE164, href: "/settings/whatsapp" },
    { key: "automation", label: "Calendário e regras de automação", done: !!automation?.autopilotEnabled, href: "/settings/automation" },
  ];
  return {
    steps,
    complete: steps.every((s) => s.done),
    integrations: {
      anthropic: anthropic ? "ok" : "missing",
      openai: openai ? "ok" : "missing",
      metaApp: metaConfigured() ? "ok" : "missing",
      instagram: ig.length ? (ig.some((a) => a.status === "ACTIVE") ? "ok" : "error") : "missing",
      facebook: fb.length ? (fb.some((a) => a.status === "ACTIVE") ? "ok" : "error") : "missing",
      storage: storageDriver(),
      worker: workerAlive ? "ok" : worker ? "error" : "missing",
    } as const,
    workerLastRun: worker?.lastRunAt ?? null,
  };
}
