import crypto from "node:crypto";
import type { AssetKind, AssetRole, AssetSource } from "@prisma/client";
import { db } from "@/lib/db";
import { putObject } from "@/server/storage";

const EXT: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
  "image/svg+xml": "svg",
  "video/mp4": "mp4",
  "video/quicktime": "mov",
  "audio/mpeg": "mp3",
  "font/ttf": "ttf",
  "font/otf": "otf",
  "application/octet-stream": "bin",
};

export async function saveAsset(input: {
  orgId: string;
  brandId?: string | null;
  buffer: Buffer;
  mimeType: string;
  kind: AssetKind;
  role: AssetRole;
  source?: AssetSource;
  originalName?: string;
  title?: string;
  prompt?: string;
  tags?: string[];
  width?: number;
  height?: number;
  durationSec?: number;
  isApproved?: boolean;
}) {
  let { width, height } = input;
  if (input.kind === "IMAGE" && (!width || !height) && input.mimeType !== "image/svg+xml") {
    try {
      const sharp = (await import("sharp")).default;
      const meta = await sharp(input.buffer).metadata();
      width = meta.width;
      height = meta.height;
    } catch {
      /* ignora */
    }
  }
  const ext = EXT[input.mimeType] ?? "bin";
  const key = `${input.orgId}/${input.brandId ?? "shared"}/${input.role.toLowerCase()}/${new Date().toISOString().slice(0, 7)}/${crypto.randomUUID()}.${ext}`;
  await putObject(key, input.buffer, input.mimeType);
  return db.mediaAsset.create({
    data: {
      orgId: input.orgId,
      brandId: input.brandId ?? null,
      kind: input.kind,
      role: input.role,
      source: input.source ?? "UPLOAD",
      storageKey: key,
      mimeType: input.mimeType,
      width,
      height,
      sizeBytes: input.buffer.length,
      durationSec: input.durationSec,
      originalName: input.originalName,
      title: input.title,
      prompt: input.prompt,
      tags: input.tags ?? [],
      isApproved: input.isApproved ?? false,
    },
  });
}
