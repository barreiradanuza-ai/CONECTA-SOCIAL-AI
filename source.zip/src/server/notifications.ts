import type { NotificationLevel } from "@prisma/client";
import { db } from "@/lib/db";
import { env } from "@/lib/env";

/**
 * Registra alerta no painel e, se configurado na marca, envia por webhook (Slack/Discord/Make/n8n)
 * e/ou e-mail (Resend). Falhas no envio externo nunca derrubam o fluxo principal.
 */
export async function notify(input: {
  orgId: string;
  brandId?: string | null;
  level?: NotificationLevel;
  title: string;
  body?: string;
  link?: string;
}) {
  const level = input.level ?? "INFO";
  const n = await db.notification.create({
    data: { orgId: input.orgId, brandId: input.brandId ?? null, level, title: input.title, body: input.body, link: input.link },
  });

  if (level === "INFO" || !input.brandId) return n;
  const settings = await db.automationSettings.findUnique({ where: { brandId: input.brandId } });
  const url = input.link ? `${env.appUrl}${input.link}` : env.appUrl;
  const text = `[Conecta Social AI] ${input.title}${input.body ? `\n${input.body}` : ""}\n${url}`;

  if (settings?.notifyWebhookUrl) {
    try {
      await fetch(settings.notifyWebhookUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text, content: text, level, title: input.title, body: input.body, url }),
        signal: AbortSignal.timeout(10_000),
      });
    } catch (e) {
      console.error("[notify] webhook falhou", e);
    }
  }
  if (settings?.notifyEmail && env.resendApiKey) {
    try {
      await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { Authorization: `Bearer ${env.resendApiKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({ from: env.emailFrom, to: [settings.notifyEmail], subject: `[Conecta Social AI] ${input.title}`, text }),
        signal: AbortSignal.timeout(10_000),
      });
    } catch (e) {
      console.error("[notify] e-mail falhou", e);
    }
  }
  return n;
}
