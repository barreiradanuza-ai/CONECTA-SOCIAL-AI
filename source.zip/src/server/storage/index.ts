// Armazenamento de mídia: S3 compatível (Railway Buckets, R2, AWS) ou disco local (dev / volume).
// URLs públicas são servidas pela rota /api/media com assinatura HMAC e expiração,
// o que permite à Meta baixar a imagem sem expor o bucket.
import fs from "node:fs/promises";
import path from "node:path";
import { env } from "@/lib/env";
import { hmac, safeEqual } from "@/lib/crypto";

type S3Mod = typeof import("@aws-sdk/client-s3");
let s3cache: { client: InstanceType<S3Mod["S3Client"]>; mod: S3Mod } | null = null;

async function s3() {
  if (s3cache) return s3cache;
  const mod = await import("@aws-sdk/client-s3");
  const client = new mod.S3Client({
    region: env.storage.region,
    endpoint: env.storage.endpoint,
    forcePathStyle: process.env.S3_FORCE_PATH_STYLE === "true",
    credentials: { accessKeyId: env.storage.accessKeyId!, secretAccessKey: env.storage.secretAccessKey! },
  });
  s3cache = { client, mod };
  return s3cache;
}

export function storageDriver(): "s3" | "local" {
  return env.storage.bucket && env.storage.accessKeyId && env.storage.secretAccessKey ? "s3" : "local";
}

function localPath(key: string) {
  const safe = key.replace(/\.\./g, "").replace(/^\/+/, "");
  return path.resolve(env.storage.localDir, safe);
}

export async function putObject(key: string, body: Buffer, contentType: string) {
  if (storageDriver() === "s3") {
    const { client, mod } = await s3();
    await client.send(new mod.PutObjectCommand({ Bucket: env.storage.bucket, Key: key, Body: body, ContentType: contentType }));
    return;
  }
  const p = localPath(key);
  await fs.mkdir(path.dirname(p), { recursive: true });
  await fs.writeFile(p, body);
}

export async function getObject(key: string): Promise<Buffer> {
  if (storageDriver() === "s3") {
    const { client, mod } = await s3();
    const res = await client.send(new mod.GetObjectCommand({ Bucket: env.storage.bucket, Key: key }));
    const bytes = await res.Body!.transformToByteArray();
    return Buffer.from(bytes);
  }
  return fs.readFile(localPath(key));
}

export async function deleteObject(key: string) {
  if (storageDriver() === "s3") {
    const { client, mod } = await s3();
    await client.send(new mod.DeleteObjectCommand({ Bucket: env.storage.bucket, Key: key }));
    return;
  }
  await fs.rm(localPath(key), { force: true });
}

/** URL assinada, acessível publicamente até expirar (para prévias e para a Meta baixar a mídia). */
export function signedMediaUrl(key: string, ttlSeconds = 60 * 60 * 24): string {
  const exp = Math.floor(Date.now() / 1000) + ttlSeconds;
  const sig = hmac(`${key}:${exp}`);
  return `${env.appUrl}/api/media/${key.split("/").map(encodeURIComponent).join("/")}?exp=${exp}&sig=${sig}`;
}

/** Caminho relativo (para uso dentro do próprio app). */
export function mediaPath(key: string, ttlSeconds = 60 * 60 * 24): string {
  return signedMediaUrl(key, ttlSeconds).replace(env.appUrl, "");
}

export function verifyMediaSignature(key: string, exp: string | null, sig: string | null) {
  if (!exp || !sig) return false;
  if (Number(exp) < Date.now() / 1000) return false;
  return safeEqual(hmac(`${key}:${exp}`), sig);
}
