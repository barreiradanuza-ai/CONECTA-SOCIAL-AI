// Migração ÚNICA do posicionamento editorial: aplica a "Diretriz central de conteúdo" (out/2026)
// às marcas já cadastradas — estratégia, posicionamento, público, tom, temas do Radar e pesos dos pilares —
// e retira da fila as pautas antigas do Radar que ainda não viraram roteiro.
// Roda uma vez no início do worker (marcada em TaskState); depois, tudo continua editável no painel.
import type { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { CONTENT_DIRECTIVE_VERSION, DEFAULT_CONTENT_STRATEGY } from "@/server/ai/strategy";
import { CONECTA_AQUI_POSITIONING } from "@/server/brand";
import { RADAR_DEFAULT_TOPICS } from "@/server/radar/radar";
import { PERSONA_PILLAR_WEIGHTS } from "@/server/planner-core";

const TASK = `positioning.${CONTENT_DIRECTIVE_VERSION}`;

export async function applyContentDirectiveOnce(): Promise<string | null> {
  const done = await db.taskState.findUnique({ where: { name: TASK } });
  if (done?.lastOk) return null;

  const all = await db.brand.findMany({ select: { id: true, name: true, personaEnabled: true, personaBible: true } });
  // A diretriz é da Conecta Aqui: aplica às marcas com esse nome; se nenhuma tiver, aplica a todas.
  const brands = all.filter((b) => /conecta\s*aqui/i.test(b.name));
  const targets = brands.length ? brands : all;
  const now = new Date();
  let pautas = 0;

  for (const b of targets) {
    const persona = b.personaEnabled && !!b.personaBible;
    const weights = persona ? PERSONA_PILLAR_WEIGHTS : { ...PERSONA_PILLAR_WEIGHTS, STORYTELLING: 0 };
    await db.brand.update({
      where: { id: b.id },
      data: { ...CONECTA_AQUI_POSITIONING, contentStrategy: DEFAULT_CONTENT_STRATEGY },
    });
    await db.automationSettings.updateMany({
      where: { brandId: b.id },
      data: {
        radarNicheTopics: RADAR_DEFAULT_TOPICS,
        radarNichePercent: 85,
        pillarWeights: weights as unknown as Prisma.InputJsonValue,
      },
    });
    // Pautas antigas (posicionamento anterior) que ainda não viraram roteiro saem da fila.
    const r = await db.trendNote.updateMany({
      where: { brandId: b.id, origin: "RADAR", scriptsAt: null, status: { in: ["PENDING", "APPROVED"] }, createdAt: { lt: now } },
      data: { status: "REJECTED", decidedAt: now, riskNote: "Arquivada na troca de posicionamento (diretriz de dicas práticas, out/2026)." },
    });
    pautas += r.count;
  }

  const msg = `Diretriz ${CONTENT_DIRECTIVE_VERSION} aplicada a ${targets.length} marca(s): ${targets.map((t) => t.name).join(", ")}; ${pautas} pauta(s) antiga(s) do Radar arquivada(s).`;
  await db.taskState.upsert({
    where: { name: TASK },
    create: { name: TASK, lastRunAt: now, lastOk: true, lastMessage: msg, runs: 1 },
    update: { lastRunAt: now, lastOk: true, lastMessage: msg, runs: { increment: 1 } },
  });
  return msg;
}
