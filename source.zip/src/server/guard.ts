// Guarda comercial: impede que textos gerados por IA contenham preços, velocidades comerciais,
// benefícios ou prazos que não estejam em uma oferta cadastrada, aprovada e válida.
// Módulo puro (sem banco) para ser testável.

export type GuardOffer = {
  id: string;
  operator: string;
  speedMbps: number;
  priceCents: number;
  benefits: string[];
  validUntil: Date;
  validFrom: Date;
  status: string;
};

export type GuardResult = { ok: boolean; violations: string[] };

const PRICE_RE = /R\$\s?(\d{1,3}(?:\.\d{3})*(?:,\d{1,2})?|\d+(?:,\d{1,2})?)/gi;
const SPEED_RE = /(\d{1,4})\s?(mega|mbps|mb|giga|gbps|gb)(?![\p{L}\d])/giu;
const PROMO_RE =
  /(?<![\p{L}\d])(promo[çc][ãa]o|desconto|gr[áa]tis|gratuit[oa]|isen[çc][ãa]o|por apenas|s[óo] hoje|[úu]ltimos dias|imperd[íi]vel|oferta rel[âa]mpago|pague menos|b[ôo]nus|cashback|\d{1,2}% off|\d{1,3}\s?%\s?de desconto)(?![\p{L}\d])/giu;
const DEADLINE_RE = /(?<![\p{L}\d])(at[ée]\s+(o\s+dia\s+)?\d{1,2}\/\d{1,2}|v[áa]lid[oa]\s+at[ée])(?![\p{L}\d])/giu;

export function parseBRL(s: string): number {
  const clean = s.replace(/\./g, "").replace(",", ".");
  return Math.round(parseFloat(clean) * 100);
}

export function isOfferValid(o: GuardOffer, at = new Date()) {
  return o.status === "APPROVED" && o.validFrom <= at && o.validUntil >= at;
}

export function checkCommercialText(texts: string[], offer: GuardOffer | null, at = new Date()): GuardResult {
  const violations: string[] = [];
  const all = texts.filter(Boolean).join("\n");
  const validOffer = offer && isOfferValid(offer, at) ? offer : null;

  if (offer && !validOffer) violations.push("A oferta vinculada não está aprovada ou está fora da validade.");

  for (const m of all.matchAll(PRICE_RE)) {
    const cents = parseBRL(m[1]);
    if (!validOffer || cents !== validOffer.priceCents) {
      violations.push(`Preço "${m[0]}" não corresponde a uma oferta aprovada e válida.`);
    }
  }

  const promoHits = [...all.matchAll(PROMO_RE)].map((m) => m[0]);
  if (promoHits.length && !validOffer) {
    violations.push(`Termos promocionais sem oferta aprovada: ${[...new Set(promoHits)].join(", ")}.`);
  } else if (promoHits.length && validOffer) {
    const benefitsText = validOffer.benefits.join(" ").toLowerCase();
    for (const hit of new Set(promoHits.map((h) => h.toLowerCase()))) {
      const root = hit.slice(0, 6);
      if (!benefitsText.includes(root)) violations.push(`Termo promocional "${hit}" não consta nos benefícios cadastrados da oferta.`);
    }
  }

  const deadlines = [...all.matchAll(DEADLINE_RE)].map((m) => m[0]);
  if (deadlines.length && !validOffer) violations.push(`Prazo promocional sem oferta válida: ${deadlines.join(", ")}.`);

  // Velocidades: em conteúdos com oferta, só a velocidade da oferta; sem oferta, velocidades
  // são aceitas apenas como conteúdo educativo (sem preço/promoção no mesmo texto).
  if (validOffer) {
    for (const m of all.matchAll(SPEED_RE)) {
      let mbps = Number(m[1]);
      if (/giga|gb/i.test(m[2])) mbps *= 1000;
      if (mbps !== validOffer.speedMbps) violations.push(`Velocidade "${m[0]}" difere da oferta (${validOffer.speedMbps} Mega).`);
    }
  }

  return { ok: violations.length === 0, violations: [...new Set(violations)] };
}

export function checkForbiddenTerms(texts: string[], forbidden: string[]): string[] {
  const all = texts.join("\n").toLowerCase();
  return forbidden.filter((t) => t.trim() && all.includes(t.trim().toLowerCase())).map((t) => `Termo proibido pela marca: "${t}".`);
}

export function formatBRL(cents: number) {
  return (cents / 100).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}
