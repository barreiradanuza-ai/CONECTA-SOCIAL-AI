// Coletores de sinais de tendência. Cada um é opcional: sem chave, é pulado e registrado como aviso.
import { getSecret } from "@/server/integrations";

export type Signal = { source: string; title: string; detail?: string; url?: string; volume?: string };

async function getJson(url: string, init?: RequestInit, timeoutMs = 60_000) {
  const r = await fetch(url, { ...init, signal: AbortSignal.timeout(timeoutMs) });
  const text = await r.text();
  let j: any;
  try {
    j = JSON.parse(text);
  } catch {
    throw new Error(`resposta inválida (${r.status})`);
  }
  if (!r.ok || j?.error) throw new Error(typeof j?.error === "string" ? j.error : j?.error?.message ?? `HTTP ${r.status}`);
  return j;
}

/** Google Trends "Em alta agora" (Brasil) e principais notícias do Google News Brasil, via SerpApi. */
export async function serpApiSignals(orgId: string): Promise<{ signals: Signal[]; warnings: string[] }> {
  const key = await getSecret(orgId, "SERPAPI_API_KEY");
  if (!key) return { signals: [], warnings: ["SerpApi não configurado: Google Trends/notícias ficaram de fora."] };
  const out: Signal[] = [];
  const warnings: string[] = [];
  try {
    const j = await getJson(`https://serpapi.com/search.json?engine=google_trends_trending_now&geo=BR&hl=pt-BR&hours=24&api_key=${encodeURIComponent(key)}`);
    for (const t of (j.trending_searches ?? []).slice(0, 25)) {
      out.push({
        source: "Google Trends BR (24h)",
        title: t.query,
        volume: t.search_volume ? String(t.search_volume) : undefined,
        detail: (t.trend_breakdown ?? []).slice(0, 5).join(", ") || (t.categories ?? []).map((c: any) => c.name).join(", ") || undefined,
        url: t.serpapi_google_trends_link ? `https://trends.google.com/trending?geo=BR` : undefined,
      });
    }
  } catch (e) {
    warnings.push(`Google Trends: ${e instanceof Error ? e.message : e}`);
  }
  // Virais mundiais: tendências dos EUA (termômetro global) — só os de maior volume
  try {
    const j = await getJson(`https://serpapi.com/search.json?engine=google_trends_trending_now&geo=US&hl=en&hours=24&api_key=${encodeURIComponent(key)}`);
    for (const t of (j.trending_searches ?? []).slice(0, 12)) {
      out.push({ source: "Google Trends mundo (EUA, 24h)", title: t.query, volume: t.search_volume ? String(t.search_volume) : undefined, detail: (t.trend_breakdown ?? []).slice(0, 4).join(", ") || undefined });
    }
  } catch (e) {
    warnings.push(`Google Trends mundo: ${e instanceof Error ? e.message : e}`);
  }
  try {
    const j = await getJson(`https://serpapi.com/search.json?engine=google_news&gl=br&hl=pt-br&api_key=${encodeURIComponent(key)}`);
    for (const n of (j.news_results ?? []).slice(0, 20)) {
      const item = n.highlight ?? n;
      if (!item?.title) continue;
      out.push({ source: `Google News BR${item.source?.name ? ` · ${item.source.name}` : ""}`, title: item.title, url: item.link, detail: item.date });
    }
  } catch (e) {
    warnings.push(`Google News: ${e instanceof Error ? e.message : e}`);
  }
  return { signals: out, warnings };
}

/** Tendências de TikTok/Instagram via ator do Apify (configurável em Configurações → Automação). */
export async function apifySignals(orgId: string, actorId: string | null | undefined, input: unknown): Promise<{ signals: Signal[]; warnings: string[] }> {
  const token = await getSecret(orgId, "APIFY_TOKEN");
  if (!token) return { signals: [], warnings: ["Apify não configurado: TikTok/Instagram ficaram de fora."] };
  if (!actorId) return { signals: [], warnings: ["Ator do Apify não definido."] };
  try {
    // Entrada padrão do ator clockworks/tiktok-trends-scraper (Creative Center do TikTok), foco Brasil.
    const def = {
      adsScrapeHashtags: true,
      adsCountryCode: "BR",
      adsTimeRange: "7",
      adsScrapeVideos: true,
      adsVideosCountryCode: "BR",
      adsSortVideosBy: "vv",
      adsScrapeSounds: true,
      adsSoundsCountryCode: "BR",
      adsRankType: "surging",
      resultsPerPage: 15,
    };
    const custom = input && typeof input === "object" && Object.keys(input as object).length ? (input as Record<string, unknown>) : null;
    // Entradas antigas com chaves que o ator não reconhece (countryCode) são trocadas pela padrão.
    const body = custom && !("countryCode" in custom) ? custom : def;
    const items = await getJson(
      `https://api.apify.com/v2/acts/${encodeURIComponent(actorId)}/run-sync-get-dataset-items?token=${encodeURIComponent(token)}&timeout=180&limit=40`,
      { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) },
      200_000,
    );
    const list: any[] = Array.isArray(items) ? items : [];
    const signals = list.slice(0, 40).map((it) => ({
      source: `Apify · ${actorId.split(/[~/]/).pop()}`,
      title: String(it.hashtag_name ?? it.hashtagName ?? it.name ?? it.hashtag ?? it.title ?? it.song_name ?? it.musicName ?? it.text ?? it.desc ?? "").slice(0, 200),
      volume: it.videoCount ?? it.viewCount ?? it.views ?? it.playCount ?? it.rank ? String(it.videoCount ?? it.viewCount ?? it.views ?? it.playCount ?? `#${it.rank}`) : undefined,
      url: it.url ?? it.webVideoUrl ?? it.link ?? undefined,
      detail: it.industryName ?? it.type ?? undefined,
    }));
    return { signals: signals.filter((s) => s.title), warnings: list.length ? [] : ["Apify não retornou itens (confira o ator e a entrada)."] };
  } catch (e) {
    return { signals: [], warnings: [`Apify: ${e instanceof Error ? e.message : e}`] };
  }
}
