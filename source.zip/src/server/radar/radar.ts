// RADAR DE TENDÊNCIAS — descobre o que está em alta no Brasil e transforma em pautas para a persona.
// Regras: toda pauta tem fonte verificável; nada de tragédia, política, religião, crimes ou pessoas comuns;
// a IA de conteúdo só usa pautas APROVADAS (manualmente ou pela regra de auto-aprovação).
import type { Prisma } from "@prisma/client";
import { z } from "zod";
import { db } from "@/lib/db";
import { researchStructured } from "@/server/ai/research";
import { notify } from "@/server/notifications";
import { BRIDGE_TOOLKIT, CREATIVE_MODEL } from "@/server/ai/creative";
import { apifySignals, serpApiSignals, type Signal } from "./collectors";

const pautaSchema = z.object({
  title: z.string().min(3),
  what_happened: z.string().min(10),
  source_url: z.string().url(),
  angle: z.string().min(10),
  bridge: z.string().min(10),
  scope: z.enum(["BR", "GLOBAL"]).catch("BR"),
  fit: z.number().min(0).max(10),
  risk: z.number().min(0).max(10),
  risk_note: z.string().optional().default(""),
  formats: z.array(z.string()).optional().default([]),
  valid_hours: z.number().min(6).max(168).optional().default(48),
});
const outSchema = z.object({ resumo: z.string(), pautas: z.array(pautaSchema).max(10) });

const TOOL_SCHEMA = {
  type: "object",
  properties: {
    resumo: { type: "string", description: "2-4 frases sobre o clima da internet brasileira hoje" },
    pautas: {
      type: "array",
      maxItems: 8,
      items: {
        type: "object",
        properties: {
          title: { type: "string", description: "nome curto do assunto" },
          what_happened: { type: "string", description: "o fato, em 1-3 frases, sem exagero e sem inventar" },
          source_url: { type: "string", description: "URL de uma fonte real encontrada nos sinais ou na busca" },
          angle: { type: "string", description: "INSIGHT + VIRADA: a verdade de comportamento que todo mundo reconhece e a surpresa da mini-história do personagem, com uma frase citável entre aspas" },
          bridge: { type: "string", description: "a PONTE com a vida conectada, específica e inesperada; diga qual mecânica do repertório usou (ex.: 'O DELAY: …'). Nunca genérica." },
          scope: { type: "string", enum: ["BR", "GLOBAL"], description: "BR = assunto brasileiro; GLOBAL = viral mundial que chegou ao Brasil" },
          fit: { type: "number", description: "0-10: encaixe com a persona e o público" },
          risk: { type: "number", description: "0-10: risco para a marca (10 = perigoso)" },
          risk_note: { type: "string" },
          formats: { type: "array", items: { type: "string", enum: ["REEL", "STORY", "CAROUSEL", "FEED_IMAGE"] } },
          valid_hours: { type: "number", description: "por quantas horas o assunto continua relevante (6-168)" },
        },
        required: ["title", "what_happened", "source_url", "angle", "bridge", "scope", "fit", "risk", "formats"],
      },
    },
  },
  required: ["resumo", "pautas"],
};

function system(brandName: string, personaBible: string | null) {
  return [
    `Você é o RADAR CRIATIVO da marca "${brandName}" (internet residencial no Brasil). Você junta duas cabeças: um caçador de tendências que sabe o que está bombando AGORA no Brasil e no mundo, e um diretor de criação premiado que transforma qualquer assunto numa história sobre a vida conectada (internet, Wi-Fi, streaming, WhatsApp, lives, redes).`,
    `O valor NÃO está em achar o assunto — está na PONTE inesperada, verdadeira e engraçada entre o assunto e o comportamento conectado das pessoas.`,
    personaBible ? `PERSONAGEM (resumo da bíblia):\n${personaBible.slice(0, 3500)}` : "",
    `COMO PESQUISAR (use a busca na web, varie as fontes)`,
    `- Parta dos sinais coletados, mas vá além: o que está nos assuntos do momento do X/Twitter Brasil, trends do TikTok e Reels, memes da semana, reality shows, futebol, música, séries/streaming, celebridades, tecnologia do dia a dia, e virais mundiais que estão chegando ao Brasil.`,
    `- Procure o DETALHE que as pessoas estão comentando (a reação, o meme, a frase), não só a manchete.`,
    `- Confirme o fato e pegue uma fonte confiável para cada pauta.`,
    BRIDGE_TOOLKIT,
    `MÉTODO (em silêncio; entregue só o resultado)`,
    `1. Levante pelo menos 12 assuntos candidatos.`,
    `2. Para cada um, tente 2-3 pontes usando mecânicas DIFERENTES do repertório.`,
    `3. Aplique o teste de qualidade; descarte o óbvio sem dó.`,
    `4. Entregue as 5 a 8 melhores, da mais forte para a mais fraca, com mecânicas variadas (no máximo 2 pautas com a mesma mecânica) e pelo menos 2 virais globais quando houver.`,
    `5. fit = encaixe com a persona e o público; seja exigente — 8+ só para ideias que você defenderia numa reunião de criação.`,
    `SEGURANÇA DE MARCA (inegociável)`,
    `- NUNCA sugira: tragédias, mortes, doenças, violência, crimes, acidentes, desastres, política/eleições/partidos/candidatos/escândalos políticos, religião, pessoas comuns (não públicas), crianças e adolescentes, conteúdo sexual, apostas.`,
    `- Temporais e eventos climáticos: só o ângulo leve do comportamento em casa, nunca vítimas ou danos; risk >= 5.`,
    `- Não invente fatos, números ou declarações. Sem fonte confirmada, descarte. source_url deve ser uma URL real vista nos sinais ou na busca.`,
    `- risk alto (>=6) para assunto polêmico, marcas concorrentes ou pessoa pública em situação delicada.`,
    `- A marca aparece como consequência natural, nunca como propaganda.`,
  ]
    .filter(Boolean)
    .join("\n");
}

const norm = (s: string) => s.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[^a-z0-9 ]/g, "").trim();

export async function runRadar(brandId: string, trigger: "auto" | "manual" = "auto") {
  const brand = await db.brand.findUniqueOrThrow({ where: { id: brandId } });
  const s = await db.automationSettings.findUniqueOrThrow({ where: { brandId } });
  const [serp, apify] = await Promise.all([serpApiSignals(brand.orgId), apifySignals(brand.orgId, s.apifyActorId, s.apifyInput)]);
  const signals: Signal[] = [...serp.signals, ...apify.signals];
  const warnings = [...serp.warnings, ...apify.warnings];

  const recent = await db.trendNote.findMany({ where: { brandId, createdAt: { gte: new Date(Date.now() - 10 * 86400_000) } }, select: { title: true, text: true, status: true } });
  const prompt = [
    `Data/hora: ${new Date().toLocaleString("pt-BR", { timeZone: brand.timezone })}.`,
    signals.length ? `SINAIS COLETADOS AGORA (${signals.length}):\n${signals.map((x) => `- [${x.source}] ${x.title}${x.volume ? ` (volume ${x.volume})` : ""}${x.detail ? ` — ${x.detail}` : ""}${x.url ? ` <${x.url}>` : ""}`).join("\n")}` : `Não há sinais das ferramentas pagas hoje: pesquise você mesmo o que está em alta no Brasil (Google Trends, X/Twitter, TikTok, notícias de entretenimento).`,
    recent.length ? `JÁ SUGERIDAS NOS ÚLTIMOS 10 DIAS (não repita): ${recent.map((r) => `${r.title ?? r.text.slice(0, 60)} [${r.status}]`).join(" | ")}` : "",
    `Pesquise amplo, levante os candidatos, construa as pontes, filtre o óbvio e registre só as melhores.`,
  ]
    .filter(Boolean)
    .join("\n\n");

  const run = await db.radarRun.create({ data: { brandId, trigger, signals: signals as unknown as Prisma.InputJsonValue, warnings } });
  try {
    const r = await researchStructured({
      orgId: brand.orgId,
      system: system(brand.name, brand.personaEnabled ? brand.personaBible : null),
      prompt,
      toolName: "registrar_pautas",
      toolDescription: "Registra o resumo do dia e as pautas sugeridas para o personagem.",
      schema: TOOL_SCHEMA,
      validator: outSchema,
      maxSearches: Math.max(s.radarMaxSearches, 15),
      maxTokens: 12000,
      model: CREATIVE_MODEL(),
    });
    const seen = new Set(recent.map((x) => norm(x.title ?? x.text.slice(0, 60))));
    let created = 0;
    let autoApproved = 0;
    for (const p of r.data.pautas) {
      const key = norm(p.title);
      if (seen.has(key)) continue;
      seen.add(key);
      const auto = s.radarAutoApprove && p.risk <= 3 && p.fit >= 7;
      await db.trendNote.create({
        data: {
          brandId,
          title: p.title,
          text: p.what_happened,
          sourceUrl: p.source_url,
          angle: p.angle,
          bridge: p.bridge,
          scope: p.scope,
          fitScore: Math.round(p.fit),
          riskScore: Math.round(p.risk),
          riskNote: p.risk_note || null,
          formats: p.formats,
          origin: "RADAR",
          status: auto ? "APPROVED" : "PENDING",
          decidedAt: auto ? new Date() : null,
          runId: run.id,
          validUntil: new Date(Date.now() + (p.valid_hours ?? 48) * 3600_000),
        },
      });
      created++;
      if (auto) autoApproved++;
    }
    await db.radarRun.update({ where: { id: run.id }, data: { summary: r.data.resumo, created, searches: r.searches, model: r.model } });
    const pending = created - autoApproved;
    if (pending > 0) await notify({ orgId: brand.orgId, brandId, level: "WARNING", title: `Radar: ${pending} pauta(s) nova(s) para aprovar`, body: r.data.resumo.slice(0, 300), link: "/radar" });
    return `${brand.name}: ${created} pautas (${autoApproved} auto-aprovadas), ${r.searches} buscas`;
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    await db.radarRun.update({ where: { id: run.id }, data: { error: msg.slice(0, 2000) } });
    throw e;
  }
}

export async function radarDaily() {
  const list = await db.automationSettings.findMany({ where: { radarEnabled: true, brand: { isActive: true } }, include: { brand: true } });
  const out: string[] = [];
  for (const s of list) {
    // Roda uma vez por dia, a partir das 6h no fuso da marca; falhas são retentadas a cada 6h.
    const hour = Number(new Date().toLocaleString("en-US", { hour: "numeric", hour12: false, timeZone: s.brand.timezone }));
    if (hour < 6) continue;
    const lastOk = await db.radarRun.findFirst({ where: { brandId: s.brandId, error: null }, orderBy: { createdAt: "desc" } });
    if (lastOk && Date.now() - lastOk.createdAt.getTime() < 20 * 3600_000) continue;
    const lastAny = await db.radarRun.findFirst({ where: { brandId: s.brandId }, orderBy: { createdAt: "desc" } });
    if (lastAny?.error && Date.now() - lastAny.createdAt.getTime() < 6 * 3600_000) continue;
    try {
      out.push(await runRadar(s.brandId, "auto"));
    } catch (e) {
      out.push(`erro: ${e instanceof Error ? e.message.slice(0, 200) : e}`);
    }
  }
  return out.join("; ") || "nada a pesquisar";
}
