// RADAR DE TENDÊNCIAS — descobre o que está em alta no Brasil e transforma em pautas para a persona.
// Regras: toda pauta tem fonte verificável; nada de tragédia, política, religião, crimes ou pessoas comuns;
// a IA de conteúdo só usa pautas APROVADAS (manualmente ou pela regra de auto-aprovação).
import type { Prisma } from "@prisma/client";
import { z } from "zod";
import { db } from "@/lib/db";
import { researchStructured } from "@/server/ai/research";
import { notify } from "@/server/notifications";
import { BRIDGE_TOOLKIT, CREATIVE_MODEL } from "@/server/ai/creative";
import { apifySignals, nicheNewsSignals, serpApiSignals, type Signal } from "./collectors";
import { FUNNEL_GUIDE } from "@/server/ai/strategy";

const pautaSchema = z.object({
  title: z.string().min(3),
  what_happened: z.string().min(10),
  source_url: z.string().url(),
  angle: z.string().min(10),
  bridge: z.string().min(10),
  scope: z.enum(["BR", "GLOBAL"]).catch("BR"),
  lane: z.enum(["NICHE", "CULTURE"]).catch("CULTURE"),
  relevance: z.number().min(0).max(10).catch(0),
  funnel: z.enum(["ATTRACTION", "AUTHORITY", "RELATIONSHIP", "CONVERSION"]).catch("ATTRACTION"),
  fit: z.number().min(0).max(10),
  risk: z.number().min(0).max(10),
  risk_note: z.string().optional().default(""),
  formats: z.array(z.string()).optional().default([]),
  valid_hours: z.number().min(6).max(168).optional().default(48),
});
const outSchema = z.object({ resumo: z.string(), pautas: z.array(pautaSchema).max(10) });

const TOOL_SCHEMA = {
  type: "object",
  properties: {
    resumo: { type: "string", description: "2-4 frases sobre o que está movimentando tecnologia e conectividade no Brasil hoje" },
    pautas: {
      type: "array",
      maxItems: 10,
      items: {
        type: "object",
        properties: {
          title: { type: "string", description: "nome curto do assunto" },
          what_happened: { type: "string", description: "o fato, em 1-3 frases, sem exagero e sem inventar" },
          source_url: { type: "string", description: "URL de uma fonte real encontrada nos sinais ou na busca" },
          angle: { type: "string", description: "INSIGHT + VIRADA: a verdade de comportamento que todo mundo reconhece e a surpresa da mini-história do personagem, com uma frase citável entre aspas" },
          bridge: { type: "string", description: "a PONTE com a vida conectada, específica e inesperada; diga qual mecânica do repertório usou (ex.: 'O DELAY: …'). Nunca genérica." },
          scope: { type: "string", enum: ["BR", "GLOBAL"], description: "BR = assunto brasileiro; GLOBAL = viral mundial que chegou ao Brasil" },
          lane: { type: "string", enum: ["NICHE", "CULTURE"], description: "NICHE = o assunto em si é de tecnologia, conectividade ou internet; CULTURE = assunto geral com ponte DIRETA com tecnologia/conexão" },
          relevance: { type: "number", description: "0-10: relação DIRETA do assunto com tecnologia, conectividade e internet (10 = é sobre isso; 7 = a tecnologia/conexão é parte central do fato; abaixo de 7 = ponte forçada)" },
          funnel: { type: "string", enum: ["ATTRACTION", "AUTHORITY", "RELATIONSHIP", "CONVERSION"], description: "função estratégica que a pauta cumpre melhor" },
          fit: { type: "number", description: "0-10: encaixe com a persona e o público" },
          risk: { type: "number", description: "0-10: risco para a marca (10 = perigoso)" },
          risk_note: { type: "string" },
          formats: { type: "array", items: { type: "string", enum: ["REEL", "STORY", "CAROUSEL", "FEED_IMAGE"] } },
          valid_hours: { type: "number", description: "por quantas horas o assunto continua relevante (6-168)" },
        },
        required: ["title", "what_happened", "source_url", "angle", "bridge", "scope", "lane", "relevance", "funnel", "fit", "risk", "formats"],
      },
    },
  },
  required: ["resumo", "pautas"],
};

function system(brandName: string, personaBible: string | null, nichePct: number, topics: string[]) {
  const cultureMax = Math.max(0, 100 - nichePct);
  return [
    `Você é o RADAR DE PAUTAS da marca "${brandName}", que ajuda brasileiros a escolher e aproveitar melhor internet, celular e TV (comparação de planos e operadoras). Você é o editor de um portal de TECNOLOGIA E CONECTIVIDADE + um diretor de criação: encontra o que está acontecendo AGORA no mundo da tecnologia, da internet e da vida conectada que importa para o brasileiro comum, e transforma em pautas úteis, curiosas e fáceis de entender para Instagram e Facebook. O perfil deve ser reconhecido como a referência descomplicada em tecnologia e conexão.`,
    `FOCO (inegociável): no mínimo ${nichePct}% das pautas são do NICHO — o assunto em si é sobre: ${topics.join(", ")}. Exemplos: lançamento de celular ou recurso novo (iPhone, Android, WhatsApp, Instagram), novidade de IA que o público já usa (ChatGPT, Gemini, Meta AI), Wi-Fi 7, expansão do 5G e da fibra, casa conectada (Alexa, câmeras, smart TV), queda de app ou serviço, golpe digital circulando (ângulo de prevenção), reajuste ou novidade de streaming, regra nova da Anatel, dicas para melhorar a conexão, curiosidades de tecnologia, portabilidade e direitos do consumidor.`,
    `No máximo ${cultureMax}% podem ser de CULTURA (futebol, reality, séries, memes, celebridades, virais) e SÓ quando a tecnologia/conexão é parte central do fato — ex.: "o jogo foi transmitido só no streaming e travou para muita gente", "o Brasil inteiro assistindo pelo celular gastou os dados", "o WhatsApp caiu". Se a ligação com tecnologia/internet/celular precisar de esforço criativo para existir, DESCARTE (relevance < 7 = descartar).`,
    personaBible ? `PERSONAGEM (resumo da bíblia; use para dar voz às pautas, não para escolher assuntos fora do foco):\n${personaBible.slice(0, 2500)}` : "",
    `FUNÇÃO ESTRATÉGICA de cada pauta (campo funnel):`,
    ...Object.entries(FUNNEL_GUIDE).map(([k, v]) => `- ${k}: ${v}`),
    `COMO PESQUISAR (use a busca na web, varie as fontes)`,
    `- Comece pelos sinais "Notícias do setor"; depois procure na web (portais como Tecmundo, Olhar Digital, Canaltech, Tecnoblog, g1 Tecnologia, Mobile Time, Teletime) novidades de tecnologia, celulares, apps, IA, Wi-Fi, 5G, fibra, streaming, operadoras e Anatel no Brasil dos últimos dias.`,
    `- Use as tendências gerais (Google Trends, notícias gerais, TikTok) só para achar os casos de CULTURA com conexão direta.`,
    `- Procure o DETALHE que as pessoas estão comentando (a reação, a dúvida, a reclamação), não só a manchete. Confirme o fato e pegue uma fonte confiável para cada pauta.`,
    `TERRITÓRIOS EDITORIAIS (conectividade de forma ampla, criativa e informativa; o perfil não pode soar como canal de operadora nem repetir o mesmo assunto):`,
    ...TERRITORIES.map((t) => `- ${t}`),
    `VARIEDADE (inegociável): em cada entrega, use pelo menos 5 territórios diferentes, no máximo 2 pautas do mesmo território, e misture pautas informativas (fato, dado, novidade) com pautas criativas (curiosidade, humor, comportamento). Evite "internet caiu/operadora" como tema padrão: só entra quando for notícia de verdade. Indique o território no início do campo angle, entre colchetes.`,
    BRIDGE_TOOLKIT,
    `MÉTODO (em silêncio; entregue só o resultado)`,
    `1. Levante pelo menos 12 assuntos candidatos, a maioria do nicho.`,
    `2. Para cada um, defina a ponte com o dia a dia de quem usa internet, celular e tecnologia (na pauta do nicho a ponte é o impacto prático: o que muda para a pessoa, o que ela deve fazer).`,
    `3. Aplique o teste de qualidade e o FOCO; descarte o genérico e o forçado sem dó.`,
    `4. Entregue as 6 a 8 melhores, da mais forte para a mais fraca, respeitando a proporção nicho/cultura e variando as funções estratégicas.`,
    `5. relevance = relação direta com tecnologia/conectividade/internet; fit = encaixe com o público e a marca. Seja exigente.`,
    `SEGURANÇA DE MARCA (inegociável)`,
    `- NUNCA sugira: tragédias, mortes, doenças, violência, crimes (golpes digitais só no ângulo de prevenção, sem vítimas identificáveis), acidentes, desastres, política/eleições/partidos/candidatos, religião, pessoas comuns (não públicas), crianças e adolescentes, conteúdo sexual, apostas.`,
    `- Operadoras e concorrentes: só fatos públicos e neutros (ex.: nova regra, novo serviço); nunca atacar marcas; risk >= 5 quando citar uma empresa.`,
    `- Temporais e eventos climáticos: só o ângulo leve (ex.: como manter a conexão), nunca vítimas ou danos; risk >= 5.`,
    `- Não invente fatos, números, preços ou declarações. Sem fonte confirmada, descarte. source_url deve ser uma URL real vista nos sinais ou na busca.`,
    `- A marca aparece como consequência natural, nunca como propaganda; nada de preços ou promoções.`,
  ]
    .filter(Boolean)
    .join("\n");
}

// Temas de busca do radar: termos curtos (viram consultas no Google Notícias), misturados de propósito
// para que cada dia traga um recorte diferente de conectividade. O radar usa 18 por dia, em rodízio.
export const RADAR_DEFAULT_TOPICS = [
  "Wi-Fi", "inteligência artificial", "golpe digital", "fibra óptica", "WhatsApp novidade", "smart TV",
  "5G", "lançamento de celular", "casa inteligente", "Starlink", "cabos submarinos internet", "games online",
  "Anatel", "privacidade online", "streaming", "inclusão digital", "fora do ar", "trabalho remoto",
  "ChatGPT", "roteador", "Instagram novidade", "segurança digital", "internet no interior", "carro conectado",
  "vazamento de dados", "relógio inteligente", "bateria de celular", "6G", "operadoras de internet", "tecnologia curiosidade",
];
const RADAR_OLD_DEFAULT_TOPICS = [
  ["internet fibra", "Wi-Fi", "plano de celular", "dados móveis", "5G", "TV por assinatura", "streaming", "operadoras de telecom", "Anatel", "direitos do consumidor de telecom", "queda de internet", "golpes digitais"],
  ["tecnologia", "internet fibra", "Wi-Fi", "5G", "celulares e smartphones", "WhatsApp e redes sociais", "inteligência artificial no dia a dia", "casa conectada", "streaming", "segurança digital e golpes", "operadoras e Anatel", "lançamentos de tecnologia"],
];

/** Recorte do dia: 18 temas em rodízio, para não repetir sempre os mesmos assuntos. */
function todaysTopics(all: string[], date = new Date()) {
  if (all.length <= 18) return all;
  const day = Math.floor(date.getTime() / 86400_000);
  const start = (day * 7) % all.length;
  return Array.from({ length: 18 }, (_, i) => all[(start + i) % all.length]);
}

/** Territórios editoriais: garantem variedade de ângulo (informativo e criativo) entre as pautas. */
const TERRITORIES = [
  "NOVIDADE ÚTIL — o que mudou e o que a pessoa faz com isso (app, celular, recurso novo)",
  "PROTEÇÃO — golpes, privacidade, segurança dos dados, sempre no ângulo de prevenção",
  "COMO FUNCIONA — os bastidores da internet (cabos submarinos, satélites, fibra, antenas, data centers) explicados de forma simples e surpreendente",
  "MITO OU VERDADE — crenças populares sobre Wi-Fi, bateria, 5G, velocidade, celular",
  "DICA PRÁTICA — melhorar a conexão, o roteador, a bateria, o streaming, o celular",
  "COMPORTAMENTO CONECTADO — como a tecnologia muda a rotina, o trabalho, o lazer, as relações (com leveza e humor)",
  "FUTURO PRÓXIMO — IA, 6G, casa e carro conectados: o que já chegou e o que está vindo, sem hype",
  "BRASIL CONECTADO — inclusão digital, internet no interior, dados e curiosidades do país",
  "SEU DIREITO — regras da Anatel, portabilidade, fidelidade, o que a pessoa pode exigir",
  "CULTURA + CONEXÃO — o grande evento do momento visto pelo lado da tecnologia (só com ligação direta)",
];

const norm = (s: string) => s.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[^a-z0-9 ]/g, "").trim();

export async function runRadar(brandId: string, trigger: "auto" | "manual" = "auto") {
  const brand = await db.brand.findUniqueOrThrow({ where: { id: brandId } });
  const s = await db.automationSettings.findUniqueOrThrow({ where: { brandId } });
  // Temas antigos (padrão anterior, só telecom) são trocados automaticamente pelo foco em tecnologia e conectividade
  let topics = s.radarNicheTopics.length ? s.radarNicheTopics : RADAR_DEFAULT_TOPICS;
  if (RADAR_OLD_DEFAULT_TOPICS.some((old) => old.join("|") === topics.join("|"))) {
    topics = RADAR_DEFAULT_TOPICS;
    await db.automationSettings.update({ where: { brandId }, data: { radarNicheTopics: topics } });
  }
  const [niche, serp, apify] = await Promise.all([nicheNewsSignals(brand.orgId, todaysTopics(topics)), serpApiSignals(brand.orgId), apifySignals(brand.orgId, s.apifyActorId, s.apifyInput)]);
  const signals: Signal[] = [...niche.signals, ...serp.signals, ...apify.signals];
  const warnings = [...niche.warnings, ...serp.warnings, ...apify.warnings];

  const recent = await db.trendNote.findMany({ where: { brandId, createdAt: { gte: new Date(Date.now() - 10 * 86400_000) } }, select: { title: true, text: true, status: true } });
  const prompt = [
    `Data/hora: ${new Date().toLocaleString("pt-BR", { timeZone: brand.timezone })}.`,
    signals.length ? `SINAIS COLETADOS AGORA (${signals.length}):\n${signals.map((x) => `- [${x.source}] ${x.title}${x.volume ? ` (volume ${x.volume})` : ""}${x.detail ? ` — ${x.detail}` : ""}${x.url ? ` <${x.url}>` : ""}`).join("\n")}` : `Não há sinais das ferramentas pagas hoje: pesquise você mesmo o que está em alta no Brasil (Google Trends, X/Twitter, TikTok, notícias de entretenimento).`,
    recent.length ? `JÁ SUGERIDAS NOS ÚLTIMOS 10 DIAS (não repita): ${recent.map((r) => `${r.title ?? r.text.slice(0, 60)} [${r.status}]`).join(" | ")}` : "",
    `Priorize o nicho (tecnologia, conectividade e internet): no mínimo ${s.radarNichePercent}% das pautas. Levante os candidatos, construa as pontes, filtre o forçado e registre só as melhores.`,
  ]
    .filter(Boolean)
    .join("\n\n");

  const run = await db.radarRun.create({ data: { brandId, trigger, signals: signals as unknown as Prisma.InputJsonValue, warnings } });
  try {
    const r = await researchStructured({
      orgId: brand.orgId,
      system: system(brand.name, brand.personaEnabled ? brand.personaBible : null, s.radarNichePercent, todaysTopics(topics)),
      prompt,
      toolName: "registrar_pautas",
      toolDescription: "Registra o resumo do dia e as pautas sugeridas para o personagem.",
      schema: TOOL_SCHEMA,
      validator: outSchema,
      maxSearches: Math.max(s.radarMaxSearches, 15),
      maxTokens: 12000,
      model: CREATIVE_MODEL(),
    });
    const seen = new Set(recent.map((x) => norm(x.title ?? x.text.slice(0, 60))));
    let created = 0;
    let autoApproved = 0;
    // Filtro de foco: cultura só com ligação direta; respeita a proporção mínima do nicho
    const nichePct = Math.min(100, Math.max(0, s.radarNichePercent));
    const good = r.data.pautas.filter((p) => (p.lane === "NICHE" ? p.relevance >= 6 : p.relevance >= 7));
    const nicheCount = good.filter((p) => p.lane === "NICHE").length;
    const maxCulture = nichePct >= 100 ? 0 : Math.max(nicheCount ? Math.floor((nicheCount * (100 - nichePct)) / nichePct) : 1, 1);
    let cultureUsed = 0;
    const kept = good.filter((p) => p.lane === "NICHE" || cultureUsed++ < maxCulture);
    for (const p of kept) {
      const key = norm(p.title);
      if (seen.has(key)) continue;
      seen.add(key);
      const auto = s.radarAutoApprove && p.risk <= 3 && p.fit >= 7;
      await db.trendNote.create({
        data: {
          brandId,
          title: p.title,
          text: p.what_happened,
          sourceUrl: p.source_url,
          angle: p.angle,
          bridge: p.bridge,
          scope: p.scope,
          lane: p.lane,
          relevance: Math.round(p.relevance),
          funnelStage: p.funnel,
          fitScore: Math.round(p.fit),
          riskScore: Math.round(p.risk),
          riskNote: p.risk_note || null,
          formats: p.formats,
          origin: "RADAR",
          status: auto ? "APPROVED" : "PENDING",
          decidedAt: auto ? new Date() : null,
          runId: run.id,
          validUntil: new Date(Date.now() + (p.valid_hours ?? 48) * 3600_000),
        },
      });
      created++;
      if (auto) autoApproved++;
    }
    const dropped = r.data.pautas.length - kept.length;
    await db.radarRun.update({
      where: { id: run.id },
      data: { summary: r.data.resumo, created, searches: r.searches, model: r.model, ...(dropped > 0 ? { warnings: [...warnings, `${dropped} pauta(s) descartada(s) por falta de ligação direta com tecnologia ou conectividade.`] } : {}) },
    });
    const pending = created - autoApproved;
    if (pending > 0) await notify({ orgId: brand.orgId, brandId, level: "WARNING", title: `Radar: ${pending} pauta(s) nova(s) para aprovar`, body: r.data.resumo.slice(0, 300), link: "/radar" });
    return `${brand.name}: ${created} pautas (${autoApproved} auto-aprovadas), ${r.searches} buscas`;
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    await db.radarRun.update({ where: { id: run.id }, data: { error: msg.slice(0, 2000) } });
    throw e;
  }
}

export async function radarDaily() {
  const list = await db.automationSettings.findMany({ where: { radarEnabled: true, brand: { isActive: true } }, include: { brand: true } });
  const out: string[] = [];
  for (const s of list) {
    // Roda uma vez por dia, a partir das 6h no fuso da marca; falhas são retentadas a cada 6h.
    const hour = Number(new Date().toLocaleString("en-US", { hour: "numeric", hour12: false, timeZone: s.brand.timezone }));
    if (hour < 6) continue;
    const lastOk = await db.radarRun.findFirst({ where: { brandId: s.brandId, error: null }, orderBy: { createdAt: "desc" } });
    if (lastOk && Date.now() - lastOk.createdAt.getTime() < 20 * 3600_000) continue;
    const lastAny = await db.radarRun.findFirst({ where: { brandId: s.brandId }, orderBy: { createdAt: "desc" } });
    if (lastAny?.error && Date.now() - lastAny.createdAt.getTime() < 6 * 3600_000) continue;
    try {
      out.push(await runRadar(s.brandId, "auto"));
    } catch (e) {
      out.push(`erro: ${e instanceof Error ? e.message.slice(0, 200) : e}`);
    }
  }
  return out.join("; ") || "nada a pesquisar";
}
