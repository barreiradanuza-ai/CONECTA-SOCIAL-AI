// RADAR DE PAUTAS ÚTEIS — descobre as dúvidas, problemas e novidades de tecnologia do dia a dia que o brasileiro
// comum está enfrentando agora e transforma em pautas práticas (dicas, tutoriais, proteção, escolha de plano).
// Regras: toda pauta tem fonte verificável; nada de tragédia, política, religião, crimes ou pessoas comuns;
// a IA de conteúdo só usa pautas APROVADAS (manualmente ou pela regra de auto-aprovação).
import type { Prisma } from "@prisma/client";
import { z } from "zod";
import { db } from "@/lib/db";
import { researchStructured } from "@/server/ai/research";
import { notify } from "@/server/notifications";
import { BRIDGE_TOOLKIT } from "@/server/ai/creative";
import { apifySignals, nicheNewsSignals, serpApiSignals, type Signal } from "./collectors";
import { ACCURACY_RULES, EDITORIAL_REFERENCES, FUNNEL_GUIDE, PRIORITY_THEMES } from "@/server/ai/strategy";

const pautaSchema = z.object({
  title: z.string().min(3),
  what_happened: z.string().min(10),
  source_url: z.string().url(),
  angle: z.string().min(10),
  bridge: z.string().min(10),
  scope: z.enum(["BR", "GLOBAL"]).catch("BR"),
  lane: z.enum(["NICHE", "CULTURE"]).catch("CULTURE"),
  relevance: z.number().min(0).max(10).catch(0),
  funnel: z.enum(["ATTRACTION", "AUTHORITY", "RELATIONSHIP", "CONVERSION"]).catch("ATTRACTION"),
  fit: z.number().min(0).max(10),
  risk: z.number().min(0).max(10),
  risk_note: z.string().optional().default(""),
  formats: z.array(z.string()).optional().default([]),
  valid_hours: z.number().min(6).max(168).optional().default(48),
});
const outSchema = z.object({ resumo: z.string(), pautas: z.array(pautaSchema).max(10) });

const TOOL_SCHEMA = {
  type: "object",
  properties: {
    resumo: { type: "string", description: "2-4 frases sobre as dúvidas, problemas e novidades de tecnologia do dia a dia que estão em alta no Brasil hoje" },
    pautas: {
      type: "array",
      maxItems: 10,
      items: {
        type: "object",
        properties: {
          title: { type: "string", description: "nome curto do assunto" },
          what_happened: { type: "string", description: "o fato, em 1-3 frases, sem exagero e sem inventar" },
          source_url: { type: "string", description: "URL de uma fonte real encontrada nos sinais ou na busca" },
          angle: { type: "string", description: "[TERRITÓRIO] + o GANCHO (problema real, dúvida frequente ou descoberta) + o que a pessoa vai aprender/fazer, com os passos principais em poucas palavras e se vale para Android, iPhone, TV ou todos" },
          bridge: { type: "string", description: "o formato do repertório usado (ex.: 'RECURSO ESCONDIDO: …') e, quando o assunto permitir, a ligação NATURAL com qualidade da conexão, cobertura, Wi-Fi residencial ou escolha de plano (ou 'sem ligação comercial — só utilidade')" },
          scope: { type: "string", enum: ["BR", "GLOBAL"], description: "BR = assunto brasileiro; GLOBAL = viral mundial que chegou ao Brasil" },
          lane: { type: "string", enum: ["NICHE", "CULTURE"], description: "NICHE = dica/dúvida/novidade prática de tecnologia e conexão do dia a dia (o foco do perfil); CULTURE = assunto do momento (evento, viral, data) que rende uma dica prática DIRETA (ex.: final na TV → como assistir sem travar)" },
          relevance: { type: "number", description: "0-10: UTILIDADE PRÁTICA para o público geral (10 = resolve um problema comum ou ensina algo que quase todo mundo usa; 7 = útil para uma parte grande do público; abaixo de 6 = curiosidade sem utilidade, nicho profissional ou ponte forçada)" },
          funnel: { type: "string", enum: ["ATTRACTION", "AUTHORITY", "RELATIONSHIP", "CONVERSION"], description: "função estratégica que a pauta cumpre melhor" },
          fit: { type: "number", description: "0-10: encaixe com a diretriz (temas prioritários, linguagem simples, potencial de salvar/compartilhar) e com o público que não domina tecnologia" },
          risk: { type: "number", description: "0-10: risco para a marca (10 = perigoso)" },
          risk_note: { type: "string" },
          formats: { type: "array", items: { type: "string", enum: ["REEL", "STORY", "CAROUSEL", "FEED_IMAGE"] } },
          valid_hours: { type: "number", description: "por quantas horas o assunto continua relevante (6-168)" },
        },
        required: ["title", "what_happened", "source_url", "angle", "bridge", "scope", "lane", "relevance", "funnel", "fit", "risk", "formats"],
      },
    },
  },
  required: ["resumo", "pautas"],
};

function system(brandName: string, personaBible: string | null, nichePct: number, topics: string[]) {
  const cultureMax = Math.max(0, 100 - nichePct);
  return [
    `Você é o RADAR DE PAUTAS da marca "${brandName}", um buscador de planos de internet e serviços de telecomunicações no Brasil. O perfil quer ser reconhecido como a marca que ajuda as pessoas a aproveitar melhor a tecnologia e a internet. Você é o editor de pautas de um canal de DICAS PRÁTICAS para o público geral — inclusive quem não domina tecnologia, mas usa celular, internet, Wi-Fi, TV, aplicativos e serviços digitais todos os dias.`,
    `NÃO concentre as pautas em inteligência artificial, marketing digital, lançamentos caros ou ferramentas para profissionais. A prioridade é conteúdo prático: resolver problemas comuns e descobrir funcionalidades úteis.`,
    `TEMAS PRIORITÁRIOS (a maior parte das pautas sai daqui, com ângulos novos a cada dia):`,
    ...PRIORITY_THEMES.map((t, i) => `${i + 1}. ${t}`),
    `FOCO (inegociável): no mínimo ${nichePct}% das pautas são do NICHO — dica, dúvida, problema ou novidade prática de tecnologia e conexão do dia a dia. Termos de busca do dia: ${topics.join(", ")}. Novidades (atualização do WhatsApp, recurso novo do Android/iPhone, mudança em app, golpe circulando, regra da Anatel) só entram pelo ângulo prático: o que muda para a pessoa e o que ela deve fazer.`,
    `No máximo ${cultureMax}% podem ser de CULTURA (futebol, reality, séries, datas, virais) e SÓ quando rendem uma dica prática direta — ex.: "a final vai passar no streaming → como colocar o celular na TV e evitar travar", "viagem de feriado → como economizar dados". Se a ligação precisar de esforço criativo, DESCARTE.`,
    personaBible ? `PERSONAGEM (a voz que apresenta as dicas; não use para escolher assuntos fora do foco):\n${personaBible.slice(0, 1500)}` : "",
    `FUNÇÃO ESTRATÉGICA de cada pauta (campo funnel):`,
    ...Object.entries(FUNNEL_GUIDE).map(([k, v]) => `- ${k}: ${v}`),
    `REFERÊNCIAS EDITORIAIS (observe formatos públicos, estruturas de vídeo e abordagens educativas; NUNCA copie conteúdos, roteiros ou identidade visual):`,
    ...EDITORIAL_REFERENCES.map((r) => `- ${r}`),
    `COMO PESQUISAR (use a busca na web, varie as fontes)`,
    `- Comece pelos sinais "Notícias do setor"; depois procure nos portais de referência (TechTudo, Canaltech, TecMundo, Olhar Digital, Tecnoblog, g1 Tecnologia) tutoriais e dúvidas em alta, recursos novos de Android, iPhone, WhatsApp e Smart TV, golpes circulando, problemas de conexão e mudanças em apps e serviços usados pelo brasileiro.`,
    `- Procure a DÚVIDA REAL das pessoas (o que elas perguntam, o erro que cometem, a reclamação frequente), não só a manchete.`,
    `- Para cada pauta, confirme os passos e a informação técnica em fonte confiável (site oficial do fabricante/app, Anatel, portal de tecnologia reconhecido). source_url deve ser essa fonte.`,
    `TERRITÓRIOS EDITORIAIS:`,
    ...TERRITORIES.map((t) => `- ${t}`),
    `VARIEDADE (inegociável): em cada entrega, use pelo menos 5 territórios diferentes, no máximo 2 pautas do mesmo território, misture aparelhos (Android, iPhone, Smart TV, computador, roteador) e funções estratégicas. Indique o território no início do campo angle, entre colchetes.`,
    BRIDGE_TOOLKIT,
    ACCURACY_RULES,
    `MÉTODO (em silêncio; entregue só o resultado)`,
    `1. Levante pelo menos 12 pautas candidatas, a maioria ligada aos temas prioritários.`,
    `2. Para cada uma, defina o gancho (problema real, dúvida frequente ou descoberta), o que a pessoa vai conseguir fazer e para quais aparelhos vale.`,
    `3. Aplique o teste de qualidade, a precisão técnica e o FOCO; descarte o genérico, o profissional, o clickbait e o impreciso sem dó.`,
    `4. Entregue as 6 a 8 melhores, da mais útil para a menos útil, respeitando a proporção nicho/cultura e variando territórios e funções.`,
    `5. relevance = utilidade prática para o público geral; fit = encaixe com a diretriz e potencial de salvar/compartilhar. Seja exigente.`,
    `6. valid_hours: dicas atemporais podem durar até 168h; novidades e golpes, 24–72h.`,
    `SEGURANÇA DE MARCA (inegociável)`,
    `- NUNCA sugira: tragédias, mortes, doenças, violência, crimes (golpes digitais só no ângulo de prevenção, sem vítimas identificáveis), acidentes, desastres, política/eleições/partidos/candidatos, religião, pessoas comuns (não públicas), crianças e adolescentes, conteúdo sexual, apostas, invasão de redes ou contas alheias (ex.: "descobrir senha do Wi-Fi do vizinho").`,
    `- Operadoras e concorrentes: só fatos públicos e neutros; nunca atacar marcas; risk >= 5 quando citar uma empresa.`,
    `- Não invente fatos, números, preços, passos ou declarações. Sem fonte confirmada, descarte.`,
    `- A marca aparece como consequência natural, nunca como propaganda; nada de preços ou promoções. Nem toda pauta precisa falar de planos de internet.`,
  ]
    .filter(Boolean)
    .join("\n");
}

// Temas de busca do radar: termos curtos (viram consultas no Google Notícias), misturados de propósito
// para que cada dia traga um recorte diferente de conectividade. O radar usa 18 por dia, em rodízio.
export const RADAR_DEFAULT_TOPICS = [
  "liberar espaço no celular", "espelhar celular na TV", "melhorar sinal do Wi-Fi", "internet lenta", "teste de velocidade",
  "economizar dados móveis", "conectar ao Wi-Fi", "problema de conexão", "roteador do celular", "dispositivos conectados Wi-Fi",
  "Smart TV dicas", "assistir na TV", "segurança do WhatsApp", "golpe no WhatsApp", "verificação em duas etapas",
  "dicas Android", "dicas iPhone", "atualização do WhatsApp", "recurso novo Android", "recurso novo iPhone",
  "roteador Wi-Fi", "repetidor de sinal", "Wi-Fi 2,4 GHz e 5 GHz", "fibra óptica", "plano de internet",
  "cobertura de internet", "franquia de dados", "Anatel consumidor", "bateria do celular", "senha do Wi-Fi",
];
const RADAR_OLD_DEFAULT_TOPICS = [
  ["Wi-Fi", "inteligência artificial", "golpe digital", "fibra óptica", "WhatsApp novidade", "smart TV", "5G", "lançamento de celular", "casa inteligente", "Starlink", "cabos submarinos internet", "games online", "Anatel", "privacidade online", "streaming", "inclusão digital", "fora do ar", "trabalho remoto", "ChatGPT", "roteador", "Instagram novidade", "segurança digital", "internet no interior", "carro conectado", "vazamento de dados", "relógio inteligente", "bateria de celular", "6G", "operadoras de internet", "tecnologia curiosidade"],
  ["internet fibra", "Wi-Fi", "plano de celular", "dados móveis", "5G", "TV por assinatura", "streaming", "operadoras de telecom", "Anatel", "direitos do consumidor de telecom", "queda de internet", "golpes digitais"],
  ["tecnologia", "internet fibra", "Wi-Fi", "5G", "celulares e smartphones", "WhatsApp e redes sociais", "inteligência artificial no dia a dia", "casa conectada", "streaming", "segurança digital e golpes", "operadoras e Anatel", "lançamentos de tecnologia"],
];

/** Recorte do dia: 18 temas em rodízio, para não repetir sempre os mesmos assuntos. */
function todaysTopics(all: string[], date = new Date()) {
  if (all.length <= 18) return all;
  const day = Math.floor(date.getTime() / 86400_000);
  const start = (day * 7) % all.length;
  return Array.from({ length: 18 }, (_, i) => all[(start + i) % all.length]);
}

/** Territórios editoriais: garantem variedade de ângulo (informativo e criativo) entre as pautas. */
const TERRITORIES = [
  "CELULAR NA MÃO — liberar espaço com segurança, bateria, recursos escondidos e truques úteis de Android e iPhone",
  "CELULAR NA TV — espelhar, transmitir, conectar e assistir vídeos e conteúdos na Smart TV (por marca/sistema quando mudar)",
  "WI-FI EM CASA — sinal fraco, posição do roteador, 2,4 × 5 GHz, repetidor, quem está conectado, conectar novos aparelhos",
  "INTERNET LENTA? — como testar a velocidade e descobrir se o problema é o celular, o Wi-Fi, os dados móveis ou a conexão",
  "DADOS MÓVEIS — economizar, compartilhar a internet do celular (roteador/hotspot), ajustes de apps",
  "PROTEÇÃO — WhatsApp e contas protegidos, verificação em duas etapas, golpes circulando (só prevenção)",
  "MITO OU VERDADE — crenças populares sobre Wi-Fi, bateria, 5G, velocidade, limpeza do celular",
  "ENTENDA SEU PLANO — velocidade, Mega, cobertura, franquia, fibra óptica, como escolher o plano certo para a família",
  "NOVIDADE ÚTIL — atualização de app ou sistema e o que a pessoa faz com isso (sem hype)",
  "MOMENTO + DICA — o evento ou data do momento visto pelo lado prático (só com dica direta)",
];

const norm = (s: string) => s.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[^a-z0-9 ]/g, "").trim();

export async function runRadar(brandId: string, trigger: "auto" | "manual" = "auto") {
  const brand = await db.brand.findUniqueOrThrow({ where: { id: brandId } });
  const s = await db.automationSettings.findUniqueOrThrow({ where: { brandId } });
  // Temas antigos (padrão anterior, só telecom) são trocados automaticamente pelo foco em tecnologia e conectividade
  let topics = s.radarNicheTopics.length ? s.radarNicheTopics : RADAR_DEFAULT_TOPICS;
  if (RADAR_OLD_DEFAULT_TOPICS.some((old) => old.join("|") === topics.join("|"))) {
    topics = RADAR_DEFAULT_TOPICS;
    await db.automationSettings.update({ where: { brandId }, data: { radarNicheTopics: topics } });
  }
  const [niche, serp, apify] = await Promise.all([nicheNewsSignals(brand.orgId, todaysTopics(topics)), serpApiSignals(brand.orgId), apifySignals(brand.orgId, s.apifyActorId, s.apifyInput)]);
  const signals: Signal[] = [...niche.signals, ...serp.signals, ...apify.signals];
  const warnings = [...niche.warnings, ...serp.warnings, ...apify.warnings];

  const recent = await db.trendNote.findMany({ where: { brandId, createdAt: { gte: new Date(Date.now() - 10 * 86400_000) } }, select: { title: true, text: true, status: true } });
  const prompt = [
    `Data/hora: ${new Date().toLocaleString("pt-BR", { timeZone: brand.timezone })}.`,
    signals.length ? `SINAIS COLETADOS AGORA (${signals.length}):\n${signals.map((x) => `- [${x.source}] ${x.title}${x.volume ? ` (volume ${x.volume})` : ""}${x.detail ? ` — ${x.detail}` : ""}${x.url ? ` <${x.url}>` : ""}`).join("\n")}` : `Não há sinais das ferramentas pagas hoje: pesquise você mesmo as dúvidas e novidades práticas de tecnologia em alta no Brasil (portais de referência, Google Trends, perguntas frequentes).`,
    recent.length ? `JÁ SUGERIDAS NOS ÚLTIMOS 10 DIAS (não repita): ${recent.map((r) => `${r.title ?? r.text.slice(0, 60)} [${r.status}]`).join(" | ")}` : "",
    `Priorize dicas práticas e dúvidas do dia a dia ligadas aos temas prioritários: no mínimo ${s.radarNichePercent}% das pautas no nicho. Levante os candidatos, confirme os passos em fontes confiáveis, filtre o genérico e o impreciso e registre só as mais úteis.`,
  ]
    .filter(Boolean)
    .join("\n\n");

  const run = await db.radarRun.create({ data: { brandId, trigger, signals: signals as unknown as Prisma.InputJsonValue, warnings } });
  try {
    const r = await researchStructured({
      orgId: brand.orgId,
      system: system(brand.name, brand.personaEnabled ? brand.personaBible : null, s.radarNichePercent, todaysTopics(topics)),
      prompt,
      toolName: "registrar_pautas",
      toolDescription: "Registra o resumo do dia e as pautas práticas sugeridas.",
      schema: TOOL_SCHEMA,
      validator: outSchema,
      // Economia: o Radar filtra e resume (Sonnet basta); buscas limitadas a 8 e saída mais curta
      maxSearches: Math.min(Math.max(s.radarMaxSearches, 3), 8),
      maxTokens: 6000,
    });
    const seen = new Set(recent.map((x) => norm(x.title ?? x.text.slice(0, 60))));
    let created = 0;
    let autoApproved = 0;
    // Filtro de foco: cultura só com ligação direta; respeita a proporção mínima do nicho
    const nichePct = Math.min(100, Math.max(0, s.radarNichePercent));
    const good = r.data.pautas.filter((p) => (p.lane === "NICHE" ? p.relevance >= 6 : p.relevance >= 7));
    const nicheCount = good.filter((p) => p.lane === "NICHE").length;
    const maxCulture = nichePct >= 100 ? 0 : Math.max(nicheCount ? Math.floor((nicheCount * (100 - nichePct)) / nichePct) : 1, 1);
    let cultureUsed = 0;
    const kept = good.filter((p) => p.lane === "NICHE" || cultureUsed++ < maxCulture);
    for (const p of kept) {
      const key = norm(p.title);
      if (seen.has(key)) continue;
      seen.add(key);
      const auto = s.radarAutoApprove && p.risk <= 3 && p.fit >= 7;
      await db.trendNote.create({
        data: {
          brandId,
          title: p.title,
          text: p.what_happened,
          sourceUrl: p.source_url,
          angle: p.angle,
          bridge: p.bridge,
          scope: p.scope,
          lane: p.lane,
          relevance: Math.round(p.relevance),
          funnelStage: p.funnel,
          fitScore: Math.round(p.fit),
          riskScore: Math.round(p.risk),
          riskNote: p.risk_note || null,
          formats: p.formats,
          origin: "RADAR",
          status: auto ? "APPROVED" : "PENDING",
          decidedAt: auto ? new Date() : null,
          runId: run.id,
          validUntil: new Date(Date.now() + (p.valid_hours ?? 48) * 3600_000),
        },
      });
      created++;
      if (auto) autoApproved++;
    }
    const dropped = r.data.pautas.length - kept.length;
    await db.radarRun.update({
      where: { id: run.id },
      data: { summary: r.data.resumo, created, searches: r.searches, model: r.model, ...(dropped > 0 ? { warnings: [...warnings, `${dropped} pauta(s) descartada(s) por baixa utilidade prática ou ligação forçada.`] } : {}) },
    });
    const pending = created - autoApproved;
    if (pending > 0) await notify({ orgId: brand.orgId, brandId, level: "WARNING", title: `Radar: ${pending} pauta(s) nova(s) para aprovar`, body: r.data.resumo.slice(0, 300), link: "/radar" });
    return `${brand.name}: ${created} pautas (${autoApproved} auto-aprovadas), ${r.searches} buscas`;
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    await db.radarRun.update({ where: { id: run.id }, data: { error: msg.slice(0, 2000) } });
    throw e;
  }
}

export async function radarDaily() {
  const list = await db.automationSettings.findMany({ where: { radarEnabled: true, brand: { isActive: true } }, include: { brand: true } });
  const out: string[] = [];
  for (const s of list) {
    // Roda uma vez por dia, a partir das 6h no fuso da marca; falhas são retentadas a cada 6h.
    const hour = Number(new Date().toLocaleString("en-US", { hour: "numeric", hour12: false, timeZone: s.brand.timezone }));
    if (hour < 6) continue;
    const lastOk = await db.radarRun.findFirst({ where: { brandId: s.brandId, error: null }, orderBy: { createdAt: "desc" } });
    if (lastOk && Date.now() - lastOk.createdAt.getTime() < 20 * 3600_000) continue;
    const lastAny = await db.radarRun.findFirst({ where: { brandId: s.brandId }, orderBy: { createdAt: "desc" } });
    if (lastAny?.error && Date.now() - lastAny.createdAt.getTime() < 6 * 3600_000) continue;
    try {
      out.push(await runRadar(s.brandId, "auto"));
    } catch (e) {
      out.push(`erro: ${e instanceof Error ? e.message.slice(0, 200) : e}`);
    }
  }
  return out.join("; ") || "nada a pesquisar";
}
