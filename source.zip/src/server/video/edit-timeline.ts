// Linha do tempo da edição dos Reels (funções puras, sem ffmpeg nem rede): tempo de cada palavra da fala,
// blocos de legenda, gancho, cartões de passo, efeitos sonoros e pontos de zoom.

export type SfxType = "whoosh" | "pop" | "ding" | "boing" | "scratch" | "click";
export const SFX_TYPES: SfxType[] = ["whoosh", "pop", "ding", "boing", "scratch", "click"];

/** Plano de edição escrito pela IA a partir da fala (âncoras = palavras exatas da fala). */
export type EditPlan = {
  hook?: string;
  cards?: { label?: string; text: string; anchor: string }[];
  sfx?: { type: SfxType; anchor: string }[];
  keywords?: string[];
};

export type Word = { text: string; start: number; end: number; sentenceStart: boolean };
export type Interval = [number, number];

export const norm = (s: string) =>
  s
    .toLowerCase()
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .replace(/[^a-z0-9]+/g, "");

/** Distribui as palavras pelos trechos com voz (sem silêncio), proporcional ao tamanho de cada palavra. */
export function timeWords(speech: string, voiced: Interval[]): Word[] {
  const tokens = speech.replace(/\s+/g, " ").trim().split(" ").filter(Boolean);
  if (!tokens.length || !voiced.length) return [];
  const weight = (t: string) => Math.max(2, norm(t).length) + (/[,;:]$/.test(t) ? 2 : /[.!?…]$/.test(t) ? 3 : 0);
  const total = tokens.reduce((a, t) => a + weight(t), 0);
  const voicedTotal = voiced.reduce((a, [s, e]) => a + (e - s), 0);
  const perUnit = voicedTotal / total;
  const words: Word[] = [];
  let iv = 0;
  let cursor = voiced[0][0];
  let prevEndsSentence = true;
  for (const t of tokens) {
    let need = weight(t) * perUnit;
    let start = -1;
    let end = cursor;
    while (need > 1e-6 && iv < voiced.length) {
      if (cursor < voiced[iv][0]) cursor = voiced[iv][0];
      if (start < 0) start = cursor;
      const room = voiced[iv][1] - cursor;
      if (room >= need) {
        cursor += need;
        end = cursor;
        need = 0;
      } else {
        need -= room;
        end = voiced[iv][1];
        iv++;
        cursor = iv < voiced.length ? voiced[iv][0] : end;
      }
    }
    if (start < 0) start = end;
    words.push({ text: t, start, end, sentenceStart: prevEndsSentence });
    prevEndsSentence = /[.!?…]["”']?$/.test(t);
  }
  return words;
}

export type Chunk = { words: Word[]; start: number; end: number };

/** Agrupa em blocos curtos de legenda (até 3 palavras / ~18 letras), quebrando nas pontuações. */
export function chunkWords(words: Word[], maxWords = 3, maxChars = 18): Chunk[] {
  const chunks: Chunk[] = [];
  let cur: Word[] = [];
  const flush = () => {
    if (cur.length) chunks.push({ words: cur, start: cur[0].start, end: cur[cur.length - 1].end });
    cur = [];
  };
  for (const w of words) {
    const chars = cur.reduce((a, x) => a + x.text.length + 1, 0) + w.text.length;
    if (cur.length && (cur.length >= maxWords || chars > maxChars || w.sentenceStart)) flush();
    cur.push(w);
    if (/[,;:.!?…]["”']?$/.test(w.text)) flush();
  }
  flush();
  // cada bloco fica na tela até o próximo começar (sem piscar em pausas curtas)
  for (let i = 0; i < chunks.length - 1; i++) {
    const gap = chunks[i + 1].start - chunks[i].end;
    chunks[i].end = gap < 0.6 ? chunks[i + 1].start : chunks[i].end + 0.25;
  }
  if (chunks.length) chunks[chunks.length - 1].end += 0.3;
  return chunks;
}

/** Índice da 1ª palavra onde a âncora aparece (a partir de `from`); aceita âncora parcial. */
export function findAnchor(words: Word[], anchor: string, from = 0): number {
  const a = anchor.split(/\s+/).map(norm).filter(Boolean);
  if (!a.length) return -1;
  const w = words.map((x) => norm(x.text));
  for (const need of [a.length, Math.min(2, a.length), 1]) {
    const seq = a.slice(0, need);
    for (let i = from; i <= w.length - seq.length; i++) if (seq.every((s, k) => w[i + k] === s)) return i;
  }
  return -1;
}

export type CardEvent = { label: string; text: string; start: number; end: number };
export type SfxEvent = { type: SfxType; at: number };

export type Timeline = {
  duration: number;
  words: Word[];
  chunks: Chunk[];
  hook: { text: string; start: number; end: number } | null;
  cards: CardEvent[];
  sfx: SfxEvent[];
  zoomOn: Interval[]; // trechos com zoom (alternando)
  keywords: Set<string>;
};

export function buildTimeline(o: { speech: string; voiced: Interval[]; duration: number; plan: EditPlan | null; joints?: number[] }): Timeline {
  const speechEnd = o.voiced.length ? o.voiced[o.voiced.length - 1][1] : o.duration;
  const words = timeWords(o.speech, o.voiced);
  const chunks = chunkWords(words).map((c) => ({ ...c, end: Math.min(c.end, o.duration) }));
  const plan = o.plan ?? {};

  // Gancho escrito: do início até o fim da 1ª frase (entre 1,5 e 3 s)
  const firstSentenceEnd = words.find((w, i) => i > 0 && /[.!?…]["”']?$/.test(w.text))?.end ?? 2.5;
  const hookText = (plan.hook ?? "").trim();
  const hook = hookText ? { text: hookText, start: 0, end: Math.min(3, Math.max(1.5, firstSentenceEnd)) } : null;

  // Cartões de passo: aparecem na palavra-âncora e ficam até o próximo cartão (2 a 4,5 s)
  const cards: CardEvent[] = [];
  let from = 0;
  let n = 0;
  for (const c of plan.cards ?? []) {
    const i = findAnchor(words, c.anchor, from);
    if (i < 0 || !c.text?.trim()) continue;
    from = i + 1;
    n++;
    cards.push({ label: (c.label ?? "").trim() || `PASSO ${n}`, text: c.text.trim(), start: Math.max(hook ? hook.end : 0, words[i].start - 0.1), end: 0 });
  }
  cards.sort((a, b) => a.start - b.start);
  for (let k = 0; k < cards.length; k++) {
    const next = k + 1 < cards.length ? cards[k + 1].start : speechEnd + 0.2;
    cards[k].end = Math.min(next - 0.05, cards[k].start + 4.5, o.duration);
    if (cards[k].end - cards[k].start < 1.2) cards[k].end = Math.min(o.duration, cards[k].start + 1.2);
  }
  const cardsOk = cards.filter((c, k) => c.end > c.start && (k === 0 || c.start >= cards[k - 1].end - 0.01));

  // Efeitos (por prioridade, sem amontoar): os pedidos no roteiro > whoosh na abertura e nas emendas > pop nos cartões
  const wanted: (SfxEvent & { p: number })[] = [{ type: "whoosh", at: 0.02, p: 2 }];
  for (const j of o.joints ?? []) wanted.push({ type: "whoosh", at: Math.max(0, j - 0.25), p: 2 });
  for (const c of cardsOk) wanted.push({ type: "pop", at: c.start, p: 1 });
  let sfrom = 0;
  for (const s of plan.sfx ?? []) {
    const i = findAnchor(words, s.anchor, sfrom);
    if (i < 0) continue;
    sfrom = i + 1;
    wanted.push({ type: s.type, at: words[i].start, p: 3 });
  }
  const kept: SfxEvent[] = [];
  for (const s of wanted.sort((a, b) => b.p - a.p || a.at - b.at)) {
    if (s.at >= o.duration - 0.2) continue;
    if (kept.some((k) => Math.abs(k.at - s.at) < 0.5)) continue;
    kept.push({ type: s.type, at: s.at });
  }
  const sfxOk = kept.sort((a, b) => a.at - b.at);

  // Zoom alternado no início de frases, com no mínimo ~2 s entre trocas
  const switches: number[] = [];
  let last = 0;
  for (const w of words) {
    if (w.sentenceStart && w.start - last >= 2 && w.start < speechEnd - 1) {
      switches.push(w.start);
      last = w.start;
    }
  }
  // frases muito longas: troca também no meio (a cada ~3,5 s sem troca)
  const all: number[] = [];
  let prev = 0;
  for (const s of [...switches, speechEnd]) {
    while (s - prev > 4.5) {
      prev += 3.5;
      const near = words.find((w) => w.start >= prev - 0.4)?.start ?? prev;
      if (near < s - 1.5) all.push(near);
      prev = Math.max(prev, near);
    }
    if (s < speechEnd) all.push(s);
    prev = s;
  }
  const zoomOn: Interval[] = [];
  for (let k = 0; k < all.length; k += 2) zoomOn.push([all[k], k + 1 < all.length ? all[k + 1] : speechEnd]);

  const keywords = new Set((plan.keywords ?? []).flatMap((k) => k.split(/\s+/)).map(norm).filter((k) => k.length > 2));
  return { duration: o.duration, words, chunks, hook, cards: cardsOk, sfx: sfxOk, zoomOn, keywords };
}

/** Estado visual da camada de texto num trecho de tempo (para renderizar uma imagem por estado). */
export type LayerState = { chunk: number; active: number; hook: boolean; card: number };

/** Divide a duração em trechos com o mesmo estado visual. */
export function layerSegments(t: Timeline): { start: number; end: number; state: LayerState }[] {
  const marks = new Set<number>([0, t.duration]);
  for (const c of t.chunks) {
    marks.add(c.start);
    marks.add(c.end);
    for (const w of c.words) marks.add(w.start);
  }
  if (t.hook) {
    marks.add(t.hook.start);
    marks.add(t.hook.end);
  }
  for (const c of t.cards) {
    marks.add(c.start);
    marks.add(c.end);
  }
  const pts = [...marks].filter((x) => x >= 0 && x <= t.duration).sort((a, b) => a - b);
  const segs: { start: number; end: number; state: LayerState }[] = [];
  for (let i = 0; i < pts.length - 1; i++) {
    const a = pts[i];
    const b = pts[i + 1];
    if (b - a < 0.02) continue;
    const mid = (a + b) / 2;
    const chunk = t.chunks.findIndex((c) => mid >= c.start && mid < c.end);
    let active = -1;
    if (chunk >= 0) {
      const ws = t.chunks[chunk].words;
      for (let k = 0; k < ws.length; k++) if (mid >= ws[k].start) active = k;
    }
    const hook = !!t.hook && mid >= t.hook.start && mid < t.hook.end;
    const card = t.cards.findIndex((c) => mid >= c.start && mid < c.end);
    const state = { chunk, active, hook, card };
    const prevSeg = segs[segs.length - 1];
    if (prevSeg && JSON.stringify(prevSeg.state) === JSON.stringify(state)) prevSeg.end = b;
    else segs.push({ start: a, end: b, state });
  }
  return segs;
}

/** Expressão do zoompan: 1.0 fora e ~1.10 dentro dos trechos com zoom. */
export function zoomExpr(zoomOn: Interval[], amount = 0.1): string {
  if (!zoomOn.length) return "1";
  return `1+${amount}*(${zoomOn.map(([a, b]) => `between(it,${a.toFixed(2)},${b.toFixed(2)})`).join("+")})`;
}
