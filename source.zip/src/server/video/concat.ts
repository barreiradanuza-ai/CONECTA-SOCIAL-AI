// Junta os clipes de um vídeo feito em partes (o modelo gera no máximo 15 s por clipe).
// Cada parte (menos a última) é cortada logo depois do fim da fala, para a emenda não ter silêncio.
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import crypto from "node:crypto";

const run = promisify(execFile);
const f2 = (n: number) => n.toFixed(2);

async function probe(file: string) {
  const { stdout } = await run("ffprobe", ["-v", "error", "-show_entries", "stream=codec_type,width,height:format=duration", "-of", "json", file], { timeout: 30_000 });
  const j = JSON.parse(stdout);
  const v = (j.streams ?? []).find((s: any) => s.codec_type === "video");
  return {
    width: Number(v?.width ?? 720),
    height: Number(v?.height ?? 1280),
    duration: Number(j.format?.duration ?? 6),
    hasAudio: (j.streams ?? []).some((s: any) => s.codec_type === "audio"),
  };
}

/**
 * @param clips  vídeos na ordem
 * @param cutAt  para cada clipe, segundos onde cortar (fim da fala + folga); null = usa o clipe inteiro
 */
export async function concatClips(clips: Buffer[], cutAt: (number | null)[] = []): Promise<Buffer> {
  if (clips.length === 1) return clips[0];
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), `concat-${crypto.randomUUID().slice(0, 8)}-`));
  try {
    const files: string[] = [];
    for (let i = 0; i < clips.length; i++) {
      const f = path.join(dir, `p${i}.mp4`);
      await fs.writeFile(f, clips[i]);
      files.push(f);
    }
    const infos = await Promise.all(files.map(probe));
    const W = infos[0].width - (infos[0].width % 2);
    const H = infos[0].height - (infos[0].height % 2);
    const inputs: string[] = [];
    const filters: string[] = [];
    const labels: string[] = [];
    let idx = 0;
    infos.forEach((info, i) => {
      const cut = cutAt[i];
      const dur = cut && cut > 1 && cut < info.duration ? cut : info.duration;
      inputs.push("-i", files[i]);
      const vIn = idx;
      idx++;
      filters.push(`[${vIn}:v]scale=${W}:${H}:force_original_aspect_ratio=increase,crop=${W}:${H},fps=30,setsar=1,format=yuv420p,trim=duration=${f2(dur)},setpts=PTS-STARTPTS[v${i}]`);
      if (info.hasAudio) {
        filters.push(`[${vIn}:a]aresample=44100,aformat=channel_layouts=stereo,atrim=duration=${f2(dur)},asetpts=PTS-STARTPTS,apad=whole_dur=${f2(dur)}[a${i}]`);
      } else {
        inputs.push("-f", "lavfi", "-t", f2(dur), "-i", "anullsrc=r=44100:cl=stereo");
        filters.push(`[${idx}:a]asetpts=PTS-STARTPTS[a${i}]`);
        idx++;
      }
      labels.push(`[v${i}][a${i}]`);
    });
    filters.push(`${labels.join("")}concat=n=${infos.length}:v=1:a=1[v][a]`);
    const out = path.join(dir, "out.mp4");
    await run(
      "ffmpeg",
      ["-y", ...inputs, "-filter_complex", filters.join(";"), "-map", "[v]", "-map", "[a]", "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-c:a", "aac", "-b:a", "160k", "-movflags", "+faststart", out],
      { timeout: 300_000, maxBuffer: 16 * 1024 * 1024 },
    );
    return await fs.readFile(out);
  } finally {
    await fs.rm(dir, { recursive: true, force: true }).catch(() => {});
  }
}
