// Fila de vídeos da persona: roteiro (Claude) → voz fixa (MiniMax TTS) → vídeo H3 com as fotos oficiais
// e o áudio como referência (boca sincronizada) → biblioteca de mídia → Reels para aprovação.
import { z } from "zod";
import { db } from "@/lib/db";
import { structured } from "@/server/ai/anthropic";
import { brandSystemPrompt } from "@/server/ai/agent";
import { getBrandContext } from "@/server/brand";
import { saveAsset } from "@/server/media";
import { signedMediaUrl } from "@/server/storage";
import { notify } from "@/server/notifications";
import { getSecret } from "@/server/integrations";
import { PRICE_PER_SECOND, VIDEO_MODEL, queryVideo, speak, submitVideo } from "./minimax";

const monthStart = () => {
  const d = new Date();
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1));
};

export async function monthVideoSpend(brandId: string) {
  const r = await db.videoJob.aggregate({ where: { brandId, createdAt: { gte: monthStart() }, status: { notIn: ["FAILED", "CANCELED"] } }, _sum: { estCostUsd: true } });
  return r._sum.estCostUsd ?? 0;
}

export async function enqueueVideo(input: { orgId: string; brandId: string; brief: string; postId?: string | null; createdById?: string | null; durationSec?: number; speech?: string | null; visualPrompt?: string | null }) {
  const s = await db.automationSettings.findUniqueOrThrow({ where: { brandId: input.brandId } });
  if (!s.videoEnabled) throw new Error("Geração de vídeo desligada em Configurações → Automação.");
  if (!(await getSecret(input.orgId, "MINIMAX_API_KEY"))) throw new Error("Cadastre a chave da MiniMax em Configurações → Integrações para gerar vídeos.");
  const duration = Math.min(15, Math.max(4, input.durationSec ?? s.videoDefaultSeconds));
  const est = duration * (PRICE_PER_SECOND[s.videoResolution] ?? 0.08);
  const spent = await monthVideoSpend(input.brandId);
  if (spent + est > s.videoMonthlyBudgetUsd) throw new Error(`Teto mensal de vídeo atingido: US$ ${spent.toFixed(2)} de US$ ${s.videoMonthlyBudgetUsd.toFixed(2)}. Aumente o teto em Configurações → Automação.`);
  if (input.postId) {
    const active = await db.videoJob.findFirst({ where: { postId: input.postId, status: { in: ["QUEUED", "VOICE_READY", "SUBMITTED"] } } });
    if (active) return active;
  }
  return db.videoJob.create({
    data: { orgId: input.orgId, brandId: input.brandId, postId: input.postId ?? null, brief: input.brief, speech: input.speech ?? null, visualPrompt: input.visualPrompt ?? null, durationSec: duration, resolution: s.videoResolution, model: VIDEO_MODEL, estCostUsd: est, createdById: input.createdById ?? null },
  });
}

const planSchema = z.object({ speech: z.string().min(3), visual_prompt: z.string().min(10), emotion: z.string().optional(), duration: z.number().min(4).max(15) });

async function planVideo(jobId: string) {
  const job = await db.videoJob.findUniqueOrThrow({ where: { id: jobId }, include: { brand: true } });
  const ctx = await getBrandContext(job.brand);
  const { data } = await structured({
    orgId: job.orgId,
    system: brandSystemPrompt(ctx),
    prompt: [
      `Transforme o pedido abaixo em UM clipe vertical (9:16) de ${job.durationSec} segundos com o personagem da marca falando para a câmera.`,
      `- speech: a fala exata em português do Brasil, natural, com o humor e o sarcasmo do personagem. Máximo de ${Math.round(job.durationSec * 2.3)} palavras (cabe em ${job.durationSec}s). Sem hashtags, sem emojis, sem preços.`,
      `- visual_prompt: em INGLÊS, descreva cena, cenário, enquadramento, gestos, expressão e movimento de câmera. O personagem é o mesmo das imagens de referência. Sem textos, letreiros ou logos na imagem.`,
      `- emotion: uma de happy, surprised, neutral, sad, angry, fearful, disgusted.`,
      `- duration: segundos (4 a 15).`,
      `PEDIDO:\n${job.brief}`,
    ].join("\n"),
    toolName: "roteiro_video",
    toolDescription: "Registra a fala e a cena do clipe do personagem.",
    schema: {
      type: "object",
      properties: {
        speech: { type: "string" },
        visual_prompt: { type: "string" },
        emotion: { type: "string", enum: ["happy", "surprised", "neutral", "sad", "angry", "fearful", "disgusted"] },
        duration: { type: "number" },
      },
      required: ["speech", "visual_prompt", "duration"],
    },
    validator: planSchema,
    maxTokens: 1500,
  });
  return data;
}

async function step(jobId: string) {
  const job = await db.videoJob.findUniqueOrThrow({ where: { id: jobId }, include: { brand: true } });
  const brand = job.brand;

  if (job.status === "QUEUED") {
    const plan = job.speech && job.visualPrompt ? { speech: job.speech, visual_prompt: job.visualPrompt, emotion: undefined, duration: job.durationSec } : await planVideo(job.id);
    let voiceAssetId: string | null = null;
    let duration = Math.min(15, Math.max(4, Math.round(plan.duration)));
    if (brand.personaVoiceId) {
      const tts = await speak(job.orgId, brand.personaVoiceId, plan.speech, plan.emotion);
      const a = await saveAsset({ orgId: job.orgId, brandId: brand.id, buffer: tts.audio, mimeType: "audio/mpeg", kind: "AUDIO", role: "VOICE", source: "AI", title: plan.speech.slice(0, 80), prompt: plan.speech, durationSec: tts.seconds ?? undefined, isApproved: true });
      voiceAssetId = a.id;
      if (tts.seconds) {
        if (tts.seconds > 15) throw new Error(`A fala ficou com ${tts.seconds.toFixed(1)}s (máximo 15s). Encurte o texto.`);
        duration = Math.min(15, Math.max(duration, Math.ceil(tts.seconds + 0.5)));
      }
    }
    const est = duration * (PRICE_PER_SECOND[job.resolution] ?? 0.08);
    await db.videoJob.update({ where: { id: job.id }, data: { status: "VOICE_READY", speech: plan.speech, visualPrompt: plan.visual_prompt, voiceAssetId, durationSec: duration, estCostUsd: est } });
    return "roteiro e voz prontos";
  }

  if (job.status === "VOICE_READY") {
    const refs = await db.mediaAsset.findMany({ where: { brandId: brand.id, role: "CHARACTER_REFERENCE", kind: "IMAGE" }, orderBy: { createdAt: "asc" }, take: 5 });
    if (!refs.length) throw new Error("Cadastre fotos de referência do personagem em Configurações → Marca.");
    const voice = job.voiceAssetId ? await db.mediaAsset.findUnique({ where: { id: job.voiceAssetId } }) : null;
    const prompt = [
      job.visualPrompt,
      brand.personaVisual ? `Character (same person as the reference images): ${brand.personaVisual}` : "The character is the same person shown in the reference images.",
      voice ? "The character speaks the reference audio line directly to camera with accurate lip sync, Brazilian Portuguese." : `The character says in Brazilian Portuguese: "${job.speech}".`,
      "Vertical 9:16 social media video, natural lighting, no on-screen text, no logos, no subtitles.",
    ].join(" ");
    const taskId = await submitVideo(job.orgId, {
      prompt,
      imageUrls: refs.map((r) => signedMediaUrl(r.storageKey, 6 * 3600)),
      audioUrl: voice ? signedMediaUrl(voice.storageKey, 6 * 3600) : null,
      duration: job.durationSec,
      resolution: job.resolution,
      ratio: job.ratio,
    });
    await db.videoJob.update({ where: { id: job.id }, data: { status: "SUBMITTED", taskId } });
    return "enviado à MiniMax";
  }

  if (job.status === "SUBMITTED" && job.taskId) {
    if (Date.now() - job.updatedAt.getTime() > 45 * 60_000) throw Object.assign(new Error("A MiniMax não concluiu o vídeo em 45 minutos."), { fatal: true });
    const q = await queryVideo(job.orgId, job.taskId);
    if (q.state === "running") return "";
    if (q.state === "failed") throw Object.assign(new Error(q.error ?? "Falha na geração."), { fatal: true });
    const r = await fetch(q.url!, { signal: AbortSignal.timeout(120_000) });
    if (!r.ok) throw new Error(`Download do vídeo falhou (${r.status}).`);
    const buf = Buffer.from(await r.arrayBuffer());
    const asset = await saveAsset({ orgId: job.orgId, brandId: brand.id, buffer: buf, mimeType: "video/mp4", kind: "VIDEO", role: "VIDEO", source: "AI", title: (job.speech ?? job.brief).slice(0, 80), prompt: job.visualPrompt ?? undefined, durationSec: job.durationSec, tags: ["persona", "ia"], isApproved: false });
    await db.videoJob.update({ where: { id: job.id }, data: { status: "SUCCEEDED", videoAssetId: asset.id, error: null } });
    if (job.postId) {
      await db.postMedia.deleteMany({ where: { postId: job.postId, purpose: "VIDEO" } });
      await db.postMedia.create({ data: { postId: job.postId, assetId: asset.id, purpose: "VIDEO", position: 0 } });
      await db.post.update({
        where: { id: job.postId },
        data: { status: "PENDING_APPROVAL", approvalRequired: true, approvalReasons: ["Vídeo da persona gerado por IA: revise antes de publicar e marque como conteúdo de IA."] },
      });
    }
    await notify({ orgId: job.orgId, brandId: brand.id, level: "WARNING", title: "Vídeo da persona pronto para revisão", body: (job.speech ?? job.brief).slice(0, 200), link: job.postId ? `/posts/${job.postId}` : "/studio/video" });
    return "vídeo pronto";
  }
  return "";
}

/** Tarefa do worker: avança cada vídeo pendente uma etapa. */
export async function processVideoJobs() {
  const jobs = await db.videoJob.findMany({ where: { status: { in: ["QUEUED", "VOICE_READY", "SUBMITTED"] } }, orderBy: { createdAt: "asc" }, take: 5 });
  const out: string[] = [];
  for (const j of jobs) {
    // Consulta de status a cada ~30s não conta como tentativa; só erros contam.
    try {
      const msg = await step(j.id);
      if (msg) out.push(`${j.id.slice(-6)}: ${msg}`);
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      const fatal = (e as { fatal?: boolean })?.fatal || j.attempts + 1 >= 3 || /Credencial ausente|Cadastre fotos/.test(msg);
      await db.videoJob.update({ where: { id: j.id }, data: { attempts: { increment: 1 }, error: msg.slice(0, 1000), ...(fatal ? { status: "FAILED" } : {}) } });
      if (fatal) {
        if (j.postId) await db.post.update({ where: { id: j.postId }, data: { generationError: `Vídeo da persona: ${msg}`.slice(0, 2000) } }).catch(() => {});
        await notify({ orgId: j.orgId, brandId: j.brandId, level: "ERROR", title: "Falha ao gerar vídeo da persona", body: msg.slice(0, 300), link: "/studio/video" });
      }
      out.push(`${j.id.slice(-6)}: erro — ${msg.slice(0, 120)}`);
    }
  }
  return out.join("; ");
}
