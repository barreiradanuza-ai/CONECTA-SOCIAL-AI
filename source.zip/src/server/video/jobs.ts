import crypto from "node:crypto";
// Fila de vídeos da persona: roteiro (Claude) → voz fixa (MiniMax TTS) → vídeo H3 com as fotos oficiais
// e o áudio como referência (boca sincronizada) → biblioteca de mídia → Reels para aprovação.
import { z } from "zod";
import { db } from "@/lib/db";
import { FAST_MODEL, structured } from "@/server/ai/anthropic";
import { brandSystemPrompt } from "@/server/ai/agent";
import { getBrandContext } from "@/server/brand";
import { saveAsset } from "@/server/media";
import { deleteObject, getObject, putObject, signedMediaUrl } from "@/server/storage";
import { addOutro } from "./outro";
import { notify } from "@/server/notifications";
import { getSecret } from "@/server/integrations";
import { PRICE_PER_SECOND, VIDEO_MODEL, forSpeech, queryVideo, speak, submitVideo } from "./minimax";
import { concatClips } from "./concat";
import { editVideo } from "./edit";
import { SFX_TYPES, type EditPlan } from "./edit-timeline";
import { COMPACT_VIDEO_RULES, VIDEO_SCENE_GUIDE, inspectVisual } from "@/server/ai/visual-rules";
import { sampleFrames } from "./concat";
import { CLIP_MAX_SECONDS, VIDEO_MAX_SECONDS, clampVideoSeconds, speechWordRange, splitSpeech, wordCount } from "@/lib/speech-split";

/** Uma parte do vídeo (o modelo gera no máximo 15 s por clipe; vídeos maiores são feitos em partes e juntados). */
type Part = { speech: string; seconds: number; speechSec?: number | null; voiceAssetId?: string | null; taskId?: string | null };
const readParts = (v: unknown): Part[] => (Array.isArray(v) ? (v as Part[]) : []);

const monthStart = () => {
  const d = new Date();
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1));
};

export async function monthVideoSpend(brandId: string) {
  const r = await db.videoJob.aggregate({ where: { brandId, createdAt: { gte: monthStart() }, status: { notIn: ["FAILED", "CANCELED"] } }, _sum: { estCostUsd: true } });
  return r._sum.estCostUsd ?? 0;
}

export async function enqueueVideo(input: { orgId: string; brandId: string; brief: string; postId?: string | null; createdById?: string | null; durationSec?: number; speech?: string | null; visualPrompt?: string | null; replaceAssetId?: string | null }) {
  const s = await db.automationSettings.findUniqueOrThrow({ where: { brandId: input.brandId } });
  if (!s.videoEnabled) throw new Error("Geração de vídeo desligada em Configurações → Automação.");
  if (!(await getSecret(input.orgId, "MINIMAX_API_KEY"))) throw new Error("Cadastre a chave da MiniMax em Configurações → Integrações para gerar vídeos.");
  // Mínimo de 20 s (vídeos educativos precisam de tempo para mostrar a dica); acima de 15 s o vídeo é feito em 2 partes.
  const duration = clampVideoSeconds(input.durationSec ?? s.videoDefaultSeconds);
  const est = duration * (PRICE_PER_SECOND[s.videoResolution] ?? 0.08);
  const spent = await monthVideoSpend(input.brandId);
  if (spent + est > s.videoMonthlyBudgetUsd) throw new Error(`Teto mensal de vídeo atingido: US$ ${spent.toFixed(2)} de US$ ${s.videoMonthlyBudgetUsd.toFixed(2)}. Aumente o teto em Configurações → Automação.`);
  if (input.postId) {
    const active = await db.videoJob.findFirst({ where: { postId: input.postId, status: { in: ["QUEUED", "VOICE_READY", "SUBMITTED", "REEDIT"] } } });
    if (active) return active;
  }
  return db.videoJob.create({
    data: { orgId: input.orgId, brandId: input.brandId, postId: input.postId ?? null, replaceAssetId: input.replaceAssetId ?? null, brief: input.brief, speech: input.speech ?? null, visualPrompt: input.visualPrompt ?? null, durationSec: duration, resolution: s.videoResolution, model: VIDEO_MODEL, estCostUsd: est, createdById: input.createdById ?? null },
  });
}

const planSchema = z.object({ speech: z.string().min(3), visual_prompt: z.string().min(10), emotion: z.string().optional(), duration: z.number().min(4).max(60) });

async function planVideo(jobId: string, baseSpeech?: string | null) {
  const job = await db.videoJob.findUniqueOrThrow({ where: { id: jobId }, include: { brand: true } });
  const ctx = await getBrandContext(job.brand);
  const words = speechWordRange(job.durationSec);
  const { data } = await structured({
    orgId: job.orgId,
    model: FAST_MODEL(), // tarefa mecânica: transformar o roteiro em fala + cena
    system: brandSystemPrompt(ctx),
    prompt: [
      `Transforme o pedido abaixo em UM vídeo vertical (9:16) de ${job.durationSec} segundos com o personagem da marca falando para a câmera.`,
      `- speech: a fala exata em português do Brasil, natural, no tom do personagem. Entre ${words.min} e ${words.max} palavras (cerca de ${job.durationSec}s falados — NUNCA menos de ${words.min} palavras). Para dicas/tutoriais: gancho com o problema → os passos principais, um por frase, com os nomes reais dos menus → o resultado → um cuidado ou expectativa honesta → fechamento curto que convida a ENVIAR o vídeo para alguém (ex.: \"manda pra quem vive culpando o Wi-Fi\"). Frases curtas e completas (o vídeo é montado em partes e o corte acontece entre frases). Sem hashtags, sem emojis, sem preços.`,
      baseSpeech ? `- A fala atual está curta demais (${wordCount(baseSpeech)} palavras). Use-a como base e ESTENDA mantendo o mesmo assunto, o gancho e as informações dela:\n"""${baseSpeech}"""` : "",
      `- visual_prompt: em INGLÊS, descreva cenário, enquadramento, gestos, expressão e movimento de câmera. O personagem é o mesmo das imagens de referência. ${VIDEO_SCENE_GUIDE}`,
      `- emotion: uma de happy, surprised, neutral, sad, angry, fearful, disgusted.`,
      `- duration: segundos (${job.durationSec}).`,
      `PEDIDO:\n${job.brief}`,
    ]
      .filter(Boolean)
      .join("\n"),
    toolName: "roteiro_video",
    toolDescription: "Registra a fala e a cena do clipe do personagem.",
    schema: {
      type: "object",
      properties: {
        speech: { type: "string" },
        visual_prompt: { type: "string" },
        emotion: { type: "string", enum: ["happy", "surprised", "neutral", "sad", "angry", "fearful", "disgusted"] },
        duration: { type: "number" },
      },
      required: ["speech", "visual_prompt", "duration"],
    },
    validator: planSchema,
    maxTokens: 1500,
  });
  return data;
}

const MULTI_SCENE = /montage|\bscene (two|three|2|3)\b|\bcuts?\b|split.?screen|\bother (people|person)\b|\bcrowd\b|\bteen(age)?\b|\bgirl\b|\bboy\b|\bwoman\b|on.?screen text|text overlay/i;

async function singleShotScene(orgId: string, scene: string): Promise<string> {
  if (!scene || !MULTI_SCENE.test(scene)) return scene;
  try {
    const { data } = await structured({
      orgId,
      model: FAST_MODEL(),
      system: "Você reescreve direções de cena para uma IA de vídeo. Responda só pela ferramenta.",
      prompt: [
        "Reescreva a cena abaixo, em inglês (até 600 caracteres), mantendo o clima e o cenário, seguindo estas regras:",
        VIDEO_SCENE_GUIDE,
        "O personagem da marca é a ÚNICA pessoa em cena e fala para a câmera.",
        `CENA ATUAL:\n${scene.slice(0, 1500)}`,
      ].join("\n"),
      toolName: "cena",
      toolDescription: "Registra a cena reescrita.",
      schema: { type: "object", properties: { scene: { type: "string" } }, required: ["scene"] },
      validator: z.object({ scene: z.string().min(20) }),
      maxTokens: 500,
    });
    return data.scene;
  } catch (e) {
    console.warn("[video] cena não reescrita", e instanceof Error ? e.message.slice(0, 200) : e);
    return scene;
  }
}

const editSchema = z.object({
  hook: z.string().default(""),
  cards: z.array(z.object({ label: z.string().optional().default(""), text: z.string().min(2), anchor: z.string().min(2) })).max(5).default([]),
  sfx: z.array(z.object({ type: z.enum(SFX_TYPES as [string, ...string[]]), anchor: z.string().min(2) })).max(6).default([]),
  keywords: z.array(z.string()).max(10).default([]),
});

/** Plano da edição automática (gancho escrito, cartões de passo, efeitos, palavras-chave) a partir da fala. */
async function planEdit(job: { orgId: string; brief: string }, speech: string): Promise<EditPlan | null> {
  try {
    const { data } = await structured({
      orgId: job.orgId,
      model: FAST_MODEL(),
      system: "Você é editor de Reels de dicas de tecnologia no Brasil. Planeja os elementos de edição que prendem a atenção: texto na tela, cartões com passos e efeitos sonoros. Responda só pela ferramenta.",
      prompt: [
        "Fala do vídeo (exatamente como será dita):",
        `"""${speech}"""`,
        `Contexto: ${job.brief.slice(0, 600)}`,
        "Entregue:",
        "- hook: o gancho ESCRITO que aparece no começo (3 a 6 palavras, no máximo 32 caracteres, forte, sem emoji). Pode ser uma pergunta ou promessa. Escreva Wi-Fi (nunca a forma fonética).",
        "- cards: 2 a 5 cartões com os PASSOS ou a informação que a pessoa quer salvar, na ordem em que aparecem na fala. text curto (no máximo 32 caracteres), use → entre menus (ex.: \"Configurações → Armazenamento\"); label curta opcional (ex.: \"ANDROID\", \"IPHONE\", \"PASSO 1\", \"CUIDADO\", \"RESULTADO\"). anchor: 2 a 4 palavras COPIADAS EXATAMENTE da fala, onde o cartão deve aparecer.",
        `- sfx: até 4 efeitos em momentos fortes (${SFX_TYPES.join(", ")}): ding no resultado/descoberta, boing ou scratch em virada cômica/mito, click em toque na tela. anchor = palavras exatas da fala.`,
        "- keywords: até 8 palavras-chave da fala para destacar na legenda (menus, Wi-Fi, números, a palavra principal do tema).",
        "Se a fala não tiver passos (ex.: humor, opinião), use cards só para a informação principal ou deixe vazio.",
      ].join("\n"),
      toolName: "plano_edicao",
      toolDescription: "Registra o plano de edição do Reels.",
      schema: {
        type: "object",
        properties: {
          hook: { type: "string" },
          cards: { type: "array", items: { type: "object", properties: { label: { type: "string" }, text: { type: "string" }, anchor: { type: "string" } }, required: ["text", "anchor"] } },
          sfx: { type: "array", items: { type: "object", properties: { type: { type: "string", enum: SFX_TYPES }, anchor: { type: "string" } }, required: ["type", "anchor"] } },
          keywords: { type: "array", items: { type: "string" } },
        },
        required: ["hook", "cards", "sfx", "keywords"],
      },
      validator: editSchema,
      maxTokens: 1200,
    });
    return data as EditPlan;
  } catch (e) {
    console.warn("[video] plano de edição não gerado", e instanceof Error ? e.message.slice(0, 200) : e);
    return null;
  }
}

async function step(jobId: string) {
  const job = await db.videoJob.findUniqueOrThrow({ where: { id: jobId }, include: { brand: true } });
  const brand = job.brand;

  if (job.status === "QUEUED") {
    const minWords = speechWordRange(job.durationSec).min;
    let plan: { speech: string; visual_prompt: string; emotion?: string; duration: number };
    if (job.speech && job.visualPrompt && wordCount(job.speech) >= minWords) {
      plan = { speech: job.speech, visual_prompt: job.visualPrompt, duration: job.durationSec };
    } else {
      // Sem fala, ou fala curta demais para o mínimo de 20 s: a IA escreve/estende a fala (mantém a cena aprovada)
      const p = await planVideo(job.id, job.speech);
      plan = { ...p, visual_prompt: job.visualPrompt || p.visual_prompt };
    }
    // Cena com montagem/várias cenas/outras pessoas gera erros visuais: reescreve como um plano contínuo do personagem
    plan.visual_prompt = await singleShotScene(job.orgId, plan.visual_prompt);
    const target = job.durationSec;
    let n = Math.max(1, Math.ceil(target / CLIP_MAX_SECONDS));
    let parts: Part[] = [];
    // Gera a voz de cada parte; se alguma passar de 15 s, divide em mais partes (até 3)
    for (let tries = 0; tries < 3; tries++) {
      const texts = splitSpeech(plan.speech, n);
      parts = [];
      let tooLong = false;
      for (const text of texts) {
        if (brand.personaVoiceId) {
          const tts = await speak(job.orgId, brand.personaVoiceId, text, plan.emotion);
          if (tts.seconds && tts.seconds > CLIP_MAX_SECONDS - 0.5) {
            tooLong = true;
            break;
          }
          const a = await saveAsset({ orgId: job.orgId, brandId: brand.id, buffer: tts.audio, mimeType: "audio/mpeg", kind: "AUDIO", role: "VOICE", source: "AI", title: text.slice(0, 80), prompt: text, durationSec: tts.seconds ?? undefined, isApproved: true });
          const secs = tts.seconds ? Math.min(CLIP_MAX_SECONDS, Math.max(4, Math.ceil(tts.seconds + 0.6))) : Math.min(CLIP_MAX_SECONDS, Math.ceil(target / texts.length));
          parts.push({ speech: text, seconds: secs, speechSec: tts.seconds ?? null, voiceAssetId: a.id });
        } else {
          const secs = Math.min(CLIP_MAX_SECONDS, Math.max(4, Math.ceil(Math.max(target / texts.length, wordCount(text) / 2.4 + 0.6))));
          parts.push({ speech: text, seconds: secs, speechSec: null, voiceAssetId: null });
        }
      }
      if (!tooLong) break;
      if (n >= 3) throw new Error(`A fala ficou longa demais para ${VIDEO_MAX_SECONDS}s. Encurte o texto.`);
      n++;
    }
    const total = parts.reduce((a, p) => a + p.seconds, 0);
    const editPlan = await planEdit(job, plan.speech);
    const est = total * (PRICE_PER_SECOND[job.resolution] ?? 0.08);
    await db.videoJob.update({
      where: { id: job.id },
      data: { status: "VOICE_READY", speech: plan.speech, visualPrompt: plan.visual_prompt, voiceAssetId: parts[0]?.voiceAssetId ?? null, parts: parts as any, editPlan: (editPlan ?? undefined) as any, durationSec: total, estCostUsd: est },
    });
    return `roteiro e voz prontos (${parts.length} parte(s), ${total}s)`;
  }

  if (job.status === "VOICE_READY") {
    const refs = await db.mediaAsset.findMany({ where: { brandId: brand.id, role: "CHARACTER_REFERENCE", kind: "IMAGE" }, orderBy: { createdAt: "asc" }, take: 5 });
    if (!refs.length) throw new Error("Cadastre fotos de referência do personagem em Configurações → Marca.");
    // Jobs antigos (sem partes) viram uma parte só
    const parts: Part[] = readParts(job.parts).length ? readParts(job.parts) : [{ speech: job.speech ?? "", seconds: job.durationSec, voiceAssetId: job.voiceAssetId }];
    for (let i = 0; i < parts.length; i++) {
      const part = parts[i];
      if (part.taskId) continue; // já enviada (retomada depois de erro)
      const voice = part.voiceAssetId ? await db.mediaAsset.findUnique({ where: { id: part.voiceAssetId } }) : null;
      const fixed = [
        parts.length > 1 && i > 0 ? "Continuation of the same video: same character, same outfit, same setting, same lighting and same framing." : "",
        brand.personaVisual ? `Character (same person as the reference images): ${brand.personaVisual.slice(0, 300)}` : "The character is the same person shown in the reference images.",
        voice ? "The character speaks the reference audio line directly to camera with accurate lip sync, Brazilian Portuguese." : `The character says in Brazilian Portuguese: "${part.speech}". The word "Wi-Fi" is pronounced in English ("why-fy").`,
        `Vertical 9:16 social media video, natural lighting. Mandatory rules (they override anything above): ${COMPACT_VIDEO_RULES}`,
      ].filter(Boolean);
      // limite de ~2000 caracteres do prompt de vídeo: a cena é encurtada, as regras ficam inteiras
      const room = Math.max(250, 1950 - fixed.join(" ").length - 1);
      const prompt = [(job.visualPrompt ?? "").slice(0, room), ...fixed].filter(Boolean).join(" ");
      part.taskId = await submitVideo(job.orgId, {
        prompt,
        imageUrls: refs.map((r) => signedMediaUrl(r.storageKey, 6 * 3600)),
        audioUrl: voice ? signedMediaUrl(voice.storageKey, 6 * 3600) : null,
        duration: part.seconds,
        resolution: job.resolution,
        ratio: job.ratio,
      });
      // salva a cada envio: se a próxima parte falhar, esta não é reenviada (nem cobrada de novo)
      await db.videoJob.update({ where: { id: job.id }, data: { parts: parts as any, taskId: parts[0].taskId } });
    }
    await db.videoJob.update({ where: { id: job.id }, data: { status: "SUBMITTED", parts: parts as any, taskId: parts[0].taskId } });
    return parts.length > 1 ? `${parts.length} partes enviadas à MiniMax` : "enviado à MiniMax";
  }

  if ((job.status === "SUBMITTED" && job.taskId) || job.status === "REEDIT") {
    const reedit = job.status === "REEDIT";
    const prefix = `${job.orgId}/${brand.id}/video/${new Date().toISOString().slice(0, 7)}`;
    let joined: { buffer: Buffer; joints: number[] };
    if (reedit && job.cleanKey) {
      // Refazer a edição: usa o vídeo limpo guardado (sem custo de IA de vídeo)
      joined = { buffer: await getObject(job.cleanKey), joints: Array.isArray(job.cleanJoints) ? (job.cleanJoints as number[]) : [] };
    } else {
    if (!reedit && Date.now() - job.updatedAt.getTime() > 45 * 60_000) throw Object.assign(new Error("A MiniMax não concluiu o vídeo em 45 minutos."), { fatal: true });
    const parts: Part[] = readParts(job.parts).length ? readParts(job.parts) : [{ speech: job.speech ?? "", seconds: job.durationSec, taskId: job.taskId }];
    const urls: string[] = [];
    for (const [i, part] of parts.entries()) {
      if (!part.taskId) throw Object.assign(new Error(`Parte ${i + 1} do vídeo não foi enviada.`), { fatal: true });
      const q = await queryVideo(job.orgId, part.taskId);
      if (q.state === "running") return "";
      if (q.state === "failed") throw Object.assign(new Error(`${reedit ? "Os clipes originais não estão mais disponíveis na MiniMax para refazer a edição; use Gerar novamente. " : ""}${parts.length > 1 ? `Parte ${i + 1}: ` : ""}${q.error ?? "Falha na geração."}`), { fatal: true });
      urls.push(q.url!);
    }
    const clips: Buffer[] = [];
    for (const u of urls) {
      const r = await fetch(u, { signal: AbortSignal.timeout(120_000) });
      if (!r.ok) throw Object.assign(new Error(`${reedit ? "Os clipes originais não estão mais disponíveis na MiniMax para refazer a edição; use Gerar novamente. " : ""}Download do vídeo falhou (${r.status}).`), { fatal: reedit && r.status >= 400 && r.status < 500 });
      clips.push(Buffer.from(await r.arrayBuffer()));
    }
    // Junta as partes cortando o silêncio do fim de cada fala (menos na última, onde entra a vinheta)
    joined = clips.length > 1 ? await concatClips(clips, parts.map((p, i) => (i < parts.length - 1 && p.speechSec ? p.speechSec + 0.35 : null))) : { buffer: clips[0], joints: [] as number[] };
    // guarda o vídeo limpo (sem legendas e vinheta) para poder refazer a edição depois sem gerar de novo
    const cleanKey = `${prefix}/${crypto.randomUUID()}-clean.mp4`;
    await putObject(cleanKey, joined.buffer, "video/mp4");
    await db.videoJob.update({ where: { id: job.id }, data: { cleanKey, cleanJoints: joined.joints as any } });
    }
    // Edição automática: legenda animada, gancho, cartões de passo, zoom e efeitos (em falha, segue sem edição)
    const editPlan = (job.editPlan as EditPlan | null) ?? (job.speech ? await planEdit(job, job.speech) : null);
    const edited = await editVideo(joined.buffer, { brand, speech: job.speech ?? "", plan: editPlan, joints: joined.joints });
    if (!edited.applied) console.warn("[video] edição automática não aplicada", job.id, edited.error?.slice(0, 200));
    const raw = edited.buffer;
    // Checagem visual de 3 quadros do vídeo gerado pela IA (antes das legendas do app): texto embutido, celular invertido, mãos
    const frames = await sampleFrames(joined.buffer, 3).catch(() => [] as Buffer[]);
    const vcheck = frames.length ? await inspectVisual(job.orgId, frames, `vídeo vertical do personagem da marca falando para a câmera. Cena: ${job.visualPrompt ?? ""}`) : { ok: true, problems: [] as string[] };
    // Fechamento padrão: escurece, logo da marca e a frase do tema (chamada para ação da publicação)
    const post = job.postId ? await db.post.findUnique({ where: { id: job.postId }, select: { cta: true } }) : null;
    const wa = await db.whatsAppConfig.findUnique({ where: { brandId: brand.id }, select: { ctaText: true } });
    const phrase = post?.cta?.trim() || wa?.ctaText || "Quer descobrir qual internet está disponível no seu endereço? Fale com um especialista.";
    const outro = await addOutro(raw, { brand, phrase, style: "video", postId: job.postId });
    const buf = outro.buffer;
    const totalSec = outro.durationSec ?? job.durationSec;
    const title = (job.speech ?? job.brief).slice(0, 80);
    // Gerar novamente: substitui o mesmo arquivo da biblioteca (mesmo item, conteúdo novo)
    const target = job.replaceAssetId ? await db.mediaAsset.findFirst({ where: { id: job.replaceAssetId, brandId: brand.id, kind: "VIDEO" } }) : null;
    // guarda também a versão sem fechamento (permite trocar a frase depois sem empilhar finais)
    const originalKey = outro.applied ? `${prefix}/${crypto.randomUUID()}-original.mp4` : null;
    if (originalKey) await putObject(originalKey, raw, "video/mp4");
    let asset;
    if (target) {
      const key = `${prefix}/${crypto.randomUUID()}.mp4`;
      await putObject(key, buf, "video/mp4");
      asset = await db.mediaAsset.update({
        where: { id: target.id },
        data: { storageKey: key, originalKey, sizeBytes: buf.length, durationSec: totalSec, title, prompt: job.visualPrompt ?? undefined, isApproved: false },
      });
      await deleteObject(target.storageKey).catch(() => {});
      if (target.originalKey) await deleteObject(target.originalKey).catch(() => {});
    } else {
      asset = await saveAsset({ orgId: job.orgId, brandId: brand.id, buffer: buf, mimeType: "video/mp4", kind: "VIDEO", role: "VIDEO", source: "AI", title, prompt: job.visualPrompt ?? undefined, durationSec: totalSec, tags: ["persona", "ia"], isApproved: false });
      if (originalKey) asset = await db.mediaAsset.update({ where: { id: asset.id }, data: { originalKey } });
    }
    if (!outro.applied) console.warn("[video] fechamento com logo não aplicado", job.id, outro.error?.slice(0, 200));
    await db.videoJob.update({ where: { id: job.id }, data: { status: "SUCCEEDED", videoAssetId: asset.id, error: null } });
    if (job.postId) {
      await db.postMedia.deleteMany({ where: { postId: job.postId, purpose: "VIDEO" } });
      await db.postMedia.create({ data: { postId: job.postId, assetId: asset.id, purpose: "VIDEO", position: 0 } });
      await db.post.update({
        where: { id: job.postId },
        data: {
          status: "PENDING_APPROVAL",
          approvalRequired: true,
          approvalReasons: [
            "Vídeo da persona gerado por IA: revise antes de publicar e marque como conteúdo de IA.",
            ...(vcheck.ok ? [] : [`A checagem visual viu possíveis erros no vídeo: ${vcheck.problems.join("; ")}. Se confirmar, use "Gerar novamente".`.slice(0, 500)]),
          ],
        },
      });
    }
    await notify({ orgId: job.orgId, brandId: brand.id, level: "WARNING", title: "Vídeo da persona pronto para revisão", body: (job.speech ?? job.brief).slice(0, 200), link: job.postId ? `/posts/${job.postId}` : "/studio/video" });
    return "vídeo pronto";
  }
  return "";
}

/** Tarefa do worker: avança cada vídeo pendente uma etapa. */
export async function processVideoJobs() {
  const jobs = await db.videoJob.findMany({ where: { status: { in: ["QUEUED", "VOICE_READY", "SUBMITTED", "REEDIT"] } }, orderBy: { createdAt: "asc" }, take: 5 });
  const out: string[] = [];
  for (const j of jobs) {
    // Consulta de status a cada ~30s não conta como tentativa; só erros contam.
    try {
      const msg = await step(j.id);
      if (msg) out.push(`${j.id.slice(-6)}: ${msg}`);
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      const fatal = (e as { fatal?: boolean })?.fatal || j.attempts + 1 >= 3 || /Credencial ausente|Cadastre fotos/.test(msg);
      if (j.status === "REEDIT" && fatal) {
        // Refazer a edição falhou: o vídeo que já existe continua valendo
        await db.videoJob.update({ where: { id: j.id }, data: { status: "SUCCEEDED", attempts: 0, error: `Refazer edição: ${msg}`.slice(0, 1000) } });
        await notify({ orgId: j.orgId, brandId: j.brandId, level: "WARNING", title: "Não deu para refazer a edição do vídeo", body: msg.slice(0, 300), link: j.postId ? `/posts/${j.postId}` : "/studio/video" });
        out.push(`${j.id.slice(-6)}: refazer edição falhou — ${msg.slice(0, 120)}`);
        continue;
      }
      await db.videoJob.update({ where: { id: j.id }, data: { attempts: { increment: 1 }, error: msg.slice(0, 1000), ...(fatal ? { status: "FAILED" } : {}) } });
      if (fatal) {
        if (j.postId) await db.post.update({ where: { id: j.postId }, data: { generationError: `Vídeo da persona: ${msg}`.slice(0, 2000) } }).catch(() => {});
        await notify({ orgId: j.orgId, brandId: j.brandId, level: "ERROR", title: "Falha ao gerar vídeo da persona", body: msg.slice(0, 300), link: "/studio/video" });
      }
      out.push(`${j.id.slice(-6)}: erro — ${msg.slice(0, 120)}`);
    }
  }
  return out.join("; ");
}

/**
 * Refaz só a edição (legendas, cartões, gancho, efeitos e vinheta) do vídeo de uma publicação, sem gerar
 * vídeo novo na IA: usa o vídeo limpo guardado ou baixa de novo os clipes da MiniMax. Substitui o mesmo arquivo.
 */
export async function requestReedit(postId: string): Promise<{ ok: boolean; message: string }> {
  const link = await db.postMedia.findFirst({ where: { postId, purpose: "VIDEO" }, select: { assetId: true } });
  const job = await db.videoJob.findFirst({
    where: { postId, status: "SUCCEEDED", ...(link ? { videoAssetId: link.assetId } : {}) },
    orderBy: { createdAt: "desc" },
  });
  if (!job || !job.videoAssetId) return { ok: false, message: "Esta publicação não tem vídeo da persona gerado pelo app para refazer a edição." };
  if (!job.cleanKey && !readParts(job.parts).some((p) => p.taskId) && !job.taskId) return { ok: false, message: "Não há os clipes originais deste vídeo; use Gerar novamente." };
  await db.videoJob.update({ where: { id: job.id }, data: { status: "REEDIT", replaceAssetId: job.videoAssetId, attempts: 0, error: null } });
  return { ok: true, message: "Refazendo a edição do vídeo (legendas, cartões e vinheta), sem gerar vídeo novo. Fica pronto em 1 a 2 minutos." };
}

/** Uma vez: refaz a edição dos vídeos recentes ainda não publicados com o layout novo (textos na faixa de baixo). */
export async function reeditRecentOnce(): Promise<string> {
  const TASK = "migration.reedit-band-v2";
  if (await db.taskState.findUnique({ where: { name: TASK } })) return "";
  await db.taskState.create({ data: { name: TASK, lastRunAt: new Date(), lastOk: true } });
  const since = new Date(Date.now() - 48 * 3600_000);
  const jobs = await db.videoJob.findMany({ where: { status: "SUCCEEDED", postId: { not: null }, createdAt: { gte: since } }, orderBy: { createdAt: "desc" } });
  const seen = new Set<string>();
  let n = 0;
  for (const j of jobs) {
    if (!j.postId || seen.has(j.postId)) continue;
    seen.add(j.postId);
    const post = await db.post.findUnique({ where: { id: j.postId }, select: { status: true } });
    if (!post || ["PUBLISHED", "PUBLISHING", "PARTIALLY_PUBLISHED", "CANCELED"].includes(post.status)) continue;
    const r = await requestReedit(j.postId).catch(() => ({ ok: false }));
    if (r.ok) n++;
  }
  return n ? `edição refeita (layout novo) em ${n} vídeo(s) recente(s)` : "";
}
