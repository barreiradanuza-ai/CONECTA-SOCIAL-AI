// Fundo animado de fibra óptica / dados para o fechamento dos vídeos, gerado pelo próprio app (sem banco de
// imagens de terceiros): fios de fibra em curva, pulsos de luz correndo pelos fios e partículas de dados subindo.
// Cada quadro é um SVG desenhado aqui e renderizado com o resvg; o clipe pronto fica em cache no storage.

export type FiberFrameOpts = { W: number; H: number; t: number; seed?: number };

function rng(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6d2b79f5) >>> 0;
    let x = Math.imul(s ^ (s >>> 15), 1 | s);
    x = (x + Math.imul(x ^ (x >>> 7), 61 | x)) ^ x;
    return ((x ^ (x >>> 14)) >>> 0) / 4294967296;
  };
}

type Pt = [number, number];
type Strand = { p: [Pt, Pt, Pt, Pt]; width: number; color: string; pulses: { phase: number; speed: number; len: number }[] };
type Particle = { x: number; y: number; r: number; speed: number; phase: number };

function bez(p: [Pt, Pt, Pt, Pt], u: number): Pt {
  const v = 1 - u;
  const a = v * v * v, b = 3 * v * v * u, c = 3 * v * u * u, d = u * u * u;
  return [a * p[0][0] + b * p[1][0] + c * p[2][0] + d * p[3][0], a * p[0][1] + b * p[1][1] + c * p[2][1] + d * p[3][1]];
}

const COLORS = ["#2f8cff", "#00c8ff", "#4f6bff", "#38e1ff", "#1d5cff"];

function scene(W: number, H: number, seed: number) {
  const r = rng(seed);
  const strands: Strand[] = [];
  for (let i = 0; i < 26; i++) {
    // fios saem da base/esquerda e sobem em curva para a direita/topo (feixe de fibra)
    const x0 = W * (-0.25 + r() * 0.6);
    const y0 = H * (1.02 + r() * 0.1);
    const x3 = W * (0.45 + r() * 0.8);
    const y3 = H * (-0.08 + r() * 0.35);
    const p: [Pt, Pt, Pt, Pt] = [
      [x0, y0],
      [x0 + W * (0.05 + r() * 0.3), H * (0.55 + r() * 0.3)],
      [x3 - W * (0.1 + r() * 0.4), H * (0.3 + r() * 0.35)],
      [x3, y3],
    ];
    const n = 1 + Math.floor(r() * 2);
    strands.push({
      p,
      width: W * (0.0018 + r() * 0.003),
      color: COLORS[Math.floor(r() * COLORS.length)],
      pulses: Array.from({ length: n }, () => ({ phase: r(), speed: 0.22 + r() * 0.35, len: 0.05 + r() * 0.07 })),
    });
  }
  const particles: Particle[] = Array.from({ length: 46 }, () => ({ x: r() * W, y: r() * H, r: W * (0.002 + r() * 0.004), speed: H * (0.02 + r() * 0.05), phase: r() * Math.PI * 2 }));
  return { strands, particles };
}

const cache = new Map<string, ReturnType<typeof scene>>();

/** SVG de um quadro no instante t (segundos). */
export function fiberFrameSvg({ W, H, t, seed = 7 }: FiberFrameOpts) {
  const key = `${W}x${H}:${seed}`;
  if (!cache.has(key)) cache.set(key, scene(W, H, seed));
  const { strands, particles } = cache.get(key)!;
  const f = (n: number) => n.toFixed(1);
  const base: string[] = [];
  const pulses: string[] = [];
  for (const s of strands) {
    const [a, b, c, d] = s.p;
    base.push(`<path d="M${f(a[0])},${f(a[1])} C${f(b[0])},${f(b[1])} ${f(c[0])},${f(c[1])} ${f(d[0])},${f(d[1])}" stroke="${s.color}" stroke-opacity="0.22" stroke-width="${f(s.width)}" fill="none" stroke-linecap="round"/>`);
    for (const p of s.pulses) {
      const u0 = (p.phase + t * p.speed) % 1;
      const pts: string[] = [];
      for (let k = 0; k <= 8; k++) {
        const u = Math.min(1, u0 + (p.len * k) / 8);
        const q = bez(s.p, u);
        pts.push(`${f(q[0])},${f(q[1])}`);
      }
      const head = bez(s.p, Math.min(1, u0 + p.len));
      pulses.push(`<polyline points="${pts.join(" ")}" stroke="url(#pulse)" stroke-width="${f(s.width * 2.4)}" fill="none" stroke-linecap="round"/>`);
      pulses.push(`<circle cx="${f(head[0])}" cy="${f(head[1])}" r="${f(s.width * 2.2)}" fill="#e8fbff"/>`);
    }
  }
  const dots = particles
    .map((p) => {
      const y = (((p.y - t * p.speed) % H) + H) % H;
      const o = 0.25 + 0.35 * (0.5 + 0.5 * Math.sin(p.phase + t * 3));
      return `<circle cx="${f(p.x)}" cy="${f(y)}" r="${f(p.r)}" fill="#7fdcff" fill-opacity="${o.toFixed(2)}"/>`;
    })
    .join("");
  const blur = Math.max(4, Math.round(W * 0.012));
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
<defs>
<radialGradient id="bg" cx="0.7" cy="0.28" r="0.95"><stop offset="0" stop-color="#0d2c6e"/><stop offset="0.45" stop-color="#06173d"/><stop offset="1" stop-color="#020611"/></radialGradient>
<linearGradient id="pulse" x1="0" y1="1" x2="1" y2="0"><stop offset="0" stop-color="#38e1ff" stop-opacity="0"/><stop offset="1" stop-color="#bff4ff" stop-opacity="1"/></linearGradient>
<filter id="glow" x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur stdDeviation="${blur}"/></filter>
<filter id="soft" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="${Math.round(W * 0.06)}"/></filter>
</defs>
<rect width="${W}" height="${H}" fill="url(#bg)"/>
<circle cx="${f(W * 0.78)}" cy="${f(H * 0.22)}" r="${f(W * 0.32)}" fill="#1e6bff" fill-opacity="0.18" filter="url(#soft)"/>
<circle cx="${f(W * 0.15)}" cy="${f(H * 0.85)}" r="${f(W * 0.28)}" fill="#00b4ff" fill-opacity="0.10" filter="url(#soft)"/>
<g>${base.join("")}</g>
<g filter="url(#glow)" opacity="0.9">${pulses.join("")}</g>
<g>${pulses.join("")}</g>
<g>${dots}</g>
</svg>`;
}
