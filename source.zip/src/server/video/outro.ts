// Fechamento padrão dos vídeos (vinheta): logo da marca, linha de destaque, frase do tema e site, com efeito
// sonoro sintetizado (sem música de terceiros). O fechamento SEMPRE começa depois que o personagem termina de
// falar (o fim da fala é detectado no áudio), então a frase nunca entra em cima da fala.
// Modelos:
//   - "video": o próprio vídeo escurece e entram a logo e a frase (padrão);
//   - "blur":  idem, com o vídeo desfocando;
//   - "brand": idem, escurecendo na cor da marca;
//   - "fiber": transição para um fundo animado de fibra óptica / dados (gerado pelo app ou um vídeo seu), escurecido;
//   - "image": transição para uma imagem (foto da publicação ou da biblioteca) com zoom lento, escurecida.
// Montado pelo app (ffmpeg + logo oficial + fonte da marca) — a IA de vídeo não desenha texto/logo com fidelidade.
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import crypto from "node:crypto";
import type { Brand } from "@prisma/client";
import { loadBrandKit, type BrandRenderKit } from "@/server/creative/composer";

const run = promisify(execFile);
export type OutroStyle = "video" | "blur" | "brand" | "fiber" | "image";
export const OUTRO_STYLES: { v: OutroStyle; l: string }[] = [
  { v: "video", l: "Vídeo escurecendo, depois da fala (padrão)" },
  { v: "fiber", l: "Fundo de fibra óptica / dados, escurecido" },
  { v: "image", l: "Finalização com imagem" },
  { v: "blur", l: "Vídeo escurecendo com desfoque" },
  { v: "brand", l: "Vídeo escurecendo na cor da marca" },
];
export function normalizeOutroStyle(v: unknown): OutroStyle {
  return OUTRO_STYLES.some((o) => o.v === v) ? (v as OutroStyle) : "video";
}
const OUTRO_SECONDS = 3; // tempo de leitura da vinheta depois que a fala termina
const XFADE = 0.6; // transição para fundo de fibra/imagem
export const OUTRO_TOTAL_SECONDS = OUTRO_SECONDS;

/** Momento em que a fala termina: início do silêncio final do áudio (ou o fim do vídeo, se falar até o último quadro). */
async function speechEnd(file: string, duration: number, hasAudio: boolean) {
  if (!hasAudio) return duration;
  try {
    const { stderr } = await run("ffmpeg", ["-hide_banner", "-nostats", "-i", file, "-vn", "-af", "silencedetect=noise=-33dB:d=0.25", "-f", "null", "-"], { timeout: 60_000, maxBuffer: 8 * 1024 * 1024 });
    const starts = [...stderr.matchAll(/silence_start:\s*([\d.]+)/g)].map((m) => Number(m[1]));
    const ends = [...stderr.matchAll(/silence_end:\s*([\d.]+)/g)].map((m) => Number(m[1]));
    if (!starts.length) return duration;
    const last = starts[starts.length - 1];
    const lastEnd = ends.length >= starts.length ? ends[ends.length - 1] : null;
    // silêncio final: começou e não terminou (ou terminou no fim do arquivo)
    if (lastEnd === null || lastEnd >= duration - 0.08) return last > 0.5 ? Math.min(last, duration) : duration;
    return duration;
  } catch {
    return duration;
  }
}

async function probe(file: string) {
  const { stdout } = await run("ffprobe", ["-v", "error", "-show_entries", "stream=codec_type,width,height:format=duration", "-of", "json", file], { timeout: 30_000 });
  const j = JSON.parse(stdout);
  const v = (j.streams ?? []).find((s: any) => s.codec_type === "video");
  const hasAudio = (j.streams ?? []).some((s: any) => s.codec_type === "audio");
  return { width: Number(v?.width ?? 720), height: Number(v?.height ?? 1280), duration: Number(j.format?.duration ?? 6), hasAudio };
}

async function renderPng(kit: BrandRenderKit, tree: unknown, width: number, height: number) {
  const satori = (await import("satori")).default;
  const { Resvg } = await import("@resvg/resvg-js");
  const svg = await satori(tree as any, { width, height, fonts: kit.fonts as any });
  return Buffer.from(new Resvg(svg, { fitTo: { mode: "width", value: width }, font: { loadSystemFonts: false } }).render().asPng());
}

/** Divide uma frase única em título + subtítulo (na 1ª pontuação "?", "!" ou "."), quando não vierem separados. */
export function splitOutroPhrase(phrase: string): { title: string; subtitle: string } {
  const p = phrase.trim();
  const m = /^(.{8,80}?[?!.])\s+(.+)$/.exec(p);
  return m ? { title: m[1].trim(), subtitle: m[2].trim() } : { title: p, subtitle: "" };
}

/** Camada transparente: logo (≈34% da largura), linha de destaque, título, subtítulo e site. */
async function renderOverlay(kit: BrandRenderKit, brandName: string, title: string, subtitle: string, W: number, H: number) {
  const phrase = title;
  const logo = kit.logoLight;
  const logoW = Math.round(W * 0.34);
  const logoH = logo ? Math.min(Math.round((logoW * logo.height) / Math.max(1, logo.width)), Math.round(H * 0.16)) : 0;
  const fs = Math.round(W * (phrase.length > 45 ? 0.045 : 0.05));
  const shadow = "0px 2px 12px rgba(0,0,0,0.55)";
  const tree = {
    type: "div",
    props: {
      style: { width: W, height: H, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", position: "relative" },
      children: [
        {
          type: "div",
          props: {
            style: { display: "flex", flexDirection: "column", alignItems: "center", marginTop: -Math.round(H * 0.04), width: Math.round(W * 0.8) },
            children: [
              logo
                ? { type: "img", props: { src: logo.src, width: logoW, height: logoH, style: { width: logoW, height: logoH, objectFit: "contain" } } }
                : { type: "div", props: { style: { fontFamily: kit.headingFont, fontWeight: 700, fontSize: Math.round(W * 0.07), color: "#ffffff", textShadow: shadow }, children: brandName } },
              { type: "div", props: { style: { width: Math.round(W * 0.12), height: Math.max(4, Math.round(H * 0.0045)), borderRadius: 999, background: kit.colors.accent, marginTop: Math.round(H * 0.032), marginBottom: Math.round(H * 0.03) } } },
              {
                type: "div",
                props: {
                  style: { fontFamily: kit.headingFont, fontWeight: 700, fontSize: fs, lineHeight: 1.3, color: "#ffffff", textAlign: "center", textShadow: shadow, display: "flex", justifyContent: "center" },
                  children: phrase,
                },
              },
              subtitle
                ? {
                    type: "div",
                    props: {
                      style: { marginTop: Math.round(H * 0.016), fontFamily: kit.bodyFont, fontWeight: 400, fontSize: Math.round(fs * 0.68), lineHeight: 1.4, color: "rgba(255,255,255,0.88)", textAlign: "center", textShadow: shadow, display: "flex", justifyContent: "center" },
                      children: subtitle,
                    },
                  }
                : null,
            ].filter(Boolean),
          },
        },
        kit.footer
          ? {
              type: "div",
              props: {
                style: { position: "absolute", bottom: Math.round(H * 0.075), left: 0, right: 0, display: "flex", justifyContent: "center", fontFamily: kit.bodyFont, fontWeight: 500, fontSize: Math.round(W * 0.03), color: "rgba(255,255,255,0.82)", letterSpacing: 1 },
                children: kit.footer,
              },
            }
          : null,
      ].filter(Boolean),
    },
  };
  return renderPng(kit, tree, W, H);
}

function hexToRgb(hex: string) {
  const h = hex.replace("#", "");
  const full = h.length === 3 ? h.split("").map((c) => c + c).join("") : h.padEnd(6, "0").slice(0, 6);
  const n = parseInt(full, 16);
  return Number.isFinite(n) ? [(n >> 16) & 255, (n >> 8) & 255, n & 255] : [10, 31, 68];
}

/** Modelo "brand": véu em degradê da cor da marca (topo) para quase preto (base), semitransparente. */
async function renderBrandTint(kit: BrandRenderKit, W: number, H: number) {
  const [r, g, b] = hexToRgb(kit.colors.primary || "#0a1f44");
  const tree = {
    type: "div",
    props: {
      style: { width: W, height: H, display: "flex", backgroundImage: `linear-gradient(180deg, rgba(${r},${g},${b},0.78) 0%, rgba(${Math.round(r * 0.35)},${Math.round(g * 0.35)},${Math.round(b * 0.35)},0.84) 55%, rgba(2,6,15,0.92) 100%)` },
      children: [],
    },
  };
  return renderPng(kit, tree, W, H);
}

// Efeito sonoro: whoosh (ruído filtrado) + toque suave (dois tons com decaimento). Gerado na hora, sem arquivos de terceiros.
const SFX =
  "anoisesrc=d=0.7:c=pink:a=0.35,highpass=f=500,lowpass=f=5000,afade=t=in:d=0.3,afade=t=out:st=0.3:d=0.4,aformat=sample_rates=44100:channel_layouts=stereo[w];" +
  "aevalsrc='0.22*sin(2*PI*880*t)*exp(-3*t)+0.16*sin(2*PI*1318.5*t)*exp(-3.5*t)|0.22*sin(2*PI*880*t)*exp(-3*t)+0.16*sin(2*PI*1318.5*t)*exp(-3.5*t)':s=44100:d=1.6,adelay=450|450[c];" +
  "[w][c]amix=inputs=2:duration=longest:dropout_transition=0,volume=1.8";

/** Véu escuro em degradê para fundos de fibra/imagem: deixa o fundo visível em cima e embaixo e escurece o meio, onde fica o texto. */
async function renderVeil(kit: BrandRenderKit, W: number, H: number, strength: number) {
  const k = (x: number) => Math.min(0.96, x * strength).toFixed(2);
  const tree = {
    type: "div",
    props: {
      style: { width: W, height: H, display: "flex", backgroundImage: `linear-gradient(180deg, rgba(2,6,15,${k(0.35)}) 0%, rgba(2,6,15,${k(0.72)}) 38%, rgba(2,6,15,${k(0.78)}) 62%, rgba(2,6,15,${k(0.9)}) 100%)` },
      children: [],
    },
  };
  return renderPng(kit, tree, W, H);
}

/** Clipe de fundo de fibra óptica (gerado pelo app), em cache no storage por tamanho. */
async function fiberClip(dir: string, W: number, H: number, seconds: number) {
  const { getObject, putObject } = await import("@/server/storage");
  const key = `system/outro-bg/fiber-v1-${W}x${H}-${seconds}s.mp4`;
  const file = path.join(dir, "fiber.mp4");
  try {
    await fs.writeFile(file, await getObject(key));
    return file;
  } catch {
    /* ainda não existe: gera */
  }
  const { fiberFrameSvg } = await import("./fiber");
  const { Resvg } = await import("@resvg/resvg-js");
  const frames = path.join(dir, "fiber-frames");
  await fs.mkdir(frames, { recursive: true });
  // renderiza em meia resolução (mais rápido) e o ffmpeg amplia — o desfoque do brilho esconde a diferença
  const w = Math.round(W / 2 / 2) * 2;
  const h = Math.round(H / 2 / 2) * 2;
  const fps = 30;
  const n = Math.round(seconds * fps);
  for (let i = 0; i < n; i++) {
    const png = new Resvg(fiberFrameSvg({ W: w, H: h, t: i / fps }), { fitTo: { mode: "width", value: w } }).render().asPng();
    await fs.writeFile(path.join(frames, `f${String(i).padStart(4, "0")}.png`), png);
  }
  await run("ffmpeg", ["-y", "-framerate", String(fps), "-i", path.join(frames, "f%04d.png"), "-vf", `scale=${W}:${H}:flags=bicubic,format=yuv420p`, "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-an", file], { timeout: 3 * 60_000, maxBuffer: 16 * 1024 * 1024 });
  await putObject(key, await fs.readFile(file), "video/mp4").catch(() => {});
  return file;
}

/** Imagem padrão da finalização: a foto da publicação (fundo da capa). */
export async function postPhoto(postId?: string | null): Promise<Buffer | null> {
  if (!postId) return null;
  try {
    const { db } = await import("@/lib/db");
    const { getObject } = await import("@/server/storage");
    const bg = await db.postMedia.findFirst({ where: { postId, purpose: { in: ["BACKGROUND"] } }, include: { asset: true } });
    return bg ? await getObject(bg.asset.storageKey) : null;
  } catch {
    return null;
  }
}

/**
 * Acrescenta a vinheta ao vídeo, sempre depois do fim da fala. Em qualquer falha devolve o vídeo original
 * (nunca trava a produção).
 *  - image: imagem para o modelo "image" (padrão: foto da publicação);
 *  - bgVideo: vídeo de fundo para o modelo "fiber" (padrão: fibra óptica animada gerada pelo app).
 */
export async function addOutro(
  video: Buffer,
  opts: { brand: Brand; phrase?: string; title?: string; subtitle?: string; style?: OutroStyle | string; postId?: string | null; image?: Buffer | null; bgVideo?: Buffer | null },
): Promise<{ buffer: Buffer; applied: boolean; style?: OutroStyle; durationSec?: number; error?: string }> {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), `outro-${crypto.randomUUID().slice(0, 8)}-`));
  try {
    const input = path.join(dir, "in.mp4");
    const ovFile = path.join(dir, "overlay.png");
    const tintFile = path.join(dir, "tint.png");
    const output = path.join(dir, "out.mp4");
    await fs.writeFile(input, video);
    const info = await probe(input);
    const W = info.width - (info.width % 2);
    const H = info.height - (info.height % 2);
    const D = info.duration;
    const kit = await loadBrandKit(opts.brand);
    const parts = opts.title ? { title: opts.title.trim(), subtitle: (opts.subtitle ?? "").trim() } : splitOutroPhrase(opts.phrase ?? "");
    await fs.writeFile(ovFile, await renderOverlay(kit, opts.brand.name, parts.title, parts.subtitle, W, H));

    let style = normalizeOutroStyle(opts.style);
    // T0: o fechamento começa 0,15 s depois do fim da fala
    const T0 = Math.min(D, (await speechEnd(input, D, info.hasAudio)) + 0.15);
    const total = style === "fiber" || style === "image" ? T0 + XFADE + OUTRO_SECONDS : Math.max(D, T0 + OUTRO_SECONDS);
    const f2 = (n: number) => n.toFixed(2);

    const src = info.hasAudio ? "[0:a]aformat=sample_rates=44100:channel_layouts=stereo" : `anullsrc=channel_layout=stereo:sample_rate=44100,atrim=0:${f2(D)}`;
    const audio = [
      `${src},apad,atrim=0:${f2(total)},asetpts=PTS-STARTPTS,afade=t=out:st=${f2(T0)}:d=0.6[a0]`,
      `${SFX},adelay=${Math.round(T0 * 1000)}|${Math.round(T0 * 1000)}[s]`,
      `[a0][s]amix=inputs=2:duration=first:dropout_transition=0,volume=1.8[a]`,
    ];
    const inputs = ["-y", "-i", input, "-loop", "1", "-t", f2(total), "-i", ovFile];
    const v: string[] = [];

    // Fundo para os modelos de transição
    let bgReady = false;
    if (style === "image") {
      const img = opts.image ?? (await postPhoto(opts.postId));
      if (img) {
        const sharp = (await import("sharp")).default;
        await fs.writeFile(path.join(dir, "bg.jpg"), await sharp(img).rotate().resize(W * 2, H * 2, { fit: "cover", position: "attention" }).jpeg({ quality: 88 }).toBuffer());
        inputs.push("-loop", "1", "-framerate", "30", "-t", f2(OUTRO_SECONDS + XFADE), "-i", path.join(dir, "bg.jpg"));
        v.push(`[2:v]zoompan=z='min(1+0.0016*on\\,1.12)':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=1:s=${W}x${H}:fps=30,setsar=1,format=yuv420p[bgv]`);
        bgReady = true;
      } else style = "fiber";
    }
    if (style === "fiber") {
      let bgFile: string;
      if (opts.bgVideo) {
        bgFile = path.join(dir, "bgvideo.mp4");
        await fs.writeFile(bgFile, opts.bgVideo);
      } else bgFile = await fiberClip(dir, W, H, 4);
      inputs.push("-stream_loop", "-1", "-t", f2(OUTRO_SECONDS + XFADE), "-i", bgFile);
      v.push(`[2:v]scale=${W}:${H}:force_original_aspect_ratio=increase,crop=${W}:${H},fps=30,setsar=1,format=yuv420p,trim=duration=${f2(OUTRO_SECONDS + XFADE)},setpts=PTS-STARTPTS[bgv]`);
      bgReady = true;
    }

    if (bgReady) {
      // vídeo até o fim da fala (+ quadro congelado durante a transição) → fundo escurecido com logo e frase
      await fs.writeFile(tintFile, await renderVeil(kit, W, H, opts.bgVideo || style === "image" ? 1 : 0.75));
      inputs.push("-loop", "1", "-t", f2(OUTRO_SECONDS + XFADE), "-i", tintFile);
      v.push(
        `[0:v]scale=${W}:${H},setsar=1,fps=30,format=yuv420p,trim=0:${f2(T0)},setpts=PTS-STARTPTS,tpad=stop_mode=clone:stop_duration=${f2(XFADE + 0.05)}[v0]`,
        `[3:v]format=rgba[veil]`,
        `[bgv][veil]overlay=shortest=1,format=yuv420p[bg2]`,
        `[1:v]format=rgba,trim=duration=${f2(OUTRO_SECONDS + XFADE)},fade=t=in:st=${f2(XFADE * 0.8)}:d=0.6:alpha=1[ov]`,
        `[bg2][ov]overlay=shortest=1,format=yuv420p,settb=1/30[v1]`,
        `[v0]settb=1/30[v0b]`,
        `[v0b][v1]xfade=transition=fade:duration=${XFADE}:offset=${f2(T0)},format=yuv420p[v]`,
      );
    } else {
      // o próprio vídeo escurece (congela o último quadro se a fala vai até o fim)
      const hold = Math.max(0, total - D);
      v.push(`[0:v]scale=${W}:${H},setsar=1,fps=30,format=yuv420p${hold > 0.01 ? `,tpad=stop_mode=clone:stop_duration=${f2(hold)}` : ""},trim=duration=${f2(total)}[base]`);
      if (style === "blur") {
        const r = Math.max(4, Math.round(Math.min(W, H) * 0.03));
        v.push(
          `[base]split[s1][s2]`,
          `[s2]boxblur=luma_radius=${r}:luma_power=2:chroma_radius=${Math.max(2, Math.round(r / 2))}:chroma_power=2,format=rgba,fade=t=in:st=${f2(T0)}:d=0.9:alpha=1[bl]`,
          `[s1][bl]overlay=shortest=1,format=yuv420p[b1]`,
          `color=c=0x02060f:s=${W}x${H}:d=${f2(total)}:r=30,format=rgba,colorchannelmixer=aa=0.66,fade=t=in:st=${f2(T0)}:d=0.8:alpha=1[dim]`,
          `[b1][dim]overlay=shortest=1[b2]`,
        );
      } else if (style === "brand") {
        await fs.writeFile(tintFile, await renderBrandTint(kit, W, H));
        inputs.push("-loop", "1", "-t", f2(total), "-i", tintFile);
        v.push(`[2:v]format=rgba,fade=t=in:st=${f2(T0)}:d=0.9:alpha=1[dim]`, `[base][dim]overlay=shortest=1[b2]`);
      } else {
        v.push(
          `color=c=0x02060f:s=${W}x${H}:d=${f2(total)}:r=30,format=rgba,colorchannelmixer=aa=0.72,fade=t=in:st=${f2(T0)}:d=0.8:alpha=1[dim]`,
          `[base][dim]overlay=shortest=1[b2]`,
        );
      }
      v.push(`[1:v]format=rgba,fade=t=in:st=${f2(T0 + 0.45)}:d=0.6:alpha=1[ov]`, `[b2][ov]overlay=shortest=1,format=yuv420p[v]`);
    }

    await run(
      "ffmpeg",
      [...inputs, "-filter_complex", [...v, ...audio].join(";"), "-map", "[v]", "-map", "[a]", "-t", f2(total), "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", output],
      { timeout: 5 * 60_000, maxBuffer: 16 * 1024 * 1024 },
    );
    const outInfo = await probe(output);
    return { buffer: await fs.readFile(output), applied: true, style, durationSec: Math.round(outInfo.duration) };
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    console.error("[outro] fechamento não aplicado:", msg.slice(0, 500));
    return { buffer: video, applied: false, error: msg };
  } finally {
    await fs.rm(dir, { recursive: true, force: true }).catch(() => {});
  }
}
