// Fechamento padrão de todo vídeo gerado: a imagem escurece e aparece a logo da marca com uma frase
// ligada ao tema (a chamada para ação da publicação). Montado pelo app com ffmpeg + logo oficial e fonte
// da marca — sem depender da IA de vídeo para desenhar texto/logo (o que sairia com erros).
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import crypto from "node:crypto";
import type { Brand } from "@prisma/client";
import { loadBrandKit } from "@/server/creative/composer";

const run = promisify(execFile);
const OUTRO_SECONDS = 3;
const FADE = 0.7;

async function probe(file: string) {
  const { stdout } = await run("ffprobe", ["-v", "error", "-show_entries", "stream=codec_type,width,height:format=duration", "-of", "json", file], { timeout: 30_000 });
  const j = JSON.parse(stdout);
  const v = (j.streams ?? []).find((s: any) => s.codec_type === "video");
  const hasAudio = (j.streams ?? []).some((s: any) => s.codec_type === "audio");
  return { width: Number(v?.width ?? 720), height: Number(v?.height ?? 1280), duration: Number(j.format?.duration ?? 6), hasAudio };
}

/** Tela final: fundo escuro, logo centralizada e a frase abaixo. */
async function renderOutroFrame(brand: Brand, phrase: string, width: number, height: number): Promise<Buffer> {
  const kit = await loadBrandKit(brand);
  const satori = (await import("satori")).default;
  const { Resvg } = await import("@resvg/resvg-js");
  const logo = kit.logoLight;
  const logoW = Math.round(width * 0.56);
  const logoH = logo ? Math.round((logoW * logo.height) / Math.max(1, logo.width)) : 0;
  const fontSize = Math.round(width * 0.052);
  const tree = {
    type: "div",
    props: {
      style: { width, height, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", background: "#05070d", padding: Math.round(width * 0.09) },
      children: [
        logo
          ? { type: "img", props: { src: logo.src, width: logoW, height: logoH, style: { width: logoW, height: logoH, objectFit: "contain" } } }
          : { type: "div", props: { style: { fontFamily: kit.headingFont, fontWeight: 700, fontSize: Math.round(width * 0.09), color: "#ffffff" }, children: brand.name } },
        {
          type: "div",
          props: {
            style: { marginTop: Math.round(height * 0.045), fontFamily: kit.bodyFont, fontWeight: 500, fontSize, lineHeight: 1.35, color: "#ffffff", textAlign: "center", display: "flex", justifyContent: "center" },
            children: phrase,
          },
        },
        kit.footer
          ? { type: "div", props: { style: { marginTop: Math.round(height * 0.03), fontFamily: kit.bodyFont, fontSize: Math.round(fontSize * 0.72), color: kit.colors.accent ?? "#4fc3f7", display: "flex" }, children: kit.footer } }
          : null,
      ].filter(Boolean),
    },
  };
  const svg = await satori(tree as any, { width, height, fonts: kit.fonts as any });
  return Buffer.from(new Resvg(svg, { fitTo: { mode: "width", value: width }, font: { loadSystemFonts: false } }).render().asPng());
}

/**
 * Acrescenta o fechamento ao vídeo. Em qualquer falha devolve o vídeo original (nunca trava a produção).
 */
export async function addOutro(video: Buffer, opts: { brand: Brand; phrase: string }): Promise<{ buffer: Buffer; applied: boolean; error?: string }> {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), `outro-${crypto.randomUUID().slice(0, 8)}-`));
  try {
    const input = path.join(dir, "in.mp4");
    const frame = path.join(dir, "outro.png");
    const output = path.join(dir, "out.mp4");
    await fs.writeFile(input, video);
    const info = await probe(input);
    // dimensões pares (exigência do H.264)
    const W = info.width - (info.width % 2);
    const H = info.height - (info.height % 2);
    await fs.writeFile(frame, await renderOutroFrame(opts.brand, opts.phrase.trim(), W, H));
    const fadeAt = Math.max(0, info.duration - FADE).toFixed(2);
    const filters = [
      `[0:v]scale=${W}:${H},setsar=1,fps=30,format=yuv420p,fade=t=out:st=${fadeAt}:d=${FADE}[v0]`,
      `[1:v]scale=${W}:${H},setsar=1,fps=30,format=yuv420p,fade=t=in:st=0:d=${FADE}[v1]`,
      info.hasAudio
        ? `[0:a]aformat=sample_rates=44100:channel_layouts=stereo,afade=t=out:st=${fadeAt}:d=${FADE}[a0]`
        : `[2:a]atrim=0:${info.duration.toFixed(2)},asetpts=PTS-STARTPTS[a0]`,
      `[3:a]atrim=0:${OUTRO_SECONDS},asetpts=PTS-STARTPTS[a1]`,
      `[v0][a0][v1][a1]concat=n=2:v=1:a=1[v][a]`,
    ].join(";");
    await run(
      "ffmpeg",
      [
        "-y",
        "-i", input,
        "-loop", "1", "-t", String(OUTRO_SECONDS), "-i", frame,
        "-f", "lavfi", "-i", "anullsrc=channel_layout=stereo:sample_rate=44100",
        "-f", "lavfi", "-i", "anullsrc=channel_layout=stereo:sample_rate=44100",
        "-filter_complex", filters,
        "-map", "[v]", "-map", "[a]",
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p",
        "-c:a", "aac", "-b:a", "128k",
        "-movflags", "+faststart",
        output,
      ],
      { timeout: 4 * 60_000, maxBuffer: 16 * 1024 * 1024 },
    );
    return { buffer: await fs.readFile(output), applied: true };
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    console.error("[outro] fechamento não aplicado:", msg.slice(0, 500));
    return { buffer: video, applied: false, error: msg };
  } finally {
    await fs.rm(dir, { recursive: true, force: true }).catch(() => {});
  }
}

export const OUTRO_TOTAL_SECONDS = OUTRO_SECONDS;
