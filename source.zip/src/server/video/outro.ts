// Fechamento padrão dos vídeos (vinheta): logo da marca proporcional, linha de destaque, frase do tema e
// o site, com efeito sonoro sintetizado (whoosh + toque suave, sem música de terceiros).
// O fundo varia a cada vídeo:
//   - "video": o próprio vídeo continua por baixo, escurece e a vinheta aparece por cima;
//   - "dark":  degradê escuro da marca com zoom lento;
//   - "image": uma imagem da publicação/biblioteca escurecida, com zoom lento.
// Montado pelo app (ffmpeg + logo oficial + fonte da marca) — a IA de vídeo não desenha texto/logo com fidelidade.
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import crypto from "node:crypto";
import type { Brand } from "@prisma/client";
import { db } from "@/lib/db";
import { getObject } from "@/server/storage";
import { loadBrandKit, type BrandRenderKit } from "@/server/creative/composer";

const run = promisify(execFile);
export type OutroStyle = "auto" | "video" | "dark" | "image";
const BG_SECONDS = 3; // modos "dark" e "image": vinheta acrescentada após o vídeo
const HOLD_SECONDS = 2; // modo "video": congela o último quadro por 2 s sob a vinheta
export const OUTRO_TOTAL_SECONDS = BG_SECONDS;

async function probe(file: string) {
  const { stdout } = await run("ffprobe", ["-v", "error", "-show_entries", "stream=codec_type,width,height:format=duration", "-of", "json", file], { timeout: 30_000 });
  const j = JSON.parse(stdout);
  const v = (j.streams ?? []).find((s: any) => s.codec_type === "video");
  const hasAudio = (j.streams ?? []).some((s: any) => s.codec_type === "audio");
  return { width: Number(v?.width ?? 720), height: Number(v?.height ?? 1280), duration: Number(j.format?.duration ?? 6), hasAudio };
}

async function renderPng(kit: BrandRenderKit, tree: unknown, width: number, height: number) {
  const satori = (await import("satori")).default;
  const { Resvg } = await import("@resvg/resvg-js");
  const svg = await satori(tree as any, { width, height, fonts: kit.fonts as any });
  return Buffer.from(new Resvg(svg, { fitTo: { mode: "width", value: width }, font: { loadSystemFonts: false } }).render().asPng());
}

/** Camada transparente: logo (≈34% da largura), linha de destaque, frase e site. */
async function renderOverlay(kit: BrandRenderKit, brandName: string, phrase: string, W: number, H: number) {
  const logo = kit.logoLight;
  const logoW = Math.round(W * 0.34);
  const logoH = logo ? Math.min(Math.round((logoW * logo.height) / Math.max(1, logo.width)), Math.round(H * 0.16)) : 0;
  const fs = Math.round(W * (phrase.length > 70 ? 0.043 : 0.05));
  const shadow = "0px 2px 12px rgba(0,0,0,0.55)";
  const tree = {
    type: "div",
    props: {
      style: { width: W, height: H, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", position: "relative" },
      children: [
        {
          type: "div",
          props: {
            style: { display: "flex", flexDirection: "column", alignItems: "center", marginTop: -Math.round(H * 0.04), width: Math.round(W * 0.8) },
            children: [
              logo
                ? { type: "img", props: { src: logo.src, width: logoW, height: logoH, style: { width: logoW, height: logoH, objectFit: "contain" } } }
                : { type: "div", props: { style: { fontFamily: kit.headingFont, fontWeight: 700, fontSize: Math.round(W * 0.07), color: "#ffffff", textShadow: shadow }, children: brandName } },
              { type: "div", props: { style: { width: Math.round(W * 0.12), height: Math.max(4, Math.round(H * 0.0045)), borderRadius: 999, background: kit.colors.accent, marginTop: Math.round(H * 0.032), marginBottom: Math.round(H * 0.03) } } },
              {
                type: "div",
                props: {
                  style: { fontFamily: kit.headingFont, fontWeight: 700, fontSize: fs, lineHeight: 1.3, color: "#ffffff", textAlign: "center", textShadow: shadow, display: "flex", justifyContent: "center" },
                  children: phrase,
                },
              },
            ],
          },
        },
        kit.footer
          ? {
              type: "div",
              props: {
                style: { position: "absolute", bottom: Math.round(H * 0.075), left: 0, right: 0, display: "flex", justifyContent: "center", fontFamily: kit.bodyFont, fontWeight: 500, fontSize: Math.round(W * 0.03), color: "rgba(255,255,255,0.82)", letterSpacing: 1 },
                children: kit.footer,
              },
            }
          : null,
      ].filter(Boolean),
    },
  };
  return renderPng(kit, tree, W, H);
}

/** Fundo do modo "dark" (degradê da marca) ou "image" (imagem escurecida). */
async function renderBackground(kit: BrandRenderKit, W: number, H: number, image: Buffer | null) {
  let imgSrc: string | null = null;
  if (image) {
    const sharp = (await import("sharp")).default;
    const jpg = await sharp(image).rotate().resize(W, H, { fit: "cover", position: "attention" }).blur(2).jpeg({ quality: 85 }).toBuffer();
    imgSrc = `data:image/jpeg;base64,${jpg.toString("base64")}`;
  }
  const tree = {
    type: "div",
    props: {
      style: { width: W, height: H, display: "flex", position: "relative", background: "#02060f" },
      children: [
        imgSrc
          ? { type: "img", props: { src: imgSrc, width: W, height: H, style: { position: "absolute", top: 0, left: 0, width: W, height: H } } }
          : { type: "div", props: { style: { position: "absolute", top: 0, left: 0, width: W, height: H, backgroundImage: `linear-gradient(160deg, ${kit.colors.primary} 0%, #040a1c 55%, #010309 100%)` } } },
        imgSrc
          ? { type: "div", props: { style: { position: "absolute", top: 0, left: 0, width: W, height: H, backgroundImage: "linear-gradient(180deg, rgba(2,6,15,0.55) 0%, rgba(2,6,15,0.78) 50%, rgba(2,6,15,0.9) 100%)" } } }
          : { type: "div", props: { style: { position: "absolute", top: Math.round(H * 0.26), left: Math.round(W * 0.1), width: Math.round(W * 0.8), height: Math.round(W * 0.8), borderRadius: 9999, background: kit.colors.accent, opacity: 0.1 } } },
      ],
    },
  };
  return renderPng(kit, tree, W, H);
}

// Efeito sonoro: whoosh (ruído filtrado) + toque suave (dois tons com decaimento). Gerado na hora, sem arquivos de terceiros.
const SFX =
  "anoisesrc=d=0.7:c=pink:a=0.35,highpass=f=500,lowpass=f=5000,afade=t=in:d=0.3,afade=t=out:st=0.3:d=0.4,aformat=sample_rates=44100:channel_layouts=stereo[w];" +
  "aevalsrc='0.22*sin(2*PI*880*t)*exp(-3*t)+0.16*sin(2*PI*1318.5*t)*exp(-3.5*t)|0.22*sin(2*PI*880*t)*exp(-3*t)+0.16*sin(2*PI*1318.5*t)*exp(-3.5*t)':s=44100:d=1.6,adelay=450|450[c];" +
  "[w][c]amix=inputs=2:duration=longest:dropout_transition=0,volume=1.8";

/** Imagem de fundo para o modo "image": o fundo da publicação ou uma foto/imagem da biblioteca da marca. */
export async function pickOutroImage(brandId: string, postId?: string | null): Promise<Buffer | null> {
  try {
    if (postId) {
      const bg = await db.postMedia.findFirst({ where: { postId, purpose: "BACKGROUND" }, include: { asset: true } });
      if (bg) return await getObject(bg.asset.storageKey);
    }
    const pool = await db.mediaAsset.findMany({ where: { brandId, kind: "IMAGE", role: { in: ["PHOTO", "GENERATED", "APPROVED_PIECE"] } }, orderBy: { createdAt: "desc" }, take: 20, select: { storageKey: true } });
    if (!pool.length) return null;
    return await getObject(pool[Math.floor(Math.random() * pool.length)].storageKey);
  } catch {
    return null;
  }
}

/**
 * Acrescenta a vinheta ao vídeo. Em qualquer falha devolve o vídeo original (nunca trava a produção).
 */
export async function addOutro(
  video: Buffer,
  opts: { brand: Brand; phrase: string; style?: OutroStyle; postId?: string | null },
): Promise<{ buffer: Buffer; applied: boolean; style?: OutroStyle; durationSec?: number; error?: string }> {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), `outro-${crypto.randomUUID().slice(0, 8)}-`));
  try {
    const input = path.join(dir, "in.mp4");
    const ovFile = path.join(dir, "overlay.png");
    const bgFile = path.join(dir, "bg.png");
    const output = path.join(dir, "out.mp4");
    await fs.writeFile(input, video);
    const info = await probe(input);
    const W = info.width - (info.width % 2);
    const H = info.height - (info.height % 2);
    const D = info.duration;
    const kit = await loadBrandKit(opts.brand);
    await fs.writeFile(ovFile, await renderOverlay(kit, opts.brand.name, opts.phrase.trim(), W, H));

    // Escolha do fundo (varia a cada vídeo no modo automático)
    let style: OutroStyle = opts.style ?? "auto";
    let image: Buffer | null = null;
    if (style === "image" || style === "auto") image = await pickOutroImage(opts.brand.id, opts.postId);
    if (style === "auto") {
      const options: OutroStyle[] = image ? ["video", "dark", "image"] : ["video", "dark"];
      style = options[Math.floor(Math.random() * options.length)];
    }
    if (style === "image" && !image) style = "dark";

    const src = info.hasAudio ? "[0:a]aformat=sample_rates=44100:channel_layouts=stereo" : `anullsrc=channel_layout=stereo:sample_rate=44100,atrim=0:${D.toFixed(2)},asetpts=PTS-STARTPTS`;
    let args: string[];
    if (style === "video") {
      const total = D + HOLD_SECONDS;
      const st = Math.max(0, D - 1.8).toFixed(2);
      const st2 = (Math.max(0, D - 1.8) + 0.4).toFixed(2);
      const filters = [
        `[0:v]scale=${W}:${H},setsar=1,fps=30,format=yuv420p,tpad=stop_mode=clone:stop_duration=${HOLD_SECONDS}[base]`,
        `color=c=0x02060f:s=${W}x${H}:d=${total.toFixed(2)}:r=30,format=rgba,colorchannelmixer=aa=0.72,fade=t=in:st=${st}:d=0.8:alpha=1[dim]`,
        `[base][dim]overlay=shortest=1[b2]`,
        `[1:v]format=rgba,fade=t=in:st=${st2}:d=0.6:alpha=1[ov]`,
        `[b2][ov]overlay=shortest=1,format=yuv420p[v]`,
        `${src},apad=pad_dur=${HOLD_SECONDS},afade=t=out:st=${st}:d=1.2[a0]`,
        `${SFX},adelay=${Math.round(Number(st) * 1000)}|${Math.round(Number(st) * 1000)}[s]`,
        `[a0][s]amix=inputs=2:duration=first:dropout_transition=0,volume=1.8[a]`,
      ].join(";");
      args = ["-y", "-i", input, "-loop", "1", "-t", total.toFixed(2), "-i", ovFile, "-filter_complex", filters];
    } else {
      await fs.writeFile(bgFile, await renderBackground(kit, W, H, style === "image" ? image : null));
      const fadeAt = Math.max(0, D - 0.6).toFixed(2);
      const filters = [
        `[0:v]scale=${W}:${H},setsar=1,fps=30,format=yuv420p,fade=t=out:st=${fadeAt}:d=0.6[v0]`,
        `[1:v]scale=${W * 2}:${H * 2},zoompan=z='min(1+0.03*on/30\\,1.09)':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=1:s=${W}x${H}:fps=30,format=yuv420p,fade=t=in:st=0:d=0.5[bg]`,
        `[2:v]format=rgba,fade=t=in:st=0.45:d=0.6:alpha=1[ov]`,
        `[bg][ov]overlay=shortest=1,format=yuv420p,trim=duration=${BG_SECONDS},setpts=PTS-STARTPTS[v1]`,
        `${src},afade=t=out:st=${fadeAt}:d=0.6[a0]`,
        `${SFX},apad=whole_dur=${BG_SECONDS},atrim=0:${BG_SECONDS},asetpts=PTS-STARTPTS[a1]`,
        `[v0][a0][v1][a1]concat=n=2:v=1:a=1[v][a]`,
      ].join(";");
      args = ["-y", "-i", input, "-loop", "1", "-framerate", "30", "-t", String(BG_SECONDS), "-i", bgFile, "-loop", "1", "-t", String(BG_SECONDS), "-i", ovFile, "-filter_complex", filters];
    }
    await run(
      "ffmpeg",
      [...args, "-map", "[v]", "-map", "[a]", "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", output],
      { timeout: 4 * 60_000, maxBuffer: 16 * 1024 * 1024 },
    );
    const outInfo = await probe(output);
    return { buffer: await fs.readFile(output), applied: true, style, durationSec: Math.round(outInfo.duration) };
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    console.error("[outro] fechamento não aplicado:", msg.slice(0, 500));
    return { buffer: video, applied: false, error: msg };
  } finally {
    await fs.rm(dir, { recursive: true, force: true }).catch(() => {});
  }
}
