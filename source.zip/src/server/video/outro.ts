// Fechamento padrão dos vídeos (vinheta): o próprio vídeo continua por baixo e escurece; por cima entram a logo
// da marca, uma linha de destaque, a frase do tema e o site, com efeito sonoro sintetizado (sem música de terceiros).
// Modelos (todos partem do vídeo escurecendo, o modelo aprovado):
//   - "video": escurece (padrão);
//   - "blur":  escurece e desfoca o vídeo, deixando a logo mais limpa;
//   - "brand": escurece com um degradê na cor da marca.
// Montado pelo app (ffmpeg + logo oficial + fonte da marca) — a IA de vídeo não desenha texto/logo com fidelidade.
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import crypto from "node:crypto";
import type { Brand } from "@prisma/client";
import { loadBrandKit, type BrandRenderKit } from "@/server/creative/composer";

const run = promisify(execFile);
export type OutroStyle = "video" | "blur" | "brand";
export const OUTRO_STYLES: { v: OutroStyle; l: string }[] = [
  { v: "video", l: "Vídeo escurecendo (padrão)" },
  { v: "blur", l: "Vídeo escurecendo com desfoque" },
  { v: "brand", l: "Vídeo escurecendo na cor da marca" },
];
export function normalizeOutroStyle(v: unknown): OutroStyle {
  return v === "blur" || v === "brand" ? v : "video";
}
const HOLD_SECONDS = 2; // congela o último quadro por 2 s sob a vinheta
export const OUTRO_TOTAL_SECONDS = HOLD_SECONDS;

async function probe(file: string) {
  const { stdout } = await run("ffprobe", ["-v", "error", "-show_entries", "stream=codec_type,width,height:format=duration", "-of", "json", file], { timeout: 30_000 });
  const j = JSON.parse(stdout);
  const v = (j.streams ?? []).find((s: any) => s.codec_type === "video");
  const hasAudio = (j.streams ?? []).some((s: any) => s.codec_type === "audio");
  return { width: Number(v?.width ?? 720), height: Number(v?.height ?? 1280), duration: Number(j.format?.duration ?? 6), hasAudio };
}

async function renderPng(kit: BrandRenderKit, tree: unknown, width: number, height: number) {
  const satori = (await import("satori")).default;
  const { Resvg } = await import("@resvg/resvg-js");
  const svg = await satori(tree as any, { width, height, fonts: kit.fonts as any });
  return Buffer.from(new Resvg(svg, { fitTo: { mode: "width", value: width }, font: { loadSystemFonts: false } }).render().asPng());
}

/** Divide uma frase única em título + subtítulo (na 1ª pontuação "?", "!" ou "."), quando não vierem separados. */
export function splitOutroPhrase(phrase: string): { title: string; subtitle: string } {
  const p = phrase.trim();
  const m = /^(.{8,80}?[?!.])\s+(.+)$/.exec(p);
  return m ? { title: m[1].trim(), subtitle: m[2].trim() } : { title: p, subtitle: "" };
}

/** Camada transparente: logo (≈34% da largura), linha de destaque, título, subtítulo e site. */
async function renderOverlay(kit: BrandRenderKit, brandName: string, title: string, subtitle: string, W: number, H: number) {
  const phrase = title;
  const logo = kit.logoLight;
  const logoW = Math.round(W * 0.34);
  const logoH = logo ? Math.min(Math.round((logoW * logo.height) / Math.max(1, logo.width)), Math.round(H * 0.16)) : 0;
  const fs = Math.round(W * (phrase.length > 45 ? 0.045 : 0.05));
  const shadow = "0px 2px 12px rgba(0,0,0,0.55)";
  const tree = {
    type: "div",
    props: {
      style: { width: W, height: H, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", position: "relative" },
      children: [
        {
          type: "div",
          props: {
            style: { display: "flex", flexDirection: "column", alignItems: "center", marginTop: -Math.round(H * 0.04), width: Math.round(W * 0.8) },
            children: [
              logo
                ? { type: "img", props: { src: logo.src, width: logoW, height: logoH, style: { width: logoW, height: logoH, objectFit: "contain" } } }
                : { type: "div", props: { style: { fontFamily: kit.headingFont, fontWeight: 700, fontSize: Math.round(W * 0.07), color: "#ffffff", textShadow: shadow }, children: brandName } },
              { type: "div", props: { style: { width: Math.round(W * 0.12), height: Math.max(4, Math.round(H * 0.0045)), borderRadius: 999, background: kit.colors.accent, marginTop: Math.round(H * 0.032), marginBottom: Math.round(H * 0.03) } } },
              {
                type: "div",
                props: {
                  style: { fontFamily: kit.headingFont, fontWeight: 700, fontSize: fs, lineHeight: 1.3, color: "#ffffff", textAlign: "center", textShadow: shadow, display: "flex", justifyContent: "center" },
                  children: phrase,
                },
              },
              subtitle
                ? {
                    type: "div",
                    props: {
                      style: { marginTop: Math.round(H * 0.016), fontFamily: kit.bodyFont, fontWeight: 400, fontSize: Math.round(fs * 0.68), lineHeight: 1.4, color: "rgba(255,255,255,0.88)", textAlign: "center", textShadow: shadow, display: "flex", justifyContent: "center" },
                      children: subtitle,
                    },
                  }
                : null,
            ].filter(Boolean),
          },
        },
        kit.footer
          ? {
              type: "div",
              props: {
                style: { position: "absolute", bottom: Math.round(H * 0.075), left: 0, right: 0, display: "flex", justifyContent: "center", fontFamily: kit.bodyFont, fontWeight: 500, fontSize: Math.round(W * 0.03), color: "rgba(255,255,255,0.82)", letterSpacing: 1 },
                children: kit.footer,
              },
            }
          : null,
      ].filter(Boolean),
    },
  };
  return renderPng(kit, tree, W, H);
}

function hexToRgb(hex: string) {
  const h = hex.replace("#", "");
  const full = h.length === 3 ? h.split("").map((c) => c + c).join("") : h.padEnd(6, "0").slice(0, 6);
  const n = parseInt(full, 16);
  return Number.isFinite(n) ? [(n >> 16) & 255, (n >> 8) & 255, n & 255] : [10, 31, 68];
}

/** Modelo "brand": véu em degradê da cor da marca (topo) para quase preto (base), semitransparente. */
async function renderBrandTint(kit: BrandRenderKit, W: number, H: number) {
  const [r, g, b] = hexToRgb(kit.colors.primary || "#0a1f44");
  const tree = {
    type: "div",
    props: {
      style: { width: W, height: H, display: "flex", backgroundImage: `linear-gradient(180deg, rgba(${r},${g},${b},0.78) 0%, rgba(${Math.round(r * 0.35)},${Math.round(g * 0.35)},${Math.round(b * 0.35)},0.84) 55%, rgba(2,6,15,0.92) 100%)` },
      children: [],
    },
  };
  return renderPng(kit, tree, W, H);
}

// Efeito sonoro: whoosh (ruído filtrado) + toque suave (dois tons com decaimento). Gerado na hora, sem arquivos de terceiros.
const SFX =
  "anoisesrc=d=0.7:c=pink:a=0.35,highpass=f=500,lowpass=f=5000,afade=t=in:d=0.3,afade=t=out:st=0.3:d=0.4,aformat=sample_rates=44100:channel_layouts=stereo[w];" +
  "aevalsrc='0.22*sin(2*PI*880*t)*exp(-3*t)+0.16*sin(2*PI*1318.5*t)*exp(-3.5*t)|0.22*sin(2*PI*880*t)*exp(-3*t)+0.16*sin(2*PI*1318.5*t)*exp(-3.5*t)':s=44100:d=1.6,adelay=450|450[c];" +
  "[w][c]amix=inputs=2:duration=longest:dropout_transition=0,volume=1.8";

/**
 * Acrescenta a vinheta ao vídeo. Em qualquer falha devolve o vídeo original (nunca trava a produção).
 */
export async function addOutro(
  video: Buffer,
  opts: { brand: Brand; phrase?: string; title?: string; subtitle?: string; style?: OutroStyle | string; postId?: string | null },
): Promise<{ buffer: Buffer; applied: boolean; style?: OutroStyle; durationSec?: number; error?: string }> {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), `outro-${crypto.randomUUID().slice(0, 8)}-`));
  try {
    const input = path.join(dir, "in.mp4");
    const ovFile = path.join(dir, "overlay.png");
    const bgFile = path.join(dir, "bg.png");
    const output = path.join(dir, "out.mp4");
    await fs.writeFile(input, video);
    const info = await probe(input);
    const W = info.width - (info.width % 2);
    const H = info.height - (info.height % 2);
    const D = info.duration;
    const kit = await loadBrandKit(opts.brand);
    const parts = opts.title ? { title: opts.title.trim(), subtitle: (opts.subtitle ?? "").trim() } : splitOutroPhrase(opts.phrase ?? "");
    await fs.writeFile(ovFile, await renderOverlay(kit, opts.brand.name, parts.title, parts.subtitle, W, H));

    const style = normalizeOutroStyle(opts.style);
    const src = info.hasAudio ? "[0:a]aformat=sample_rates=44100:channel_layouts=stereo" : `anullsrc=channel_layout=stereo:sample_rate=44100,atrim=0:${D.toFixed(2)},asetpts=PTS-STARTPTS`;
    const total = D + HOLD_SECONDS;
    const stN = Math.max(0, D - 1.8);
    const st = stN.toFixed(2);
    const st2 = (stN + 0.4).toFixed(2);
    const inputs = ["-y", "-i", input, "-loop", "1", "-t", total.toFixed(2), "-i", ovFile];
    const v: string[] = [`[0:v]scale=${W}:${H},setsar=1,fps=30,format=yuv420p,tpad=stop_mode=clone:stop_duration=${HOLD_SECONDS}[base]`];
    if (style === "blur") {
      // desfoque entra junto com o escurecimento
      const r = Math.max(4, Math.round(Math.min(W, H) * 0.03));
      v.push(
        `[base]split[s1][s2]`,
        `[s2]boxblur=luma_radius=${r}:luma_power=2:chroma_radius=${Math.max(2, Math.round(r / 2))}:chroma_power=2,format=rgba,fade=t=in:st=${st}:d=0.9:alpha=1[bl]`,
        `[s1][bl]overlay=shortest=1,format=yuv420p[b1]`,
        `color=c=0x02060f:s=${W}x${H}:d=${total.toFixed(2)}:r=30,format=rgba,colorchannelmixer=aa=0.66,fade=t=in:st=${st}:d=0.8:alpha=1[dim]`,
        `[b1][dim]overlay=shortest=1[b2]`,
      );
    } else if (style === "brand") {
      await fs.writeFile(bgFile, await renderBrandTint(kit, W, H));
      inputs.push("-loop", "1", "-t", total.toFixed(2), "-i", bgFile);
      v.push(`[2:v]format=rgba,fade=t=in:st=${st}:d=0.9:alpha=1[dim]`, `[base][dim]overlay=shortest=1[b2]`);
    } else {
      v.push(
        `color=c=0x02060f:s=${W}x${H}:d=${total.toFixed(2)}:r=30,format=rgba,colorchannelmixer=aa=0.72,fade=t=in:st=${st}:d=0.8:alpha=1[dim]`,
        `[base][dim]overlay=shortest=1[b2]`,
      );
    }
    const filters = [
      ...v,
      `[1:v]format=rgba,fade=t=in:st=${st2}:d=0.6:alpha=1[ov]`,
      `[b2][ov]overlay=shortest=1,format=yuv420p[v]`,
      `${src},apad=pad_dur=${HOLD_SECONDS},afade=t=out:st=${st}:d=1.2[a0]`,
      `${SFX},adelay=${Math.round(stN * 1000)}|${Math.round(stN * 1000)}[s]`,
      `[a0][s]amix=inputs=2:duration=first:dropout_transition=0,volume=1.8[a]`,
    ].join(";");
    const args = [...inputs, "-filter_complex", filters];
    await run(
      "ffmpeg",
      [...args, "-map", "[v]", "-map", "[a]", "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", output],
      { timeout: 4 * 60_000, maxBuffer: 16 * 1024 * 1024 },
    );
    const outInfo = await probe(output);
    return { buffer: await fs.readFile(output), applied: true, style, durationSec: Math.round(outInfo.duration) };
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    console.error("[outro] fechamento não aplicado:", msg.slice(0, 500));
    return { buffer: video, applied: false, error: msg };
  } finally {
    await fs.rm(dir, { recursive: true, force: true }).catch(() => {});
  }
}
