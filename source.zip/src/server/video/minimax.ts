// Cliente MiniMax: voz da persona (Voice Design + TTS) e vídeo (H3 com imagens e áudio de referência).
import { getSecret, MissingCredentialError } from "@/server/integrations";

// A MiniMax tem dois endereços: internacional (minimax.io) e China (minimaxi.com). A chave só vale no
// endereço da conta onde foi criada; se o primeiro recusar a chave, tentamos o outro e lembramos o que funcionou.
const HOSTS = Array.from(new Set([process.env.MINIMAX_API_HOST || "https://api.minimax.io", "https://api.minimax.io", "https://api.minimaxi.com"]));
let workingHost: string | null = null;
export function minimaxHosts() {
  return workingHost ? [workingHost, ...HOSTS.filter((h) => h !== workingHost)] : HOSTS;
}
export function rememberMinimaxHost(h: string) {
  workingHost = h;
}
/** Erros de autenticação da MiniMax (chave inválida ou de outro endereço). */
export function isMinimaxAuthError(status: number, code: unknown, msg: string) {
  return status === 401 || Number(code) === 1004 || /login fail|invalid api key|authorization/i.test(msg);
}
export const SPEECH_MODEL = process.env.MINIMAX_SPEECH_MODEL || "speech-2.8-hd";
export const VIDEO_MODEL = process.env.MINIMAX_VIDEO_MODEL || "MiniMax-H3";
/** Preço por segundo (US$) usado para estimar custo e respeitar o teto mensal. */
export const PRICE_PER_SECOND: Record<string, number> = { "768P": 0.08, "2K": 0.13 };

async function key(orgId: string) {
  const k = await getSecret(orgId, "MINIMAX_API_KEY");
  if (!k) throw new MissingCredentialError("chave da MiniMax (MINIMAX_API_KEY)");
  return k;
}

async function call(orgId: string, method: "GET" | "POST", path: string, body?: unknown) {
  const apiKey = (await key(orgId)).trim();
  let lastErr: Error | null = null;
  for (const host of minimaxHosts()) {
    const r = await fetch(`${host}${path}`, {
      method,
      headers: { Authorization: `Bearer ${apiKey}`, "content-type": "application/json" },
      body: body ? JSON.stringify(body) : undefined,
      signal: AbortSignal.timeout(120_000),
    });
    const text = await r.text();
    let j: any;
    try {
      j = JSON.parse(text);
    } catch {
      throw new Error(`MiniMax ${r.status}: resposta inválida`);
    }
    const code = j?.base_resp?.status_code;
    const msg = j?.base_resp?.status_msg ?? j?.error?.message ?? text.slice(0, 300);
    if (r.ok && (code == null || code === 0)) {
      rememberMinimaxHost(host);
      return j;
    }
    lastErr = new Error(`MiniMax ${r.status}: ${msg}`);
    if (!isMinimaxAuthError(r.status, code, String(msg))) throw lastErr;
  }
  throw new Error(`${lastErr?.message ?? "MiniMax: falha de autenticação"} — confira a chave da MiniMax em Configurações → Integrações (a chave precisa ser a "API Key" secreta da conta).`);
}

/** Cria uma voz fixa a partir de uma descrição. Custo único (~US$3). */
export async function designVoice(orgId: string, prompt: string, previewText: string) {
  const j = await call(orgId, "POST", "/v1/voice_design", { prompt, preview_text: previewText });
  if (!j.voice_id) throw new Error("MiniMax não retornou a voz criada.");
  return { voiceId: String(j.voice_id), sample: j.trial_audio ? Buffer.from(String(j.trial_audio), "hex") : null };
}

/**
 * Pronúncia de termos em inglês: a voz em português lê "Wi-Fi" como "vi-fi". O texto da fala continua
 * escrito do jeito certo (legenda, roteiro); só o que vai para a voz recebe a grafia que soa como no inglês.
 */
const PRONUNCIATION: [RegExp, string][] = [
  [/\bwi[\s-]?fis?\b/gi, "uái-fái"], // Wi-Fi, WiFi, wifi, wi fi (e plural)
];
export function forSpeech(text: string): string {
  return PRONUNCIATION.reduce((t, [re, say]) => t.replace(re, say), text);
}

/** Fala da persona em português com a voz fixa (mp3). */
export async function speak(orgId: string, voiceId: string, text: string, emotion?: string) {
  const j = await call(orgId, "POST", "/v1/t2a_v2", {
    model: SPEECH_MODEL,
    text: forSpeech(text),
    voice_setting: { voice_id: voiceId, speed: 1.0, vol: 1.0, pitch: 0, ...(emotion ? { emotion } : {}) },
    audio_setting: { sample_rate: 32000, bitrate: 128000, format: "mp3", channel: 1 },
    language_boost: "Portuguese",
  });
  const hex = j?.data?.audio;
  if (!hex) throw new Error("MiniMax não retornou o áudio.");
  const seconds = j?.extra_info?.audio_length ? Number(j.extra_info.audio_length) / 1000 : null;
  return { audio: Buffer.from(String(hex), "hex"), seconds };
}

/** Envia a geração de vídeo (H3). Imagens e áudio precisam de URL pública (usamos URLs assinadas do app). */
export async function submitVideo(orgId: string, input: { prompt: string; imageUrls: string[]; audioUrl?: string | null; duration: number; resolution: string; ratio: string }) {
  const content: any[] = [{ type: "text", text: input.prompt }];
  for (const url of input.imageUrls.slice(0, 5)) content.push({ type: "image_url", image_url: { url }, role: "reference_image" });
  if (input.audioUrl) content.push({ type: "audio_url", audio_url: { url: input.audioUrl }, role: "reference_audio" });
  const j = await call(orgId, "POST", "/v2/video_generation", { model: VIDEO_MODEL, content, duration: input.duration, resolution: input.resolution, ratio: input.ratio });
  const taskId = j.task_id ?? j.id ?? j.data?.task_id;
  if (!taskId) throw new Error("MiniMax não retornou o id da tarefa de vídeo.");
  return String(taskId);
}

export async function queryVideo(orgId: string, taskId: string): Promise<{ state: "running" | "succeeded" | "failed"; url?: string; error?: string }> {
  const j = await call(orgId, "GET", `/v2/query/video_generation/${encodeURIComponent(taskId)}`);
  const t = j.task ?? j.data ?? j;
  const status = String(t.status ?? "").toLowerCase();
  if (status === "succeeded" || status === "success") {
    const url = t.content?.url ?? t.content?.video_url ?? t.video_url ?? t.url;
    return url ? { state: "succeeded", url } : { state: "failed", error: "Concluído sem URL do vídeo." };
  }
  if (["failed", "fail", "error", "canceled", "cancelled"].includes(status)) return { state: "failed", error: t.error?.message ?? t.error ?? j.base_resp?.status_msg ?? "Falha na geração." };
  return { state: "running" };
}
