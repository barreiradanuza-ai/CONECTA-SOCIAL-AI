// Edição automática dos Reels da persona (feita pelo app, sem custo de IA):
//  - legenda animada palavra por palavra (palavra falada em destaque, palavras-chave na cor da marca);
//  - gancho escrito grande no 1º segundo;
//  - cartões com os passos ("Configurações → Armazenamento") na hora em que são falados;
//  - zoom alternado no ritmo das frases (corte seco, estilo Reels);
//  - efeitos sonoros: whoosh na abertura e nas emendas, pop nos cartões e os que o roteiro pedir.
// Em qualquer falha devolve o vídeo original (nunca trava a produção).
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import crypto from "node:crypto";
import type { Brand } from "@prisma/client";
import { buildTimeline, layerSegments, norm, zoomExpr, type EditPlan, type Interval, type LayerState, type SfxType, type Timeline } from "./edit-timeline";

const run = promisify(execFile);
const f2 = (n: number) => n.toFixed(3);

async function probe(file: string) {
  const { stdout } = await run("ffprobe", ["-v", "error", "-show_entries", "stream=codec_type,width,height:format=duration", "-of", "json", file], { timeout: 30_000 });
  const j = JSON.parse(stdout);
  const v = (j.streams ?? []).find((s: any) => s.codec_type === "video");
  return { width: Number(v?.width ?? 720), height: Number(v?.height ?? 1280), duration: Number(j.format?.duration ?? 6), hasAudio: (j.streams ?? []).some((s: any) => s.codec_type === "audio") };
}

/** Trechos com voz (o inverso dos silêncios). */
export async function voicedIntervals(file: string, duration: number, hasAudio: boolean): Promise<Interval[]> {
  if (!hasAudio) return [[0.3, Math.max(0.6, duration - 0.3)]];
  const { stderr } = await run("ffmpeg", ["-hide_banner", "-nostats", "-i", file, "-vn", "-af", "silencedetect=noise=-35dB:d=0.18", "-f", "null", "-"], { timeout: 60_000, maxBuffer: 8 * 1024 * 1024 });
  const starts = [...stderr.matchAll(/silence_start:\s*(-?[\d.]+)/g)].map((m) => Math.max(0, Number(m[1])));
  const ends = [...stderr.matchAll(/silence_end:\s*([\d.]+)/g)].map((m) => Number(m[1]));
  const out: Interval[] = [];
  let cursor = 0;
  for (let i = 0; i < starts.length; i++) {
    if (starts[i] - cursor > 0.05) out.push([cursor, starts[i]]);
    cursor = ends[i] ?? duration;
  }
  if (duration - cursor > 0.05) out.push([cursor, duration]);
  const voiced = out.filter(([a, b]) => b - a >= 0.08);
  return voiced.length ? voiced : [[0.3, Math.max(0.6, duration - 0.3)]];
}

// Efeitos sonoros sintetizados na hora (sem arquivos nem músicas de terceiros). Cada um é estéreo 44,1 kHz.
const SFX_SRC: Record<SfxType, string> = {
  whoosh: "anoisesrc=d=0.55:c=pink:a=0.6,highpass=f=350,lowpass=f=6500,afade=t=in:d=0.28,afade=t=out:st=0.28:d=0.27,volume=0.55",
  pop: "aevalsrc='sin(2*PI*(500+1400*t)*t)*exp(-28*t)|sin(2*PI*(500+1400*t)*t)*exp(-28*t)':s=44100:d=0.2,volume=0.55",
  ding: "aevalsrc='0.5*sin(2*PI*880*t)*exp(-3*t)+0.35*sin(2*PI*1318.5*t)*exp(-3.5*t)|0.5*sin(2*PI*880*t)*exp(-3*t)+0.35*sin(2*PI*1318.5*t)*exp(-3.5*t)':s=44100:d=1.2,volume=0.5",
  boing: "aevalsrc='sin(2*PI*(200+110*sin(2*PI*8*t))*t)*exp(-3.2*t)|sin(2*PI*(200+110*sin(2*PI*8*t))*t)*exp(-3.2*t)':s=44100:d=0.75,volume=0.45",
  scratch: "anoisesrc=d=0.32:c=white:a=0.7,bandpass=f=1400:width_type=q:w=1.4,tremolo=f=22:d=0.9,afade=t=out:st=0.18:d=0.14,volume=0.5",
  click: "aevalsrc='sin(2*PI*2200*t)*exp(-90*t)|sin(2*PI*2200*t)*exp(-90*t)':s=44100:d=0.07,volume=0.6",
};

export type LayerRenderer = (t: Timeline, s: LayerState, W: number, H: number) => Promise<Buffer>;

/** Monta o vídeo editado. `render` desenha a camada de texto (PNG transparente, tela inteira) de cada estado. */
export async function assembleEdit(input: Buffer, o: { speech: string; plan: EditPlan | null; joints?: number[]; render: LayerRenderer; zoom?: number }): Promise<{ buffer: Buffer; timeline: Timeline }> {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), `edit-${crypto.randomUUID().slice(0, 8)}-`));
  try {
    const inFile = path.join(dir, "in.mp4");
    await fs.writeFile(inFile, input);
    const info = await probe(inFile);
    const W = info.width - (info.width % 2);
    const H = info.height - (info.height % 2);
    const D = info.duration;
    const voiced = await voicedIntervals(inFile, D, info.hasAudio);
    const t = buildTimeline({ speech: o.speech, voiced, duration: D, plan: o.plan, joints: o.joints });

    // Camada de texto: uma imagem por estado visual, em sequência (concat demuxer)
    const segs = layerSegments(t);
    const cache = new Map<string, string>();
    const lines: string[] = [];
    for (const s of segs) {
      const key = JSON.stringify(s.state);
      let file = cache.get(key);
      if (!file) {
        file = path.join(dir, `l${cache.size}.png`);
        await fs.writeFile(file, await o.render(t, s.state, W, H));
        cache.set(key, file);
      }
      lines.push(`file '${file}'`, `duration ${f2(s.end - s.start)}`);
    }
    if (segs.length) lines.push(`file '${cache.get(JSON.stringify(segs[segs.length - 1].state))}'`);
    const list = path.join(dir, "layers.txt");
    await fs.writeFile(list, lines.join("\n"));

    const z = o.zoom ?? 0.1;
    const filters: string[] = [
      `[0:v]scale=${W}:${H},setsar=1,fps=30,zoompan=z='${zoomExpr(t.zoomOn, z)}':d=1:x='iw/2-(iw/zoom/2)':y='(ih-ih/zoom)*0.38':s=${W}x${H}:fps=30,format=yuv420p[bz]`,
      `[1:v]fps=30,scale=${W}:${H},format=rgba[lay]`,
      `[bz][lay]overlay=0:0:eof_action=pass:format=auto,format=yuv420p[v]`,
      info.hasAudio ? `[0:a]aresample=44100,aformat=sample_fmts=fltp:channel_layouts=stereo[voice]` : `anullsrc=r=44100:cl=stereo,atrim=duration=${f2(D)},aformat=sample_fmts=fltp[voice]`,
    ];
    const mix = ["[voice]"];
    t.sfx.forEach((s, i) => {
      const ms = Math.max(0, Math.round(s.at * 1000));
      filters.push(`${SFX_SRC[s.type]},aformat=sample_fmts=fltp:sample_rates=44100:channel_layouts=stereo,adelay=${ms}|${ms}[s${i}]`);
      mix.push(`[s${i}]`);
    });
    filters.push(mix.length > 1 ? `${mix.join("")}amix=inputs=${mix.length}:duration=first:dropout_transition=0:normalize=0,alimiter=limit=0.95[a]` : `[voice]anull[a]`);

    const out = path.join(dir, "out.mp4");
    await run(
      "ffmpeg",
      ["-y", "-i", inFile, "-f", "concat", "-safe", "0", "-i", list, "-filter_complex", filters.join(";"), "-map", "[v]", "-map", "[a]", "-t", f2(D), "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k", "-movflags", "+faststart", out],
      { timeout: 6 * 60_000, maxBuffer: 16 * 1024 * 1024 },
    );
    return { buffer: await fs.readFile(out), timeline: t };
  } finally {
    await fs.rm(dir, { recursive: true, force: true }).catch(() => {});
  }
}

// ─────────────── Camada de texto (Satori, fontes e cores da marca) ───────────────
// Tudo fica na faixa de baixo do quadro (o rosto do personagem fica na metade de cima — ver VIDEO_FRAMING_RULES):
// gancho/cartão a partir de 58% da altura e legenda a partir de 73%, longe dos ícones laterais do Reels.
const SLOT_TOP = 0.58;
const CAPTION_TOP = 0.73;
const BAND_LEFT = 0.06;
const BAND_WIDTH = 0.78;

/** Texto seguro para a fonte da marca: sem emoji/hashtag e com "›" no lugar de "→" (a fonte não tem a seta). */
function safeText(s: string, clean: (s: string) => string) {
  return clean(s).replace(/\s*(→|->|=>|➜)\s*/g, " › ").trim();
}

function brandRenderer(kit: import("@/server/creative/composer").BrandRenderKit, readableOn: (bg: string) => string, renderPng: (kit: any, tree: unknown, w: number, h: number) => Promise<Buffer>, clean: (s: string) => string): LayerRenderer {
  const accent = kit.colors.accent || "#18c3e8";
  const primary = kit.colors.primary || "#0a1f44";
  return async (t, s, W, H) => {
    const children: unknown[] = [];
    const shadow = "0px 3px 10px rgba(0,0,0,0.65)";
    if (s.hook && t.hook) {
      const hookText = safeText(t.hook.text, clean);
      const len = hookText.length;
      children.push({
        type: "div",
        props: {
          style: { position: "absolute", top: Math.round(H * SLOT_TOP), left: Math.round(W * BAND_LEFT), width: Math.round(W * BAND_WIDTH), display: "flex", justifyContent: "center" },
          children: {
            type: "div",
            props: {
              style: { display: "flex", textAlign: "center", justifyContent: "center", backgroundColor: primary, color: readableOn(primary), fontFamily: kit.headingFont, fontWeight: 700, fontSize: Math.round(W * (len > 40 ? 0.052 : len > 26 ? 0.06 : 0.07)), lineHeight: 1.18, padding: `${Math.round(W * 0.03)}px ${Math.round(W * 0.045)}px`, borderRadius: Math.round(W * 0.03), borderBottom: `${Math.max(4, Math.round(W * 0.01))}px solid ${accent}` },
              children: hookText.toUpperCase(),
            },
          },
        },
      });
    }
    if (s.card >= 0) {
      const c = { ...t.cards[s.card], text: safeText(t.cards[s.card].text, clean), label: safeText(t.cards[s.card].label, clean) };
      children.push({
        type: "div",
        props: {
          style: { position: "absolute", top: Math.round(H * SLOT_TOP), left: Math.round(W * BAND_LEFT), width: Math.round(W * BAND_WIDTH), display: "flex", flexDirection: "column", alignItems: "flex-start", backgroundColor: "rgba(8,16,36,0.78)", borderRadius: Math.round(W * 0.03), padding: `${Math.round(W * 0.026)}px ${Math.round(W * 0.036)}px`, borderLeft: `${Math.max(5, Math.round(W * 0.012))}px solid ${accent}` },
          children: [
            { type: "div", props: { style: { display: "flex", backgroundColor: accent, color: readableOn(accent), fontFamily: kit.bodyFont, fontWeight: 700, fontSize: Math.round(W * 0.026), letterSpacing: 1, padding: `${Math.round(W * 0.006)}px ${Math.round(W * 0.018)}px`, borderRadius: 999, marginBottom: Math.round(W * 0.012) }, children: c.label.toUpperCase() } },
            { type: "div", props: { style: { display: "flex", color: "#ffffff", fontFamily: kit.headingFont, fontWeight: 700, fontSize: Math.round(W * (c.text.length > 34 ? 0.042 : 0.048)), lineHeight: 1.25 }, children: c.text } },
          ],
        },
      });
    }
    if (s.chunk >= 0) {
      const ws = t.chunks[s.chunk].words;
      children.push({
        type: "div",
        props: {
          style: { position: "absolute", top: Math.round(H * CAPTION_TOP), left: Math.round(W * BAND_LEFT), width: Math.round(W * BAND_WIDTH), display: "flex", justifyContent: "center" },
          children: {
            type: "div",
            props: {
              style: { display: "flex", flexWrap: "wrap", justifyContent: "center", alignItems: "center" },
              children: ws.map((w, k) => {
                const isActive = k === s.active;
                const isKey = t.keywords.has(norm(w.text));
                return {
                  type: "div",
                  props: {
                    style: {
                      display: "flex",
                      fontFamily: kit.headingFont,
                      fontWeight: 700,
                      fontSize: Math.round(W * 0.072),
                      lineHeight: 1.1,
                      padding: `${Math.round(W * 0.006)}px ${Math.round(W * 0.016)}px`,
                      borderRadius: Math.round(W * 0.02),
                      margin: `${Math.round(W * 0.006)}px ${Math.round(W * 0.008)}px`,
                      color: isActive ? readableOn(accent) : isKey ? accent : "#ffffff",
                      backgroundColor: isActive ? accent : "rgba(0,0,0,0)",
                      textShadow: isActive ? "none" : shadow,
                    },
                    children: safeText(w.text, clean).replace(/[,;:]$/, "").toUpperCase() || " ",
                  },
                };
              }),
            },
          },
        },
      });
    }
    const tree = { type: "div", props: { style: { width: W, height: H, display: "flex", position: "relative" }, children } };
    return renderPng(kit, tree, W, H);
  };
}

/** Edita o vídeo com a identidade da marca. Nunca lança erro: em falha devolve o original. */
export async function editVideo(video: Buffer, o: { brand: Brand; speech: string; plan: EditPlan | null; joints?: number[] }): Promise<{ buffer: Buffer; applied: boolean; error?: string }> {
  try {
    if (!o.speech?.trim()) return { buffer: video, applied: false, error: "sem fala" };
    const { loadBrandKit } = await import("@/server/creative/composer");
    const { readableOn } = await import("@/server/creative/color");
    const { renderPng } = await import("./outro");
    const { cleanArtText } = await import("@/server/creative/templates");
    const kit = await loadBrandKit(o.brand);
    const { buffer } = await assembleEdit(video, { speech: o.speech, plan: o.plan, joints: o.joints, render: brandRenderer(kit, (bg) => readableOn(bg), renderPng, cleanArtText) });
    return { buffer, applied: true };
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    console.error("[edit] edição automática não aplicada:", msg.slice(0, 500));
    return { buffer: video, applied: false, error: msg };
  }
}
