// Motor de composição gráfica: fundo (IA ou biblioteca) + camada tipográfica/logotipo/CTA/preço
// renderizada deterministicamente (Satori → SVG → Resvg → PNG → JPEG via sharp).
import fs from "node:fs/promises";
import path from "node:path";
import type { Brand } from "@prisma/client";
import { db } from "@/lib/db";
import { getObject } from "@/server/storage";
import { buildLayout, type ComposeInput, type LogoInfo } from "./templates";
import { normalizeColors, type BrandColors } from "./color";

type FontDef = { name: string; data: Buffer; weight: 400 | 500 | 700; style: "normal" };

let defaultFontsCache: FontDef[] | null = null;

async function loadDefaultFonts(): Promise<FontDef[]> {
  if (defaultFontsCache) return defaultFontsCache;
  const dir = path.join(process.cwd(), "assets", "fonts");
  const [r, m, b] = await Promise.all(["Poppins-Regular.ttf", "Poppins-Medium.ttf", "Poppins-Bold.ttf"].map((f) => fs.readFile(path.join(dir, f))));
  defaultFontsCache = [
    { name: "Poppins", data: r, weight: 400, style: "normal" },
    { name: "Poppins", data: m, weight: 500, style: "normal" },
    { name: "Poppins", data: b, weight: 700, style: "normal" },
  ];
  return defaultFontsCache;
}

export type BrandRenderKit = {
  colors: BrandColors;
  fonts: FontDef[];
  headingFont: string;
  bodyFont: string;
  logoLight: LogoInfo; // para fundos escuros/fotos
  logoDark: LogoInfo; // para fundos claros
  footer: string | null;
  hasLogo: boolean;
};

async function assetToLogo(assetId: string | undefined | null): Promise<LogoInfo> {
  if (!assetId) return null;
  const asset = await db.mediaAsset.findUnique({ where: { id: assetId } });
  if (!asset) return null;
  const buf = await getObject(asset.storageKey);
  const sharp = (await import("sharp")).default;
  // Converte para PNG preservando proporção e transparência (sem distorcer ou recolorir).
  const png = await sharp(buf, { density: asset.mimeType === "image/svg+xml" ? 300 : 72 }).png().toBuffer();
  const meta = await sharp(png).metadata();
  return { src: `data:image/png;base64,${png.toString("base64")}`, width: meta.width ?? 400, height: meta.height ?? 120 };
}

export async function loadBrandKit(brand: Brand): Promise<BrandRenderKit> {
  const fonts = [...(await loadDefaultFonts())];
  let headingFont = "Poppins";
  let bodyFont = "Poppins";
  for (const [id, alias] of [
    [brand.fontHeadingAssetId, "BrandHeading"],
    [brand.fontBodyAssetId, "BrandBody"],
  ] as const) {
    if (!id) continue;
    const a = await db.mediaAsset.findUnique({ where: { id } });
    if (!a) continue;
    try {
      const data = await getObject(a.storageKey);
      fonts.push({ name: alias, data, weight: 400, style: "normal" }, { name: alias, data, weight: 700, style: "normal" });
      if (alias === "BrandHeading") headingFont = alias;
      else bodyFont = alias;
    } catch (e) {
      console.warn("[composer] fonte da marca indisponível", e);
    }
  }
  const logos = await db.mediaAsset.findMany({
    where: { brandId: brand.id, role: { in: ["LOGO_TRANSPARENT", "LOGO_PRIMARY", "LOGO_ALT"] } },
    orderBy: { createdAt: "desc" },
  });
  // LOGO_TRANSPARENT = versão para fundo escuro (ex.: branca); LOGO_PRIMARY = versão colorida para fundo claro
  const light = logos.find((l) => l.role === "LOGO_TRANSPARENT") ?? logos.find((l) => l.role === "LOGO_PRIMARY") ?? logos[0];
  const dark = logos.find((l) => l.role === "LOGO_PRIMARY") ?? light;
  const logoLight = light ? await assetToLogo(light.id) : null;
  const logoDark = dark && dark.id !== light?.id ? await assetToLogo(dark.id) : logoLight;
  const footer = brand.website ? brand.website.replace(/^https?:\/\/(www\.)?/, "").replace(/\/$/, "") : null;
  return { colors: normalizeColors(brand.colors), fonts, headingFont, bodyFont, logoLight, logoDark, footer, hasLogo: !!logoLight };
}

/** Recorta/redimensiona o fundo para o tamanho exato e devolve data URI JPEG. */
export async function prepareBackground(buf: Buffer, width: number, height: number): Promise<string> {
  const sharp = (await import("sharp")).default;
  const out = await sharp(buf).rotate().resize(width, height, { fit: "cover", position: "attention" }).jpeg({ quality: 90 }).toBuffer();
  return `data:image/jpeg;base64,${out.toString("base64")}`;
}

export async function renderCreative(kit: BrandRenderKit, input: Omit<ComposeInput, "colors" | "headingFont" | "bodyFont" | "logo" | "logoDark" | "footer"> & { footer?: string | null }): Promise<Buffer> {
  const satori = (await import("satori")).default;
  const { Resvg } = await import("@resvg/resvg-js");
  const sharp = (await import("sharp")).default;

  const tree = buildLayout({
    ...input,
    colors: kit.colors,
    headingFont: kit.headingFont,
    bodyFont: kit.bodyFont,
    logo: kit.logoLight,
    logoDark: kit.logoDark,
    footer: input.footer === undefined ? kit.footer : input.footer,
  });
  const svg = await satori(tree as any, { width: input.width, height: input.height, fonts: kit.fonts as any });
  const png = new Resvg(svg, { fitTo: { mode: "width", value: input.width }, font: { loadSystemFonts: false } }).render().asPng();
  return sharp(png).flatten({ background: "#ffffff" }).jpeg({ quality: 90, chromaSubsampling: "4:4:4", mozjpeg: true }).toBuffer();
}
