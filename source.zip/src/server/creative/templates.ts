// Layouts de peças (árvores de elementos para o Satori). Sem JSX para rodar igual no Next e no worker.
// Regra do Satori: todo <div> com mais de um filho precisa de display:flex.
import { type BrandColors, readableOn, rgba } from "./color";

export type El = { type: string; props: Record<string, unknown> };
type Style = Record<string, string | number>;

export function h(type: string, style: Style, children?: unknown, extra: Record<string, unknown> = {}): El {
  return { type, props: { style, children, ...extra } };
}
const div = (style: Style, children?: unknown) => h("div", { display: "flex", ...style }, children);
const text = (style: Style, value: string) => h("div", { display: "flex", ...style }, value);

export type LogoInfo = { src: string; width: number; height: number } | null;

export type ComposeInput = {
  width: number;
  height: number;
  layout: string;
  colors: BrandColors;
  headingFont: string;
  bodyFont: string;
  backgroundSrc?: string | null; // data URI já redimensionado
  logo: LogoInfo; // versão para fundos escuros/foto
  logoDark?: LogoInfo; // versão colorida para fundos claros
  title: string;
  subtitle?: string | null;
  cta?: string | null;
  footer?: string | null;
  offer?: { operator: string; speed: string; price: string; period: string; benefits: string[]; footnote: string } | null;
  slide?: { index: number; total: number; title: string; body: string; kind: "cover" | "content" | "final" } | null;
};

/** Remove emojis e caracteres que a fonte não suporta (evita "tofu" na arte). */
export function cleanArtText(s: string | null | undefined): string {
  if (!s) return "";
  return s
    .replace(/[\p{Extended_Pictographic}\u{FE0F}\u{200D}]/gu, "")
    .replace(/#\w+/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

export function titleSize(t: string, base: number) {
  const n = t.length;
  if (n <= 22) return Math.round(base * 1.12);
  if (n <= 36) return base;
  if (n <= 52) return Math.round(base * 0.84);
  if (n <= 70) return Math.round(base * 0.72);
  return Math.round(base * 0.62);
}

function logoEl(logo: LogoInfo, maxW: number, maxH: number): El | null {
  if (!logo) return null;
  const scale = Math.min(maxW / logo.width, maxH / logo.height);
  return h("img", {}, undefined, { src: logo.src, width: Math.round(logo.width * scale), height: Math.round(logo.height * scale) });
}

function ctaPill(input: ComposeInput, size: number): El | null {
  const cta = cleanArtText(input.cta);
  if (!cta) return null;
  const fg = readableOn(input.colors.accent);
  return div(
    {
      backgroundColor: input.colors.accent,
      color: fg,
      borderRadius: 999,
      padding: `${Math.round(size * 0.55)}px ${Math.round(size * 1.1)}px`,
      fontSize: size,
      fontFamily: input.bodyFont,
      fontWeight: 700,
      alignSelf: "flex-start",
      alignItems: "center",
    },
    cta,
  );
}

function techRings(color: string, size: number, top: number, right: number): El {
  return div(
    { position: "absolute", top, right, width: size, height: size, alignItems: "center", justifyContent: "center" },
    [
      div({ position: "absolute", width: size, height: size, borderRadius: 999, border: `2px solid ${rgba(color, 0.25)}` }),
      div({ position: "absolute", width: size * 0.66, height: size * 0.66, borderRadius: 999, border: `2px solid ${rgba(color, 0.35)}` }),
      div({ position: "absolute", width: size * 0.33, height: size * 0.33, borderRadius: 999, border: `2px solid ${rgba(color, 0.5)}` }),
      div({ position: "absolute", width: 14, height: 14, borderRadius: 999, backgroundColor: color }),
    ],
  );
}

function bgImage(input: ComposeInput, height = input.height, opacity = 1): El | null {
  if (!input.backgroundSrc) return null;
  return h("img", { position: "absolute", top: 0, left: 0, width: input.width, height, objectFit: "cover", opacity }, undefined, {
    src: input.backgroundSrc,
    width: input.width,
    height,
  });
}

function footerEl(input: ComposeInput, color: string, size = 24): El | null {
  const f = cleanArtText(input.footer);
  return f ? text({ fontSize: size, color, fontFamily: input.bodyFont, opacity: 0.85 }, f) : null;
}

// ─────────────── Layouts ───────────────

function heroBottom(input: ComposeInput): El {
  const { width: W, height: H, colors } = input;
  const pad = Math.round(W * 0.066);
  const title = cleanArtText(input.title);
  const isStory = H / W > 1.6;
  const tSize = titleSize(title, isStory ? 88 : 76);
  return div({ position: "relative", width: W, height: H, backgroundColor: colors.primary, fontFamily: input.bodyFont }, [
    bgImage(input),
    div({
      position: "absolute",
      top: 0,
      left: 0,
      width: W,
      height: H,
      backgroundImage: `linear-gradient(180deg, ${rgba(colors.primary, 0.35)} 0%, ${rgba(colors.primary, 0)} 22%, ${rgba(colors.primary, 0.1)} 42%, ${rgba(colors.primary, 0.88)} 70%, ${rgba(colors.primary, 0.97)} 100%)`,
    }),
    techRings("#ffffff", 220, isStory ? 230 : 40, -60),
    div({ position: "absolute", top: isStory ? 250 : pad, left: pad }, logoEl(input.logo, 260, 150)),
    div(
      {
        position: "absolute",
        left: pad,
        right: pad,
        bottom: isStory ? 360 : pad,
        flexDirection: "column",
        gap: 26,
      },
      [
        div({ width: 96, height: 8, borderRadius: 8, backgroundColor: colors.accent }),
        text({ fontSize: tSize, lineHeight: 1.08, fontWeight: 700, color: "#ffffff", fontFamily: input.headingFont, letterSpacing: -1 }, title),
        input.subtitle ? text({ fontSize: isStory ? 40 : 34, lineHeight: 1.3, color: "rgba(255,255,255,0.9)" }, cleanArtText(input.subtitle)) : null,
        div({ marginTop: 10, alignItems: "center", justifyContent: "space-between", width: "100%" }, [ctaPill(input, isStory ? 36 : 30), footerEl(input, "#ffffff")]),
      ],
    ),
  ]);
}

function splitPanel(input: ComposeInput): El {
  const { width: W, height: H, colors } = input;
  const pad = Math.round(W * 0.066);
  const imgH = Math.round(H * 0.56);
  const title = cleanArtText(input.title);
  const onPrimary = readableOn(colors.primary);
  return div({ position: "relative", width: W, height: H, backgroundColor: colors.primary, fontFamily: input.bodyFont }, [
    bgImage(input, imgH),
    div({ position: "absolute", top: 0, left: 0, width: W, height: 200, backgroundImage: `linear-gradient(180deg, ${rgba(colors.primary, 0.55)}, ${rgba(colors.primary, 0)})` }),
    div({ position: "absolute", top: pad, left: pad }, logoEl(input.logo, 240, 140)),
    div(
      {
        position: "absolute",
        left: 0,
        top: imgH - 48,
        width: W,
        height: H - imgH + 48,
        backgroundColor: colors.primary,
        borderTopLeftRadius: 48,
        borderTopRightRadius: 48,
        padding: `${pad}px ${pad}px ${pad}px ${pad}px`,
        flexDirection: "column",
        gap: 22,
      },
      [
        div({ width: 96, height: 8, borderRadius: 8, backgroundColor: colors.accent }),
        text({ fontSize: titleSize(title, 66), lineHeight: 1.1, fontWeight: 700, color: onPrimary, fontFamily: input.headingFont, letterSpacing: -0.5 }, title),
        input.subtitle ? text({ fontSize: 32, lineHeight: 1.32, color: rgba(onPrimary === "#ffffff" ? "#ffffff" : "#0b1530", 0.88) }, cleanArtText(input.subtitle)) : null,
        div({ marginTop: "auto", alignItems: "center", justifyContent: "space-between", width: "100%" }, [ctaPill(input, 30), footerEl(input, onPrimary)]),
      ],
    ),
    techRings(colors.accent, 180, imgH - 150, -40),
  ]);
}

function questionCard(input: ComposeInput): El {
  const { width: W, height: H, colors } = input;
  const pad = Math.round(W * 0.08);
  const title = cleanArtText(input.title);
  const isStory = H / W > 1.6;
  return div(
    {
      position: "relative",
      width: W,
      height: H,
      backgroundImage: `linear-gradient(135deg, ${colors.primary} 0%, ${colors.secondary} 100%)`,
      fontFamily: input.bodyFont,
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
    },
    [
      bgImage(input, H, 0.16),
      techRings("#ffffff", 360, isStory ? 200 : -80, -120),
      div({ position: "absolute", top: isStory ? 250 : pad, left: pad }, logoEl(input.logo, 240, 140)),
      div({ flexDirection: "column", alignItems: "center", padding: `0 ${pad}px`, gap: 34 }, [
        div(
          { width: 120, height: 120, borderRadius: 999, backgroundColor: colors.accent, alignItems: "center", justifyContent: "center", color: readableOn(colors.accent), fontSize: 76, fontWeight: 700, fontFamily: input.headingFont },
          "?",
        ),
        text({ fontSize: titleSize(title, isStory ? 86 : 74), lineHeight: 1.12, fontWeight: 700, color: "#ffffff", textAlign: "center", fontFamily: input.headingFont, justifyContent: "center" }, title),
        input.subtitle ? text({ fontSize: isStory ? 40 : 34, color: "rgba(255,255,255,0.88)", textAlign: "center", justifyContent: "center", lineHeight: 1.3 }, cleanArtText(input.subtitle)) : null,
        input.cta
          ? div({ border: "3px solid rgba(255,255,255,0.8)", borderRadius: 999, padding: "16px 36px", color: "#ffffff", fontSize: isStory ? 36 : 30, fontWeight: 700 }, cleanArtText(input.cta))
          : null,
      ]),
      div({ position: "absolute", bottom: isStory ? 360 : pad * 0.8 }, footerEl(input, "#ffffff")),
    ],
  );
}

function offerLayout(input: ComposeInput): El {
  const { width: W, height: H, colors } = input;
  const o = input.offer!;
  const pad = Math.round(W * 0.066);
  const isStory = H / W > 1.6;
  const imgH = Math.round(H * (isStory ? 0.4 : 0.42));
  const onPrimary = readableOn(colors.primary);
  const check = (label: string) =>
    div({ alignItems: "center", gap: 16 }, [
      div({ width: 30, height: 30, borderRadius: 999, backgroundColor: colors.accent, alignItems: "center", justifyContent: "center" }, div({ width: 10, height: 10, borderRadius: 999, backgroundColor: readableOn(colors.accent) })),
      text({ fontSize: 30, color: onPrimary }, cleanArtText(label)),
    ]);
  return div({ position: "relative", width: W, height: H, backgroundColor: colors.primary, fontFamily: input.bodyFont }, [
    bgImage(input, imgH),
    div({ position: "absolute", top: isStory ? 250 : pad, left: pad }, logoEl(input.logo, 240, 140)),
    div(
      {
        position: "absolute",
        left: 0,
        top: imgH - 48,
        width: W,
        height: H - imgH + 48,
        backgroundColor: colors.primary,
        borderTopLeftRadius: 48,
        borderTopRightRadius: 48,
        padding: `${pad}px ${pad}px ${isStory ? 360 : pad}px ${pad}px`,
        flexDirection: "column",
        gap: 18,
      },
      [
        text({ fontSize: 30, color: colors.accent, fontWeight: 700, letterSpacing: 2 }, cleanArtText(o.operator).toUpperCase()),
        text({ fontSize: titleSize(cleanArtText(input.title), 52), color: onPrimary, fontWeight: 700, fontFamily: input.headingFont, lineHeight: 1.12 }, cleanArtText(input.title)),
        div({ alignItems: "flex-end", gap: 36 }, [
          div({ alignItems: "flex-end", gap: 10 }, [
            text({ fontSize: 132, fontWeight: 700, color: onPrimary, lineHeight: 0.9, fontFamily: input.headingFont, letterSpacing: -3 }, o.speed),
            text({ fontSize: 40, fontWeight: 700, color: colors.accent, paddingBottom: 10 }, "MEGA"),
          ]),
          div({ flexDirection: "column", paddingBottom: 6 }, [
            text({ fontSize: 26, color: rgba(onPrimary === "#ffffff" ? "#ffffff" : "#0b1530", 0.8) }, "por"),
            div({ alignItems: "flex-end", gap: 6 }, [
              text({ fontSize: 62, fontWeight: 700, color: onPrimary, lineHeight: 1 }, o.price),
              text({ fontSize: 28, color: onPrimary, paddingBottom: 6 }, o.period),
            ]),
          ]),
        ]),
        div({ flexDirection: "column", gap: 12, marginTop: 6 }, o.benefits.slice(0, 3).map(check)),
        div({ marginTop: "auto", flexDirection: "column", gap: 16 }, [
          ctaPill(input, 30),
          text({ fontSize: 20, color: rgba(onPrimary === "#ffffff" ? "#ffffff" : "#0b1530", 0.75), lineHeight: 1.3 }, cleanArtText(o.footnote)),
        ]),
      ],
    ),
  ]);
}

function carouselSlide(input: ComposeInput): El {
  const s = input.slide!;
  if (s.kind === "cover") {
    return heroBottom({ ...input, cta: input.cta || "Arraste para o lado" });
  }
  const { width: W, height: H, colors } = input;
  const pad = Math.round(W * 0.08);
  const final = s.kind === "final";
  const bg = final ? colors.primary : colors.background;
  const fg = readableOn(bg);
  const titleColor = final ? fg : colors.primary;
  return div({ position: "relative", width: W, height: H, backgroundColor: bg, fontFamily: input.bodyFont, flexDirection: "column", padding: pad }, [
    techRings(final ? "#ffffff" : colors.primary, 260, -70, -70),
    div({ alignItems: "center", gap: 18 }, [
      div(
        { backgroundColor: colors.accent, color: readableOn(colors.accent), borderRadius: 999, padding: "10px 24px", fontSize: 26, fontWeight: 700 },
        `${String(s.index).padStart(2, "0")}/${String(s.total).padStart(2, "0")}`,
      ),
    ]),
    div({ flexDirection: "column", gap: 34, marginTop: 90 }, [
      text({ fontSize: titleSize(cleanArtText(s.title), 64), fontWeight: 700, color: titleColor, fontFamily: input.headingFont, lineHeight: 1.1, letterSpacing: -0.5 }, cleanArtText(s.title)),
      div({ width: 96, height: 8, borderRadius: 8, backgroundColor: colors.accent }),
      text({ fontSize: 40, color: final ? rgba(fg === "#ffffff" ? "#ffffff" : "#0b1530", 0.9) : colors.text, lineHeight: 1.38 }, cleanArtText(s.body)),
      final ? ctaPill(input, 32) : null,
    ]),
    div({ position: "absolute", left: pad, right: pad, bottom: pad, alignItems: "center", justifyContent: "space-between" }, [
      logoEl(final ? input.logo : input.logoDark ?? input.logo, 140, 110),
      div({ gap: 10 }, Array.from({ length: s.total }, (_, i) =>
        div({ width: i + 1 === s.index ? 36 : 12, height: 12, borderRadius: 999, backgroundColor: i + 1 === s.index ? colors.accent : rgba(final ? "#ffffff" : colors.primary, 0.25) }),
      )),
    ]),
  ]);
}

export function buildLayout(input: ComposeInput): El {
  if (input.slide) return carouselSlide(input);
  switch (input.layout) {
    case "split-panel":
      return splitPanel(input);
    case "question-card":
      return questionCard(input);
    case "offer":
      return input.offer ? offerLayout(input) : heroBottom(input);
    case "story":
    case "hero-bottom":
    default:
      return heroBottom(input);
  }
}
