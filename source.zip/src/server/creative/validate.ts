// Validação pré-publicação: dimensões, proporção, formato, peso, legibilidade e marca.
import { FORMAT_SPEC, MAX_JPEG_BYTES, type CreativeFormat } from "./formats";
import { contrastRatio, hexToRgb } from "./color";

export type ValidationReport = { ok: boolean; errors: string[]; warnings: string[]; checkedAt: string };

export async function validateImage(buf: Buffer, format: CreativeFormat, opts: { hasLogo: boolean; layout: string; lightTextOverImage: boolean }): Promise<ValidationReport> {
  const sharp = (await import("sharp")).default;
  const errors: string[] = [];
  const warnings: string[] = [];
  const spec = FORMAT_SPEC[format];
  const meta = await sharp(buf).metadata();

  if (meta.format !== "jpeg") errors.push(`Formato ${meta.format} — o Instagram exige JPEG.`);
  if (meta.width !== spec.width || meta.height !== spec.height) errors.push(`Dimensões ${meta.width}×${meta.height}; esperado ${spec.width}×${spec.height}.`);
  const ratio = (meta.width ?? 1) / (meta.height ?? 1);
  if (ratio < spec.minRatio - 0.01 || ratio > spec.maxRatio + 0.01) errors.push(`Proporção ${ratio.toFixed(2)} fora do permitido para ${spec.label}.`);
  if (buf.length > MAX_JPEG_BYTES) errors.push(`Arquivo com ${(buf.length / 1048576).toFixed(1)} MB (máx. 8 MB).`);
  if (!opts.hasLogo) warnings.push("Logotipo não cadastrado: a peça saiu sem logotipo oficial.");

  // Legibilidade: contraste médio da faixa onde fica o texto claro sobre foto.
  if (opts.lightTextOverImage) {
    const h = meta.height ?? spec.height;
    const w = meta.width ?? spec.width;
    const top = format === "STORY" ? Math.round(h * 0.45) : Math.round(h * 0.55);
    const height = format === "STORY" ? Math.round(h * 0.35) : h - top;
    const stats = await sharp(buf).extract({ left: 0, top, width: w, height }).stats();
    const mean: [number, number, number] = [stats.channels[0].mean, stats.channels[1].mean, stats.channels[2].mean];
    const cr = contrastRatio(mean, hexToRgb("#ffffff"));
    if (cr < 3) errors.push(`Contraste insuficiente do texto (${cr.toFixed(1)}:1). Recomendo outro fundo ou layout.`);
    else if (cr < 4.5) warnings.push(`Contraste moderado do texto (${cr.toFixed(1)}:1).`);
  }
  return { ok: errors.length === 0, errors, warnings, checkedAt: new Date().toISOString() };
}

export function validateCopy(input: { title?: string | null; captionInstagram?: string | null; captionFacebook?: string | null; hashtags: string[]; maxHashtags: number }): ValidationReport {
  const errors: string[] = [];
  const warnings: string[] = [];
  if (!input.title?.trim()) errors.push("Título ausente.");
  if ((input.title ?? "").length > 80) warnings.push("Título longo: pode perder legibilidade no celular.");
  if ((input.captionInstagram ?? "").length > 2200) errors.push("Legenda do Instagram acima de 2.200 caracteres.");
  if (input.hashtags.length > input.maxHashtags) warnings.push(`Mais de ${input.maxHashtags} hashtags; as excedentes serão removidas.`);
  return { ok: errors.length === 0, errors, warnings, checkedAt: new Date().toISOString() };
}
