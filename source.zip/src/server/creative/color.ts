// Utilitários de cor e contraste (WCAG 2.x).
export function hexToRgb(hex: string): [number, number, number] {
  let h = hex.replace("#", "").trim();
  if (h.length === 3) h = h.split("").map((c) => c + c).join("");
  const n = parseInt(h.slice(0, 6), 16);
  if (Number.isNaN(n)) return [0, 0, 0];
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

export function rgba(hex: string, alpha: number) {
  const [r, g, b] = hexToRgb(hex);
  return `rgba(${r},${g},${b},${alpha})`;
}

export function relativeLuminance([r, g, b]: [number, number, number]) {
  const f = (c: number) => {
    const s = c / 255;
    return s <= 0.03928 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4;
  };
  return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b);
}

export function contrastRatio(a: [number, number, number], b: [number, number, number]) {
  const la = relativeLuminance(a);
  const lb = relativeLuminance(b);
  const [hi, lo] = la > lb ? [la, lb] : [lb, la];
  return (hi + 0.05) / (lo + 0.05);
}

/** Melhor cor de texto (branco ou tinta escura) sobre um fundo. */
export function readableOn(bgHex: string, dark = "#0b1530", light = "#ffffff") {
  const bg = hexToRgb(bgHex);
  return contrastRatio(bg, hexToRgb(light)) >= contrastRatio(bg, hexToRgb(dark)) ? light : dark;
}

export function isHex(s: unknown): s is string {
  return typeof s === "string" && /^#?[0-9a-f]{3}([0-9a-f]{3})?$/i.test(s.trim());
}

export type BrandColors = { primary: string; secondary: string; accent: string; background: string; text: string };

export function normalizeColors(raw: unknown): BrandColors {
  const c = (raw ?? {}) as Record<string, unknown>;
  const pick = (k: string, d: string) => (isHex(c[k]) ? `#${String(c[k]).replace("#", "")}` : d);
  return {
    primary: pick("primary", "#071b45"),
    secondary: pick("secondary", "#0f3a8a"),
    accent: pick("accent", "#1f7bff"),
    background: pick("background", "#f4f7fc"),
    text: pick("text", "#0b1530"),
  };
}
