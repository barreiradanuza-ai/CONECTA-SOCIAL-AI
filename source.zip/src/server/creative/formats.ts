// Especificações de formato (dimensões recomendadas pela Meta para Feed, Stories e Reels).
export type CreativeFormat = "FEED" | "SQUARE" | "STORY";

export const FORMAT_SPEC: Record<CreativeFormat, { width: number; height: number; label: string; minRatio: number; maxRatio: number }> = {
  FEED: { width: 1080, height: 1350, label: "Feed 4:5 (1080×1350)", minRatio: 0.8, maxRatio: 1.91 },
  SQUARE: { width: 1080, height: 1080, label: "Feed 1:1 (1080×1080)", minRatio: 0.8, maxRatio: 1.91 },
  STORY: { width: 1080, height: 1920, label: "Stories/Reels 9:16 (1080×1920)", minRatio: 0.5, maxRatio: 0.6 },
};

export function creativeFormatFor(postFormat: string): CreativeFormat {
  return postFormat === "STORY" || postFormat === "REEL" ? "STORY" : "FEED";
}

export const MAX_JPEG_BYTES = 8 * 1024 * 1024; // limite de imagem do Instagram
