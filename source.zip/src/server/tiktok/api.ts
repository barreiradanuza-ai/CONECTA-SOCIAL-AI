// TikTok — Login Kit (OAuth v2) + Content Posting API (Direct Post).
// Vídeos são enviados por FILE_UPLOAD (não exige domínio verificado).
// Fotos/carrossel usam PULL_FROM_URL e exigem o domínio verificado no app do TikTok.
// Apps ainda não auditados pelo TikTok só podem publicar em modo privado (SELF_ONLY).
import { env } from "@/lib/env";
import { getSecret } from "@/server/integrations";
import { GraphError } from "@/server/meta/graph";

export const TIKTOK_SCOPES = ["user.info.basic", "video.publish"];
const API = "https://open.tiktokapis.com";

export function tiktokRedirectUri() {
  return `${env.appUrl}/api/tiktok/oauth/callback`;
}

export async function tiktokConfig(orgId: string) {
  const [clientKey, clientSecret] = await Promise.all([getSecret(orgId, "TIKTOK_CLIENT_KEY"), getSecret(orgId, "TIKTOK_CLIENT_SECRET")]);
  return clientKey && clientSecret ? { clientKey, clientSecret } : null;
}

export function tiktokAuthUrl(clientKey: string, state: string) {
  const u = new URL("https://www.tiktok.com/v2/auth/authorize/");
  u.searchParams.set("client_key", clientKey);
  u.searchParams.set("scope", TIKTOK_SCOPES.join(","));
  u.searchParams.set("response_type", "code");
  u.searchParams.set("redirect_uri", tiktokRedirectUri());
  u.searchParams.set("state", state);
  return u.toString();
}

/** Erros da API do TikTok convertidos para o formato usado pela fila de publicação. */
export class TikTokError extends GraphError {
  constructor(message: string, status: number, public ttCode?: string, public logId?: string) {
    super(message, status, undefined, undefined, ttCode, logId);
    this.name = "TikTokError";
  }
  override get retryable() {
    if (this.status >= 500 || this.status === 429) return true;
    return ["rate_limit_exceeded", "internal_error", "spam_risk_too_many_pending_share"].includes(this.ttCode ?? "");
  }
  override get authError() {
    return ["access_token_invalid", "scope_not_authorized", "scope_permission_missed", "token_not_authorized_for_specified_scope"].includes(this.ttCode ?? "") || this.status === 401;
  }
}

const FRIENDLY: Record<string, string> = {
  unaudited_client_can_only_post_to_private_accounts: "App do TikTok ainda não auditado: só pode publicar em modo privado.",
  url_ownership_unverified: "Domínio do app não verificado no TikTok (necessário para publicar fotos). Verifique o domínio em developers.tiktok.com.",
  spam_risk_too_many_posts: "O TikTok limitou a quantidade de publicações desta conta hoje. Nova tentativa mais tarde.",
  spam_risk_user_banned_from_posting: "A conta do TikTok está impedida de publicar no momento.",
  privacy_level_option_mismatch: "Nível de privacidade não permitido para esta conta do TikTok.",
  access_token_invalid: "Acesso ao TikTok expirado ou revogado. Reconecte o TikTok.",
  scope_not_authorized: "Permissões do TikTok insuficientes. Reconecte o TikTok e autorize a publicação.",
};

async function readTikTok(res: Response) {
  const text = await res.text();
  let json: any = {};
  try {
    json = text ? JSON.parse(text) : {};
  } catch {
    json = { raw: text };
  }
  const err = json.error;
  // OAuth devolve { error, error_description }; Content API devolve { error: { code, message, log_id } }
  if (typeof err === "string") throw new TikTokError(json.error_description || err, res.status || 400, err, json.log_id);
  if (!res.ok || (err && err.code && err.code !== "ok")) {
    const code = err?.code as string | undefined;
    throw new TikTokError(FRIENDLY[code ?? ""] ?? err?.message ?? `TikTok HTTP ${res.status}`, res.status, code, err?.log_id);
  }
  return json;
}

function tokenResult(j: any) {
  if (!j.access_token) throw new TikTokError("O TikTok não devolveu o token de acesso.", 400);
  const now = Date.now();
  return {
    token: j.access_token as string,
    openId: j.open_id as string,
    expiresAt: new Date(now + Number(j.expires_in ?? 86400) * 1000),
    refreshToken: j.refresh_token as string | undefined,
    refreshExpiresAt: j.refresh_expires_in ? new Date(now + Number(j.refresh_expires_in) * 1000) : null,
    scopes: String(j.scope ?? "")
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean),
  };
}

export async function tiktokExchangeCode(cfg: { clientKey: string; clientSecret: string }, code: string) {
  const body = new URLSearchParams({
    client_key: cfg.clientKey,
    client_secret: cfg.clientSecret,
    code,
    grant_type: "authorization_code",
    redirect_uri: tiktokRedirectUri(),
  });
  const j = await readTikTok(
    await fetch(`${API}/v2/oauth/token/`, { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body, signal: AbortSignal.timeout(30_000) }),
  );
  return tokenResult(j);
}

export async function tiktokRefresh(cfg: { clientKey: string; clientSecret: string }, refreshToken: string) {
  const body = new URLSearchParams({ client_key: cfg.clientKey, client_secret: cfg.clientSecret, grant_type: "refresh_token", refresh_token: refreshToken });
  const j = await readTikTok(
    await fetch(`${API}/v2/oauth/token/`, { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body, signal: AbortSignal.timeout(30_000) }),
  );
  return tokenResult(j);
}

export async function tiktokUser(token: string) {
  const j = await readTikTok(
    await fetch(`${API}/v2/user/info/?fields=open_id,display_name,avatar_url`, { headers: { Authorization: `Bearer ${token}` }, signal: AbortSignal.timeout(20_000) }),
  );
  const u = j.data?.user ?? {};
  return { openId: u.open_id as string, name: (u.display_name as string) || "TikTok", avatar: (u.avatar_url as string) || null };
}

async function postJson(token: string, path: string, payload: unknown) {
  return readTikTok(
    await fetch(`${API}${path}`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json; charset=UTF-8" },
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(60_000),
    }),
  );
}

export type CreatorInfo = {
  privacyOptions: string[];
  commentDisabled: boolean;
  duetDisabled: boolean;
  stitchDisabled: boolean;
  maxVideoSec: number;
  nickname?: string;
};

export async function tiktokCreatorInfo(token: string): Promise<CreatorInfo> {
  const j = await postJson(token, "/v2/post/publish/creator_info/query/", {});
  const d = j.data ?? {};
  return {
    privacyOptions: d.privacy_level_options ?? [],
    commentDisabled: !!d.comment_disabled,
    duetDisabled: !!d.duet_disabled,
    stitchDisabled: !!d.stitch_disabled,
    maxVideoSec: Number(d.max_video_post_duration_sec ?? 600),
    nickname: d.creator_nickname,
  };
}

/** Público quando permitido; o fluxo cai para privado se o app ainda não foi auditado. */
export function pickPrivacy(info: CreatorInfo, forcePrivate: boolean) {
  if (forcePrivate && info.privacyOptions.includes("SELF_ONLY")) return "SELF_ONLY";
  if (info.privacyOptions.includes("PUBLIC_TO_EVERYONE")) return "PUBLIC_TO_EVERYONE";
  return info.privacyOptions[0] ?? "SELF_ONLY";
}

const MB = 1024 * 1024;

/** Inicia o post de vídeo e envia o arquivo. Devolve o publish_id para acompanhar o processamento. */
export async function tiktokPublishVideo(token: string, input: { video: Buffer; caption: string; privacy: string; info: CreatorInfo }) {
  const size = input.video.length;
  // Regras de chunk do TikTok: arquivos até 64 MB vão em uma parte; acima disso, partes de 10 MB (a última absorve o resto).
  const chunkSize = size <= 64 * MB ? size : 10 * MB;
  const total = size <= 64 * MB ? 1 : Math.floor(size / chunkSize);
  const init = await postJson(token, "/v2/post/publish/video/init/", {
    post_info: {
      title: input.caption.slice(0, 2200),
      privacy_level: input.privacy,
      disable_comment: input.info.commentDisabled,
      disable_duet: input.info.duetDisabled,
      disable_stitch: input.info.stitchDisabled,
      video_cover_timestamp_ms: 1000,
    },
    source_info: { source: "FILE_UPLOAD", video_size: size, chunk_size: chunkSize, total_chunk_count: total },
  });
  const publishId = init.data?.publish_id as string;
  const uploadUrl = init.data?.upload_url as string;
  if (!publishId || !uploadUrl) throw new TikTokError("O TikTok não devolveu o endereço de envio do vídeo.", 502);
  for (let i = 0; i < total; i++) {
    const start = i * chunkSize;
    const end = i === total - 1 ? size - 1 : start + chunkSize - 1;
    const part = input.video.subarray(start, end + 1);
    const res = await fetch(uploadUrl, {
      method: "PUT",
      headers: { "Content-Type": "video/mp4", "Content-Length": String(part.length), "Content-Range": `bytes ${start}-${end}/${size}` },
      body: new Uint8Array(part),
      signal: AbortSignal.timeout(5 * 60_000),
    });
    if (!res.ok && res.status !== 206) throw new TikTokError(`Falha ao enviar o vídeo ao TikTok (HTTP ${res.status}).`, res.status >= 500 ? res.status : 502);
  }
  return publishId;
}

/** Post de fotos (1 a 35 imagens) por URL — exige domínio verificado no app do TikTok. */
export async function tiktokPublishPhotos(token: string, input: { urls: string[]; title: string; caption: string; privacy: string; info: CreatorInfo }) {
  const j = await postJson(token, "/v2/post/publish/content/init/", {
    post_info: {
      title: input.title.slice(0, 90),
      description: input.caption.slice(0, 4000),
      privacy_level: input.privacy,
      disable_comment: input.info.commentDisabled,
      auto_add_music: true,
    },
    source_info: { source: "PULL_FROM_URL", photo_cover_index: 0, photo_images: input.urls.slice(0, 35) },
    post_mode: "DIRECT_POST",
    media_type: "PHOTO",
  });
  const publishId = j.data?.publish_id as string;
  if (!publishId) throw new TikTokError("O TikTok não devolveu o identificador da publicação.", 502);
  return publishId;
}

export type TikTokStatus = { state: "done"; postId: string | null } | { state: "processing" } | { state: "failed"; reason: string };

export async function tiktokStatus(token: string, publishId: string): Promise<TikTokStatus> {
  const j = await postJson(token, "/v2/post/publish/status/fetch/", { publish_id: publishId });
  const d = j.data ?? {};
  const status = String(d.status ?? "");
  if (status === "PUBLISH_COMPLETE" || status === "SEND_TO_USER_INBOX") {
    const ids: unknown[] = d.publicaly_available_post_id ?? d.publicly_available_post_id ?? [];
    return { state: "done", postId: ids.length ? String(ids[0]) : null };
  }
  if (status === "FAILED") return { state: "failed", reason: FRIENDLY[d.fail_reason] ?? d.fail_reason ?? "Falha no processamento do TikTok." };
  return { state: "processing" };
}
