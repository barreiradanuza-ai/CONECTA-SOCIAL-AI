import type { SocialAccount } from "@prisma/client";
import { db } from "@/lib/db";
import { decrypt, encrypt } from "@/lib/crypto";
import { notify } from "@/server/notifications";
import { TikTokError, tiktokConfig, tiktokRefresh } from "./api";

/** Token de acesso do TikTok válido (dura 24h): renova com o refresh token quando faltar menos de 1h. */
export async function tiktokAccessToken(a: SocialAccount, opts: { force?: boolean } = {}) {
  const current = decrypt(a.accessTokenEnc);
  const fresh = a.tokenExpiresAt && a.tokenExpiresAt.getTime() - Date.now() > 60 * 60_000;
  if (fresh && !opts.force) return current;
  if (!a.refreshTokenEnc) throw new TikTokError("Acesso ao TikTok expirado. Reconecte o TikTok.", 401, "access_token_invalid");
  const cfg = await tiktokConfig(a.orgId);
  if (!cfg) throw new TikTokError("App do TikTok não configurado em Integrações e chaves.", 400);
  const r = await tiktokRefresh(cfg, decrypt(a.refreshTokenEnc));
  await db.socialAccount.update({
    where: { id: a.id },
    data: {
      accessTokenEnc: encrypt(r.token),
      tokenExpiresAt: r.expiresAt,
      ...(r.refreshToken ? { refreshTokenEnc: encrypt(r.refreshToken), refreshExpiresAt: r.refreshExpiresAt } : {}),
      status: "ACTIVE",
      lastCheckedAt: new Date(),
      lastError: null,
    },
  });
  return r.token;
}

/** Rotina do worker: mantém o token renovado e avisa antes do refresh token (365 dias) vencer. */
export async function checkTikTokAccount(a: SocialAccount) {
  try {
    await tiktokAccessToken(a);
    if (a.refreshExpiresAt && a.refreshExpiresAt.getTime() - Date.now() < 14 * 86400_000) {
      await notify({ orgId: a.orgId, brandId: a.brandId, level: "WARNING", title: `Acesso do TikTok ${a.name} expira em breve`, body: "Reconecte o TikTok para evitar interrupções.", link: "/settings/accounts" });
    }
    await db.socialAccount.update({ where: { id: a.id }, data: { lastCheckedAt: new Date() } });
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    const expired = e instanceof TikTokError && (e.authError || e.status === 400);
    await db.socialAccount.update({ where: { id: a.id }, data: { status: expired ? "EXPIRED" : a.status, lastCheckedAt: new Date(), lastError: msg } });
    if (expired) await notify({ orgId: a.orgId, brandId: a.brandId, level: "ERROR", title: `Reconecte o TikTok ${a.name}`, body: "O acesso ao TikTok expirou. As publicações no TikTok estão pausadas.", link: "/settings/accounts" });
  }
}
