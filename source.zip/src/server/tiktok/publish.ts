import type { PostFormat, SocialAccount } from "@prisma/client";
import { db } from "@/lib/db";
import { getObject, signedMediaUrl } from "@/server/storage";
import { TikTokError, pickPrivacy, tiktokCreatorInfo, tiktokPublishPhotos, tiktokPublishVideo, tiktokStatus, type CreatorInfo } from "./api";

export type TikTokPublishResult = { status: "processing"; containerId: string; privateOnly: boolean } | { status: "published"; externalId: string | null; containerId: string };

/** Envia a publicação ao TikTok. O resultado final chega depois (processamento assíncrono do TikTok). */
export async function publishTikTok(
  token: string,
  input: { postId: string; format: PostFormat; caption: string; title: string | null },
): Promise<TikTokPublishResult> {
  const media = await db.postMedia.findMany({ where: { postId: input.postId }, include: { asset: true }, orderBy: { position: "asc" } });
  const info = await tiktokCreatorInfo(token);

  const send = async (privacy: string, i: CreatorInfo) => {
    if (input.format === "REEL") {
      const video = media.find((m) => m.purpose === "VIDEO");
      if (!video) throw new TikTokError("Reels sem vídeo vinculado: o TikTok só aceita vídeo neste formato.", 400);
      const buf = await getObject(video.asset.storageKey);
      return tiktokPublishVideo(token, { video: buf, caption: input.caption, privacy, info: i });
    }
    const images = input.format === "CAROUSEL" ? media.filter((m) => m.purpose === "SLIDE") : media.filter((m) => m.purpose === "COMPOSED").slice(0, 1);
    if (!images.length) throw new TikTokError("Publicação sem imagem final para o TikTok.", 400);
    const urls = images.map((m) => signedMediaUrl(m.asset.storageKey, 60 * 60 * 6));
    return tiktokPublishPhotos(token, { urls, title: input.title ?? "", caption: input.caption, privacy, info: i });
  };

  let privateOnly = false;
  let publishId: string;
  try {
    publishId = await send(pickPrivacy(info, false), info);
  } catch (e) {
    // App ainda não auditado pelo TikTok: publica em modo privado em vez de falhar
    if (e instanceof TikTokError && e.ttCode === "unaudited_client_can_only_post_to_private_accounts") {
      privateOnly = true;
      publishId = await send("SELF_ONLY", info);
    } else throw e;
  }
  return { status: "processing", containerId: publishId, privateOnly };
}

/** Consulta o andamento de um envio já feito (publish_id). */
export async function tiktokCheck(token: string, publishId: string) {
  return tiktokStatus(token, publishId);
}

export function tiktokAccountLabel(a: SocialAccount | null) {
  return a ? `TikTok ${a.name}` : "TikTok";
}
