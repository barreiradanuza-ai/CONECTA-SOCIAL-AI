// Núcleo determinístico do planejamento editorial: define QUANDO e em QUE FORMATO/PILAR
// publicar. O agente de IA depois define O QUÊ (temas e conteúdo). Módulo puro, testável.
import { addDaysYMD, parseHHmm, zonedParts, zonedTimeToUtc } from "@/lib/time";

export type PillarKey = "EDUCATION" | "ENGAGEMENT" | "AUTHORITY" | "OFFERS" | "INSTITUTIONAL" | "SEASONAL" | "STORYTELLING";
export type FormatKey = "FEED_IMAGE" | "CAROUSEL" | "STORY" | "REEL";
export type NetworkKey = "INSTAGRAM" | "FACEBOOK";

export type PlannerSettings = {
  timezone: string;
  horizonDays: number;
  igFeedPerDay: number;
  fbFeedPerDay: number;
  storiesPerDay: number;
  reelsPerWeek: number;
  carouselsPerWeek: number;
  storiesToFacebook: boolean;
  feedTimes: string[];
  fbOnlyTimes: string[];
  storyTimes: string[];
  reelTimes: string[];
  reelWeekdays: number[];
  pillarWeights: Partial<Record<PillarKey, number>>;
  hasValidOffers: boolean;
  hasReelVideos: boolean;
  personaEnabled?: boolean;
};

export type Slot = {
  scheduledAt: Date;
  dateKey: string;
  format: FormatKey;
  networks: NetworkKey[];
  pillar: PillarKey;
  kind: "feed" | "fb-only" | "story" | "reel";
};

export const DEFAULT_PILLAR_WEIGHTS: Record<PillarKey, number> = {
  EDUCATION: 30,
  ENGAGEMENT: 20,
  AUTHORITY: 20,
  OFFERS: 10,
  INSTITUTIONAL: 10,
  SEASONAL: 10,
  STORYTELLING: 0,
};

/** Distribuição sugerida quando a marca tem um personagem: entretenimento primeiro, venda como consequência. */
export const PERSONA_PILLAR_WEIGHTS: Record<PillarKey, number> = {
  STORYTELLING: 45,
  EDUCATION: 20,
  ENGAGEMENT: 15,
  AUTHORITY: 10,
  OFFERS: 0, // a Conecta Aqui optou por não divulgar ofertas nas redes
  INSTITUTIONAL: 5,
  SEASONAL: 5,
};

/** Round-robin ponderado suave (nginx-style): distribuição estável e sem repetições longas. */
export class PillarPicker {
  private current: Record<string, number> = {};
  private last: PillarKey | null = null;
  constructor(private weights: Record<PillarKey, number>) {
    for (const k of Object.keys(weights)) this.current[k] = 0;
  }
  next(exclude: PillarKey[] = []): PillarKey {
    const entries = (Object.entries(this.weights) as [PillarKey, number][]).filter(([k, w]) => w > 0 && !exclude.includes(k));
    if (!entries.length) return "EDUCATION";
    const total = entries.reduce((s, [, w]) => s + w, 0);
    for (const [k, w] of entries) this.current[k] += w;
    let best = entries[0][0];
    for (const [k] of entries) {
      const better = this.current[k] > this.current[best];
      const tieAvoidRepeat = this.current[k] === this.current[best] && best === this.last;
      if (better || tieAvoidRepeat) best = k;
    }
    this.current[best] -= total;
    this.last = best;
    return best;
  }
}

function effectiveWeights(s: PlannerSettings): Record<PillarKey, number> {
  const w = { ...DEFAULT_PILLAR_WEIGHTS, ...s.pillarWeights } as Record<PillarKey, number>;
  if (!s.hasValidOffers) w.OFFERS = 0; // nunca planejar ofertas sem dados comerciais válidos
  if (!s.personaEnabled) w.STORYTELLING = 0; // sem personagem cadastrado, sem mini-novelas
  return w;
}

/**
 * Gera os slots dos próximos N dias a partir de `from` (inclusive), no fuso da marca.
 * Slots já existentes (mesma data/hora/formato) devem ser filtrados por quem chama.
 */
export function buildSlots(from: Date, s: PlannerSettings): Slot[] {
  const tz = s.timezone;
  const start = zonedParts(from, tz);
  const feedPicker = new PillarPicker(effectiveWeights(s));
  const storyWeights = { ...effectiveWeights(s), ENGAGEMENT: (effectiveWeights(s).ENGAGEMENT || 0) + 20 };
  const storyPicker = new PillarPicker(storyWeights);
  const slots: Slot[] = [];
  let carouselsThisWeek = 0;
  let reelsThisWeek = 0;

  for (let i = 0; i < s.horizonDays; i++) {
    const day = addDaysYMD(start.year, start.month, start.day, i);
    if (day.weekday === 1) {
      carouselsThisWeek = 0;
      reelsThisWeek = 0;
    }
    const dateKey = `${day.y}-${String(day.m).padStart(2, "0")}-${String(day.d).padStart(2, "0")}`;
    const at = (hhmm: string) => {
      const { h, m } = parseHHmm(hhmm);
      return zonedTimeToUtc(day.y, day.m, day.d, h, m, tz);
    };

    // Feed compartilhado (Instagram + Facebook com legendas adaptadas)
    const shared = Math.min(s.igFeedPerDay, s.fbFeedPerDay);
    const igOnly = Math.max(0, s.igFeedPerDay - shared);
    const fbOnly = Math.max(0, s.fbFeedPerDay - shared);
    const feedTimes = s.feedTimes.length ? s.feedTimes : ["12:00"];
    let feedIdx = 0;
    const pushFeed = (networks: NetworkKey[], time: string, kind: Slot["kind"]) => {
      const pillar = feedPicker.next();
      const weekPos = (day.weekday + 6) % 7; // segunda = 0
      const spacing = 7 / Math.max(1, s.carouselsPerWeek);
      const wantsCarousel =
        networks.includes("INSTAGRAM") &&
        s.carouselsPerWeek > 0 &&
        carouselsThisWeek < s.carouselsPerWeek &&
        weekPos >= Math.floor(carouselsThisWeek * spacing) &&
        (pillar === "EDUCATION" || pillar === "AUTHORITY" || pillar === "STORYTELLING");
      if (wantsCarousel) carouselsThisWeek++;
      slots.push({ scheduledAt: at(time), dateKey, format: wantsCarousel ? "CAROUSEL" : "FEED_IMAGE", networks, pillar, kind });
    };
    for (let k = 0; k < shared; k++) pushFeed(["INSTAGRAM", "FACEBOOK"], feedTimes[feedIdx++ % feedTimes.length], "feed");
    for (let k = 0; k < igOnly; k++) pushFeed(["INSTAGRAM"], feedTimes[feedIdx++ % feedTimes.length], "feed");
    const fbTimes = s.fbOnlyTimes.length ? s.fbOnlyTimes : ["18:30"];
    for (let k = 0; k < fbOnly; k++) pushFeed(["FACEBOOK"], fbTimes[k % fbTimes.length], "fb-only");

    // Stories
    const storyTimes = s.storyTimes.slice(0, s.storiesPerDay);
    for (const t of storyTimes) {
      slots.push({
        scheduledAt: at(t),
        dateKey,
        format: "STORY",
        networks: s.storiesToFacebook ? ["INSTAGRAM", "FACEBOOK"] : ["INSTAGRAM"],
        pillar: storyPicker.next(["OFFERS"]),
        kind: "story",
      });
    }

    // Reels: somente quando há vídeos disponíveis na biblioteca (IA de vídeo não é assumida)
    if (s.hasReelVideos && s.reelsPerWeek > 0 && s.reelWeekdays.includes(day.weekday) && reelsThisWeek < s.reelsPerWeek) {
      reelsThisWeek++;
      slots.push({
        scheduledAt: at(s.reelTimes[0] ?? "19:30"),
        dateKey,
        format: "REEL",
        networks: ["INSTAGRAM", "FACEBOOK"],
        pillar: feedPicker.next(["OFFERS"]),
        kind: "reel",
      });
    }
  }
  return slots.filter((x) => x.scheduledAt.getTime() > from.getTime());
}

/** Chave para detectar slot já existente. */
export function slotKey(scheduledAt: Date, format: string) {
  return `${scheduledAt.toISOString().slice(0, 16)}|${format === "CAROUSEL" ? "FEED_IMAGE" : format}`;
}

/** Sugestão de horário a partir do histórico (média de interações por hora). */
export function bestHourFromHistory(
  rows: { hour: number; interactions: number; views: number }[],
  minSamples = 8,
): { hour: number; reason: string } | null {
  if (rows.length < minSamples) return null;
  const byHour = new Map<number, { n: number; rate: number }>();
  for (const r of rows) {
    const rate = r.views > 0 ? r.interactions / r.views : 0;
    const cur = byHour.get(r.hour) ?? { n: 0, rate: 0 };
    byHour.set(r.hour, { n: cur.n + 1, rate: cur.rate + rate });
  }
  const ranked = [...byHour.entries()].filter(([, v]) => v.n >= 2).map(([h, v]) => ({ h, avg: v.rate / v.n, n: v.n })).sort((a, b) => b.avg - a.avg);
  if (!ranked.length) return null;
  const top = ranked[0];
  return {
    hour: top.h,
    reason: `Horário ${String(top.h).padStart(2, "0")}h teve a maior taxa média de interações por visualização (${(top.avg * 100).toFixed(1)}%, ${top.n} publicações). Associação observada, não prova de causa.`,
  };
}

/**
 * Rebalanceia os pilares dos novos slots considerando o que já está planejado/publicado,
 * para que renovações diárias do calendário mantenham a distribuição desejada.
 */
export function rebalancePillars(
  newSlots: Slot[],
  existing: { pillar: PillarKey; kind: "story" | "other" }[],
  weights: Partial<Record<PillarKey, number>>,
  hasValidOffers: boolean,
  personaEnabled = false,
): Slot[] {
  const w = { ...DEFAULT_PILLAR_WEIGHTS, ...weights } as Record<PillarKey, number>;
  if (!hasValidOffers) w.OFFERS = 0;
  if (!personaEnabled) w.STORYTELLING = 0;
  const zero = (): Record<PillarKey, number> => ({ EDUCATION: 0, ENGAGEMENT: 0, AUTHORITY: 0, OFFERS: 0, INSTITUTIONAL: 0, SEASONAL: 0, STORYTELLING: 0 });
  const groups: Record<"story" | "other", Record<PillarKey, number>> = { story: zero(), other: zero() };
  for (const e of existing) groups[e.kind][e.pillar]++;
  const last: Record<string, PillarKey | null> = { story: null, other: null };
  const sorted = [...newSlots].sort((a, b) => a.scheduledAt.getTime() - b.scheduledAt.getTime());
  return sorted.map((slot) => {
    const g = slot.kind === "story" ? "story" : "other";
    const counts = groups[g];
    const ww = { ...w };
    if (g === "story") {
      ww.OFFERS = 0;
      ww.ENGAGEMENT += 20;
    }
    if (slot.kind === "reel") ww.OFFERS = 0;
    const totalW = Object.values(ww).reduce((a, b) => a + b, 0) || 1;
    const total = Object.values(counts).reduce((a, b) => a + b, 0) + 1;
    let best: PillarKey = "EDUCATION";
    let bestDeficit = -Infinity;
    for (const k of Object.keys(ww) as PillarKey[]) {
      if (ww[k] <= 0) continue;
      let deficit = (ww[k] / totalW) * total - counts[k];
      if (k === last[g]) deficit -= 0.75; // evita repetir o mesmo pilar em sequência
      if (deficit > bestDeficit) {
        bestDeficit = deficit;
        best = k;
      }
    }
    counts[best]++;
    last[g] = best;
    // Episódios da mini-novela no feed do Instagram viram carrossel (7 atos)
    const format: FormatKey = best === "STORYTELLING" && slot.format === "FEED_IMAGE" && slot.networks.includes("INSTAGRAM") ? "CAROUSEL" : slot.format;
    return { ...slot, pillar: best, format };
  });
}
