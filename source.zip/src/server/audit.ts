import type { Prisma } from "@prisma/client";
import { db } from "@/lib/db";

export async function audit(
  orgId: string,
  action: string,
  opts: { userId?: string | null; entity?: string; entityId?: string; meta?: Prisma.InputJsonValue } = {},
) {
  try {
    await db.auditLog.create({
      data: { orgId, action, userId: opts.userId ?? null, entity: opts.entity, entityId: opts.entityId, meta: opts.meta },
    });
  } catch (e) {
    console.error("[audit] falha ao registrar", action, e);
  }
}
