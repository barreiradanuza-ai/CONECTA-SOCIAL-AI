import { NextResponse, type NextRequest } from "next/server";
import { SESSION_COOKIE } from "@/lib/session-token";

// Proteção rápida das rotas administrativas: sem cookie de sessão → login.
// A verificação criptográfica completa e a checagem de papel ocorrem no servidor (requireAuth).
const PUBLIC = ["/login", "/setup", "/recuperar", "/brand/", "/r/", "/api/media/", "/api/meta/oauth/callback", "/api/health", "/privacidade", "/_next", "/favicon"];

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  if (PUBLIC.some((p) => pathname.startsWith(p))) return NextResponse.next();
  if (!req.cookies.get(SESSION_COOKIE)?.value) {
    const url = req.nextUrl.clone();
    url.pathname = "/login";
    url.search = "";
    return NextResponse.redirect(url);
  }
  return NextResponse.next();
}

export const config = { matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"] };
