import Link from "next/link";
import { requireBrand } from "@/lib/auth";
import { db } from "@/lib/db";
import { setupStatus } from "@/server/status";
import { getSecret } from "@/server/integrations";
import { trafficSettings, latestSnapshot, dailyTotals, sumTotals, computeAlerts } from "@/server/traffic/service";
import { IntegrationState, StatusBadge, FormatBadge } from "@/components/ui";
import { Kpi, Section, DualBars, LevelBadge } from "@/components/traffic";
import { brl, int, delta } from "@/lib/format";
import { formatDateTime } from "@/lib/time";

export const dynamic = "force-dynamic";

export default async function CentralPage() {
  const { auth, brand } = await requireBrand();
  const now = new Date();
  const since30 = new Date(now.getTime() - 30 * 86400_000);
  const ts = await trafficSettings(brand.id);
  const [status, automation, snap, d14, trafficAi, trafficRecs, postsPending, upcoming, published, snapshots, planTask, contentErr, metaAds] = await Promise.all([
    setupStatus(auth.orgId, brand),
    db.automationSettings.findUnique({ where: { brandId: brand.id } }),
    latestSnapshot(brand.id),
    dailyTotals(brand.id, 14),
    db.trafficAnalysis.findFirst({ where: { brandId: brand.id }, orderBy: { createdAt: "desc" } }),
    db.trafficRecommendation.findMany({ where: { brandId: brand.id, status: "PENDING", level: "APPROVAL" }, orderBy: { createdAt: "desc" }, take: 5 }),
    db.post.findMany({ where: { brandId: brand.id, status: "PENDING_APPROVAL" }, orderBy: { scheduledAt: "asc" }, take: 5 }),
    db.post.findMany({ where: { brandId: brand.id, scheduledAt: { gte: now }, status: { notIn: ["CANCELED", "FAILED"] } }, orderBy: { scheduledAt: "asc" }, take: 6 }),
    db.postTarget.count({ where: { post: { brandId: brand.id }, status: "PUBLISHED", publishedAt: { gte: since30 } } }),
    db.metricSnapshot.findMany({ where: { target: { post: { brandId: brand.id }, publishedAt: { gte: since30 } } }, orderBy: { collectedAt: "desc" }, select: { targetId: true, views: true, interactions: true } }),
    db.taskState.findUnique({ where: { name: "autopilot.plan" } }),
    db.notification.findFirst({ where: { brandId: brand.id, title: "Falha no planejamento automático", createdAt: { gte: new Date(now.getTime() - 24 * 3600_000) } }, orderBy: { createdAt: "desc" } }),
    getSecret(auth.orgId, "META_ADS_ACCESS_TOKEN").then((v) => v || process.env.META_ACCESS_TOKEN),
  ]);

  const cur = sumTotals(d14.slice(-7));
  const prev = sumTotals(d14.slice(0, 7));
  const cap = ts.dailyCapCents / 100;
  const latest = new Map<string, { views: number | null; interactions: number | null }>();
  for (const s of snapshots) if (!latest.has(s.targetId)) latest.set(s.targetId, s);
  const views = [...latest.values()].reduce((a, b) => a + (b.views ?? 0), 0);
  const interactions = [...latest.values()].reduce((a, b) => a + (b.interactions ?? 0), 0);
  const alerts = snap ? computeAlerts(snap, cap).filter((a) => a.level === "alto") : [];
  const todo = trafficRecs.length + postsPending.length + alerts.length;
  const fmtDay = (d: string) => `${d.slice(8, 10)}/${d.slice(5, 7)}`;
  const hour = Number(now.toLocaleString("en-US", { hour: "numeric", hour12: false, timeZone: brand.timezone }));
  const hello = hour < 12 ? "Bom dia" : hour < 18 ? "Boa tarde" : "Boa noite";

  return (
    <div>
      <div className="mb-6 overflow-hidden rounded-3xl bg-gradient-to-r from-navy via-navy-600 to-accent p-6 text-white shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="text-[11px] font-bold uppercase tracking-[0.2em] text-cyan">Central de Performance · {brand.name}</div>
            <h1 className="mt-1 text-2xl font-bold">{hello}, {auth.user.name.split(" ")[0]}</h1>
            <p className="mt-1 text-sm text-white/80">
              {todo ? <>Você tem <strong className="text-white">{todo} item(ns)</strong> precisando de atenção.</> : "Nada pendente agora. As duas IAs seguem monitorando."}
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Link href="/studio/content" className="btn bg-white text-navy hover:bg-white/90">Criar conteúdo</Link>
            <Link href="/traffic" className="btn border border-white/40 text-white hover:bg-white/10">Ver tráfego</Link>
          </div>
        </div>
      </div>

      <div className="mb-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
        <Kpi tone="navy" label="Investimento 7d" value={snap ? brl(cur.spend) : "—"} change={snap ? delta(cur.spend, prev.spend) : null} hint={snap ? `hoje ${brl(snap.today.spend)} de ${brl(cap)}` : "Meta Ads não conectado"} />
        <Kpi label="Conversas 7d" value={snap ? int(cur.conversations) : "—"} change={snap ? delta(cur.conversations, prev.conversations) : null} hint="WhatsApp" />
        <Kpi label="Custo por conversa" value={snap ? brl(cur.cpl) : "—"} change={snap ? delta(cur.cpl, prev.cpl) : null} goodWhen="down" />
        <Kpi label="Vendas" value="—" hint="aguardando CRM" />
        <Kpi label="Posts publicados 30d" value={int(published)} hint={`${int(views)} visualizações`} />
        <Kpi label="Interações 30d" value={int(interactions)} hint="orgânico" />
      </div>

      <div className="mb-6 grid gap-6 lg:grid-cols-2">
        <section className="card overflow-hidden">
          <div className="flex items-center justify-between bg-navy px-5 py-3 text-white">
            <div className="flex items-center gap-2 font-semibold"><span className="h-2 w-2 rounded-full bg-cyan" /> IA gestora de tráfego</div>
            <Link href="/traffic/ai" className="text-xs font-semibold text-cyan">Abrir →</Link>
          </div>
          <div className="p-5">
            {trafficAi?.error ? (
              <p className="rounded-lg bg-red-50 p-3 text-sm text-red-800">Última análise falhou: {trafficAi.error.slice(0, 220)}</p>
            ) : trafficAi ? (
              <p className="text-sm leading-relaxed text-ink-soft">{trafficAi.diagnosis}</p>
            ) : (
              <p className="text-sm text-ink-soft">Aguardando a primeira análise{!metaAds ? " (falta o token do Meta Ads)" : ""}.</p>
            )}
            {trafficAi && <p className="mt-2 text-xs text-ink-mute">{formatDateTime(trafficAi.createdAt, brand.timezone)} · a cada {ts.aiEveryHours}h</p>}
            {trafficAi?.contentBrief && (
              <div className="mt-4 rounded-xl bg-cyan-soft p-3 text-xs text-navy">
                <strong>Enviado à IA de conteúdo:</strong> {trafficAi.contentBrief}
              </div>
            )}
          </div>
        </section>

        <section className="card overflow-hidden">
          <div className="flex items-center justify-between bg-accent px-5 py-3 text-white">
            <div className="flex items-center gap-2 font-semibold"><span className="h-2 w-2 rounded-full bg-white" /> IA de conteúdo (social media)</div>
            <Link href="/calendar" className="text-xs font-semibold text-white/90">Abrir →</Link>
          </div>
          <div className="p-5 text-sm">
            <p className="text-ink-soft">
              Piloto automático{" "}
              {automation?.autopilotEnabled ? <strong className="text-emerald-700">ativo ({automation.mode === "AUTOMATIC" ? "automático" : "com aprovação"})</strong> : <strong>desligado</strong>}
              {planTask?.lastRunAt && <> · último planejamento {formatDateTime(planTask.lastRunAt, brand.timezone)}</>}
            </p>
            {contentErr && <p className="mt-3 rounded-lg bg-red-50 p-3 text-red-800">{contentErr.body?.includes("credit balance") ? "Sem crédito na Anthropic: a IA de conteúdo está parada até a recarga." : contentErr.body?.slice(0, 220)}</p>}
            <div className="mt-4">
              <div className="mb-2 text-xs font-semibold uppercase tracking-wide text-ink-mute">Próximas publicações</div>
              {upcoming.length === 0 ? (
                <p className="text-ink-soft">Nada agendado.</p>
              ) : (
                <ul className="divide-y divide-slate-100">
                  {upcoming.map((p) => (
                    <li key={p.id} className="flex items-center gap-2 py-2">
                      <span className="w-28 shrink-0 text-xs text-ink-mute">{formatDateTime(p.scheduledAt, brand.timezone)}</span>
                      <Link href={`/posts/${p.id}`} className="min-w-0 flex-1 truncate font-medium hover:text-accent">{p.title ?? p.theme}</Link>
                      <FormatBadge format={p.format} />
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </section>
      </div>

      <div className="mb-6 grid gap-6 lg:grid-cols-3">
        <Section title="Precisa de você" subtitle="Aprovações e alertas críticos" className="lg:col-span-1">
          {todo === 0 ? (
            <p className="text-sm text-ink-soft">Tudo em dia.</p>
          ) : (
            <ul className="space-y-2 text-sm">
              {alerts.map((a) => (
                <li key={a.key}><Link href="/traffic" className="block rounded-xl bg-red-50 p-3 text-red-900"><strong>{a.subject}</strong><span className="block text-xs">{a.text}</span></Link></li>
              ))}
              {trafficRecs.map((r) => (
                <li key={r.id}><Link href="/traffic/ai" className="block rounded-xl bg-amber-50 p-3"><div className="mb-1"><LevelBadge level={r.level} /></div><strong>{r.title}</strong></Link></li>
              ))}
              {postsPending.map((p) => (
                <li key={p.id}><Link href={`/posts/${p.id}`} className="flex items-center justify-between gap-2 rounded-xl bg-slate-50 p-3"><span className="truncate"><strong>Aprovar post:</strong> {p.title ?? p.theme}</span><StatusBadge status={p.status} /></Link></li>
              ))}
            </ul>
          )}
        </Section>
        <Section title="Tráfego — últimos 14 dias" subtitle="Investimento × conversas" className="lg:col-span-2">
          {snap ? <DualBars data={d14.map((d) => ({ label: fmtDay(d.date), a: d.spend, b: d.conversations }))} a={{ name: "Investimento", fmt: brl }} b={{ name: "Conversas", fmt: (v) => int(v) }} /> : <p className="text-sm text-ink-soft">Conecte o Meta Ads em Tráfego → Configuração.</p>}
        </Section>
      </div>

      <Section title="Saúde da operação">
        <ul className="grid gap-3 text-sm sm:grid-cols-2 lg:grid-cols-4">
          {[
            ["Meta Ads (tráfego)", metaAds ? (ts.lastSyncError ? "error" : "ok") : "missing"],
            ["Claude (as duas IAs)", status.integrations.anthropic],
            ["OpenAI (imagens)", status.integrations.openai],
            ["Instagram", status.integrations.instagram],
            ["Facebook", status.integrations.facebook],
            ["Worker de automação", status.integrations.worker],
          ].map(([k, v]) => (
            <li key={k} className="flex items-center justify-between rounded-xl border border-slate-200 p-3"><span>{k}</span><IntegrationState state={v as "ok" | "missing" | "error"} /></li>
          ))}
          <li className="flex items-center justify-between rounded-xl border border-slate-200 p-3"><span>CRM (Data Crazy)</span><IntegrationState state="pending" /></li>
        </ul>
      </Section>
    </div>
  );
}
