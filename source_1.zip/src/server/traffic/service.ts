// Gestor de tráfego: sincronização, alertas, decisões e execução segura.
import type { Prisma, TrafficSettings } from "@prisma/client";
import { db } from "@/lib/db";
import { notify } from "@/server/notifications";
import { audit } from "@/server/audit";
import { validOffers } from "@/server/brand";
import { adsToken, fetchAccount, fetchDaily, isoDay, readObject, setCampaignDailyBudget, setStatus, type AccountSnapshot } from "./meta";

export async function trafficSettings(brandId: string): Promise<TrafficSettings> {
  const envAccounts = (process.env.META_AD_ACCOUNT_IDS ?? "").split(",").map((s) => s.trim().replace(/^act_/, "")).filter(Boolean);
  return db.trafficSettings.upsert({ where: { brandId }, create: { brandId, accountIds: envAccounts }, update: {} });
}

export async function latestSnapshot(brandId: string): Promise<(AccountSnapshot & { id: string }) | null> {
  const s = await db.trafficSnapshot.findFirst({ where: { brandId }, orderBy: { collectedAt: "desc" } });
  return s ? { ...(s.data as unknown as AccountSnapshot), id: s.id } : null;
}

// ───────────── Alertas objetivos (regras fixas, sem opinião) ─────────────

export type TrafficAlert = { key: string; level: "alto" | "medio" | "info"; subject: string; text: string; campaignId?: string };

export function computeAlerts(snap: AccountSnapshot, capReais: number): TrafficAlert[] {
  const out: TrafficAlert[] = [];
  for (const c of snap.campaigns) {
    const active = c.status === "ACTIVE";
    if (active && c.spend >= 50 && !c.conversations) out.push({ key: `semconv:${c.id}`, level: "alto", subject: c.name, campaignId: c.id, text: `R$ ${c.spend.toFixed(2)} gastos e nenhuma conversa iniciada.` });
    if (active && c.frequency != null && c.frequency >= 3) out.push({ key: `freq:${c.id}`, level: "medio", subject: c.name, campaignId: c.id, text: `Frequência ${c.frequency.toFixed(2)}: possível fadiga do público/criativo.` });
    if (active && (c.impressions ?? 0) >= 1000 && c.ctr != null && c.ctr < 0.8) out.push({ key: `ctr:${c.id}`, level: "medio", subject: c.name, campaignId: c.id, text: `CTR ${c.ctr.toFixed(2)}% abaixo de 0,8% com ${c.impressions} impressões.` });
  }
  for (const a of snap.ads) {
    if (["DISAPPROVED", "WITH_ISSUES"].includes(a.status)) out.push({ key: `reprov:${a.id}`, level: "alto", subject: a.name, campaignId: a.campaignId, text: `${a.status === "DISAPPROVED" ? "Anúncio REPROVADO" : "Anúncio com problemas"}${a.reviewNote ? `: ${a.reviewNote}` : "."}` });
  }
  const t = snap.today;
  if (capReais > 0) {
    const p = t.spend / capReais;
    if (p >= 1) out.push({ key: `pacing100:${t.date}`, level: "alto", subject: "Orçamento do dia", text: `Gasto de hoje R$ ${t.spend.toFixed(2)} atingiu o teto de R$ ${capReais.toFixed(2)}.` });
    else if (p >= 0.9) out.push({ key: `pacing90:${t.date}`, level: "medio", subject: "Orçamento do dia", text: `Gasto de hoje R$ ${t.spend.toFixed(2)} = ${(p * 100).toFixed(0)}% do teto.` });
    if (t.activeBudget > capReais) out.push({ key: `orc:${Math.round(t.activeBudget)}`, level: "alto", subject: "Orçamento ativo", text: `Orçamentos diários ativos somam R$ ${t.activeBudget.toFixed(2)}, acima do teto de R$ ${capReais.toFixed(2)}.` });
  }
  return out;
}

async function pushNewAlerts(orgId: string, brandId: string, alerts: TrafficAlert[]) {
  const since = new Date(Date.now() - 24 * 3600_000);
  for (const a of alerts.filter((x) => x.level !== "info")) {
    const title = `Tráfego: ${a.subject}`;
    const dup = await db.notification.findFirst({ where: { orgId, brandId, title, body: a.text, createdAt: { gte: since } } });
    if (dup) continue;
    await notify({ orgId, brandId, level: a.level === "alto" ? "ERROR" : "WARNING", title, body: a.text, link: "/traffic" });
  }
}

// ───────────── Sincronização ─────────────

export async function syncBrand(brandId: string) {
  const brand = await db.brand.findUniqueOrThrow({ where: { id: brandId } });
  const s = await trafficSettings(brandId);
  if (!s.accountIds.length) return "sem conta de anúncio configurada";
  try {
    const token = await adsToken(brand.orgId);
    const snap = await fetchAccount(token, s.accountIds, s.sinceDate);
    const daily = await fetchDaily(token, s.accountIds, 35, s.sinceDate).catch((e) => {
      snap.warnings.push(`Série diária indisponível: ${e instanceof Error ? e.message : e}`);
      return [];
    });
    await db.trafficSnapshot.create({ data: { brandId, data: snap as unknown as Prisma.InputJsonValue } });
    for (const d of daily) {
      await db.trafficDaily.upsert({
        where: { brandId_date_campaignId: { brandId, date: d.date, campaignId: d.campaignId } },
        create: { brandId, ...d },
        update: { campaignName: d.campaignName, spend: d.spend, impressions: d.impressions, clicks: d.clicks, conversations: d.conversations },
      });
    }
    // mantém as 60 fotografias mais recentes
    const old = await db.trafficSnapshot.findMany({ where: { brandId }, orderBy: { collectedAt: "desc" }, skip: 60, select: { id: true } });
    if (old.length) await db.trafficSnapshot.deleteMany({ where: { id: { in: old.map((o) => o.id) } } });
    await db.trafficSettings.update({ where: { brandId }, data: { lastSyncAt: new Date(), lastSyncError: null } });
    await pushNewAlerts(brand.orgId, brandId, computeAlerts(snap, s.dailyCapCents / 100));
    return `${brand.name}: ${snap.campaigns.length} campanhas, ${snap.ads.length} anúncios`;
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    await db.trafficSettings.update({ where: { brandId }, data: { lastSyncError: msg.slice(0, 1000) } });
    throw e;
  }
}

export async function syncAll() {
  const list = await db.trafficSettings.findMany({ where: { NOT: { accountIds: { isEmpty: true } }, brand: { isActive: true } } });
  const out: string[] = [];
  for (const s of list) {
    try {
      out.push(await syncBrand(s.brandId));
    } catch (e) {
      out.push(`erro: ${e instanceof Error ? e.message : e}`);
    }
  }
  return out.join("; ") || "nenhuma marca com conta de anúncio";
}

// ───────────── Séries para o painel ─────────────

export type DayTotal = { date: string; spend: number; impressions: number; clicks: number; conversations: number };

export async function dailyTotals(brandId: string, days: number): Promise<DayTotal[]> {
  const start = isoDay(new Date(Date.now() - (days - 1) * 86400_000));
  const rows = await db.trafficDaily.findMany({ where: { brandId, date: { gte: start } }, orderBy: { date: "asc" } });
  const map = new Map<string, DayTotal>();
  for (let i = days - 1; i >= 0; i--) {
    const d = isoDay(new Date(Date.now() - i * 86400_000));
    map.set(d, { date: d, spend: 0, impressions: 0, clicks: 0, conversations: 0 });
  }
  for (const r of rows) {
    const t = map.get(r.date);
    if (!t) continue;
    t.spend += r.spend;
    t.impressions += r.impressions;
    t.clicks += r.clicks;
    t.conversations += r.conversations;
  }
  return [...map.values()];
}

export function sumTotals(list: DayTotal[]) {
  const t = list.reduce((a, b) => ({ spend: a.spend + b.spend, impressions: a.impressions + b.impressions, clicks: a.clicks + b.clicks, conversations: a.conversations + b.conversations }), { spend: 0, impressions: 0, clicks: 0, conversations: 0 });
  return { ...t, ctr: t.impressions ? (t.clicks / t.impressions) * 100 : null, cpc: t.clicks ? t.spend / t.clicks : null, cpm: t.impressions ? (t.spend / t.impressions) * 1000 : null, cpl: t.conversations ? t.spend / t.conversations : null };
}

// ───────────── Decisão e execução ─────────────

export const EXECUTABLE = ["PAUSE_AD", "PAUSE_CAMPAIGN", "ACTIVATE_AD", "SET_CAMPAIGN_BUDGET", "NEW_CREATIVE"];

export async function executeRecommendation(recId: string, actor: { userId?: string | null; label: string }) {
  const rec = await db.trafficRecommendation.findUniqueOrThrow({ where: { id: recId }, include: { brand: true } });
  if (rec.level === "BLOCKED") throw new Error("Recomendação bloqueada: não pode ser executada pelo sistema.");
  if (!EXECUTABLE.includes(rec.actionType)) throw new Error("Esta recomendação é manual: execute no Gerenciador de Anúncios e marque como feita.");
  const brand = rec.brand;
  let result = "";
  try {
    if (rec.actionType === "NEW_CREATIVE") {
      const offers = await validOffers(brand.id);
      const offer = offers[0];
      const post = await db.post.create({
        data: {
          orgId: brand.orgId,
          brandId: brand.id,
          pillar: offer ? "OFFERS" : "AUTHORITY",
          format: "FEED_IMAGE",
          theme: rec.action.slice(0, 300),
          objective: "Novo criativo para anúncio (pedido pela IA de tráfego)",
          offerId: offer?.id ?? null,
          scheduledAt: new Date(Date.now() + 2 * 86400_000),
          timeReason: "Criativo solicitado pelo gestor de tráfego.",
          approvalRequired: true,
          approvalReasons: ["Criativo pedido pela IA de tráfego"],
          origin: "AI",
          status: "PLANNED",
          targets: { create: [{ network: "INSTAGRAM" }] },
        },
      });
      result = `Briefing enviado ao AI Creative Studio (publicação ${post.id}). Aguarda produção e aprovação.`;
    } else {
      if (!rec.targetId) throw new Error("Recomendação sem objeto alvo (id).");
      const token = await adsToken(brand.orgId);
      if (rec.actionType === "PAUSE_AD" || rec.actionType === "PAUSE_CAMPAIGN") {
        await setStatus(token, rec.targetId, "PAUSED");
        const after = await readObject(token, rec.targetId, "effective_status");
        result = `Pausado. Status atual na Meta: ${after.effective_status}.`;
      } else if (rec.actionType === "ACTIVATE_AD") {
        await setStatus(token, rec.targetId, "ACTIVE");
        const after = await readObject(token, rec.targetId, "effective_status");
        result = `Ativado. Status atual na Meta: ${after.effective_status}.`;
      } else if (rec.actionType === "SET_CAMPAIGN_BUDGET") {
        const value = rec.value ?? 0;
        if (value <= 0) throw new Error("Valor de orçamento inválido.");
        const s = await trafficSettings(brand.id);
        const snap = await latestSnapshot(brand.id);
        const current = await readObject(token, rec.targetId, "daily_budget,effective_status");
        if (!current.daily_budget) throw new Error("Campanha sem orçamento no nível da campanha (CBO). Ajuste no conjunto pelo Gerenciador.");
        const others = (snap?.campaigns ?? []).filter((c) => c.id !== rec.targetId && c.status === "ACTIVE").reduce((t, c) => t + (c.dailyBudget ?? 0), 0);
        const cap = s.dailyCapCents / 100;
        if (others + value > cap) throw new Error(`Bloqueado: o total ficaria em R$ ${(others + value).toFixed(2)}, acima do teto de R$ ${cap.toFixed(2)}.`);
        await setCampaignDailyBudget(token, rec.targetId, value);
        const after = await readObject(token, rec.targetId, "daily_budget");
        result = `Orçamento diário alterado de R$ ${(Number(current.daily_budget) / 100).toFixed(2)} para R$ ${(Number(after.daily_budget) / 100).toFixed(2)} (confirmado na Meta).`;
      }
    }
    await db.trafficRecommendation.update({ where: { id: rec.id }, data: { status: "EXECUTED", executedAt: new Date(), result } });
    await audit(brand.orgId, "traffic.execute", { userId: actor.userId ?? null, entity: "TrafficRecommendation", entityId: rec.id, meta: { actionType: rec.actionType, targetId: rec.targetId, value: rec.value, by: actor.label, result } });
    return result;
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    await db.trafficRecommendation.update({ where: { id: rec.id }, data: { status: "FAILED", result: msg.slice(0, 1000) } });
    await audit(brand.orgId, "traffic.execute_failed", { userId: actor.userId ?? null, entity: "TrafficRecommendation", entityId: rec.id, meta: { error: msg } });
    throw e;
  }
}
